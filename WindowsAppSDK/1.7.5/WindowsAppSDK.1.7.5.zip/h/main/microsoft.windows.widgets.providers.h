
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

/* verify that the <rpcsal.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCSAL_H_VERSION__
#define __REQUIRED_RPCSAL_H_VERSION__ 100
#endif

#include <rpc.h>
#include <rpcndr.h>

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include <windows.h>
#include <ole2.h>
#endif /*COM_NO_WINDOWS_H*/
#ifndef __microsoft2Ewindows2Ewidgets2Eproviders_h__
#define __microsoft2Ewindows2Ewidgets2Eproviders_h__
#ifndef __microsoft2Ewindows2Ewidgets2Eproviders_p_h__
#define __microsoft2Ewindows2Ewidgets2Eproviders_p_h__


#pragma once

//
// Deprecated attribute support
//

#pragma push_macro("DEPRECATED")
#undef DEPRECATED

#if !defined(DISABLE_WINRT_DEPRECATION)
#if defined(__cplusplus)
#if __cplusplus >= 201402
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#elif defined(_MSC_VER)
#if _MSC_VER >= 1900
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#else
#define DEPRECATED(x) __declspec(deprecated(x))
#define DEPRECATEDENUMERATOR(x)
#endif // _MSC_VER >= 1900
#else // Not Standard C++ or MSVC, ignore the construct.
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  // C++ deprecation
#else // C - disable deprecation
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif
#else // Deprecation is disabled
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  /* DEPRECATED */

// Disable Deprecation for this header, MIDL verifies that cross-type access is acceptable
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#else
#pragma warning(push)
#pragma warning(disable: 4996)
#endif

// Ensure that the setting of the /ns_prefix command line switch is consistent for all headers.
// If you get an error from the compiler indicating "warning C4005: 'CHECK_NS_PREFIX_STATE': macro redefinition", this
// indicates that you have included two different headers with different settings for the /ns_prefix MIDL command line switch
#if !defined(DISABLE_NS_PREFIX_CHECKS)
#define CHECK_NS_PREFIX_STATE "always"
#endif // !defined(DISABLE_NS_PREFIX_CHECKS)


#pragma push_macro("MIDL_CONST_ID")
#undef MIDL_CONST_ID
#define MIDL_CONST_ID const __declspec(selectany)


//  API Contract Inclusion Definitions
#if !defined(SPECIFIC_API_CONTRACT_DEFINITIONS)
#if !defined(MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION)
#define MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION 0xb0000
#endif // defined(MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION 0x50000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION)
#define WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION)
#define WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION)
#define WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION)
#define WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION 0x60000
#endif // defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION)
#define WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)
#define WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)
#define WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION 0x130000
#endif // defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)

#if !defined(WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION)
#define WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION)

#if !defined(WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION)
#define WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION)
#define WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION)
#define WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION)
#define WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION)
#define WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)
#define WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)
#define WINDOWS_PHONE_PHONECONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)
#define WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)

#if !defined(WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION)
#define WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION 0x50000
#endif // defined(WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION)

#if !defined(WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION)
#define WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION)

#if !defined(WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION)
#define WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION)

#if !defined(WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION)
#define WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION)

#if !defined(WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION)
#define WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION)

#if !defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)
#define WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)

#endif // defined(SPECIFIC_API_CONTRACT_DEFINITIONS)


// Header files for imported files
#include "inspectable.h"
#include "AsyncInfo.h"
#include "EventToken.h"
#include "windowscontracts.h"
#include "Windows.Foundation.h"
#include "Microsoft.Windows.Widgets.h"
#include "Windows.Storage.Streams.h"
// Importing Collections header
#include <windows.foundation.collections.h>

#if defined(__cplusplus) && !defined(CINTERFACE)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetActionInvokedArgs;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs ABI::Microsoft::Windows::Widgets::Providers::IWidgetActionInvokedArgs

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetAnalyticsInfoReportedArgs;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs ABI::Microsoft::Windows::Widgets::Providers::IWidgetAnalyticsInfoReportedArgs

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetContext;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext ABI::Microsoft::Windows::Widgets::Providers::IWidgetContext

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetContextChangedArgs;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs ABI::Microsoft::Windows::Widgets::Providers::IWidgetContextChangedArgs

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetCustomizationRequestedArgs;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs ABI::Microsoft::Windows::Widgets::Providers::IWidgetCustomizationRequestedArgs

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetErrorInfoReportedArgs;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs ABI::Microsoft::Windows::Widgets::Providers::IWidgetErrorInfoReportedArgs

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetInfo;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo ABI::Microsoft::Windows::Widgets::Providers::IWidgetInfo

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetInfo2;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2 ABI::Microsoft::Windows::Widgets::Providers::IWidgetInfo2

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetInfo3;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3 ABI::Microsoft::Windows::Widgets::Providers::IWidgetInfo3

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetManager;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager ABI::Microsoft::Windows::Widgets::Providers::IWidgetManager

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetManager2;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2 ABI::Microsoft::Windows::Widgets::Providers::IWidgetManager2

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetManagerStatics;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics ABI::Microsoft::Windows::Widgets::Providers::IWidgetManagerStatics

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetMessageReceivedArgs;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs ABI::Microsoft::Windows::Widgets::Providers::IWidgetMessageReceivedArgs

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetProvider;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider ABI::Microsoft::Windows::Widgets::Providers::IWidgetProvider

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetProvider2;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2 ABI::Microsoft::Windows::Widgets::Providers::IWidgetProvider2

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetProviderAnalytics;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics ABI::Microsoft::Windows::Widgets::Providers::IWidgetProviderAnalytics

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetProviderErrors;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors ABI::Microsoft::Windows::Widgets::Providers::IWidgetProviderErrors

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetProviderMessage;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage ABI::Microsoft::Windows::Widgets::Providers::IWidgetProviderMessage

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetResourceProvider;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider ABI::Microsoft::Windows::Widgets::Providers::IWidgetResourceProvider

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetResourceRequest;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest ABI::Microsoft::Windows::Widgets::Providers::IWidgetResourceRequest

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetResourceRequestedArgs;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs ABI::Microsoft::Windows::Widgets::Providers::IWidgetResourceRequestedArgs

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetResourceResponse;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse ABI::Microsoft::Windows::Widgets::Providers::IWidgetResourceResponse

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetResourceResponseFactory;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory ABI::Microsoft::Windows::Widgets::Providers::IWidgetResourceResponseFactory

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetUpdateRequestOptions;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions ABI::Microsoft::Windows::Widgets::Providers::IWidgetUpdateRequestOptions

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetUpdateRequestOptions2;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2 ABI::Microsoft::Windows::Widgets::Providers::IWidgetUpdateRequestOptions2

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetUpdateRequestOptions3;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3 ABI::Microsoft::Windows::Widgets::Providers::IWidgetUpdateRequestOptions3

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetUpdateRequestOptionsFactory;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory ABI::Microsoft::Windows::Widgets::Providers::IWidgetUpdateRequestOptionsFactory

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    interface IWidgetUpdateRequestOptionsStatics;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics ABI::Microsoft::Windows::Widgets::Providers::IWidgetUpdateRequestOptionsStatics

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_FWD_DEFINED__

// Parameterized interface forward declarations (C++)

// Collection interface definitions

#ifndef DEF___FIKeyValuePair_2_HSTRING_HSTRING_USE
#define DEF___FIKeyValuePair_2_HSTRING_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("60310303-49c5-52e6-abc6-a9b36eccc716"))
IKeyValuePair<HSTRING,HSTRING> : IKeyValuePair_impl<HSTRING,HSTRING> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IKeyValuePair`2<String, String>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IKeyValuePair<HSTRING,HSTRING> __FIKeyValuePair_2_HSTRING_HSTRING_t;
#define __FIKeyValuePair_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::__FIKeyValuePair_2_HSTRING_HSTRING_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIKeyValuePair_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::IKeyValuePair<HSTRING,HSTRING>
//#define __FIKeyValuePair_2_HSTRING_HSTRING_t ABI::Windows::Foundation::Collections::IKeyValuePair<HSTRING,HSTRING>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIKeyValuePair_2_HSTRING_HSTRING_USE */





#ifndef DEF___FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_USE
#define DEF___FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("05eb86f1-7140-5517-b88d-cbaebe57e6b1"))
IIterator<__FIKeyValuePair_2_HSTRING_HSTRING*> : IIterator_impl<__FIKeyValuePair_2_HSTRING_HSTRING*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String, String>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterator<__FIKeyValuePair_2_HSTRING_HSTRING*> __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_t;
#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::__FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Foundation::Collections::IKeyValuePair<HSTRING,HSTRING>*>
//#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_t ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Foundation::Collections::IKeyValuePair<HSTRING,HSTRING>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_USE */





#ifndef DEF___FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_USE
#define DEF___FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("e9bdaaf0-cbf6-5c72-be90-29cbf3a1319b"))
IIterable<__FIKeyValuePair_2_HSTRING_HSTRING*> : IIterable_impl<__FIKeyValuePair_2_HSTRING_HSTRING*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String, String>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterable<__FIKeyValuePair_2_HSTRING_HSTRING*> __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_t;
#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::__FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Foundation::Collections::IKeyValuePair<HSTRING,HSTRING>*>
//#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_t ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Foundation::Collections::IKeyValuePair<HSTRING,HSTRING>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_USE */




#ifndef DEF___FIMapView_2_HSTRING_HSTRING_USE
#define DEF___FIMapView_2_HSTRING_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("ac7f26f2-feb7-5b2a-8ac4-345bc62caede"))
IMapView<HSTRING,HSTRING> : IMapView_impl<HSTRING,HSTRING> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IMapView`2<String, String>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IMapView<HSTRING,HSTRING> __FIMapView_2_HSTRING_HSTRING_t;
#define __FIMapView_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::__FIMapView_2_HSTRING_HSTRING_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIMapView_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::IMapView<HSTRING,HSTRING>
//#define __FIMapView_2_HSTRING_HSTRING_t ABI::Windows::Foundation::Collections::IMapView<HSTRING,HSTRING>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIMapView_2_HSTRING_HSTRING_USE */




#ifndef DEF___FIMap_2_HSTRING_HSTRING_USE
#define DEF___FIMap_2_HSTRING_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("f6d1f700-49c2-52ae-8154-826f9908773c"))
IMap<HSTRING,HSTRING> : IMap_impl<HSTRING,HSTRING> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IMap`2<String, String>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IMap<HSTRING,HSTRING> __FIMap_2_HSTRING_HSTRING_t;
#define __FIMap_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::__FIMap_2_HSTRING_HSTRING_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIMap_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::IMap<HSTRING,HSTRING>
//#define __FIMap_2_HSTRING_HSTRING_t ABI::Windows::Foundation::Collections::IMap<HSTRING,HSTRING>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIMap_2_HSTRING_HSTRING_USE */




#ifndef DEF___FIReference_1_boolean_USE
#define DEF___FIReference_1_boolean_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("3c00fd60-2950-5939-a21a-2d12c5a01b8a"))
IReference<bool> : IReference_impl<ABI::Windows::Foundation::Internal::AggregateType<bool, boolean>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IReference`1<Boolean>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IReference<bool> __FIReference_1_boolean_t;
#define __FIReference_1_boolean ABI::Windows::Foundation::__FIReference_1_boolean_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIReference_1_boolean ABI::Windows::Foundation::IReference<boolean>
//#define __FIReference_1_boolean_t ABI::Windows::Foundation::IReference<boolean>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIReference_1_boolean_USE */




#ifndef DEF___FIReference_1_int_USE
#define DEF___FIReference_1_int_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("548cefbd-bc8a-5fa0-8df2-957440fc8bf4"))
IReference<int> : IReference_impl<int> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IReference`1<Int32>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IReference<int> __FIReference_1_int_t;
#define __FIReference_1_int ABI::Windows::Foundation::__FIReference_1_int_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIReference_1_int ABI::Windows::Foundation::IReference<INT32>
//#define __FIReference_1_int_t ABI::Windows::Foundation::IReference<INT32>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIReference_1_int_USE */






namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                
                typedef enum WidgetSize : int WidgetSize;
                
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */




namespace ABI {
    namespace Windows {
        namespace Foundation {
            
            typedef struct DateTime DateTime;
            
        } /* Foundation */
    } /* Windows */
} /* ABI */

namespace ABI {
    namespace Windows {
        namespace Foundation {
            class Deferral;
        } /* Foundation */
    } /* Windows */
} /* ABI */

#ifndef ____x_ABI_CWindows_CFoundation_CIDeferral_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIDeferral_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Foundation {
            interface IDeferral;
        } /* Foundation */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CFoundation_CIDeferral ABI::Windows::Foundation::IDeferral

#endif // ____x_ABI_CWindows_CFoundation_CIDeferral_FWD_DEFINED__




#ifndef ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStreamReference_FWD_DEFINED__
#define ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStreamReference_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Storage {
            namespace Streams {
                interface IRandomAccessStreamReference;
            } /* Streams */
        } /* Storage */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStreamReference ABI::Windows::Storage::Streams::IRandomAccessStreamReference

#endif // ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStreamReference_FWD_DEFINED__

































namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    class WidgetActionInvokedArgs;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    class WidgetAnalyticsInfoReportedArgs;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    class WidgetContext;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    class WidgetContextChangedArgs;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    class WidgetCustomizationRequestedArgs;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    class WidgetErrorInfoReportedArgs;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    class WidgetInfo;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    class WidgetManager;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    class WidgetMessageReceivedArgs;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    class WidgetResourceRequest;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    class WidgetResourceRequestedArgs;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    class WidgetResourceResponse;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    class WidgetUpdateRequestOptions;
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */







/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetActionInvokedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetActionInvokedArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetActionInvokedArgs[] = L"Microsoft.Windows.Widgets.Providers.IWidgetActionInvokedArgs";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("C593CC57-04B9-52CA-88AD-46FEA21EA340"), exclusiveto, contract] */
                    MIDL_INTERFACE("C593CC57-04B9-52CA-88AD-46FEA21EA340")
                    IWidgetActionInvokedArgs : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_WidgetContext(
                            /* [retval, out] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetContext * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Verb(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Data(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_CustomState(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetActionInvokedArgs=__uuidof(IWidgetActionInvokedArgs);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetAnalyticsInfoReportedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetAnalyticsInfoReportedArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetAnalyticsInfoReportedArgs[] = L"Microsoft.Windows.Widgets.Providers.IWidgetAnalyticsInfoReportedArgs";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("1D9E5FB5-2BCE-5350-87B1-D63199526639"), exclusiveto, contract] */
                    MIDL_INTERFACE("1D9E5FB5-2BCE-5350-87B1-D63199526639")
                    IWidgetAnalyticsInfoReportedArgs : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_WidgetContext(
                            /* [retval, out] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetContext * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_AnalyticsJson(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetAnalyticsInfoReportedArgs=__uuidof(IWidgetAnalyticsInfoReportedArgs);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetContext
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetContext
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetContext[] = L"Microsoft.Windows.Widgets.Providers.IWidgetContext";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("903C518B-40BC-5BC6-88F7-AF9D81C0CDC1"), exclusiveto, contract] */
                    MIDL_INTERFACE("903C518B-40BC-5BC6-88F7-AF9D81C0CDC1")
                    IWidgetContext : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Id(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_DefinitionId(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Size(
                            /* [retval, out] */ABI::Microsoft::Windows::Widgets::WidgetSize * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_IsActive(
                            /* [retval, out] */::boolean * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetContext=__uuidof(IWidgetContext);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetContextChangedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetContextChangedArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetContextChangedArgs[] = L"Microsoft.Windows.Widgets.Providers.IWidgetContextChangedArgs";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("2C226D54-2252-576B-A197-370B28D25C2F"), exclusiveto, contract] */
                    MIDL_INTERFACE("2C226D54-2252-576B-A197-370B28D25C2F")
                    IWidgetContextChangedArgs : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_WidgetContext(
                            /* [retval, out] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetContext * * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetContextChangedArgs=__uuidof(IWidgetContextChangedArgs);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetCustomizationRequestedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetCustomizationRequestedArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetCustomizationRequestedArgs[] = L"Microsoft.Windows.Widgets.Providers.IWidgetCustomizationRequestedArgs";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("41DEA311-DD9B-5B8B-B493-3A30552116B8"), exclusiveto, contract] */
                    MIDL_INTERFACE("41DEA311-DD9B-5B8B-B493-3A30552116B8")
                    IWidgetCustomizationRequestedArgs : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_WidgetContext(
                            /* [retval, out] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetContext * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_CustomState(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetCustomizationRequestedArgs=__uuidof(IWidgetCustomizationRequestedArgs);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetErrorInfoReportedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetErrorInfoReportedArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetErrorInfoReportedArgs[] = L"Microsoft.Windows.Widgets.Providers.IWidgetErrorInfoReportedArgs";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("30EFA627-B21F-55D5-B91A-B23B4AA13645"), exclusiveto, contract] */
                    MIDL_INTERFACE("30EFA627-B21F-55D5-B91A-B23B4AA13645")
                    IWidgetErrorInfoReportedArgs : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_WidgetContext(
                            /* [retval, out] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetContext * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_ErrorJson(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetErrorInfoReportedArgs=__uuidof(IWidgetErrorInfoReportedArgs);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetInfo
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetInfo
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetInfo[] = L"Microsoft.Windows.Widgets.Providers.IWidgetInfo";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("CEA11F42-A020-5DB5-89E2-B7DECE4AE5CB"), exclusiveto, contract] */
                    MIDL_INTERFACE("CEA11F42-A020-5DB5-89E2-B7DECE4AE5CB")
                    IWidgetInfo : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_WidgetContext(
                            /* [retval, out] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetContext * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Template(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Data(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_CustomState(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LastUpdateTime(
                            /* [retval, out] */ABI::Windows::Foundation::DateTime * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetInfo=__uuidof(IWidgetInfo);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetInfo2
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 9.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetInfo
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x90000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetInfo2[] = L"Microsoft.Windows.Widgets.Providers.IWidgetInfo2";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("081B0A6F-D784-5408-BB29-252FEF2926D4"), exclusiveto, contract] */
                    MIDL_INTERFACE("081B0A6F-D784-5408-BB29-252FEF2926D4")
                    IWidgetInfo2 : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_IsPlaceholderContent(
                            /* [retval, out] */::boolean * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetInfo2=__uuidof(IWidgetInfo2);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x90000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetInfo3
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 11.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetInfo
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0xb0000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetInfo3[] = L"Microsoft.Windows.Widgets.Providers.IWidgetInfo3";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("965538CD-289D-54AB-916E-9315EBF97EA4"), exclusiveto, contract] */
                    MIDL_INTERFACE("965538CD-289D-54AB-916E-9315EBF97EA4")
                    IWidgetInfo3 : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Rank(
                            /* [retval, out] */INT32 * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetInfo3=__uuidof(IWidgetInfo3);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0xb0000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetManager
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetManager[] = L"Microsoft.Windows.Widgets.Providers.IWidgetManager";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("71CB10C0-671E-48E3-B995-207940397123"), contract] */
                    MIDL_INTERFACE("71CB10C0-671E-48E3-B995-207940397123")
                    IWidgetManager : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE UpdateWidget(
                            /* [in] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetUpdateRequestOptions * widgetUpdateRequestOptions
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetWidgetIds(
                            /* [out] */UINT32 * __resultSize,
                            /* [size_is(, *(__resultSize)), retval, out] */HSTRING * * result
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetWidgetInfo(
                            /* [in] */HSTRING widgetId,
                            /* [retval, out] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetInfo * * result
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetWidgetInfos(
                            /* [out] */UINT32 * __resultSize,
                            /* [size_is(, *(__resultSize)), retval, out] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetInfo * * * result
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE DeleteWidget(
                            /* [in] */HSTRING widgetId
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetManager=__uuidof(IWidgetManager);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetManager2
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetManager2[] = L"Microsoft.Windows.Widgets.Providers.IWidgetManager2";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("55C65A27-8845-406C-9EE1-1E79F0556BEF"), contract] */
                    MIDL_INTERFACE("55C65A27-8845-406C-9EE1-1E79F0556BEF")
                    IWidgetManager2 : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE SendMessageToContent(
                            /* [in] */HSTRING widgetId,
                            /* [in] */HSTRING message
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetManager2=__uuidof(IWidgetManager2);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetManagerStatics
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetManager
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetManagerStatics[] = L"Microsoft.Windows.Widgets.Providers.IWidgetManagerStatics";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("7F233B06-28E5-5E2B-8C04-A4FA747C28C7"), exclusiveto, contract] */
                    MIDL_INTERFACE("7F233B06-28E5-5E2B-8C04-A4FA747C28C7")
                    IWidgetManagerStatics : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE GetDefault(
                            /* [retval, out] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetManager * * result
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetManagerStatics=__uuidof(IWidgetManagerStatics);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetMessageReceivedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetMessageReceivedArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetMessageReceivedArgs[] = L"Microsoft.Windows.Widgets.Providers.IWidgetMessageReceivedArgs";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("2261CB2B-C741-5F96-9ADB-FB3A7667BCB6"), exclusiveto, contract] */
                    MIDL_INTERFACE("2261CB2B-C741-5F96-9ADB-FB3A7667BCB6")
                    IWidgetMessageReceivedArgs : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_WidgetContext(
                            /* [retval, out] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetContext * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Message(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetMessageReceivedArgs=__uuidof(IWidgetMessageReceivedArgs);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetProvider
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetProvider[] = L"Microsoft.Windows.Widgets.Providers.IWidgetProvider";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("5C5774CC-72A0-452D-B9ED-075C0DD25EED"), contract] */
                    MIDL_INTERFACE("5C5774CC-72A0-452D-B9ED-075C0DD25EED")
                    IWidgetProvider : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE CreateWidget(
                            /* [in] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetContext * widgetContext
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE DeleteWidget(
                            /* [in] */HSTRING widgetId,
                            /* [in] */HSTRING customState
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE OnActionInvoked(
                            /* [in] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetActionInvokedArgs * actionInvokedArgs
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE OnWidgetContextChanged(
                            /* [in] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetContextChangedArgs * contextChangedArgs
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE Activate(
                            /* [in] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetContext * widgetContext
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE Deactivate(
                            /* [in] */HSTRING widgetId
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetProvider=__uuidof(IWidgetProvider);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetProvider2
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetProvider2[] = L"Microsoft.Windows.Widgets.Providers.IWidgetProvider2";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("38C3A963-DD93-479D-9276-04BF84EE1816"), contract] */
                    MIDL_INTERFACE("38C3A963-DD93-479D-9276-04BF84EE1816")
                    IWidgetProvider2 : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE OnCustomizationRequested(
                            /* [in] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetCustomizationRequestedArgs * customizationRequestedArgs
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetProvider2=__uuidof(IWidgetProvider2);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetProviderAnalytics
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetProviderAnalytics[] = L"Microsoft.Windows.Widgets.Providers.IWidgetProviderAnalytics";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("661985A5-D187-482D-9EEF-6FDA05D21845"), contract] */
                    MIDL_INTERFACE("661985A5-D187-482D-9EEF-6FDA05D21845")
                    IWidgetProviderAnalytics : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE OnAnalyticsInfoReported(
                            /* [in] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetAnalyticsInfoReportedArgs * args
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetProviderAnalytics=__uuidof(IWidgetProviderAnalytics);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetProviderErrors
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetProviderErrors[] = L"Microsoft.Windows.Widgets.Providers.IWidgetProviderErrors";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("90C1B5F0-0D3A-4AC6-ABB7-C97B367B8FCC"), contract] */
                    MIDL_INTERFACE("90C1B5F0-0D3A-4AC6-ABB7-C97B367B8FCC")
                    IWidgetProviderErrors : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE OnErrorInfoReported(
                            /* [in] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetErrorInfoReportedArgs * args
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetProviderErrors=__uuidof(IWidgetProviderErrors);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetProviderMessage
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetProviderMessage[] = L"Microsoft.Windows.Widgets.Providers.IWidgetProviderMessage";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("EA4DC186-9E24-4B35-A5EF-A9F5DF72D6AC"), contract] */
                    MIDL_INTERFACE("EA4DC186-9E24-4B35-A5EF-A9F5DF72D6AC")
                    IWidgetProviderMessage : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE OnMessageReceived(
                            /* [in] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetMessageReceivedArgs * args
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetProviderMessage=__uuidof(IWidgetProviderMessage);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetResourceProvider
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetResourceProvider[] = L"Microsoft.Windows.Widgets.Providers.IWidgetResourceProvider";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("DCF328C0-012C-40F5-BB28-3A1C714D027D"), contract] */
                    MIDL_INTERFACE("DCF328C0-012C-40F5-BB28-3A1C714D027D")
                    IWidgetResourceProvider : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE OnResourceRequested(
                            /* [in] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetResourceRequestedArgs * args
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetResourceProvider=__uuidof(IWidgetResourceProvider);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetResourceRequest
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetResourceRequest
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetResourceRequest[] = L"Microsoft.Windows.Widgets.Providers.IWidgetResourceRequest";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("113D249F-82D9-57CB-8CEA-9A5291F2FE22"), exclusiveto, contract] */
                    MIDL_INTERFACE("113D249F-82D9-57CB-8CEA-9A5291F2FE22")
                    IWidgetResourceRequest : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Uri(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Method(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Method(
                            /* [in] */HSTRING value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Content(
                            /* [retval, out] */ABI::Windows::Storage::Streams::IRandomAccessStreamReference * * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Content(
                            /* [in] */ABI::Windows::Storage::Streams::IRandomAccessStreamReference * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Headers(
                            /* [retval, out] */__FIMap_2_HSTRING_HSTRING * * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetResourceRequest=__uuidof(IWidgetResourceRequest);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetResourceRequestedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetResourceRequestedArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetResourceRequestedArgs[] = L"Microsoft.Windows.Widgets.Providers.IWidgetResourceRequestedArgs";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("2BB30F4D-0166-58E3-AAF6-31B2AE970BCD"), exclusiveto, contract] */
                    MIDL_INTERFACE("2BB30F4D-0166-58E3-AAF6-31B2AE970BCD")
                    IWidgetResourceRequestedArgs : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_WidgetContext(
                            /* [retval, out] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetContext * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Request(
                            /* [retval, out] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetResourceRequest * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Response(
                            /* [retval, out] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetResourceResponse * * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Response(
                            /* [in] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetResourceResponse * value
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetDeferral(
                            /* [retval, out] */ABI::Windows::Foundation::IDeferral * * result
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetResourceRequestedArgs=__uuidof(IWidgetResourceRequestedArgs);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetResourceResponse
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetResourceResponse
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetResourceResponse[] = L"Microsoft.Windows.Widgets.Providers.IWidgetResourceResponse";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("03A2D32C-2E9E-54A3-B084-1479D5060F80"), exclusiveto, contract] */
                    MIDL_INTERFACE("03A2D32C-2E9E-54A3-B084-1479D5060F80")
                    IWidgetResourceResponse : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Content(
                            /* [retval, out] */ABI::Windows::Storage::Streams::IRandomAccessStreamReference * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Headers(
                            /* [retval, out] */__FIMap_2_HSTRING_HSTRING * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_ReasonPhrase(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_StatusCode(
                            /* [retval, out] */INT32 * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetResourceResponse=__uuidof(IWidgetResourceResponse);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetResourceResponseFactory
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetResourceResponse
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetResourceResponseFactory[] = L"Microsoft.Windows.Widgets.Providers.IWidgetResourceResponseFactory";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("08881EF1-A78A-5804-B070-9153A8657F85"), exclusiveto, contract] */
                    MIDL_INTERFACE("08881EF1-A78A-5804-B070-9153A8657F85")
                    IWidgetResourceResponseFactory : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE CreateInstance(
                            /* [in] */ABI::Windows::Storage::Streams::IRandomAccessStreamReference * content,
                            /* [in] */HSTRING reasonPhrase,
                            /* [in] */INT32 statusCode,
                            /* [retval, out] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetResourceResponse * * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetResourceResponseFactory=__uuidof(IWidgetResourceResponseFactory);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetUpdateRequestOptions
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetUpdateRequestOptions[] = L"Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("B09CA8F7-7424-5687-BAAF-7DD6FA639672"), exclusiveto, contract] */
                    MIDL_INTERFACE("B09CA8F7-7424-5687-BAAF-7DD6FA639672")
                    IWidgetUpdateRequestOptions : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_WidgetId(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Template(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Template(
                            /* [in] */HSTRING value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Data(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Data(
                            /* [in] */HSTRING value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_CustomState(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_CustomState(
                            /* [in] */HSTRING value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetUpdateRequestOptions=__uuidof(IWidgetUpdateRequestOptions);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions2
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 9.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetUpdateRequestOptions
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x90000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetUpdateRequestOptions2[] = L"Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions2";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("77C4EFC4-38F3-57A5-ABA1-F83F257B899E"), exclusiveto, contract] */
                    MIDL_INTERFACE("77C4EFC4-38F3-57A5-ABA1-F83F257B899E")
                    IWidgetUpdateRequestOptions2 : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_IsPlaceholderContent(
                            /* [retval, out] */__FIReference_1_boolean * * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_IsPlaceholderContent(
                            /* [in] */__FIReference_1_boolean * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetUpdateRequestOptions2=__uuidof(IWidgetUpdateRequestOptions2);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x90000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions3
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 11.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetUpdateRequestOptions
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0xb0000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetUpdateRequestOptions3[] = L"Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions3";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("A78E2A8B-A26C-596A-ADE3-DB8F4C72FE02"), exclusiveto, contract] */
                    MIDL_INTERFACE("A78E2A8B-A26C-596A-ADE3-DB8F4C72FE02")
                    IWidgetUpdateRequestOptions3 : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Rank(
                            /* [retval, out] */__FIReference_1_int * * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Rank(
                            /* [in] */__FIReference_1_int * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetUpdateRequestOptions3=__uuidof(IWidgetUpdateRequestOptions3);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0xb0000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptionsFactory
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetUpdateRequestOptions
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetUpdateRequestOptionsFactory[] = L"Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptionsFactory";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("E0E00AF8-1D10-57A8-9419-3F568E854DAA"), exclusiveto, contract] */
                    MIDL_INTERFACE("E0E00AF8-1D10-57A8-9419-3F568E854DAA")
                    IWidgetUpdateRequestOptionsFactory : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE CreateInstance(
                            /* [in] */HSTRING widgetId,
                            /* [retval, out] */ABI::Microsoft::Windows::Widgets::Providers::IWidgetUpdateRequestOptions * * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetUpdateRequestOptionsFactory=__uuidof(IWidgetUpdateRequestOptionsFactory);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptionsStatics
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetUpdateRequestOptions
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetUpdateRequestOptionsStatics[] = L"Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptionsStatics";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Providers {
                    /* [object, uuid("4645B5E3-D332-5D11-82F0-3607E5DF6018"), exclusiveto, contract] */
                    MIDL_INTERFACE("4645B5E3-D332-5D11-82F0-3607E5DF6018")
                    IWidgetUpdateRequestOptionsStatics : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_UnsetValue(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IWidgetUpdateRequestOptionsStatics=__uuidof(IWidgetUpdateRequestOptionsStatics);
                    
                } /* Providers */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetActionInvokedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetActionInvokedArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetActionInvokedArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetActionInvokedArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetActionInvokedArgs[] = L"Microsoft.Windows.Widgets.Providers.WidgetActionInvokedArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetAnalyticsInfoReportedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetAnalyticsInfoReportedArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetAnalyticsInfoReportedArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetAnalyticsInfoReportedArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetAnalyticsInfoReportedArgs[] = L"Microsoft.Windows.Widgets.Providers.WidgetAnalyticsInfoReportedArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetContext
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetContext ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetContext_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetContext_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetContext[] = L"Microsoft.Windows.Widgets.Providers.WidgetContext";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetContextChangedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetContextChangedArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetContextChangedArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetContextChangedArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetContextChangedArgs[] = L"Microsoft.Windows.Widgets.Providers.WidgetContextChangedArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetCustomizationRequestedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetCustomizationRequestedArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetCustomizationRequestedArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetCustomizationRequestedArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetCustomizationRequestedArgs[] = L"Microsoft.Windows.Widgets.Providers.WidgetCustomizationRequestedArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetErrorInfoReportedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetErrorInfoReportedArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetErrorInfoReportedArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetErrorInfoReportedArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetErrorInfoReportedArgs[] = L"Microsoft.Windows.Widgets.Providers.WidgetErrorInfoReportedArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetInfo
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetInfo ** Default Interface **
 *    Microsoft.Windows.Widgets.Providers.IWidgetInfo2
 *    Microsoft.Windows.Widgets.Providers.IWidgetInfo3
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetInfo_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetInfo_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetInfo[] = L"Microsoft.Windows.Widgets.Providers.WidgetInfo";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetManager
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.Widgets.Providers.IWidgetManagerStatics interface starting with version 1.0 of the Microsoft.Windows.Widgets.WidgetContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetManager ** Default Interface **
 *    Microsoft.Windows.Widgets.Providers.IWidgetManager2
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetManager_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetManager_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetManager[] = L"Microsoft.Windows.Widgets.Providers.WidgetManager";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetMessageReceivedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetMessageReceivedArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetMessageReceivedArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetMessageReceivedArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetMessageReceivedArgs[] = L"Microsoft.Windows.Widgets.Providers.WidgetMessageReceivedArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetResourceRequest
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetResourceRequest ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetResourceRequest_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetResourceRequest_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetResourceRequest[] = L"Microsoft.Windows.Widgets.Providers.WidgetResourceRequest";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetResourceRequestedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetResourceRequestedArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetResourceRequestedArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetResourceRequestedArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetResourceRequestedArgs[] = L"Microsoft.Windows.Widgets.Providers.WidgetResourceRequestedArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetResourceResponse
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * RuntimeClass can be activated.
 *   Type can be activated via the Microsoft.Windows.Widgets.Providers.IWidgetResourceResponseFactory interface starting with version 6.0 of the Microsoft.Windows.Widgets.WidgetContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetResourceResponse ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetResourceResponse_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetResourceResponse_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetResourceResponse[] = L"Microsoft.Windows.Widgets.Providers.WidgetResourceResponse";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetUpdateRequestOptions
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * RuntimeClass can be activated.
 *   Type can be activated via the Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptionsFactory interface starting with version 1.0 of the Microsoft.Windows.Widgets.WidgetContract API contract
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptionsStatics interface starting with version 1.0 of the Microsoft.Windows.Widgets.WidgetContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions ** Default Interface **
 *    Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions2
 *    Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions3
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetUpdateRequestOptions_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetUpdateRequestOptions_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetUpdateRequestOptions[] = L"Microsoft.Windows.Widgets.Providers.WidgetUpdateRequestOptions";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000





#else // !defined(__cplusplus)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2 __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3 __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2 __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2 __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2 __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3 __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_FWD_DEFINED__

// Parameterized interface forward declarations (C)

// Collection interface definitions
#if !defined(____FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__)
#define ____FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__

typedef interface __FIKeyValuePair_2_HSTRING_HSTRING __FIKeyValuePair_2_HSTRING_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIKeyValuePair_2_HSTRING_HSTRING;

typedef struct __FIKeyValuePair_2_HSTRING_HSTRINGVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIKeyValuePair_2_HSTRING_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIKeyValuePair_2_HSTRING_HSTRING * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIKeyValuePair_2_HSTRING_HSTRING * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIKeyValuePair_2_HSTRING_HSTRING * This,
            /* [out] */ __RPC__out ULONG *iidCount,
            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIKeyValuePair_2_HSTRING_HSTRING * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIKeyValuePair_2_HSTRING_HSTRING * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Key )(__RPC__in __FIKeyValuePair_2_HSTRING_HSTRING * This, /* [retval][out] */ __RPC__out HSTRING *key);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Value )(__RPC__in __FIKeyValuePair_2_HSTRING_HSTRING * This, /* [retval][out] */ __RPC__deref_out_opt HSTRING *value);
    END_INTERFACE
} __FIKeyValuePair_2_HSTRING_HSTRINGVtbl;

interface __FIKeyValuePair_2_HSTRING_HSTRING
{
    CONST_VTBL struct __FIKeyValuePair_2_HSTRING_HSTRINGVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIKeyValuePair_2_HSTRING_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIKeyValuePair_2_HSTRING_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIKeyValuePair_2_HSTRING_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIKeyValuePair_2_HSTRING_HSTRING_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIKeyValuePair_2_HSTRING_HSTRING_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIKeyValuePair_2_HSTRING_HSTRING_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIKeyValuePair_2_HSTRING_HSTRING_get_Key(This,key)	\
    ( (This)->lpVtbl -> get_Key(This,key) ) 

#define __FIKeyValuePair_2_HSTRING_HSTRING_get_Value(This,value)	\
    ( (This)->lpVtbl -> get_Value(This,value) ) 
#endif /* COBJMACROS */


#endif // ____FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__



#if !defined(____FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__)
#define ____FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__

typedef interface __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING;

typedef struct __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRINGVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Current )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This, /* [retval][out] */ __RPC__out __FIKeyValuePair_2_HSTRING_HSTRING * *current);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasCurrent )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *MoveNext )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *GetMany )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This,
        /* [in] */ unsigned int capacity,
        /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) __FIKeyValuePair_2_HSTRING_HSTRING * *items,
        /* [retval][out] */ __RPC__out unsigned int *actual);

    END_INTERFACE
} __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRINGVtbl;

interface __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING
{
    CONST_VTBL struct __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRINGVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_get_Current(This,current)	\
    ( (This)->lpVtbl -> get_Current(This,current) ) 

#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_get_HasCurrent(This,hasCurrent)	\
    ( (This)->lpVtbl -> get_HasCurrent(This,hasCurrent) ) 

#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_MoveNext(This,hasCurrent)	\
    ( (This)->lpVtbl -> MoveNext(This,hasCurrent) ) 

#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_GetMany(This,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,capacity,items,actual) ) 

#endif /* COBJMACROS */


#endif // ____FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__



#if !defined(____FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__)
#define ____FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__

typedef interface __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING;

typedef  struct __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRINGVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING * This);

    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING * This,
                                           /* [out] */ __RPC__out ULONG *iidCount,
                                           /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *First )(__RPC__in __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING * This, /* [retval][out] */ __RPC__deref_out_opt __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING **first);

    END_INTERFACE
} __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRINGVtbl;

interface __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING
{
    CONST_VTBL struct __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRINGVtbl *lpVtbl;
};

#ifdef COBJMACROS

#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_First(This,first)	\
    ( (This)->lpVtbl -> First(This,first) ) 

#endif /* COBJMACROS */


#endif // ____FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__


#if !defined(____FIMapView_2_HSTRING_HSTRING_INTERFACE_DEFINED__)
#define ____FIMapView_2_HSTRING_HSTRING_INTERFACE_DEFINED__

typedef interface __FIMapView_2_HSTRING_HSTRING __FIMapView_2_HSTRING_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIMapView_2_HSTRING_HSTRING;

typedef struct __FIMapView_2_HSTRING_HSTRINGVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This);

    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This,/* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *Lookup )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This,
        /* [in] */ __RPC__in HSTRING key,
        /* [retval][out] */ __RPC__deref_out_opt HSTRING *value);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Size )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This, /* [retval][out] */ __RPC__out unsigned int *size);
    HRESULT ( STDMETHODCALLTYPE *HasKey )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This, /* [in] */ __RPC__in HSTRING key, /* [retval][out] */ __RPC__out boolean *found);
    HRESULT ( STDMETHODCALLTYPE *Split )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This,/* [out] */ __RPC__deref_out_opt __FIMapView_2_HSTRING_HSTRING **firstPartition,
        /* [out] */ __RPC__deref_out_opt __FIMapView_2_HSTRING_HSTRING **secondPartition);
    END_INTERFACE
} __FIMapView_2_HSTRING_HSTRINGVtbl;

interface __FIMapView_2_HSTRING_HSTRING
{
    CONST_VTBL struct __FIMapView_2_HSTRING_HSTRINGVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIMapView_2_HSTRING_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIMapView_2_HSTRING_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIMapView_2_HSTRING_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIMapView_2_HSTRING_HSTRING_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIMapView_2_HSTRING_HSTRING_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIMapView_2_HSTRING_HSTRING_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIMapView_2_HSTRING_HSTRING_Lookup(This,key,value)	\
    ( (This)->lpVtbl -> Lookup(This,key,value) ) 
#define __FIMapView_2_HSTRING_HSTRING_get_Size(This,size)	\
    ( (This)->lpVtbl -> get_Size(This,size) ) 
#define __FIMapView_2_HSTRING_HSTRING_HasKey(This,key,found)	\
    ( (This)->lpVtbl -> HasKey(This,key,found) ) 
#define __FIMapView_2_HSTRING_HSTRING_Split(This,firstPartition,secondPartition)	\
    ( (This)->lpVtbl -> Split(This,firstPartition,secondPartition) ) 
#endif /* COBJMACROS */


#endif // ____FIMapView_2_HSTRING_HSTRING_INTERFACE_DEFINED__


#if !defined(____FIMap_2_HSTRING_HSTRING_INTERFACE_DEFINED__)
#define ____FIMap_2_HSTRING_HSTRING_INTERFACE_DEFINED__

typedef interface __FIMap_2_HSTRING_HSTRING __FIMap_2_HSTRING_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIMap_2_HSTRING_HSTRING;

typedef struct __FIMap_2_HSTRING_HSTRINGVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIMap_2_HSTRING_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIMap_2_HSTRING_HSTRING * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIMap_2_HSTRING_HSTRING * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIMap_2_HSTRING_HSTRING * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIMap_2_HSTRING_HSTRING * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIMap_2_HSTRING_HSTRING * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *Lookup )(__RPC__in __FIMap_2_HSTRING_HSTRING * This,
        /* [in] */ HSTRING key,
        /* [retval][out] */ __RPC__deref_out_opt HSTRING **value);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Size )(__RPC__in __FIMap_2_HSTRING_HSTRING * This, /* [retval][out] */ __RPC__out unsigned int *size);
    HRESULT ( STDMETHODCALLTYPE *HasKey )(__RPC__in __FIMap_2_HSTRING_HSTRING * This, /* [in] */ HSTRING key, /* [retval][out] */ __RPC__out boolean *found);
    HRESULT ( STDMETHODCALLTYPE *GetView )(__RPC__in __FIMap_2_HSTRING_HSTRING * This, /* [retval][out] */ __RPC__deref_out_opt __FIMapView_2_HSTRING_HSTRING **view);
    HRESULT ( STDMETHODCALLTYPE *Insert )(__RPC__in __FIMap_2_HSTRING_HSTRING * This,
        /* [in] */ HSTRING key,
        /* [in] */ __RPC__in_opt HSTRING *value,
        /* [retval][out] */ __RPC__out boolean *replaced);
    HRESULT ( STDMETHODCALLTYPE *Remove )(__RPC__in __FIMap_2_HSTRING_HSTRING * This,/* [in] */ HSTRING key);
    HRESULT ( STDMETHODCALLTYPE *Clear )(__RPC__in __FIMap_2_HSTRING_HSTRING * This);
    END_INTERFACE
} __FIMap_2_HSTRING_HSTRINGVtbl;

interface __FIMap_2_HSTRING_HSTRING
{
    CONST_VTBL struct __FIMap_2_HSTRING_HSTRINGVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIMap_2_HSTRING_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIMap_2_HSTRING_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIMap_2_HSTRING_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIMap_2_HSTRING_HSTRING_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIMap_2_HSTRING_HSTRING_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIMap_2_HSTRING_HSTRING_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIMap_2_HSTRING_HSTRING_Lookup(This,key,value)	\
    ( (This)->lpVtbl -> Lookup(This,key,value) ) 

#define __FIMap_2_HSTRING_HSTRING_get_Size(This,size)	\
    ( (This)->lpVtbl -> get_Size(This,size) ) 

#define __FIMap_2_HSTRING_HSTRING_HasKey(This,key,found)	\
    ( (This)->lpVtbl -> HasKey(This,key,found) ) 

#define __FIMap_2_HSTRING_HSTRING_GetView(This,view)	\
    ( (This)->lpVtbl -> GetView(This,view) ) 

#define __FIMap_2_HSTRING_HSTRING_Insert(This,key,value,replaced)	\
    ( (This)->lpVtbl -> Insert(This,key,value,replaced) ) 

#define __FIMap_2_HSTRING_HSTRING_Remove(This,key)	\
    ( (This)->lpVtbl -> Remove(This,key) ) 

#define __FIMap_2_HSTRING_HSTRING_Clear(This)	\
    ( (This)->lpVtbl -> Clear(This) ) 
#endif /* COBJMACROS */



#endif // ____FIMap_2_HSTRING_HSTRING_INTERFACE_DEFINED__


#if !defined(____FIReference_1_boolean_INTERFACE_DEFINED__)
#define ____FIReference_1_boolean_INTERFACE_DEFINED__

typedef interface __FIReference_1_boolean __FIReference_1_boolean;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIReference_1_boolean;

typedef struct __FIReference_1_booleanVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIReference_1_boolean * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )( __RPC__in __FIReference_1_boolean * This );
    ULONG ( STDMETHODCALLTYPE *Release )( __RPC__in __FIReference_1_boolean * This );

    HRESULT ( STDMETHODCALLTYPE *GetIids )( __RPC__in __FIReference_1_boolean * This, 
                                            /* [out] */ __RPC__out ULONG *iidCount,
                                            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( __RPC__in __FIReference_1_boolean * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( __RPC__in __FIReference_1_boolean * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Value )(__RPC__in __FIReference_1_boolean * This, /* [retval][out] */ __RPC__out boolean *value);
    END_INTERFACE
} __FIReference_1_booleanVtbl;

interface __FIReference_1_boolean
{
    CONST_VTBL struct __FIReference_1_booleanVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIReference_1_boolean_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIReference_1_boolean_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIReference_1_boolean_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIReference_1_boolean_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIReference_1_boolean_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIReference_1_boolean_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIReference_1_boolean_get_Value(This,value)	\
    ( (This)->lpVtbl -> get_Value(This,value) ) 
#endif /* COBJMACROS */


#endif // ____FIReference_1_boolean_INTERFACE_DEFINED__


#if !defined(____FIReference_1_int_INTERFACE_DEFINED__)
#define ____FIReference_1_int_INTERFACE_DEFINED__

typedef interface __FIReference_1_int __FIReference_1_int;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIReference_1_int;

typedef struct __FIReference_1_intVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIReference_1_int * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )( __RPC__in __FIReference_1_int * This );
    ULONG ( STDMETHODCALLTYPE *Release )( __RPC__in __FIReference_1_int * This );

    HRESULT ( STDMETHODCALLTYPE *GetIids )( __RPC__in __FIReference_1_int * This, 
                                            /* [out] */ __RPC__out ULONG *iidCount,
                                            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( __RPC__in __FIReference_1_int * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( __RPC__in __FIReference_1_int * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Value )(__RPC__in __FIReference_1_int * This, /* [retval][out] */ __RPC__out int *value);
    END_INTERFACE
} __FIReference_1_intVtbl;

interface __FIReference_1_int
{
    CONST_VTBL struct __FIReference_1_intVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIReference_1_int_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIReference_1_int_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIReference_1_int_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIReference_1_int_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIReference_1_int_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIReference_1_int_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIReference_1_int_get_Value(This,value)	\
    ( (This)->lpVtbl -> get_Value(This,value) ) 
#endif /* COBJMACROS */


#endif // ____FIReference_1_int_INTERFACE_DEFINED__





typedef enum __x_ABI_CMicrosoft_CWindows_CWidgets_CWidgetSize __x_ABI_CMicrosoft_CWindows_CWidgets_CWidgetSize;





typedef struct __x_ABI_CWindows_CFoundation_CDateTime __x_ABI_CWindows_CFoundation_CDateTime;

#ifndef ____x_ABI_CWindows_CFoundation_CIDeferral_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIDeferral_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CFoundation_CIDeferral __x_ABI_CWindows_CFoundation_CIDeferral;

#endif // ____x_ABI_CWindows_CFoundation_CIDeferral_FWD_DEFINED__




#ifndef ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStreamReference_FWD_DEFINED__
#define ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStreamReference_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStreamReference __x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStreamReference;

#endif // ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStreamReference_FWD_DEFINED__



















































/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetActionInvokedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetActionInvokedArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetActionInvokedArgs[] = L"Microsoft.Windows.Widgets.Providers.IWidgetActionInvokedArgs";
/* [object, uuid("C593CC57-04B9-52CA-88AD-46FEA21EA340"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_WidgetContext )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Verb )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Data )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_CustomState )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs * This,
        /* [retval, out] */HSTRING * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_get_WidgetContext(This,value) \
    ( (This)->lpVtbl->get_WidgetContext(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_get_Verb(This,value) \
    ( (This)->lpVtbl->get_Verb(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_get_Data(This,value) \
    ( (This)->lpVtbl->get_Data(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_get_CustomState(This,value) \
    ( (This)->lpVtbl->get_CustomState(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetAnalyticsInfoReportedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetAnalyticsInfoReportedArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetAnalyticsInfoReportedArgs[] = L"Microsoft.Windows.Widgets.Providers.IWidgetAnalyticsInfoReportedArgs";
/* [object, uuid("1D9E5FB5-2BCE-5350-87B1-D63199526639"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_WidgetContext )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_AnalyticsJson )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs * This,
        /* [retval, out] */HSTRING * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_get_WidgetContext(This,value) \
    ( (This)->lpVtbl->get_WidgetContext(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_get_AnalyticsJson(This,value) \
    ( (This)->lpVtbl->get_AnalyticsJson(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetContext
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetContext
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetContext[] = L"Microsoft.Windows.Widgets.Providers.IWidgetContext";
/* [object, uuid("903C518B-40BC-5BC6-88F7-AF9D81C0CDC1"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Id )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_DefinitionId )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Size )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CWidgetSize * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_IsActive )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * This,
        /* [retval, out] */boolean * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_get_Id(This,value) \
    ( (This)->lpVtbl->get_Id(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_get_DefinitionId(This,value) \
    ( (This)->lpVtbl->get_DefinitionId(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_get_Size(This,value) \
    ( (This)->lpVtbl->get_Size(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_get_IsActive(This,value) \
    ( (This)->lpVtbl->get_IsActive(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetContextChangedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetContextChangedArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetContextChangedArgs[] = L"Microsoft.Windows.Widgets.Providers.IWidgetContextChangedArgs";
/* [object, uuid("2C226D54-2252-576B-A197-370B28D25C2F"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_WidgetContext )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_get_WidgetContext(This,value) \
    ( (This)->lpVtbl->get_WidgetContext(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetCustomizationRequestedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetCustomizationRequestedArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetCustomizationRequestedArgs[] = L"Microsoft.Windows.Widgets.Providers.IWidgetCustomizationRequestedArgs";
/* [object, uuid("41DEA311-DD9B-5B8B-B493-3A30552116B8"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_WidgetContext )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_CustomState )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs * This,
        /* [retval, out] */HSTRING * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_get_WidgetContext(This,value) \
    ( (This)->lpVtbl->get_WidgetContext(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_get_CustomState(This,value) \
    ( (This)->lpVtbl->get_CustomState(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetErrorInfoReportedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetErrorInfoReportedArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetErrorInfoReportedArgs[] = L"Microsoft.Windows.Widgets.Providers.IWidgetErrorInfoReportedArgs";
/* [object, uuid("30EFA627-B21F-55D5-B91A-B23B4AA13645"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_WidgetContext )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_ErrorJson )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs * This,
        /* [retval, out] */HSTRING * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_get_WidgetContext(This,value) \
    ( (This)->lpVtbl->get_WidgetContext(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_get_ErrorJson(This,value) \
    ( (This)->lpVtbl->get_ErrorJson(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetInfo
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetInfo
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetInfo[] = L"Microsoft.Windows.Widgets.Providers.IWidgetInfo";
/* [object, uuid("CEA11F42-A020-5DB5-89E2-B7DECE4AE5CB"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfoVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_WidgetContext )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Template )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Data )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_CustomState )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LastUpdateTime )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CDateTime * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfoVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfoVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_get_WidgetContext(This,value) \
    ( (This)->lpVtbl->get_WidgetContext(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_get_Template(This,value) \
    ( (This)->lpVtbl->get_Template(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_get_Data(This,value) \
    ( (This)->lpVtbl->get_Data(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_get_CustomState(This,value) \
    ( (This)->lpVtbl->get_CustomState(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_get_LastUpdateTime(This,value) \
    ( (This)->lpVtbl->get_LastUpdateTime(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetInfo2
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 9.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetInfo
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x90000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetInfo2[] = L"Microsoft.Windows.Widgets.Providers.IWidgetInfo2";
/* [object, uuid("081B0A6F-D784-5408-BB29-252FEF2926D4"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2Vtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2 * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2 * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2 * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2 * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2 * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2 * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_IsPlaceholderContent )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2 * This,
        /* [retval, out] */boolean * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2Vtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2Vtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_get_IsPlaceholderContent(This,value) \
    ( (This)->lpVtbl->get_IsPlaceholderContent(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo2_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x90000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetInfo3
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 11.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetInfo
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0xb0000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetInfo3[] = L"Microsoft.Windows.Widgets.Providers.IWidgetInfo3";
/* [object, uuid("965538CD-289D-54AB-916E-9315EBF97EA4"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3Vtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3 * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3 * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3 * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3 * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3 * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3 * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Rank )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3 * This,
        /* [retval, out] */INT32 * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3Vtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3Vtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_get_Rank(This,value) \
    ( (This)->lpVtbl->get_Rank(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo3_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0xb0000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetManager
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetManager[] = L"Microsoft.Windows.Widgets.Providers.IWidgetManager";
/* [object, uuid("71CB10C0-671E-48E3-B995-207940397123"), contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *UpdateWidget )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions * widgetUpdateRequestOptions
        );
    HRESULT ( STDMETHODCALLTYPE *GetWidgetIds )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager * This,
        /* [out] */UINT32 * __resultSize,
        /* [size_is(, *(__resultSize)), retval, out] */HSTRING * * result
        );
    HRESULT ( STDMETHODCALLTYPE *GetWidgetInfo )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager * This,
        /* [in] */HSTRING widgetId,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo * * result
        );
    HRESULT ( STDMETHODCALLTYPE *GetWidgetInfos )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager * This,
        /* [out] */UINT32 * __resultSize,
        /* [size_is(, *(__resultSize)), retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetInfo * * * result
        );
    HRESULT ( STDMETHODCALLTYPE *DeleteWidget )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager * This,
        /* [in] */HSTRING widgetId
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_UpdateWidget(This,widgetUpdateRequestOptions) \
    ( (This)->lpVtbl->UpdateWidget(This,widgetUpdateRequestOptions) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_GetWidgetIds(This,__resultSize,result) \
    ( (This)->lpVtbl->GetWidgetIds(This,__resultSize,result) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_GetWidgetInfo(This,widgetId,result) \
    ( (This)->lpVtbl->GetWidgetInfo(This,widgetId,result) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_GetWidgetInfos(This,__resultSize,result) \
    ( (This)->lpVtbl->GetWidgetInfos(This,__resultSize,result) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_DeleteWidget(This,widgetId) \
    ( (This)->lpVtbl->DeleteWidget(This,widgetId) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetManager2
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetManager2[] = L"Microsoft.Windows.Widgets.Providers.IWidgetManager2";
/* [object, uuid("55C65A27-8845-406C-9EE1-1E79F0556BEF"), contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2Vtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2 * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2 * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2 * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2 * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2 * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2 * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *SendMessageToContent )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2 * This,
        /* [in] */HSTRING widgetId,
        /* [in] */HSTRING message
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2Vtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2Vtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_SendMessageToContent(This,widgetId,message) \
    ( (This)->lpVtbl->SendMessageToContent(This,widgetId,message) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager2_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetManagerStatics
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetManager
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetManagerStatics[] = L"Microsoft.Windows.Widgets.Providers.IWidgetManagerStatics";
/* [object, uuid("7F233B06-28E5-5E2B-8C04-A4FA747C28C7"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *GetDefault )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManager * * result
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStaticsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_GetDefault(This,result) \
    ( (This)->lpVtbl->GetDefault(This,result) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetManagerStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetMessageReceivedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetMessageReceivedArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetMessageReceivedArgs[] = L"Microsoft.Windows.Widgets.Providers.IWidgetMessageReceivedArgs";
/* [object, uuid("2261CB2B-C741-5F96-9ADB-FB3A7667BCB6"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_WidgetContext )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Message )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs * This,
        /* [retval, out] */HSTRING * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_get_WidgetContext(This,value) \
    ( (This)->lpVtbl->get_WidgetContext(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_get_Message(This,value) \
    ( (This)->lpVtbl->get_Message(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetProvider
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetProvider[] = L"Microsoft.Windows.Widgets.Providers.IWidgetProvider";
/* [object, uuid("5C5774CC-72A0-452D-B9ED-075C0DD25EED"), contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateWidget )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * widgetContext
        );
    HRESULT ( STDMETHODCALLTYPE *DeleteWidget )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider * This,
        /* [in] */HSTRING widgetId,
        /* [in] */HSTRING customState
        );
    HRESULT ( STDMETHODCALLTYPE *OnActionInvoked )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetActionInvokedArgs * actionInvokedArgs
        );
    HRESULT ( STDMETHODCALLTYPE *OnWidgetContextChanged )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContextChangedArgs * contextChangedArgs
        );
    HRESULT ( STDMETHODCALLTYPE *Activate )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * widgetContext
        );
    HRESULT ( STDMETHODCALLTYPE *Deactivate )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider * This,
        /* [in] */HSTRING widgetId
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_CreateWidget(This,widgetContext) \
    ( (This)->lpVtbl->CreateWidget(This,widgetContext) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_DeleteWidget(This,widgetId,customState) \
    ( (This)->lpVtbl->DeleteWidget(This,widgetId,customState) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_OnActionInvoked(This,actionInvokedArgs) \
    ( (This)->lpVtbl->OnActionInvoked(This,actionInvokedArgs) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_OnWidgetContextChanged(This,contextChangedArgs) \
    ( (This)->lpVtbl->OnWidgetContextChanged(This,contextChangedArgs) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_Activate(This,widgetContext) \
    ( (This)->lpVtbl->Activate(This,widgetContext) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_Deactivate(This,widgetId) \
    ( (This)->lpVtbl->Deactivate(This,widgetId) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetProvider2
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetProvider2[] = L"Microsoft.Windows.Widgets.Providers.IWidgetProvider2";
/* [object, uuid("38C3A963-DD93-479D-9276-04BF84EE1816"), contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2Vtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2 * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2 * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2 * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2 * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2 * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2 * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *OnCustomizationRequested )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2 * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetCustomizationRequestedArgs * customizationRequestedArgs
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2Vtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2Vtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_OnCustomizationRequested(This,customizationRequestedArgs) \
    ( (This)->lpVtbl->OnCustomizationRequested(This,customizationRequestedArgs) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProvider2_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetProviderAnalytics
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetProviderAnalytics[] = L"Microsoft.Windows.Widgets.Providers.IWidgetProviderAnalytics";
/* [object, uuid("661985A5-D187-482D-9EEF-6FDA05D21845"), contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalyticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *OnAnalyticsInfoReported )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetAnalyticsInfoReportedArgs * args
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalyticsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalyticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_OnAnalyticsInfoReported(This,args) \
    ( (This)->lpVtbl->OnAnalyticsInfoReported(This,args) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderAnalytics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetProviderErrors
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetProviderErrors[] = L"Microsoft.Windows.Widgets.Providers.IWidgetProviderErrors";
/* [object, uuid("90C1B5F0-0D3A-4AC6-ABB7-C97B367B8FCC"), contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrorsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *OnErrorInfoReported )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetErrorInfoReportedArgs * args
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrorsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrorsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_OnErrorInfoReported(This,args) \
    ( (This)->lpVtbl->OnErrorInfoReported(This,args) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderErrors_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetProviderMessage
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetProviderMessage[] = L"Microsoft.Windows.Widgets.Providers.IWidgetProviderMessage";
/* [object, uuid("EA4DC186-9E24-4B35-A5EF-A9F5DF72D6AC"), contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessageVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *OnMessageReceived )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetMessageReceivedArgs * args
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessageVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessageVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_OnMessageReceived(This,args) \
    ( (This)->lpVtbl->OnMessageReceived(This,args) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetProviderMessage_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetResourceProvider
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetResourceProvider[] = L"Microsoft.Windows.Widgets.Providers.IWidgetResourceProvider";
/* [object, uuid("DCF328C0-012C-40F5-BB28-3A1C714D027D"), contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProviderVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *OnResourceRequested )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs * args
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProviderVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProviderVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_OnResourceRequested(This,args) \
    ( (This)->lpVtbl->OnResourceRequested(This,args) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceProvider_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetResourceRequest
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetResourceRequest
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetResourceRequest[] = L"Microsoft.Windows.Widgets.Providers.IWidgetResourceRequest";
/* [object, uuid("113D249F-82D9-57CB-8CEA-9A5291F2FE22"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Uri )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Method )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Method )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest * This,
        /* [in] */HSTRING value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Content )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest * This,
        /* [retval, out] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStreamReference * * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Content )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest * This,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStreamReference * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Headers )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest * This,
        /* [retval, out] */__FIMap_2_HSTRING_HSTRING * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_get_Uri(This,value) \
    ( (This)->lpVtbl->get_Uri(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_get_Method(This,value) \
    ( (This)->lpVtbl->get_Method(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_put_Method(This,value) \
    ( (This)->lpVtbl->put_Method(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_get_Content(This,value) \
    ( (This)->lpVtbl->get_Content(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_put_Content(This,value) \
    ( (This)->lpVtbl->put_Content(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_get_Headers(This,value) \
    ( (This)->lpVtbl->get_Headers(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetResourceRequestedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetResourceRequestedArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetResourceRequestedArgs[] = L"Microsoft.Windows.Widgets.Providers.IWidgetResourceRequestedArgs";
/* [object, uuid("2BB30F4D-0166-58E3-AAF6-31B2AE970BCD"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_WidgetContext )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetContext * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Request )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequest * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Response )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse * * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Response )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse * value
        );
    HRESULT ( STDMETHODCALLTYPE *GetDeferral )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CIDeferral * * result
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_get_WidgetContext(This,value) \
    ( (This)->lpVtbl->get_WidgetContext(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_get_Request(This,value) \
    ( (This)->lpVtbl->get_Request(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_get_Response(This,value) \
    ( (This)->lpVtbl->get_Response(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_put_Response(This,value) \
    ( (This)->lpVtbl->put_Response(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_GetDeferral(This,result) \
    ( (This)->lpVtbl->GetDeferral(This,result) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceRequestedArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetResourceResponse
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetResourceResponse
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetResourceResponse[] = L"Microsoft.Windows.Widgets.Providers.IWidgetResourceResponse";
/* [object, uuid("03A2D32C-2E9E-54A3-B084-1479D5060F80"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Content )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse * This,
        /* [retval, out] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStreamReference * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Headers )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse * This,
        /* [retval, out] */__FIMap_2_HSTRING_HSTRING * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_ReasonPhrase )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_StatusCode )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse * This,
        /* [retval, out] */INT32 * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_get_Content(This,value) \
    ( (This)->lpVtbl->get_Content(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_get_Headers(This,value) \
    ( (This)->lpVtbl->get_Headers(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_get_ReasonPhrase(This,value) \
    ( (This)->lpVtbl->get_ReasonPhrase(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_get_StatusCode(This,value) \
    ( (This)->lpVtbl->get_StatusCode(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetResourceResponseFactory
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetResourceResponse
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetResourceResponseFactory[] = L"Microsoft.Windows.Widgets.Providers.IWidgetResourceResponseFactory";
/* [object, uuid("08881EF1-A78A-5804-B070-9153A8657F85"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateInstance )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory * This,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStreamReference * content,
        /* [in] */HSTRING reasonPhrase,
        /* [in] */INT32 statusCode,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponse * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactoryVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_CreateInstance(This,content,reasonPhrase,statusCode,value) \
    ( (This)->lpVtbl->CreateInstance(This,content,reasonPhrase,statusCode,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetResourceResponseFactory_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetUpdateRequestOptions
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetUpdateRequestOptions[] = L"Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions";
/* [object, uuid("B09CA8F7-7424-5687-BAAF-7DD6FA639672"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_WidgetId )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Template )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Template )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions * This,
        /* [in] */HSTRING value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Data )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Data )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions * This,
        /* [in] */HSTRING value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_CustomState )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_CustomState )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions * This,
        /* [in] */HSTRING value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_get_WidgetId(This,value) \
    ( (This)->lpVtbl->get_WidgetId(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_get_Template(This,value) \
    ( (This)->lpVtbl->get_Template(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_put_Template(This,value) \
    ( (This)->lpVtbl->put_Template(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_get_Data(This,value) \
    ( (This)->lpVtbl->get_Data(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_put_Data(This,value) \
    ( (This)->lpVtbl->put_Data(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_get_CustomState(This,value) \
    ( (This)->lpVtbl->get_CustomState(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_put_CustomState(This,value) \
    ( (This)->lpVtbl->put_CustomState(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions2
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 9.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetUpdateRequestOptions
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x90000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetUpdateRequestOptions2[] = L"Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions2";
/* [object, uuid("77C4EFC4-38F3-57A5-ABA1-F83F257B899E"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2Vtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2 * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2 * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2 * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2 * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2 * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2 * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_IsPlaceholderContent )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2 * This,
        /* [retval, out] */__FIReference_1_boolean * * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_IsPlaceholderContent )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2 * This,
        /* [in] */__FIReference_1_boolean * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2Vtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2Vtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_get_IsPlaceholderContent(This,value) \
    ( (This)->lpVtbl->get_IsPlaceholderContent(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_put_IsPlaceholderContent(This,value) \
    ( (This)->lpVtbl->put_IsPlaceholderContent(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions2_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x90000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions3
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 11.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetUpdateRequestOptions
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0xb0000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetUpdateRequestOptions3[] = L"Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions3";
/* [object, uuid("A78E2A8B-A26C-596A-ADE3-DB8F4C72FE02"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3Vtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3 * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3 * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3 * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3 * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3 * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3 * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Rank )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3 * This,
        /* [retval, out] */__FIReference_1_int * * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Rank )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3 * This,
        /* [in] */__FIReference_1_int * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3Vtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3Vtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_get_Rank(This,value) \
    ( (This)->lpVtbl->get_Rank(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_put_Rank(This,value) \
    ( (This)->lpVtbl->put_Rank(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions3_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0xb0000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptionsFactory
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetUpdateRequestOptions
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetUpdateRequestOptionsFactory[] = L"Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptionsFactory";
/* [object, uuid("E0E00AF8-1D10-57A8-9419-3F568E854DAA"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateInstance )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory * This,
        /* [in] */HSTRING widgetId,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptions * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactoryVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_CreateInstance(This,widgetId,value) \
    ( (This)->lpVtbl->CreateInstance(This,widgetId,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsFactory_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptionsStatics
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Providers.WidgetUpdateRequestOptions
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Providers_IWidgetUpdateRequestOptionsStatics[] = L"Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptionsStatics";
/* [object, uuid("4645B5E3-D332-5D11-82F0-3607E5DF6018"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_UnsetValue )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics * This,
        /* [retval, out] */HSTRING * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStaticsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_get_UnsetValue(This,value) \
    ( (This)->lpVtbl->get_UnsetValue(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CProviders_CIWidgetUpdateRequestOptionsStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetActionInvokedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetActionInvokedArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetActionInvokedArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetActionInvokedArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetActionInvokedArgs[] = L"Microsoft.Windows.Widgets.Providers.WidgetActionInvokedArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetAnalyticsInfoReportedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetAnalyticsInfoReportedArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetAnalyticsInfoReportedArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetAnalyticsInfoReportedArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetAnalyticsInfoReportedArgs[] = L"Microsoft.Windows.Widgets.Providers.WidgetAnalyticsInfoReportedArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetContext
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetContext ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetContext_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetContext_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetContext[] = L"Microsoft.Windows.Widgets.Providers.WidgetContext";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetContextChangedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetContextChangedArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetContextChangedArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetContextChangedArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetContextChangedArgs[] = L"Microsoft.Windows.Widgets.Providers.WidgetContextChangedArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetCustomizationRequestedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetCustomizationRequestedArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetCustomizationRequestedArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetCustomizationRequestedArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetCustomizationRequestedArgs[] = L"Microsoft.Windows.Widgets.Providers.WidgetCustomizationRequestedArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetErrorInfoReportedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 2.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetErrorInfoReportedArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetErrorInfoReportedArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetErrorInfoReportedArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetErrorInfoReportedArgs[] = L"Microsoft.Windows.Widgets.Providers.WidgetErrorInfoReportedArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x20000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetInfo
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetInfo ** Default Interface **
 *    Microsoft.Windows.Widgets.Providers.IWidgetInfo2
 *    Microsoft.Windows.Widgets.Providers.IWidgetInfo3
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetInfo_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetInfo_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetInfo[] = L"Microsoft.Windows.Widgets.Providers.WidgetInfo";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetManager
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.Widgets.Providers.IWidgetManagerStatics interface starting with version 1.0 of the Microsoft.Windows.Widgets.WidgetContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetManager ** Default Interface **
 *    Microsoft.Windows.Widgets.Providers.IWidgetManager2
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetManager_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetManager_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetManager[] = L"Microsoft.Windows.Widgets.Providers.WidgetManager";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetMessageReceivedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetMessageReceivedArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetMessageReceivedArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetMessageReceivedArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetMessageReceivedArgs[] = L"Microsoft.Windows.Widgets.Providers.WidgetMessageReceivedArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetResourceRequest
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetResourceRequest ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetResourceRequest_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetResourceRequest_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetResourceRequest[] = L"Microsoft.Windows.Widgets.Providers.WidgetResourceRequest";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetResourceRequestedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetResourceRequestedArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetResourceRequestedArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetResourceRequestedArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetResourceRequestedArgs[] = L"Microsoft.Windows.Widgets.Providers.WidgetResourceRequestedArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetResourceResponse
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 6.0
 *
 *
 * RuntimeClass can be activated.
 *   Type can be activated via the Microsoft.Windows.Widgets.Providers.IWidgetResourceResponseFactory interface starting with version 6.0 of the Microsoft.Windows.Widgets.WidgetContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetResourceResponse ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetResourceResponse_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetResourceResponse_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetResourceResponse[] = L"Microsoft.Windows.Widgets.Providers.WidgetResourceResponse";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x60000


/*
 *
 * Class Microsoft.Windows.Widgets.Providers.WidgetUpdateRequestOptions
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 1.0
 *
 *
 * RuntimeClass can be activated.
 *   Type can be activated via the Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptionsFactory interface starting with version 1.0 of the Microsoft.Windows.Widgets.WidgetContract API contract
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptionsStatics interface starting with version 1.0 of the Microsoft.Windows.Widgets.WidgetContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions ** Default Interface **
 *    Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions2
 *    Microsoft.Windows.Widgets.Providers.IWidgetUpdateRequestOptions3
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetUpdateRequestOptions_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Providers_WidgetUpdateRequestOptions_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Providers_WidgetUpdateRequestOptions[] = L"Microsoft.Windows.Widgets.Providers.WidgetUpdateRequestOptions";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x10000





#endif // defined(__cplusplus)
#pragma pop_macro("MIDL_CONST_ID")
// Restore the original value of the 'DEPRECATED' macro
#pragma pop_macro("DEPRECATED")

#ifdef __clang__
#pragma clang diagnostic pop // deprecated-declarations
#else
#pragma warning(pop)
#endif
#endif // __microsoft2Ewindows2Ewidgets2Eproviders_p_h__

#endif // __microsoft2Ewindows2Ewidgets2Eproviders_h__
