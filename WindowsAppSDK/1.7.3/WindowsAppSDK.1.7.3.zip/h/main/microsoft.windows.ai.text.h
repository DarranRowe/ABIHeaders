
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

/* verify that the <rpcsal.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCSAL_H_VERSION__
#define __REQUIRED_RPCSAL_H_VERSION__ 100
#endif

#include <rpc.h>
#include <rpcndr.h>

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include <windows.h>
#include <ole2.h>
#endif /*COM_NO_WINDOWS_H*/
#ifndef __microsoft2Ewindows2Eai2Etext_h__
#define __microsoft2Ewindows2Eai2Etext_h__
#ifndef __microsoft2Ewindows2Eai2Etext_p_h__
#define __microsoft2Ewindows2Eai2Etext_p_h__


#pragma once

//
// Deprecated attribute support
//

#pragma push_macro("DEPRECATED")
#undef DEPRECATED

#if !defined(DISABLE_WINRT_DEPRECATION)
#if defined(__cplusplus)
#if __cplusplus >= 201402
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#elif defined(_MSC_VER)
#if _MSC_VER >= 1900
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#else
#define DEPRECATED(x) __declspec(deprecated(x))
#define DEPRECATEDENUMERATOR(x)
#endif // _MSC_VER >= 1900
#else // Not Standard C++ or MSVC, ignore the construct.
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  // C++ deprecation
#else // C - disable deprecation
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif
#else // Deprecation is disabled
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  /* DEPRECATED */

// Disable Deprecation for this header, MIDL verifies that cross-type access is acceptable
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#else
#pragma warning(push)
#pragma warning(disable: 4996)
#endif

// Ensure that the setting of the /ns_prefix command line switch is consistent for all headers.
// If you get an error from the compiler indicating "warning C4005: 'CHECK_NS_PREFIX_STATE': macro redefinition", this
// indicates that you have included two different headers with different settings for the /ns_prefix MIDL command line switch
#if !defined(DISABLE_NS_PREFIX_CHECKS)
#define CHECK_NS_PREFIX_STATE "always"
#endif // !defined(DISABLE_NS_PREFIX_CHECKS)


#pragma push_macro("MIDL_CONST_ID")
#undef MIDL_CONST_ID
#define MIDL_CONST_ID const __declspec(selectany)


//  API Contract Inclusion Definitions
#if !defined(SPECIFIC_API_CONTRACT_DEFINITIONS)
#if !defined(MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION)
#define MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION 0x10000
#endif // defined(MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION)

#if !defined(MICROSOFT_WINDOWS_AI_CONTENTSAFETY_CONTENTSAFETYCONTRACT_VERSION)
#define MICROSOFT_WINDOWS_AI_CONTENTSAFETY_CONTENTSAFETYCONTRACT_VERSION 0x10000
#endif // defined(MICROSOFT_WINDOWS_AI_CONTENTSAFETY_CONTENTSAFETYCONTRACT_VERSION)

#if !defined(MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION)
#define MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION 0x20000
#endif // defined(MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION)

#if !defined(MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION)
#define MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION 0x20000
#endif // defined(MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)
#define WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)
#define WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION 0x130000
#endif // defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)
#define WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)
#define WINDOWS_PHONE_PHONECONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)
#define WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)

#if !defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)
#define WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)

#endif // defined(SPECIFIC_API_CONTRACT_DEFINITIONS)


// Header files for imported files
#include "inspectable.h"
#include "AsyncInfo.h"
#include "EventToken.h"
#include "windowscontracts.h"
#include "Windows.Foundation.h"
#include "Microsoft.Windows.AI.h"
#include "Microsoft.Windows.AI.ContentSafety.h"
// Importing Collections header
#include <windows.foundation.collections.h>

#if defined(__cplusplus) && !defined(CINTERFACE)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    interface ILanguageModel;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel ABI::Microsoft::Windows::AI::Text::ILanguageModel

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    interface ILanguageModelContext;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext ABI::Microsoft::Windows::AI::Text::ILanguageModelContext

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    interface ILanguageModelOptions;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions ABI::Microsoft::Windows::AI::Text::ILanguageModelOptions

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    interface ILanguageModelResponseResult;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult ABI::Microsoft::Windows::AI::Text::ILanguageModelResponseResult

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    interface ILanguageModelStatics;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics ABI::Microsoft::Windows::AI::Text::ILanguageModelStatics

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    interface ITextRewriter;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter ABI::Microsoft::Windows::AI::Text::ITextRewriter

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    interface ITextRewriterFactory;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory ABI::Microsoft::Windows::AI::Text::ITextRewriterFactory

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    interface ITextSummarizer;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer ABI::Microsoft::Windows::AI::Text::ITextSummarizer

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    interface ITextSummarizerFactory;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory ABI::Microsoft::Windows::AI::Text::ITextSummarizerFactory

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    interface ITextToTableConverter;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter ABI::Microsoft::Windows::AI::Text::ITextToTableConverter

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    interface ITextToTableConverterFactory;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory ABI::Microsoft::Windows::AI::Text::ITextToTableConverterFactory

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    interface ITextToTableResponseResult;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult ABI::Microsoft::Windows::AI::Text::ITextToTableResponseResult

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    interface ITextToTableRow;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow ABI::Microsoft::Windows::AI::Text::ITextToTableRow

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_FWD_DEFINED__

// Parameterized interface forward declarations (C++)

// Collection interface definitions
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    class LanguageModelResponseResult;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_USE
#define DEF___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("f4a5a68d-50cf-502d-84e5-f41c62830b58"))
IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::Text::LanguageModelResponseResult*,HSTRING> : IAsyncOperationProgressHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Text::LanguageModelResponseResult*, ABI::Microsoft::Windows::AI::Text::ILanguageModelResponseResult*>,HSTRING> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationProgressHandler`2<Microsoft.Windows.AI.Text.LanguageModelResponseResult, String>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::Text::LanguageModelResponseResult*,HSTRING> __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_t;
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING ABI::Windows::Foundation::__FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING ABI::Windows::Foundation::IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::Text::ILanguageModelResponseResult*,HSTRING>
//#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_t ABI::Windows::Foundation::IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::Text::ILanguageModelResponseResult*,HSTRING>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_USE */


#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_USE
#define DEF___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("f936a4d3-cdb2-5356-adc5-adb43b59a6bc"))
IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::Text::LanguageModelResponseResult*,HSTRING> : IAsyncOperationWithProgressCompletedHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Text::LanguageModelResponseResult*, ABI::Microsoft::Windows::AI::Text::ILanguageModelResponseResult*>,HSTRING> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Microsoft.Windows.AI.Text.LanguageModelResponseResult, String>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::Text::LanguageModelResponseResult*,HSTRING> __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_t;
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING ABI::Windows::Foundation::__FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING ABI::Windows::Foundation::IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::Text::ILanguageModelResponseResult*,HSTRING>
//#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_t ABI::Windows::Foundation::IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::Text::ILanguageModelResponseResult*,HSTRING>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_USE */


#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_USE
#define DEF___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("5aec37a6-a5fa-5c0d-9da7-7614e0b4ed76"))
IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::Text::LanguageModelResponseResult*,HSTRING> : IAsyncOperationWithProgress_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Text::LanguageModelResponseResult*, ABI::Microsoft::Windows::AI::Text::ILanguageModelResponseResult*>,HSTRING> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IAsyncOperationWithProgress`2<Microsoft.Windows.AI.Text.LanguageModelResponseResult, String>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::Text::LanguageModelResponseResult*,HSTRING> __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_t;
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING ABI::Windows::Foundation::__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING ABI::Windows::Foundation::IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::Text::ILanguageModelResponseResult*,HSTRING>
//#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_t ABI::Windows::Foundation::IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::Text::ILanguageModelResponseResult*,HSTRING>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_USE */


#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000

namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    class TextToTableResponseResult;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_USE
#define DEF___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("57351f20-f3a6-5410-8284-8c4ccbeee776"))
IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::Text::TextToTableResponseResult*,HSTRING> : IAsyncOperationProgressHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Text::TextToTableResponseResult*, ABI::Microsoft::Windows::AI::Text::ITextToTableResponseResult*>,HSTRING> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationProgressHandler`2<Microsoft.Windows.AI.Text.TextToTableResponseResult, String>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::Text::TextToTableResponseResult*,HSTRING> __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_t;
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING ABI::Windows::Foundation::__FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING ABI::Windows::Foundation::IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::Text::ITextToTableResponseResult*,HSTRING>
//#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_t ABI::Windows::Foundation::IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::Text::ITextToTableResponseResult*,HSTRING>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_USE */


#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_USE
#define DEF___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("1fab5408-2f63-54cd-b5d1-80224a632477"))
IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::Text::TextToTableResponseResult*,HSTRING> : IAsyncOperationWithProgressCompletedHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Text::TextToTableResponseResult*, ABI::Microsoft::Windows::AI::Text::ITextToTableResponseResult*>,HSTRING> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Microsoft.Windows.AI.Text.TextToTableResponseResult, String>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::Text::TextToTableResponseResult*,HSTRING> __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_t;
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING ABI::Windows::Foundation::__FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING ABI::Windows::Foundation::IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::Text::ITextToTableResponseResult*,HSTRING>
//#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_t ABI::Windows::Foundation::IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::Text::ITextToTableResponseResult*,HSTRING>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_USE */


#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_USE
#define DEF___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("cff503d4-0ecb-5924-acbf-796ca6c7d373"))
IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::Text::TextToTableResponseResult*,HSTRING> : IAsyncOperationWithProgress_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Text::TextToTableResponseResult*, ABI::Microsoft::Windows::AI::Text::ITextToTableResponseResult*>,HSTRING> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IAsyncOperationWithProgress`2<Microsoft.Windows.AI.Text.TextToTableResponseResult, String>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::Text::TextToTableResponseResult*,HSTRING> __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_t;
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING ABI::Windows::Foundation::__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING ABI::Windows::Foundation::IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::Text::ITextToTableResponseResult*,HSTRING>
//#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_t ABI::Windows::Foundation::IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::Text::ITextToTableResponseResult*,HSTRING>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_USE */


#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000

namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    class LanguageModel;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel_USE
#define DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("9be75163-9cd2-5a27-8f31-6d6beae7629a"))
IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Text::LanguageModel*> : IAsyncOperationCompletedHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Text::LanguageModel*, ABI::Microsoft::Windows::AI::Text::ILanguageModel*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationCompletedHandler`1<Microsoft.Windows.AI.Text.LanguageModel>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Text::LanguageModel*> __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel_t;
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel ABI::Windows::Foundation::__FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Text::ILanguageModel*>
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel_t ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Text::ILanguageModel*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel_USE */


#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_USE
#define DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("172f62b5-1d49-535f-8c07-4ddd02066f36"))
IAsyncOperation<ABI::Microsoft::Windows::AI::Text::LanguageModel*> : IAsyncOperation_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Text::LanguageModel*, ABI::Microsoft::Windows::AI::Text::ILanguageModel*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IAsyncOperation`1<Microsoft.Windows.AI.Text.LanguageModel>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperation<ABI::Microsoft::Windows::AI::Text::LanguageModel*> __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_t;
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel ABI::Windows::Foundation::__FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Windows::AI::Text::ILanguageModel*>
//#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_t ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Windows::AI::Text::ILanguageModel*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_USE */


#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000

namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                class AIFeatureReadyResult;
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                interface IAIFeatureReadyResult;
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult ABI::Microsoft::Windows::AI::IAIFeatureReadyResult

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult_FWD_DEFINED__


#if MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE
#define DEF___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("5b37e602-8caa-581f-9ece-5dc72ab6ae7e"))
IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*,double> : IAsyncOperationProgressHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*, ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*>,double> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationProgressHandler`2<Microsoft.Windows.AI.AIFeatureReadyResult, Double>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*,double> __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t;
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double ABI::Windows::Foundation::__FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double ABI::Windows::Foundation::IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*,DOUBLE>
//#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t ABI::Windows::Foundation::IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*,DOUBLE>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE */


#endif // MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE
#define DEF___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("ceea7604-5166-549f-8844-03192865a975"))
IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*,double> : IAsyncOperationWithProgressCompletedHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*, ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*>,double> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Microsoft.Windows.AI.AIFeatureReadyResult, Double>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*,double> __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t;
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double ABI::Windows::Foundation::__FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double ABI::Windows::Foundation::IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*,DOUBLE>
//#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t ABI::Windows::Foundation::IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*,DOUBLE>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE */


#endif // MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE
#define DEF___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("39c32af0-c9b4-595f-9e9b-c6c289ad9ea1"))
IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*,double> : IAsyncOperationWithProgress_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*, ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*>,double> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IAsyncOperationWithProgress`2<Microsoft.Windows.AI.AIFeatureReadyResult, Double>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*,double> __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t;
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double ABI::Windows::Foundation::__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double ABI::Windows::Foundation::IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*,DOUBLE>
//#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t ABI::Windows::Foundation::IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*,DOUBLE>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE */


#endif // MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000




namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                
                typedef enum AIFeatureReadyState : int AIFeatureReadyState;
                
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */




namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace ContentSafety {
                    class ContentFilterOptions;
                } /* ContentSafety */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace ContentSafety {
                    interface IContentFilterOptions;
                } /* ContentSafety */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions ABI::Microsoft::Windows::AI::ContentSafety::IContentFilterOptions

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions_FWD_DEFINED__






#ifndef ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Foundation {
            interface IClosable;
        } /* Foundation */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CFoundation_CIClosable ABI::Windows::Foundation::IClosable

#endif // ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__






namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    
                    typedef enum LanguageModelResponseStatus : int LanguageModelResponseStatus;
                    
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */















namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    class LanguageModelContext;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    class LanguageModelOptions;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */



namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    class TextRewriter;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    class TextSummarizer;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    class TextToTableConverter;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */



namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    class TextToTableRow;
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */














/*
 *
 * Struct Microsoft.Windows.AI.Text.LanguageModelResponseStatus
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 */

#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    /* [v1_enum, contract] */
                    enum LanguageModelResponseStatus : int
                    {
                        LanguageModelResponseStatus_Complete = 0,
                        LanguageModelResponseStatus_InProgress = 1,
                        LanguageModelResponseStatus_BlockedByPolicy = 2,
                        LanguageModelResponseStatus_PromptLargerThanContext = 3,
                        LanguageModelResponseStatus_PromptBlockedByContentModeration = 4,
                        LanguageModelResponseStatus_ResponseBlockedByContentModeration = 5,
                        LanguageModelResponseStatus_Error = 6,
                    };
                    
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ILanguageModel
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.LanguageModel
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ILanguageModel[] = L"Microsoft.Windows.AI.Text.ILanguageModel";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    /* [object, uuid("6331C629-8C86-5BFE-8C4E-9CA5573CC14B"), exclusiveto, contract] */
                    MIDL_INTERFACE("6331C629-8C86-5BFE-8C4E-9CA5573CC14B")
                    ILanguageModel : public IInspectable
                    {
                    public:
                        
                    };

                    MIDL_CONST_ID IID & IID_ILanguageModel=__uuidof(ILanguageModel);
                    
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ILanguageModelContext
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.LanguageModelContext
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ILanguageModelContext[] = L"Microsoft.Windows.AI.Text.ILanguageModelContext";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    /* [object, uuid("518B305C-7B69-5A33-8129-D47D6B8EEC4E"), exclusiveto, contract] */
                    MIDL_INTERFACE("518B305C-7B69-5A33-8129-D47D6B8EEC4E")
                    ILanguageModelContext : public IInspectable
                    {
                    public:
                        
                    };

                    MIDL_CONST_ID IID & IID_ILanguageModelContext=__uuidof(ILanguageModelContext);
                    
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ILanguageModelOptions
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.LanguageModelOptions
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ILanguageModelOptions[] = L"Microsoft.Windows.AI.Text.ILanguageModelOptions";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    /* [object, uuid("7F380003-5A09-5F1F-AFB0-AA483E3670CC"), exclusiveto, contract] */
                    MIDL_INTERFACE("7F380003-5A09-5F1F-AFB0-AA483E3670CC")
                    ILanguageModelOptions : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Temperature(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Temperature(
                            /* [in] */FLOAT value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_TopP(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_TopP(
                            /* [in] */FLOAT value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_TopK(
                            /* [retval, out] */UINT32 * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_TopK(
                            /* [in] */UINT32 value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_ContentFilterOptions(
                            /* [retval, out] */ABI::Microsoft::Windows::AI::ContentSafety::IContentFilterOptions * * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_ContentFilterOptions(
                            /* [in] */ABI::Microsoft::Windows::AI::ContentSafety::IContentFilterOptions * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ILanguageModelOptions=__uuidof(ILanguageModelOptions);
                    
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ILanguageModelResponseResult
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.LanguageModelResponseResult
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ILanguageModelResponseResult[] = L"Microsoft.Windows.AI.Text.ILanguageModelResponseResult";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    /* [object, uuid("3A256FFF-A426-5D3B-8E4B-3AC84162471E"), exclusiveto, contract] */
                    MIDL_INTERFACE("3A256FFF-A426-5D3B-8E4B-3AC84162471E")
                    ILanguageModelResponseResult : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Text(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Status(
                            /* [retval, out] */ABI::Microsoft::Windows::AI::Text::LanguageModelResponseStatus * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_ExtendedError(
                            /* [retval, out] */HRESULT * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ILanguageModelResponseResult=__uuidof(ILanguageModelResponseResult);
                    
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ILanguageModelStatics
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.LanguageModel
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ILanguageModelStatics[] = L"Microsoft.Windows.AI.Text.ILanguageModelStatics";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    /* [object, uuid("8F18F9AF-6095-553B-8D9D-6BCC98026546"), exclusiveto, contract] */
                    MIDL_INTERFACE("8F18F9AF-6095-553B-8D9D-6BCC98026546")
                    ILanguageModelStatics : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE GetReadyState(
                            /* [retval, out] */ABI::Microsoft::Windows::AI::AIFeatureReadyState * result
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE EnsureReadyAsync(
                            /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * * operation
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE CreateAsync(
                            /* [retval, out] */__FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel * * operation
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ILanguageModelStatics=__uuidof(ILanguageModelStatics);
                    
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ITextRewriter
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.TextRewriter
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ITextRewriter[] = L"Microsoft.Windows.AI.Text.ITextRewriter";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    /* [object, uuid("EB1E7CF0-E110-506C-B0EA-7A288D8E7778"), exclusiveto, contract] */
                    MIDL_INTERFACE("EB1E7CF0-E110-506C-B0EA-7A288D8E7778")
                    ITextRewriter : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE RewriteAsync(
                            /* [in] */HSTRING text,
                            /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * * operation
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ITextRewriter=__uuidof(ITextRewriter);
                    
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ITextRewriterFactory
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.TextRewriter
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ITextRewriterFactory[] = L"Microsoft.Windows.AI.Text.ITextRewriterFactory";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    /* [object, uuid("F452E60D-EF50-5BC9-B483-217D5B4E7151"), exclusiveto, contract] */
                    MIDL_INTERFACE("F452E60D-EF50-5BC9-B483-217D5B4E7151")
                    ITextRewriterFactory : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE CreateInstance(
                            /* [in] */ABI::Microsoft::Windows::AI::Text::ILanguageModel * languageModel,
                            /* [retval, out] */ABI::Microsoft::Windows::AI::Text::ITextRewriter * * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ITextRewriterFactory=__uuidof(ITextRewriterFactory);
                    
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ITextSummarizer
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 2.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.TextSummarizer
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x20000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ITextSummarizer[] = L"Microsoft.Windows.AI.Text.ITextSummarizer";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    /* [object, uuid("EEF548C5-D7BC-50BE-A8AB-29E241B78BD1"), exclusiveto, contract] */
                    MIDL_INTERFACE("EEF548C5-D7BC-50BE-A8AB-29E241B78BD1")
                    ITextSummarizer : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE SummarizeAsync(
                            /* [in] */HSTRING text,
                            /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * * operation
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SummarizeParagraphAsync(
                            /* [in] */HSTRING text,
                            /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * * operation
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ITextSummarizer=__uuidof(ITextSummarizer);
                    
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x20000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ITextSummarizerFactory
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 2.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.TextSummarizer
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x20000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ITextSummarizerFactory[] = L"Microsoft.Windows.AI.Text.ITextSummarizerFactory";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    /* [object, uuid("B6A75913-4A1E-59E7-856A-AE7AB2383864"), exclusiveto, contract] */
                    MIDL_INTERFACE("B6A75913-4A1E-59E7-856A-AE7AB2383864")
                    ITextSummarizerFactory : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE CreateInstance(
                            /* [in] */ABI::Microsoft::Windows::AI::Text::ILanguageModel * languageModel,
                            /* [retval, out] */ABI::Microsoft::Windows::AI::Text::ITextSummarizer * * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ITextSummarizerFactory=__uuidof(ITextSummarizerFactory);
                    
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x20000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ITextToTableConverter
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.TextToTableConverter
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ITextToTableConverter[] = L"Microsoft.Windows.AI.Text.ITextToTableConverter";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    /* [object, uuid("A008D9AD-25CE-5A6B-9CEB-D8E95D04E10B"), exclusiveto, contract] */
                    MIDL_INTERFACE("A008D9AD-25CE-5A6B-9CEB-D8E95D04E10B")
                    ITextToTableConverter : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE ConvertAsync(
                            /* [in] */HSTRING text,
                            /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * * operation
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ITextToTableConverter=__uuidof(ITextToTableConverter);
                    
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ITextToTableConverterFactory
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.TextToTableConverter
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ITextToTableConverterFactory[] = L"Microsoft.Windows.AI.Text.ITextToTableConverterFactory";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    /* [object, uuid("BB84CBB5-19C8-5857-B65D-705AA1486404"), exclusiveto, contract] */
                    MIDL_INTERFACE("BB84CBB5-19C8-5857-B65D-705AA1486404")
                    ITextToTableConverterFactory : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE CreateInstance(
                            /* [in] */ABI::Microsoft::Windows::AI::Text::ILanguageModel * languageModel,
                            /* [retval, out] */ABI::Microsoft::Windows::AI::Text::ITextToTableConverter * * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ITextToTableConverterFactory=__uuidof(ITextToTableConverterFactory);
                    
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ITextToTableResponseResult
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.TextToTableResponseResult
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ITextToTableResponseResult[] = L"Microsoft.Windows.AI.Text.ITextToTableResponseResult";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    /* [object, uuid("391FBF11-59CD-575D-834A-9EF823116F98"), exclusiveto, contract] */
                    MIDL_INTERFACE("391FBF11-59CD-575D-834A-9EF823116F98")
                    ITextToTableResponseResult : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE GetRows(
                            /* [out] */UINT32 * __resultSize,
                            /* [size_is(, *(__resultSize)), retval, out] */ABI::Microsoft::Windows::AI::Text::ITextToTableRow * * * result
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Status(
                            /* [retval, out] */ABI::Microsoft::Windows::AI::Text::LanguageModelResponseStatus * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_ExtendedError(
                            /* [retval, out] */HRESULT * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ITextToTableResponseResult=__uuidof(ITextToTableResponseResult);
                    
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ITextToTableRow
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.TextToTableRow
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ITextToTableRow[] = L"Microsoft.Windows.AI.Text.ITextToTableRow";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Text {
                    /* [object, uuid("036294FE-E53C-5E66-93D2-7C92338DB881"), exclusiveto, contract] */
                    MIDL_INTERFACE("036294FE-E53C-5E66-93D2-7C92338DB881")
                    ITextToTableRow : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE GetColumns(
                            /* [out] */UINT32 * __resultSize,
                            /* [size_is(, *(__resultSize)), retval, out] */HSTRING * * result
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ITextToTableRow=__uuidof(ITextToTableRow);
                    
                } /* Text */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Text.LanguageModel
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.AI.Text.ILanguageModelStatics interface starting with version 1.0 of the Microsoft.Windows.AI.Text.LanguageModelContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ILanguageModel ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_LanguageModel_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_LanguageModel_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_LanguageModel[] = L"Microsoft.Windows.AI.Text.LanguageModel";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Text.LanguageModelContext
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ILanguageModelContext ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_LanguageModelContext_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_LanguageModelContext_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_LanguageModelContext[] = L"Microsoft.Windows.AI.Text.LanguageModelContext";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Text.LanguageModelOptions
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * RuntimeClass can be activated.
 *   Type can be activated via RoActivateInstance starting with version 1.0 of the Microsoft.Windows.AI.Text.LanguageModelContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ILanguageModelOptions ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_LanguageModelOptions_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_LanguageModelOptions_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_LanguageModelOptions[] = L"Microsoft.Windows.AI.Text.LanguageModelOptions";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Text.LanguageModelResponseResult
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ILanguageModelResponseResult ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_LanguageModelResponseResult_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_LanguageModelResponseResult_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_LanguageModelResponseResult[] = L"Microsoft.Windows.AI.Text.LanguageModelResponseResult";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Text.TextRewriter
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * RuntimeClass can be activated.
 *   Type can be activated via the Microsoft.Windows.AI.Text.ITextRewriterFactory interface starting with version 1.0 of the Microsoft.Windows.AI.Text.TextIntelligenceContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ITextRewriter ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_TextRewriter_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_TextRewriter_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_TextRewriter[] = L"Microsoft.Windows.AI.Text.TextRewriter";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Text.TextSummarizer
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 2.0
 *
 *
 * RuntimeClass can be activated.
 *   Type can be activated via the Microsoft.Windows.AI.Text.ITextSummarizerFactory interface starting with version 2.0 of the Microsoft.Windows.AI.Text.TextIntelligenceContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ITextSummarizer ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x20000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_TextSummarizer_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_TextSummarizer_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_TextSummarizer[] = L"Microsoft.Windows.AI.Text.TextSummarizer";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x20000


/*
 *
 * Class Microsoft.Windows.AI.Text.TextToTableConverter
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * RuntimeClass can be activated.
 *   Type can be activated via the Microsoft.Windows.AI.Text.ITextToTableConverterFactory interface starting with version 1.0 of the Microsoft.Windows.AI.Text.TextIntelligenceContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ITextToTableConverter ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_TextToTableConverter_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_TextToTableConverter_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_TextToTableConverter[] = L"Microsoft.Windows.AI.Text.TextToTableConverter";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Text.TextToTableResponseResult
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ITextToTableResponseResult ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_TextToTableResponseResult_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_TextToTableResponseResult_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_TextToTableResponseResult[] = L"Microsoft.Windows.AI.Text.TextToTableResponseResult";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Text.TextToTableRow
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ITextToTableRow ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_TextToTableRow_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_TextToTableRow_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_TextToTableRow[] = L"Microsoft.Windows.AI.Text.TextToTableRow";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000





#else // !defined(__cplusplus)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_FWD_DEFINED__

// Parameterized interface forward declarations (C)

// Collection interface definitions

#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_INTERFACE_DEFINED__)
#define ____FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING;

typedef interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING;

typedef struct __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRINGVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This, /* [in] */ __RPC__in_opt __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING *asyncInfo, /* [in] */ HSTRING progressInfo);
    END_INTERFACE
} __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRINGVtbl;

interface __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING
{
    CONST_VTBL struct __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRINGVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_Invoke(This,asyncInfo,progressInfo)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,progressInfo) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_INTERFACE_DEFINED__)
#define ____FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING;

//  Forward declare the async operation.
typedef interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING;

typedef struct __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRINGVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This, /* [in] */ __RPC__in_opt __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING *asyncInfo, /* [in] */ AsyncStatus status);
    END_INTERFACE
} __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRINGVtbl;

interface __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING
{
    CONST_VTBL struct __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRINGVtbl *lpVtbl;
};



#ifdef COBJMACROS
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_Invoke(This,asyncInfo,status)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,status) ) 
#endif /* COBJMACROS */



#endif // ____FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_INTERFACE_DEFINED__)
#define ____FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING;

typedef struct __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRINGVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Progress )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This, /* [in] */ __RPC__in_opt __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Progress )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING **handler);
    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Completed )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This, /* [in] */ __RPC__in_opt __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Completed )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING **handler);
    HRESULT ( STDMETHODCALLTYPE *GetResults )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * This, /* [retval][out] */ __RPC__deref_out_opt __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult * *results);
    END_INTERFACE
} __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRINGVtbl;

interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING
{
    CONST_VTBL struct __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRINGVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_put_Progress(This,handler)	\
    ( (This)->lpVtbl -> put_Progress(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_get_Progress(This,handler)	\
    ( (This)->lpVtbl -> get_Progress(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_put_Completed(This,handler)	\
    ( (This)->lpVtbl -> put_Completed(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_get_Completed(This,handler)	\
    ( (This)->lpVtbl -> get_Completed(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_GetResults(This,results)	\
    ( (This)->lpVtbl -> GetResults(This,results) ) 
#endif /* COBJMACROS */



#endif // ____FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_INTERFACE_DEFINED__)
#define ____FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING;

typedef interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING;

typedef struct __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRINGVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This, /* [in] */ __RPC__in_opt __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING *asyncInfo, /* [in] */ HSTRING progressInfo);
    END_INTERFACE
} __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRINGVtbl;

interface __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING
{
    CONST_VTBL struct __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRINGVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_Invoke(This,asyncInfo,progressInfo)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,progressInfo) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_INTERFACE_DEFINED__)
#define ____FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING;

//  Forward declare the async operation.
typedef interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING;

typedef struct __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRINGVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This, /* [in] */ __RPC__in_opt __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING *asyncInfo, /* [in] */ AsyncStatus status);
    END_INTERFACE
} __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRINGVtbl;

interface __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING
{
    CONST_VTBL struct __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRINGVtbl *lpVtbl;
};



#ifdef COBJMACROS
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_Invoke(This,asyncInfo,status)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,status) ) 
#endif /* COBJMACROS */



#endif // ____FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_INTERFACE_DEFINED__)
#define ____FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING;

typedef struct __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRINGVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Progress )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This, /* [in] */ __RPC__in_opt __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Progress )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING **handler);
    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Completed )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This, /* [in] */ __RPC__in_opt __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Completed )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING **handler);
    HRESULT ( STDMETHODCALLTYPE *GetResults )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * This, /* [retval][out] */ __RPC__deref_out_opt __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult * *results);
    END_INTERFACE
} __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRINGVtbl;

interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING
{
    CONST_VTBL struct __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRINGVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_put_Progress(This,handler)	\
    ( (This)->lpVtbl -> put_Progress(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_get_Progress(This,handler)	\
    ( (This)->lpVtbl -> get_Progress(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_put_Completed(This,handler)	\
    ( (This)->lpVtbl -> put_Completed(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_get_Completed(This,handler)	\
    ( (This)->lpVtbl -> get_Completed(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_GetResults(This,results)	\
    ( (This)->lpVtbl -> GetResults(This,results) ) 
#endif /* COBJMACROS */



#endif // ____FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel_INTERFACE_DEFINED__)
#define ____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel;

// Forward declare the async operation.
typedef interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel;

typedef struct __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModelVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel * This,/* [in] */ __RPC__in_opt __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel *asyncInfo, /* [in] */ AsyncStatus status);
    END_INTERFACE
} __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModelVtbl;

interface __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel
{
    CONST_VTBL struct __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModelVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel_Invoke(This,asyncInfo,status)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,status) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_INTERFACE_DEFINED__)
#define ____FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_INTERFACE_DEFINED__

typedef interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel;

typedef struct __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModelVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel * This, /* [in] */ __RPC__in_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CText__CLanguageModel **handler);
    HRESULT ( STDMETHODCALLTYPE *GetResults )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel * This, /* [retval][out] */ __RPC__out __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel * *results);
    END_INTERFACE
} __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModelVtbl;

interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel
{
    CONST_VTBL struct __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModelVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_put_Completed(This,handler)	\
    ( (This)->lpVtbl -> put_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_get_Completed(This,handler)	\
    ( (This)->lpVtbl -> get_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_GetResults(This,results)	\
    ( (This)->lpVtbl -> GetResults(This,results) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult __x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult_FWD_DEFINED__


#if MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__)
#define ____FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double;

typedef interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double;

typedef struct __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [in] */ __RPC__in_opt __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double *asyncInfo, /* [in] */ double progressInfo);
    END_INTERFACE
} __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl;

interface __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double
{
    CONST_VTBL struct __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_Invoke(This,asyncInfo,progressInfo)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,progressInfo) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__)
#define ____FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double;

//  Forward declare the async operation.
typedef interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double;

typedef struct __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [in] */ __RPC__in_opt __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double *asyncInfo, /* [in] */ AsyncStatus status);
    END_INTERFACE
} __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl;

interface __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double
{
    CONST_VTBL struct __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl *lpVtbl;
};



#ifdef COBJMACROS
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_Invoke(This,asyncInfo,status)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,status) ) 
#endif /* COBJMACROS */



#endif // ____FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__)
#define ____FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double;

typedef struct __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Progress )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [in] */ __RPC__in_opt __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Progress )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double **handler);
    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Completed )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [in] */ __RPC__in_opt __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Completed )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double **handler);
    HRESULT ( STDMETHODCALLTYPE *GetResults )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [retval][out] */ __RPC__deref_out_opt __x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult * *results);
    END_INTERFACE
} __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl;

interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double
{
    CONST_VTBL struct __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_put_Progress(This,handler)	\
    ( (This)->lpVtbl -> put_Progress(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_get_Progress(This,handler)	\
    ( (This)->lpVtbl -> get_Progress(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_put_Completed(This,handler)	\
    ( (This)->lpVtbl -> put_Completed(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_get_Completed(This,handler)	\
    ( (This)->lpVtbl -> get_Completed(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_GetResults(This,results)	\
    ( (This)->lpVtbl -> GetResults(This,results) ) 
#endif /* COBJMACROS */



#endif // ____FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000




typedef enum __x_ABI_CMicrosoft_CWindows_CAI_CAIFeatureReadyState __x_ABI_CMicrosoft_CWindows_CAI_CAIFeatureReadyState;




#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions __x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions_FWD_DEFINED__






#ifndef ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CFoundation_CIClosable __x_ABI_CWindows_CFoundation_CIClosable;

#endif // ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__







typedef enum __x_ABI_CMicrosoft_CWindows_CAI_CText_CLanguageModelResponseStatus __x_ABI_CMicrosoft_CWindows_CAI_CText_CLanguageModelResponseStatus;



































/*
 *
 * Struct Microsoft.Windows.AI.Text.LanguageModelResponseStatus
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 */

#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000
/* [v1_enum, contract] */
enum __x_ABI_CMicrosoft_CWindows_CAI_CText_CLanguageModelResponseStatus
{
    LanguageModelResponseStatus_Complete = 0,
    LanguageModelResponseStatus_InProgress = 1,
    LanguageModelResponseStatus_BlockedByPolicy = 2,
    LanguageModelResponseStatus_PromptLargerThanContext = 3,
    LanguageModelResponseStatus_PromptBlockedByContentModeration = 4,
    LanguageModelResponseStatus_ResponseBlockedByContentModeration = 5,
    LanguageModelResponseStatus_Error = 6,
};
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ILanguageModel
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.LanguageModel
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ILanguageModel[] = L"Microsoft.Windows.AI.Text.ILanguageModel";
/* [object, uuid("6331C629-8C86-5BFE-8C4E-9CA5573CC14B"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ILanguageModelContext
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.LanguageModelContext
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ILanguageModelContext[] = L"Microsoft.Windows.AI.Text.ILanguageModelContext";
/* [object, uuid("518B305C-7B69-5A33-8129-D47D6B8EEC4E"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContextVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContextVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContextVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelContext_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ILanguageModelOptions
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.LanguageModelOptions
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ILanguageModelOptions[] = L"Microsoft.Windows.AI.Text.ILanguageModelOptions";
/* [object, uuid("7F380003-5A09-5F1F-AFB0-AA483E3670CC"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptionsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Temperature )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Temperature )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions * This,
        /* [in] */FLOAT value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_TopP )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_TopP )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions * This,
        /* [in] */FLOAT value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_TopK )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions * This,
        /* [retval, out] */UINT32 * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_TopK )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions * This,
        /* [in] */UINT32 value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_ContentFilterOptions )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions * * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_ContentFilterOptions )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptionsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptionsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_get_Temperature(This,value) \
    ( (This)->lpVtbl->get_Temperature(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_put_Temperature(This,value) \
    ( (This)->lpVtbl->put_Temperature(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_get_TopP(This,value) \
    ( (This)->lpVtbl->get_TopP(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_put_TopP(This,value) \
    ( (This)->lpVtbl->put_TopP(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_get_TopK(This,value) \
    ( (This)->lpVtbl->get_TopK(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_put_TopK(This,value) \
    ( (This)->lpVtbl->put_TopK(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_get_ContentFilterOptions(This,value) \
    ( (This)->lpVtbl->get_ContentFilterOptions(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_put_ContentFilterOptions(This,value) \
    ( (This)->lpVtbl->put_ContentFilterOptions(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelOptions_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ILanguageModelResponseResult
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.LanguageModelResponseResult
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ILanguageModelResponseResult[] = L"Microsoft.Windows.AI.Text.ILanguageModelResponseResult";
/* [object, uuid("3A256FFF-A426-5D3B-8E4B-3AC84162471E"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResultVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Text )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Status )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CText_CLanguageModelResponseStatus * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_ExtendedError )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult * This,
        /* [retval, out] */HRESULT * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResultVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResultVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_get_Text(This,value) \
    ( (This)->lpVtbl->get_Text(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_get_Status(This,value) \
    ( (This)->lpVtbl->get_Status(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_get_ExtendedError(This,value) \
    ( (This)->lpVtbl->get_ExtendedError(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelResponseResult_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ILanguageModelStatics
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.LanguageModel
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ILanguageModelStatics[] = L"Microsoft.Windows.AI.Text.ILanguageModelStatics";
/* [object, uuid("8F18F9AF-6095-553B-8D9D-6BCC98026546"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *GetReadyState )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CAIFeatureReadyState * result
        );
    HRESULT ( STDMETHODCALLTYPE *EnsureReadyAsync )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics * This,
        /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * * operation
        );
    HRESULT ( STDMETHODCALLTYPE *CreateAsync )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics * This,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CWindows__CAI__CText__CLanguageModel * * operation
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStaticsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_GetReadyState(This,result) \
    ( (This)->lpVtbl->GetReadyState(This,result) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_EnsureReadyAsync(This,operation) \
    ( (This)->lpVtbl->EnsureReadyAsync(This,operation) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_CreateAsync(This,operation) \
    ( (This)->lpVtbl->CreateAsync(This,operation) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModelStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ITextRewriter
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.TextRewriter
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ITextRewriter[] = L"Microsoft.Windows.AI.Text.ITextRewriter";
/* [object, uuid("EB1E7CF0-E110-506C-B0EA-7A288D8E7778"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *RewriteAsync )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter * This,
        /* [in] */HSTRING text,
        /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * * operation
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_RewriteAsync(This,text,operation) \
    ( (This)->lpVtbl->RewriteAsync(This,text,operation) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ITextRewriterFactory
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.TextRewriter
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ITextRewriterFactory[] = L"Microsoft.Windows.AI.Text.ITextRewriterFactory";
/* [object, uuid("F452E60D-EF50-5BC9-B483-217D5B4E7151"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateInstance )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel * languageModel,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriter * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactoryVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_CreateInstance(This,languageModel,value) \
    ( (This)->lpVtbl->CreateInstance(This,languageModel,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextRewriterFactory_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ITextSummarizer
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 2.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.TextSummarizer
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x20000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ITextSummarizer[] = L"Microsoft.Windows.AI.Text.ITextSummarizer";
/* [object, uuid("EEF548C5-D7BC-50BE-A8AB-29E241B78BD1"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *SummarizeAsync )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer * This,
        /* [in] */HSTRING text,
        /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * * operation
        );
    HRESULT ( STDMETHODCALLTYPE *SummarizeParagraphAsync )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer * This,
        /* [in] */HSTRING text,
        /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CLanguageModelResponseResult_HSTRING * * operation
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_SummarizeAsync(This,text,operation) \
    ( (This)->lpVtbl->SummarizeAsync(This,text,operation) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_SummarizeParagraphAsync(This,text,operation) \
    ( (This)->lpVtbl->SummarizeParagraphAsync(This,text,operation) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x20000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ITextSummarizerFactory
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 2.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.TextSummarizer
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x20000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ITextSummarizerFactory[] = L"Microsoft.Windows.AI.Text.ITextSummarizerFactory";
/* [object, uuid("B6A75913-4A1E-59E7-856A-AE7AB2383864"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateInstance )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel * languageModel,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizer * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactoryVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_CreateInstance(This,languageModel,value) \
    ( (This)->lpVtbl->CreateInstance(This,languageModel,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextSummarizerFactory_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x20000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ITextToTableConverter
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.TextToTableConverter
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ITextToTableConverter[] = L"Microsoft.Windows.AI.Text.ITextToTableConverter";
/* [object, uuid("A008D9AD-25CE-5A6B-9CEB-D8E95D04E10B"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *ConvertAsync )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter * This,
        /* [in] */HSTRING text,
        /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CText__CTextToTableResponseResult_HSTRING * * operation
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_ConvertAsync(This,text,operation) \
    ( (This)->lpVtbl->ConvertAsync(This,text,operation) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ITextToTableConverterFactory
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.TextToTableConverter
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ITextToTableConverterFactory[] = L"Microsoft.Windows.AI.Text.ITextToTableConverterFactory";
/* [object, uuid("BB84CBB5-19C8-5857-B65D-705AA1486404"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateInstance )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CAI_CText_CILanguageModel * languageModel,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverter * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactoryVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_CreateInstance(This,languageModel,value) \
    ( (This)->lpVtbl->CreateInstance(This,languageModel,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableConverterFactory_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ITextToTableResponseResult
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.TextToTableResponseResult
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ITextToTableResponseResult[] = L"Microsoft.Windows.AI.Text.ITextToTableResponseResult";
/* [object, uuid("391FBF11-59CD-575D-834A-9EF823116F98"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResultVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *GetRows )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult * This,
        /* [out] */UINT32 * __resultSize,
        /* [size_is(, *(__resultSize)), retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow * * * result
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Status )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CText_CLanguageModelResponseStatus * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_ExtendedError )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult * This,
        /* [retval, out] */HRESULT * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResultVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResultVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_GetRows(This,__resultSize,result) \
    ( (This)->lpVtbl->GetRows(This,__resultSize,result) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_get_Status(This,value) \
    ( (This)->lpVtbl->get_Status(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_get_ExtendedError(This,value) \
    ( (This)->lpVtbl->get_ExtendedError(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableResponseResult_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Text.ITextToTableRow
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Text.TextToTableRow
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Text_ITextToTableRow[] = L"Microsoft.Windows.AI.Text.ITextToTableRow";
/* [object, uuid("036294FE-E53C-5E66-93D2-7C92338DB881"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRowVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *GetColumns )(
        __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow * This,
        /* [out] */UINT32 * __resultSize,
        /* [size_is(, *(__resultSize)), retval, out] */HSTRING * * result
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRowVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRowVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_GetColumns(This,__resultSize,result) \
    ( (This)->lpVtbl->GetColumns(This,__resultSize,result) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CText_CITextToTableRow_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Text.LanguageModel
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.AI.Text.ILanguageModelStatics interface starting with version 1.0 of the Microsoft.Windows.AI.Text.LanguageModelContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ILanguageModel ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_LanguageModel_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_LanguageModel_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_LanguageModel[] = L"Microsoft.Windows.AI.Text.LanguageModel";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Text.LanguageModelContext
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ILanguageModelContext ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_LanguageModelContext_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_LanguageModelContext_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_LanguageModelContext[] = L"Microsoft.Windows.AI.Text.LanguageModelContext";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Text.LanguageModelOptions
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * RuntimeClass can be activated.
 *   Type can be activated via RoActivateInstance starting with version 1.0 of the Microsoft.Windows.AI.Text.LanguageModelContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ILanguageModelOptions ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_LanguageModelOptions_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_LanguageModelOptions_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_LanguageModelOptions[] = L"Microsoft.Windows.AI.Text.LanguageModelOptions";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Text.LanguageModelResponseResult
 *
 * Introduced to Microsoft.Windows.AI.Text.LanguageModelContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ILanguageModelResponseResult ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_LanguageModelResponseResult_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_LanguageModelResponseResult_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_LanguageModelResponseResult[] = L"Microsoft.Windows.AI.Text.LanguageModelResponseResult";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_LANGUAGEMODELCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Text.TextRewriter
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * RuntimeClass can be activated.
 *   Type can be activated via the Microsoft.Windows.AI.Text.ITextRewriterFactory interface starting with version 1.0 of the Microsoft.Windows.AI.Text.TextIntelligenceContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ITextRewriter ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_TextRewriter_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_TextRewriter_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_TextRewriter[] = L"Microsoft.Windows.AI.Text.TextRewriter";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Text.TextSummarizer
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 2.0
 *
 *
 * RuntimeClass can be activated.
 *   Type can be activated via the Microsoft.Windows.AI.Text.ITextSummarizerFactory interface starting with version 2.0 of the Microsoft.Windows.AI.Text.TextIntelligenceContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ITextSummarizer ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x20000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_TextSummarizer_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_TextSummarizer_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_TextSummarizer[] = L"Microsoft.Windows.AI.Text.TextSummarizer";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x20000


/*
 *
 * Class Microsoft.Windows.AI.Text.TextToTableConverter
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * RuntimeClass can be activated.
 *   Type can be activated via the Microsoft.Windows.AI.Text.ITextToTableConverterFactory interface starting with version 1.0 of the Microsoft.Windows.AI.Text.TextIntelligenceContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ITextToTableConverter ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_TextToTableConverter_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_TextToTableConverter_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_TextToTableConverter[] = L"Microsoft.Windows.AI.Text.TextToTableConverter";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Text.TextToTableResponseResult
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ITextToTableResponseResult ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_TextToTableResponseResult_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_TextToTableResponseResult_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_TextToTableResponseResult[] = L"Microsoft.Windows.AI.Text.TextToTableResponseResult";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Text.TextToTableRow
 *
 * Introduced to Microsoft.Windows.AI.Text.TextIntelligenceContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Text.ITextToTableRow ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Text_TextToTableRow_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Text_TextToTableRow_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Text_TextToTableRow[] = L"Microsoft.Windows.AI.Text.TextToTableRow";
#endif
#endif // MICROSOFT_WINDOWS_AI_TEXT_TEXTINTELLIGENCECONTRACT_VERSION >= 0x10000





#endif // defined(__cplusplus)
#pragma pop_macro("MIDL_CONST_ID")
// Restore the original value of the 'DEPRECATED' macro
#pragma pop_macro("DEPRECATED")

#ifdef __clang__
#pragma clang diagnostic pop // deprecated-declarations
#else
#pragma warning(pop)
#endif
#endif // __microsoft2Ewindows2Eai2Etext_p_h__

#endif // __microsoft2Ewindows2Eai2Etext_h__
