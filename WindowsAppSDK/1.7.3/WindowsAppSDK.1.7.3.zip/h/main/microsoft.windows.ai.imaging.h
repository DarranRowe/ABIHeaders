
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

/* verify that the <rpcsal.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCSAL_H_VERSION__
#define __REQUIRED_RPCSAL_H_VERSION__ 100
#endif

#include <rpc.h>
#include <rpcndr.h>

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include <windows.h>
#include <ole2.h>
#endif /*COM_NO_WINDOWS_H*/
#ifndef __microsoft2Ewindows2Eai2Eimaging_h__
#define __microsoft2Ewindows2Eai2Eimaging_h__
#ifndef __microsoft2Ewindows2Eai2Eimaging_p_h__
#define __microsoft2Ewindows2Eai2Eimaging_p_h__


#pragma once

//
// Deprecated attribute support
//

#pragma push_macro("DEPRECATED")
#undef DEPRECATED

#if !defined(DISABLE_WINRT_DEPRECATION)
#if defined(__cplusplus)
#if __cplusplus >= 201402
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#elif defined(_MSC_VER)
#if _MSC_VER >= 1900
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#else
#define DEPRECATED(x) __declspec(deprecated(x))
#define DEPRECATEDENUMERATOR(x)
#endif // _MSC_VER >= 1900
#else // Not Standard C++ or MSVC, ignore the construct.
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  // C++ deprecation
#else // C - disable deprecation
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif
#else // Deprecation is disabled
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  /* DEPRECATED */

// Disable Deprecation for this header, MIDL verifies that cross-type access is acceptable
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#else
#pragma warning(push)
#pragma warning(disable: 4996)
#endif

// Ensure that the setting of the /ns_prefix command line switch is consistent for all headers.
// If you get an error from the compiler indicating "warning C4005: 'CHECK_NS_PREFIX_STATE': macro redefinition", this
// indicates that you have included two different headers with different settings for the /ns_prefix MIDL command line switch
#if !defined(DISABLE_NS_PREFIX_CHECKS)
#define CHECK_NS_PREFIX_STATE "always"
#endif // !defined(DISABLE_NS_PREFIX_CHECKS)


#pragma push_macro("MIDL_CONST_ID")
#undef MIDL_CONST_ID
#define MIDL_CONST_ID const __declspec(selectany)


//  API Contract Inclusion Definitions
#if !defined(SPECIFIC_API_CONTRACT_DEFINITIONS)
#if !defined(MICROSOFT_GRAPHICS_IMAGING_IMAGEBUFFERCONTRACT_VERSION)
#define MICROSOFT_GRAPHICS_IMAGING_IMAGEBUFFERCONTRACT_VERSION 0x10000
#endif // defined(MICROSOFT_GRAPHICS_IMAGING_IMAGEBUFFERCONTRACT_VERSION)

#if !defined(MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION)
#define MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION 0x10000
#endif // defined(MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION)

#if !defined(MICROSOFT_WINDOWS_AI_CONTENTSAFETY_CONTENTSAFETYCONTRACT_VERSION)
#define MICROSOFT_WINDOWS_AI_CONTENTSAFETY_CONTENTSAFETYCONTRACT_VERSION 0x10000
#endif // defined(MICROSOFT_WINDOWS_AI_CONTENTSAFETY_CONTENTSAFETYCONTRACT_VERSION)

#if !defined(MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION)
#define MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION 0x10000
#endif // defined(MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION)

#if !defined(MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION)
#define MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION 0x10000
#endif // defined(MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION)

#if !defined(MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION)
#define MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION 0x10000
#endif // defined(MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION)

#if !defined(MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION)
#define MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION 0x10000
#endif // defined(MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION 0x50000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION)
#define WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION)
#define WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION)
#define WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION)
#define WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION 0x60000
#endif // defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION)
#define WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)
#define WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)
#define WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION 0x130000
#endif // defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)

#if !defined(WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION)
#define WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION)

#if !defined(WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION)
#define WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION)
#define WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION)
#define WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION)
#define WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION)
#define WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)
#define WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)
#define WINDOWS_PHONE_PHONECONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)
#define WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)

#if !defined(WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION)
#define WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION 0x50000
#endif // defined(WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION)

#if !defined(WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION)
#define WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION)

#if !defined(WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION)
#define WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION)

#if !defined(WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION)
#define WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION)

#if !defined(WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION)
#define WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION)

#if !defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)
#define WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)

#endif // defined(SPECIFIC_API_CONTRACT_DEFINITIONS)


// Header files for imported files
#include "inspectable.h"
#include "AsyncInfo.h"
#include "EventToken.h"
#include "windowscontracts.h"
#include "Windows.Foundation.h"
#include "Microsoft.Graphics.Imaging.h"
#include "Microsoft.Windows.AI.h"
#include "Microsoft.Windows.AI.ContentSafety.h"
#include "Windows.Graphics.h"
#include "Windows.Graphics.Imaging.h"
// Importing Collections header
#include <windows.foundation.collections.h>

#if defined(__cplusplus) && !defined(CINTERFACE)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    interface IImageDescriptionGenerator;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionGenerator

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    interface IImageDescriptionGeneratorStatics;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionGeneratorStatics

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    interface IImageDescriptionResult;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionResult

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    interface IImageObjectExtractor;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor ABI::Microsoft::Windows::AI::Imaging::IImageObjectExtractor

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    interface IImageObjectExtractorHint;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint ABI::Microsoft::Windows::AI::Imaging::IImageObjectExtractorHint

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    interface IImageObjectExtractorHintFactory;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory ABI::Microsoft::Windows::AI::Imaging::IImageObjectExtractorHintFactory

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    interface IImageObjectExtractorStatics;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics ABI::Microsoft::Windows::AI::Imaging::IImageObjectExtractorStatics

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    interface IImageScaler;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler ABI::Microsoft::Windows::AI::Imaging::IImageScaler

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    interface IImageScalerStatics;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics ABI::Microsoft::Windows::AI::Imaging::IImageScalerStatics

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    interface IRecognizedLine;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine ABI::Microsoft::Windows::AI::Imaging::IRecognizedLine

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    interface IRecognizedText;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText ABI::Microsoft::Windows::AI::Imaging::IRecognizedText

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    interface IRecognizedWord;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord ABI::Microsoft::Windows::AI::Imaging::IRecognizedWord

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    interface ITextRecognizer;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer ABI::Microsoft::Windows::AI::Imaging::ITextRecognizer

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    interface ITextRecognizerStatics;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics ABI::Microsoft::Windows::AI::Imaging::ITextRecognizerStatics

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_FWD_DEFINED__

// Parameterized interface forward declarations (C++)

// Collection interface definitions
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    class ImageDescriptionResult;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_USE
#define DEF___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("f09f3cdf-54d7-52ee-b4af-f27111ed1625"))
IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::Imaging::ImageDescriptionResult*,HSTRING> : IAsyncOperationProgressHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Imaging::ImageDescriptionResult*, ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionResult*>,HSTRING> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationProgressHandler`2<Microsoft.Windows.AI.Imaging.ImageDescriptionResult, String>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::Imaging::ImageDescriptionResult*,HSTRING> __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_t;
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING ABI::Windows::Foundation::__FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING ABI::Windows::Foundation::IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionResult*,HSTRING>
//#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_t ABI::Windows::Foundation::IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionResult*,HSTRING>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_USE */


#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_USE
#define DEF___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("253bf69f-d270-57d8-a287-2a6d1b234353"))
IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::ImageDescriptionResult*,HSTRING> : IAsyncOperationWithProgressCompletedHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Imaging::ImageDescriptionResult*, ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionResult*>,HSTRING> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Microsoft.Windows.AI.Imaging.ImageDescriptionResult, String>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::ImageDescriptionResult*,HSTRING> __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_t;
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING ABI::Windows::Foundation::__FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING ABI::Windows::Foundation::IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionResult*,HSTRING>
//#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_t ABI::Windows::Foundation::IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionResult*,HSTRING>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_USE */


#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_USE
#define DEF___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("cb8eead4-f793-58c5-96cc-08b56d595f39"))
IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::Imaging::ImageDescriptionResult*,HSTRING> : IAsyncOperationWithProgress_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Imaging::ImageDescriptionResult*, ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionResult*>,HSTRING> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IAsyncOperationWithProgress`2<Microsoft.Windows.AI.Imaging.ImageDescriptionResult, String>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::Imaging::ImageDescriptionResult*,HSTRING> __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_t;
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING ABI::Windows::Foundation::__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING ABI::Windows::Foundation::IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionResult*,HSTRING>
//#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_t ABI::Windows::Foundation::IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionResult*,HSTRING>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_USE */


#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000

namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    class ImageDescriptionGenerator;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_USE
#define DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("1e25454f-c3e0-526a-8376-56b637b350d0"))
IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::ImageDescriptionGenerator*> : IAsyncOperationCompletedHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Imaging::ImageDescriptionGenerator*, ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionGenerator*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationCompletedHandler`1<Microsoft.Windows.AI.Imaging.ImageDescriptionGenerator>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::ImageDescriptionGenerator*> __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_t;
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator ABI::Windows::Foundation::__FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionGenerator*>
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_t ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionGenerator*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_USE */


#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_USE
#define DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("1ebb676d-c291-55ef-8d3f-847ff701ef72"))
IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::ImageDescriptionGenerator*> : IAsyncOperation_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Imaging::ImageDescriptionGenerator*, ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionGenerator*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IAsyncOperation`1<Microsoft.Windows.AI.Imaging.ImageDescriptionGenerator>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::ImageDescriptionGenerator*> __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_t;
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator ABI::Windows::Foundation::__FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionGenerator*>
//#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_t ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::IImageDescriptionGenerator*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_USE */


#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000

namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    class ImageObjectExtractor;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_USE
#define DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("0beeabbb-8fb8-519c-a098-140cfe7a77d4"))
IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::ImageObjectExtractor*> : IAsyncOperationCompletedHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Imaging::ImageObjectExtractor*, ABI::Microsoft::Windows::AI::Imaging::IImageObjectExtractor*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationCompletedHandler`1<Microsoft.Windows.AI.Imaging.ImageObjectExtractor>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::ImageObjectExtractor*> __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_t;
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor ABI::Windows::Foundation::__FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::IImageObjectExtractor*>
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_t ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::IImageObjectExtractor*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_USE */


#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_USE
#define DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("0f52d3c6-6444-5bc9-a7f2-b8a6006934aa"))
IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::ImageObjectExtractor*> : IAsyncOperation_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Imaging::ImageObjectExtractor*, ABI::Microsoft::Windows::AI::Imaging::IImageObjectExtractor*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IAsyncOperation`1<Microsoft.Windows.AI.Imaging.ImageObjectExtractor>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::ImageObjectExtractor*> __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_t;
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor ABI::Windows::Foundation::__FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::IImageObjectExtractor*>
//#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_t ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::IImageObjectExtractor*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_USE */


#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000

namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    class ImageScaler;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_USE
#define DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("58962921-0a74-5f0d-b231-d494d294d2cc"))
IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::ImageScaler*> : IAsyncOperationCompletedHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Imaging::ImageScaler*, ABI::Microsoft::Windows::AI::Imaging::IImageScaler*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationCompletedHandler`1<Microsoft.Windows.AI.Imaging.ImageScaler>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::ImageScaler*> __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_t;
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler ABI::Windows::Foundation::__FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::IImageScaler*>
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_t ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::IImageScaler*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_USE */


#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_USE
#define DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("afbdba2c-fa3c-551c-8570-350aae1c53ab"))
IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::ImageScaler*> : IAsyncOperation_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Imaging::ImageScaler*, ABI::Microsoft::Windows::AI::Imaging::IImageScaler*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IAsyncOperation`1<Microsoft.Windows.AI.Imaging.ImageScaler>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::ImageScaler*> __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_t;
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler ABI::Windows::Foundation::__FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::IImageScaler*>
//#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_t ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::IImageScaler*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_USE */


#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000

namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    class RecognizedText;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_USE
#define DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("27584192-a176-5f6e-a6e0-e769be5de471"))
IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::RecognizedText*> : IAsyncOperationCompletedHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Imaging::RecognizedText*, ABI::Microsoft::Windows::AI::Imaging::IRecognizedText*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationCompletedHandler`1<Microsoft.Windows.AI.Imaging.RecognizedText>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::RecognizedText*> __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_t;
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText ABI::Windows::Foundation::__FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::IRecognizedText*>
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_t ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::IRecognizedText*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_USE */


#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_USE
#define DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("3103ec71-2340-5b2b-8833-cc4ed639e936"))
IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::RecognizedText*> : IAsyncOperation_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Imaging::RecognizedText*, ABI::Microsoft::Windows::AI::Imaging::IRecognizedText*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IAsyncOperation`1<Microsoft.Windows.AI.Imaging.RecognizedText>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::RecognizedText*> __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_t;
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText ABI::Windows::Foundation::__FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::IRecognizedText*>
//#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_t ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::IRecognizedText*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_USE */


#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000

namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    class TextRecognizer;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_USE
#define DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("9aa12e4e-55af-531f-bff7-846f2d0b42d6"))
IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::TextRecognizer*> : IAsyncOperationCompletedHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Imaging::TextRecognizer*, ABI::Microsoft::Windows::AI::Imaging::ITextRecognizer*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationCompletedHandler`1<Microsoft.Windows.AI.Imaging.TextRecognizer>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::TextRecognizer*> __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_t;
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer ABI::Windows::Foundation::__FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::ITextRecognizer*>
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_t ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Windows::AI::Imaging::ITextRecognizer*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_USE */


#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_USE
#define DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("740b5d43-1472-53d9-92ec-8465f678d0c3"))
IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::TextRecognizer*> : IAsyncOperation_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::Imaging::TextRecognizer*, ABI::Microsoft::Windows::AI::Imaging::ITextRecognizer*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IAsyncOperation`1<Microsoft.Windows.AI.Imaging.TextRecognizer>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::TextRecognizer*> __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_t;
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer ABI::Windows::Foundation::__FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::ITextRecognizer*>
//#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_t ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Windows::AI::Imaging::ITextRecognizer*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_USE */


#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000

namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                class AIFeatureReadyResult;
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                interface IAIFeatureReadyResult;
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult ABI::Microsoft::Windows::AI::IAIFeatureReadyResult

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult_FWD_DEFINED__


#if MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE
#define DEF___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("5b37e602-8caa-581f-9ece-5dc72ab6ae7e"))
IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*,double> : IAsyncOperationProgressHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*, ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*>,double> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationProgressHandler`2<Microsoft.Windows.AI.AIFeatureReadyResult, Double>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*,double> __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t;
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double ABI::Windows::Foundation::__FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double ABI::Windows::Foundation::IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*,DOUBLE>
//#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t ABI::Windows::Foundation::IAsyncOperationProgressHandler<ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*,DOUBLE>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE */


#endif // MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE
#define DEF___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("ceea7604-5166-549f-8844-03192865a975"))
IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*,double> : IAsyncOperationWithProgressCompletedHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*, ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*>,double> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Microsoft.Windows.AI.AIFeatureReadyResult, Double>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*,double> __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t;
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double ABI::Windows::Foundation::__FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double ABI::Windows::Foundation::IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*,DOUBLE>
//#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t ABI::Windows::Foundation::IAsyncOperationWithProgressCompletedHandler<ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*,DOUBLE>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE */


#endif // MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000

#ifndef DEF___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE
#define DEF___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("39c32af0-c9b4-595f-9e9b-c6c289ad9ea1"))
IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*,double> : IAsyncOperationWithProgress_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*, ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*>,double> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IAsyncOperationWithProgress`2<Microsoft.Windows.AI.AIFeatureReadyResult, Double>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::AIFeatureReadyResult*,double> __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t;
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double ABI::Windows::Foundation::__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double ABI::Windows::Foundation::IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*,DOUBLE>
//#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_t ABI::Windows::Foundation::IAsyncOperationWithProgress<ABI::Microsoft::Windows::AI::IAIFeatureReadyResult*,DOUBLE>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_USE */


#endif // MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000

namespace ABI {
    namespace Windows {
        namespace Graphics {
            struct RectInt32;
            
        } /* Graphics */
    } /* Windows */
} /* ABI */


#ifndef DEF___FIIterator_1_Windows__CGraphics__CRectInt32_USE
#define DEF___FIIterator_1_Windows__CGraphics__CRectInt32_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("1abdf3f6-23f1-55ad-babd-f4cd908406e7"))
IIterator<struct ABI::Windows::Graphics::RectInt32> : IIterator_impl<struct ABI::Windows::Graphics::RectInt32> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterator`1<Windows.Graphics.RectInt32>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterator<struct ABI::Windows::Graphics::RectInt32> __FIIterator_1_Windows__CGraphics__CRectInt32_t;
#define __FIIterator_1_Windows__CGraphics__CRectInt32 ABI::Windows::Foundation::Collections::__FIIterator_1_Windows__CGraphics__CRectInt32_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterator_1_Windows__CGraphics__CRectInt32 ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Graphics::RectInt32>
//#define __FIIterator_1_Windows__CGraphics__CRectInt32_t ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Graphics::RectInt32>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterator_1_Windows__CGraphics__CRectInt32_USE */





#ifndef DEF___FIIterable_1_Windows__CGraphics__CRectInt32_USE
#define DEF___FIIterable_1_Windows__CGraphics__CRectInt32_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("d6222360-b82e-5eed-9eab-2e275b36e47e"))
IIterable<struct ABI::Windows::Graphics::RectInt32> : IIterable_impl<struct ABI::Windows::Graphics::RectInt32> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterable`1<Windows.Graphics.RectInt32>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterable<struct ABI::Windows::Graphics::RectInt32> __FIIterable_1_Windows__CGraphics__CRectInt32_t;
#define __FIIterable_1_Windows__CGraphics__CRectInt32 ABI::Windows::Foundation::Collections::__FIIterable_1_Windows__CGraphics__CRectInt32_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterable_1_Windows__CGraphics__CRectInt32 ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Graphics::RectInt32>
//#define __FIIterable_1_Windows__CGraphics__CRectInt32_t ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Graphics::RectInt32>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterable_1_Windows__CGraphics__CRectInt32_USE */





#ifndef DEF___FIVectorView_1_Windows__CGraphics__CRectInt32_USE
#define DEF___FIVectorView_1_Windows__CGraphics__CRectInt32_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("4f5e243f-3812-5200-b70c-30dcfc61717b"))
IVectorView<struct ABI::Windows::Graphics::RectInt32> : IVectorView_impl<struct ABI::Windows::Graphics::RectInt32> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IVectorView`1<Windows.Graphics.RectInt32>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IVectorView<struct ABI::Windows::Graphics::RectInt32> __FIVectorView_1_Windows__CGraphics__CRectInt32_t;
#define __FIVectorView_1_Windows__CGraphics__CRectInt32 ABI::Windows::Foundation::Collections::__FIVectorView_1_Windows__CGraphics__CRectInt32_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIVectorView_1_Windows__CGraphics__CRectInt32 ABI::Windows::Foundation::Collections::IVectorView<ABI::Windows::Graphics::RectInt32>
//#define __FIVectorView_1_Windows__CGraphics__CRectInt32_t ABI::Windows::Foundation::Collections::IVectorView<ABI::Windows::Graphics::RectInt32>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIVectorView_1_Windows__CGraphics__CRectInt32_USE */



namespace ABI {
    namespace Windows {
        namespace Graphics {
            struct PointInt32;
            
        } /* Graphics */
    } /* Windows */
} /* ABI */


#ifndef DEF___FIIterator_1_Windows__CGraphics__CPointInt32_USE
#define DEF___FIIterator_1_Windows__CGraphics__CPointInt32_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("c4c6f428-e11f-5266-a012-783e25ad266f"))
IIterator<struct ABI::Windows::Graphics::PointInt32> : IIterator_impl<struct ABI::Windows::Graphics::PointInt32> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterator`1<Windows.Graphics.PointInt32>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterator<struct ABI::Windows::Graphics::PointInt32> __FIIterator_1_Windows__CGraphics__CPointInt32_t;
#define __FIIterator_1_Windows__CGraphics__CPointInt32 ABI::Windows::Foundation::Collections::__FIIterator_1_Windows__CGraphics__CPointInt32_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterator_1_Windows__CGraphics__CPointInt32 ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Graphics::PointInt32>
//#define __FIIterator_1_Windows__CGraphics__CPointInt32_t ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Graphics::PointInt32>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterator_1_Windows__CGraphics__CPointInt32_USE */





#ifndef DEF___FIIterable_1_Windows__CGraphics__CPointInt32_USE
#define DEF___FIIterable_1_Windows__CGraphics__CPointInt32_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("5802f68e-f696-5c18-9f52-169f079dbba3"))
IIterable<struct ABI::Windows::Graphics::PointInt32> : IIterable_impl<struct ABI::Windows::Graphics::PointInt32> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterable`1<Windows.Graphics.PointInt32>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterable<struct ABI::Windows::Graphics::PointInt32> __FIIterable_1_Windows__CGraphics__CPointInt32_t;
#define __FIIterable_1_Windows__CGraphics__CPointInt32 ABI::Windows::Foundation::Collections::__FIIterable_1_Windows__CGraphics__CPointInt32_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterable_1_Windows__CGraphics__CPointInt32 ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Graphics::PointInt32>
//#define __FIIterable_1_Windows__CGraphics__CPointInt32_t ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Graphics::PointInt32>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterable_1_Windows__CGraphics__CPointInt32_USE */





#ifndef DEF___FIVectorView_1_Windows__CGraphics__CPointInt32_USE
#define DEF___FIVectorView_1_Windows__CGraphics__CPointInt32_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("3c3a4b61-a864-5cb4-a996-2bbee4922757"))
IVectorView<struct ABI::Windows::Graphics::PointInt32> : IVectorView_impl<struct ABI::Windows::Graphics::PointInt32> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IVectorView`1<Windows.Graphics.PointInt32>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IVectorView<struct ABI::Windows::Graphics::PointInt32> __FIVectorView_1_Windows__CGraphics__CPointInt32_t;
#define __FIVectorView_1_Windows__CGraphics__CPointInt32 ABI::Windows::Foundation::Collections::__FIVectorView_1_Windows__CGraphics__CPointInt32_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIVectorView_1_Windows__CGraphics__CPointInt32 ABI::Windows::Foundation::Collections::IVectorView<ABI::Windows::Graphics::PointInt32>
//#define __FIVectorView_1_Windows__CGraphics__CPointInt32_t ABI::Windows::Foundation::Collections::IVectorView<ABI::Windows::Graphics::PointInt32>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIVectorView_1_Windows__CGraphics__CPointInt32_USE */





#ifndef DEF___FIVector_1_Windows__CGraphics__CRectInt32_USE
#define DEF___FIVector_1_Windows__CGraphics__CRectInt32_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("b4c6b283-6002-5af2-afa2-88a5be7ff16f"))
IVector<struct ABI::Windows::Graphics::RectInt32> : IVector_impl<struct ABI::Windows::Graphics::RectInt32> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IVector`1<Windows.Graphics.RectInt32>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IVector<struct ABI::Windows::Graphics::RectInt32> __FIVector_1_Windows__CGraphics__CRectInt32_t;
#define __FIVector_1_Windows__CGraphics__CRectInt32 ABI::Windows::Foundation::Collections::__FIVector_1_Windows__CGraphics__CRectInt32_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIVector_1_Windows__CGraphics__CRectInt32 ABI::Windows::Foundation::Collections::IVector<ABI::Windows::Graphics::RectInt32>
//#define __FIVector_1_Windows__CGraphics__CRectInt32_t ABI::Windows::Foundation::Collections::IVector<ABI::Windows::Graphics::RectInt32>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIVector_1_Windows__CGraphics__CRectInt32_USE */





#ifndef DEF___FIVector_1_Windows__CGraphics__CPointInt32_USE
#define DEF___FIVector_1_Windows__CGraphics__CPointInt32_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("0a15cbe9-ee02-5823-8a2b-fca63940e84f"))
IVector<struct ABI::Windows::Graphics::PointInt32> : IVector_impl<struct ABI::Windows::Graphics::PointInt32> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IVector`1<Windows.Graphics.PointInt32>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IVector<struct ABI::Windows::Graphics::PointInt32> __FIVector_1_Windows__CGraphics__CPointInt32_t;
#define __FIVector_1_Windows__CGraphics__CPointInt32 ABI::Windows::Foundation::Collections::__FIVector_1_Windows__CGraphics__CPointInt32_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIVector_1_Windows__CGraphics__CPointInt32 ABI::Windows::Foundation::Collections::IVector<ABI::Windows::Graphics::PointInt32>
//#define __FIVector_1_Windows__CGraphics__CPointInt32_t ABI::Windows::Foundation::Collections::IVector<ABI::Windows::Graphics::PointInt32>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIVector_1_Windows__CGraphics__CPointInt32_USE */





namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Imaging {
                class ImageBuffer;
            } /* Imaging */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CImaging_CIImageBuffer_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CImaging_CIImageBuffer_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Imaging {
                interface IImageBuffer;
            } /* Imaging */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CImaging_CIImageBuffer ABI::Microsoft::Graphics::Imaging::IImageBuffer

#endif // ____x_ABI_CMicrosoft_CGraphics_CImaging_CIImageBuffer_FWD_DEFINED__






namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                
                typedef enum AIFeatureReadyState : int AIFeatureReadyState;
                
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */




namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace ContentSafety {
                    class ContentFilterOptions;
                } /* ContentSafety */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace ContentSafety {
                    interface IContentFilterOptions;
                } /* ContentSafety */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions ABI::Microsoft::Windows::AI::ContentSafety::IContentFilterOptions

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions_FWD_DEFINED__






#ifndef ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Foundation {
            interface IClosable;
        } /* Foundation */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CFoundation_CIClosable ABI::Windows::Foundation::IClosable

#endif // ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__


namespace ABI {
    namespace Windows {
        namespace Foundation {
            
            typedef struct Point Point;
            
        } /* Foundation */
    } /* Windows */
} /* ABI */



namespace ABI {
    namespace Windows {
        namespace Graphics {
            namespace Imaging {
                class SoftwareBitmap;
            } /* Imaging */
        } /* Graphics */
    } /* Windows */
} /* ABI */

#ifndef ____x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap_FWD_DEFINED__
#define ____x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Graphics {
            namespace Imaging {
                interface ISoftwareBitmap;
            } /* Imaging */
        } /* Graphics */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap ABI::Windows::Graphics::Imaging::ISoftwareBitmap

#endif // ____x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap_FWD_DEFINED__





namespace ABI {
    namespace Windows {
        namespace Graphics {
            
            typedef struct PointInt32 PointInt32;
            
        } /* Graphics */
    } /* Windows */
} /* ABI */

namespace ABI {
    namespace Windows {
        namespace Graphics {
            
            typedef struct RectInt32 RectInt32;
            
        } /* Graphics */
    } /* Windows */
} /* ABI */







namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    
                    typedef enum ImageDescriptionKind : int ImageDescriptionKind;
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    
                    typedef enum ImageDescriptionResultStatus : int ImageDescriptionResultStatus;
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    
                    typedef enum RecognizedLineStyle : int RecognizedLineStyle;
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    
                    typedef struct RecognizedTextBoundingBox RecognizedTextBoundingBox;
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


















namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    class ImageObjectExtractorHint;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */



namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    class RecognizedLine;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */



namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    class RecognizedWord;
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

















/*
 *
 * Struct Microsoft.Windows.AI.Imaging.ImageDescriptionKind
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageDescriptionContract in version 1.0
 *
 *
 */

#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [v1_enum, contract] */
                    enum ImageDescriptionKind : int
                    {
                        ImageDescriptionKind_BriefDescription = 0,
                        ImageDescriptionKind_DetailedDescription = 1,
                        ImageDescriptionKind_DiagramDescription = 2,
                        ImageDescriptionKind_AccessibleDescription = 3,
                    };
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Struct Microsoft.Windows.AI.Imaging.ImageDescriptionResultStatus
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageDescriptionContract in version 1.0
 *
 *
 */

#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [v1_enum, contract] */
                    enum ImageDescriptionResultStatus : int
                    {
                        ImageDescriptionResultStatus_Complete = 0,
                        ImageDescriptionResultStatus_InProgress = 1,
                        ImageDescriptionResultStatus_BlockedByPolicy = 2,
                        ImageDescriptionResultStatus_ImageBlockedByContentModeration = 3,
                        ImageDescriptionResultStatus_TextInImageBlockedByContentModeration = 4,
                        ImageDescriptionResultStatus_DescriptionTextBlockedByContentModeration = 5,
                        ImageDescriptionResultStatus_ImageHasTooMuchText = 6,
                        ImageDescriptionResultStatus_InternalError = 7,
                    };
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Struct Microsoft.Windows.AI.Imaging.RecognizedLineStyle
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 */

#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [v1_enum, contract] */
                    enum RecognizedLineStyle : int
                    {
                        RecognizedLineStyle_Handwritten = 0,
                    };
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Struct Microsoft.Windows.AI.Imaging.RecognizedTextBoundingBox
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000

namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [contract] */
                    struct RecognizedTextBoundingBox
                    {
                        ABI::Windows::Foundation::Point BottomLeft;
                        ABI::Windows::Foundation::Point BottomRight;
                        ABI::Windows::Foundation::Point TopLeft;
                        ABI::Windows::Foundation::Point TopRight;
                    };
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageDescriptionGenerator
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageDescriptionContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageDescriptionGenerator
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageDescriptionGenerator[] = L"Microsoft.Windows.AI.Imaging.IImageDescriptionGenerator";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [object, uuid("576B989E-9829-5682-91B0-A7110FA7D51E"), exclusiveto, contract] */
                    MIDL_INTERFACE("576B989E-9829-5682-91B0-A7110FA7D51E")
                    IImageDescriptionGenerator : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE DescribeAsync(
                            /* [in] */ABI::Microsoft::Graphics::Imaging::IImageBuffer * image,
                            /* [in] */ABI::Microsoft::Windows::AI::Imaging::ImageDescriptionKind kind,
                            /* [in] */ABI::Microsoft::Windows::AI::ContentSafety::IContentFilterOptions * contentFilterOptions,
                            /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * * operation
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IImageDescriptionGenerator=__uuidof(IImageDescriptionGenerator);
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageDescriptionGeneratorStatics
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageDescriptionContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageDescriptionGenerator
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageDescriptionGeneratorStatics[] = L"Microsoft.Windows.AI.Imaging.IImageDescriptionGeneratorStatics";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [object, uuid("5FB50B2A-5700-55A7-B413-6073B4B7F175"), exclusiveto, contract] */
                    MIDL_INTERFACE("5FB50B2A-5700-55A7-B413-6073B4B7F175")
                    IImageDescriptionGeneratorStatics : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE GetReadyState(
                            /* [retval, out] */ABI::Microsoft::Windows::AI::AIFeatureReadyState * result
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE EnsureReadyAsync(
                            /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * * operation
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE CreateAsync(
                            /* [retval, out] */__FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator * * operation
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IImageDescriptionGeneratorStatics=__uuidof(IImageDescriptionGeneratorStatics);
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageDescriptionResult
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageDescriptionContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageDescriptionResult
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageDescriptionResult[] = L"Microsoft.Windows.AI.Imaging.IImageDescriptionResult";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [object, uuid("A066DD0C-110B-5275-A635-52BED7519A2F"), exclusiveto, contract] */
                    MIDL_INTERFACE("A066DD0C-110B-5275-A635-52BED7519A2F")
                    IImageDescriptionResult : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Description(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Status(
                            /* [retval, out] */ABI::Microsoft::Windows::AI::Imaging::ImageDescriptionResultStatus * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IImageDescriptionResult=__uuidof(IImageDescriptionResult);
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageObjectExtractor
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageObjectExtractorContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageObjectExtractor
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageObjectExtractor[] = L"Microsoft.Windows.AI.Imaging.IImageObjectExtractor";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [object, uuid("2919FDC0-D772-5FD9-A8B7-FFB56010C99C"), exclusiveto, contract] */
                    MIDL_INTERFACE("2919FDC0-D772-5FD9-A8B7-FFB56010C99C")
                    IImageObjectExtractor : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE GetSoftwareBitmapObjectMask(
                            /* [in] */ABI::Microsoft::Windows::AI::Imaging::IImageObjectExtractorHint * hint,
                            /* [retval, out] */ABI::Windows::Graphics::Imaging::ISoftwareBitmap * * result
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetImageBufferObjectMask(
                            /* [in] */ABI::Microsoft::Windows::AI::Imaging::IImageObjectExtractorHint * hint,
                            /* [retval, out] */ABI::Microsoft::Graphics::Imaging::IImageBuffer * * result
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IImageObjectExtractor=__uuidof(IImageObjectExtractor);
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageObjectExtractorHint
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageObjectExtractorContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageObjectExtractorHint
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageObjectExtractorHint[] = L"Microsoft.Windows.AI.Imaging.IImageObjectExtractorHint";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [object, uuid("1BD8D67C-8A7A-5FE7-98A5-CBDFEB509452"), exclusiveto, contract] */
                    MIDL_INTERFACE("1BD8D67C-8A7A-5FE7-98A5-CBDFEB509452")
                    IImageObjectExtractorHint : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_IncludeRects(
                            /* [retval, out] */__FIVectorView_1_Windows__CGraphics__CRectInt32 * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_IncludePoints(
                            /* [retval, out] */__FIVectorView_1_Windows__CGraphics__CPointInt32 * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_ExcludePoints(
                            /* [retval, out] */__FIVectorView_1_Windows__CGraphics__CPointInt32 * * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IImageObjectExtractorHint=__uuidof(IImageObjectExtractorHint);
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageObjectExtractorHintFactory
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageObjectExtractorContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageObjectExtractorHint
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageObjectExtractorHintFactory[] = L"Microsoft.Windows.AI.Imaging.IImageObjectExtractorHintFactory";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [object, uuid("5028F206-145D-5A70-9A51-E17E60CFBAD8"), exclusiveto, contract] */
                    MIDL_INTERFACE("5028F206-145D-5A70-9A51-E17E60CFBAD8")
                    IImageObjectExtractorHintFactory : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE CreateInstance(
                            /* [in] */__FIVector_1_Windows__CGraphics__CRectInt32 * includeRects,
                            /* [in] */__FIVector_1_Windows__CGraphics__CPointInt32 * includePoints,
                            /* [in] */__FIVector_1_Windows__CGraphics__CPointInt32 * excludePoints,
                            /* [retval, out] */ABI::Microsoft::Windows::AI::Imaging::IImageObjectExtractorHint * * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IImageObjectExtractorHintFactory=__uuidof(IImageObjectExtractorHintFactory);
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageObjectExtractorStatics
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageObjectExtractorContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageObjectExtractor
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageObjectExtractorStatics[] = L"Microsoft.Windows.AI.Imaging.IImageObjectExtractorStatics";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [object, uuid("38FA261E-2C33-54CB-9E10-98D50685743D"), exclusiveto, contract] */
                    MIDL_INTERFACE("38FA261E-2C33-54CB-9E10-98D50685743D")
                    IImageObjectExtractorStatics : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE CreateWithSoftwareBitmapAsync(
                            /* [in] */ABI::Windows::Graphics::Imaging::ISoftwareBitmap * softwareBitmap,
                            /* [retval, out] */__FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor * * operation
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE CreateWithImageBufferAsync(
                            /* [in] */ABI::Microsoft::Graphics::Imaging::IImageBuffer * imageBuffer,
                            /* [retval, out] */__FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor * * operation
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetReadyState(
                            /* [retval, out] */ABI::Microsoft::Windows::AI::AIFeatureReadyState * result
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE EnsureReadyAsync(
                            /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * * operation
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IImageObjectExtractorStatics=__uuidof(IImageObjectExtractorStatics);
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageScaler
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageScalerContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageScaler
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageScaler[] = L"Microsoft.Windows.AI.Imaging.IImageScaler";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [object, uuid("06EEC88E-91C5-5326-8128-2807FAAFA571"), exclusiveto, contract] */
                    MIDL_INTERFACE("06EEC88E-91C5-5326-8128-2807FAAFA571")
                    IImageScaler : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE ScaleSoftwareBitmap(
                            /* [in] */ABI::Windows::Graphics::Imaging::ISoftwareBitmap * softwareBitmap,
                            /* [in] */INT32 width,
                            /* [in] */INT32 height,
                            /* [retval, out] */ABI::Windows::Graphics::Imaging::ISoftwareBitmap * * result
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE ScaleImageBuffer(
                            /* [in] */ABI::Microsoft::Graphics::Imaging::IImageBuffer * imageBuffer,
                            /* [in] */INT32 width,
                            /* [in] */INT32 height,
                            /* [retval, out] */ABI::Microsoft::Graphics::Imaging::IImageBuffer * * result
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_MaxSupportedScaleFactor(
                            /* [retval, out] */INT32 * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IImageScaler=__uuidof(IImageScaler);
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageScalerStatics
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageScalerContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageScaler
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageScalerStatics[] = L"Microsoft.Windows.AI.Imaging.IImageScalerStatics";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [object, uuid("75380C81-9C7F-544B-9337-6E638CFB464A"), exclusiveto, contract] */
                    MIDL_INTERFACE("75380C81-9C7F-544B-9337-6E638CFB464A")
                    IImageScalerStatics : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE GetReadyState(
                            /* [retval, out] */ABI::Microsoft::Windows::AI::AIFeatureReadyState * result
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE EnsureReadyAsync(
                            /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * * operation
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE CreateAsync(
                            /* [retval, out] */__FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler * * operation
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IImageScalerStatics=__uuidof(IImageScalerStatics);
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IRecognizedLine
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.RecognizedLine
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IRecognizedLine[] = L"Microsoft.Windows.AI.Imaging.IRecognizedLine";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [object, uuid("612A6BE6-F6BB-53C9-84CE-F0A5E565FAA7"), exclusiveto, contract] */
                    MIDL_INTERFACE("612A6BE6-F6BB-53C9-84CE-F0A5E565FAA7")
                    IRecognizedLine : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Text(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_BoundingBox(
                            /* [retval, out] */ABI::Microsoft::Windows::AI::Imaging::RecognizedTextBoundingBox * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Words(
                            /* [out] */UINT32 * __valueSize,
                            /* [size_is(, *(__valueSize)), retval, out] */ABI::Microsoft::Windows::AI::Imaging::IRecognizedWord * * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Style(
                            /* [retval, out] */ABI::Microsoft::Windows::AI::Imaging::RecognizedLineStyle * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LineStyleConfidence(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IRecognizedLine=__uuidof(IRecognizedLine);
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IRecognizedText
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.RecognizedText
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IRecognizedText[] = L"Microsoft.Windows.AI.Imaging.IRecognizedText";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [object, uuid("AE4766D3-2924-57A6-B3D3-B866F59B9972"), exclusiveto, contract] */
                    MIDL_INTERFACE("AE4766D3-2924-57A6-B3D3-B866F59B9972")
                    IRecognizedText : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Lines(
                            /* [out] */UINT32 * __valueSize,
                            /* [size_is(, *(__valueSize)), retval, out] */ABI::Microsoft::Windows::AI::Imaging::IRecognizedLine * * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_TextAngle(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IRecognizedText=__uuidof(IRecognizedText);
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IRecognizedWord
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.RecognizedWord
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IRecognizedWord[] = L"Microsoft.Windows.AI.Imaging.IRecognizedWord";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [object, uuid("6B53DAAB-3410-5088-826A-0788A1EE3B52"), exclusiveto, contract] */
                    MIDL_INTERFACE("6B53DAAB-3410-5088-826A-0788A1EE3B52")
                    IRecognizedWord : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Text(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_BoundingBox(
                            /* [retval, out] */ABI::Microsoft::Windows::AI::Imaging::RecognizedTextBoundingBox * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_MatchConfidence(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_IRecognizedWord=__uuidof(IRecognizedWord);
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.ITextRecognizer
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.TextRecognizer
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_ITextRecognizer[] = L"Microsoft.Windows.AI.Imaging.ITextRecognizer";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [object, uuid("BE7BF6C0-30F6-570D-BD92-3FFE5665D933"), exclusiveto, contract] */
                    MIDL_INTERFACE("BE7BF6C0-30F6-570D-BD92-3FFE5665D933")
                    ITextRecognizer : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE RecognizeTextFromImageAsync(
                            /* [in] */ABI::Microsoft::Graphics::Imaging::IImageBuffer * imageBuffer,
                            /* [retval, out] */__FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText * * operation
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE RecognizeTextFromImage(
                            /* [in] */ABI::Microsoft::Graphics::Imaging::IImageBuffer * imageBuffer,
                            /* [retval, out] */ABI::Microsoft::Windows::AI::Imaging::IRecognizedText * * result
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ITextRecognizer=__uuidof(ITextRecognizer);
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.ITextRecognizerStatics
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.TextRecognizer
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_ITextRecognizerStatics[] = L"Microsoft.Windows.AI.Imaging.ITextRecognizerStatics";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace AI {
                namespace Imaging {
                    /* [object, uuid("3788C2FD-E496-53AB-85A7-E54A135824E9"), exclusiveto, contract] */
                    MIDL_INTERFACE("3788C2FD-E496-53AB-85A7-E54A135824E9")
                    ITextRecognizerStatics : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE GetReadyState(
                            /* [retval, out] */ABI::Microsoft::Windows::AI::AIFeatureReadyState * result
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE EnsureReadyAsync(
                            /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * * operation
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE CreateAsync(
                            /* [retval, out] */__FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer * * operation
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ITextRecognizerStatics=__uuidof(ITextRecognizerStatics);
                    
                } /* Imaging */
            } /* AI */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.ImageDescriptionGenerator
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageDescriptionContract in version 1.0
 *
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.AI.Imaging.IImageDescriptionGeneratorStatics interface starting with version 1.0 of the Microsoft.Windows.AI.Imaging.ImageDescriptionContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.IImageDescriptionGenerator ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageDescriptionGenerator_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageDescriptionGenerator_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_ImageDescriptionGenerator[] = L"Microsoft.Windows.AI.Imaging.ImageDescriptionGenerator";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.ImageDescriptionResult
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageDescriptionContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.IImageDescriptionResult ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageDescriptionResult_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageDescriptionResult_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_ImageDescriptionResult[] = L"Microsoft.Windows.AI.Imaging.ImageDescriptionResult";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.ImageObjectExtractor
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageObjectExtractorContract in version 1.0
 *
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.AI.Imaging.IImageObjectExtractorStatics interface starting with version 1.0 of the Microsoft.Windows.AI.Imaging.ImageObjectExtractorContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.IImageObjectExtractor ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageObjectExtractor_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageObjectExtractor_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_ImageObjectExtractor[] = L"Microsoft.Windows.AI.Imaging.ImageObjectExtractor";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.ImageObjectExtractorHint
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageObjectExtractorContract in version 1.0
 *
 *
 * RuntimeClass can be activated.
 *   Type can be activated via the Microsoft.Windows.AI.Imaging.IImageObjectExtractorHintFactory interface starting with version 1.0 of the Microsoft.Windows.AI.Imaging.ImageObjectExtractorContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.IImageObjectExtractorHint ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageObjectExtractorHint_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageObjectExtractorHint_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_ImageObjectExtractorHint[] = L"Microsoft.Windows.AI.Imaging.ImageObjectExtractorHint";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.ImageScaler
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageScalerContract in version 1.0
 *
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.AI.Imaging.IImageScalerStatics interface starting with version 1.0 of the Microsoft.Windows.AI.Imaging.ImageScalerContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.IImageScaler ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageScaler_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageScaler_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_ImageScaler[] = L"Microsoft.Windows.AI.Imaging.ImageScaler";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.RecognizedLine
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.IRecognizedLine ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_RecognizedLine_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_RecognizedLine_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_RecognizedLine[] = L"Microsoft.Windows.AI.Imaging.RecognizedLine";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.RecognizedText
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.IRecognizedText ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_RecognizedText_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_RecognizedText_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_RecognizedText[] = L"Microsoft.Windows.AI.Imaging.RecognizedText";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.RecognizedWord
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.IRecognizedWord ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_RecognizedWord_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_RecognizedWord_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_RecognizedWord[] = L"Microsoft.Windows.AI.Imaging.RecognizedWord";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.TextRecognizer
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.AI.Imaging.ITextRecognizerStatics interface starting with version 1.0 of the Microsoft.Windows.AI.Imaging.TextRecognitionContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.ITextRecognizer ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_TextRecognizer_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_TextRecognizer_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_TextRecognizer[] = L"Microsoft.Windows.AI.Imaging.TextRecognizer";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000





#else // !defined(__cplusplus)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_FWD_DEFINED__

// Parameterized interface forward declarations (C)

// Collection interface definitions

#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_INTERFACE_DEFINED__)
#define ____FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING;

typedef interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING;

typedef struct __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRINGVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This, /* [in] */ __RPC__in_opt __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING *asyncInfo, /* [in] */ HSTRING progressInfo);
    END_INTERFACE
} __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRINGVtbl;

interface __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING
{
    CONST_VTBL struct __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRINGVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_Invoke(This,asyncInfo,progressInfo)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,progressInfo) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_INTERFACE_DEFINED__)
#define ____FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING;

//  Forward declare the async operation.
typedef interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING;

typedef struct __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRINGVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This, /* [in] */ __RPC__in_opt __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING *asyncInfo, /* [in] */ AsyncStatus status);
    END_INTERFACE
} __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRINGVtbl;

interface __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING
{
    CONST_VTBL struct __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRINGVtbl *lpVtbl;
};



#ifdef COBJMACROS
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_Invoke(This,asyncInfo,status)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,status) ) 
#endif /* COBJMACROS */



#endif // ____FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_INTERFACE_DEFINED__)
#define ____FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING;

typedef struct __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRINGVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Progress )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This, /* [in] */ __RPC__in_opt __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Progress )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING **handler);
    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Completed )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This, /* [in] */ __RPC__in_opt __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Completed )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING **handler);
    HRESULT ( STDMETHODCALLTYPE *GetResults )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * This, /* [retval][out] */ __RPC__deref_out_opt __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult * *results);
    END_INTERFACE
} __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRINGVtbl;

interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING
{
    CONST_VTBL struct __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRINGVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_put_Progress(This,handler)	\
    ( (This)->lpVtbl -> put_Progress(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_get_Progress(This,handler)	\
    ( (This)->lpVtbl -> get_Progress(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_put_Completed(This,handler)	\
    ( (This)->lpVtbl -> put_Completed(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_get_Completed(This,handler)	\
    ( (This)->lpVtbl -> get_Completed(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_GetResults(This,results)	\
    ( (This)->lpVtbl -> GetResults(This,results) ) 
#endif /* COBJMACROS */



#endif // ____FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_INTERFACE_DEFINED__)
#define ____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator;

// Forward declare the async operation.
typedef interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator;

typedef struct __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGeneratorVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator * This,/* [in] */ __RPC__in_opt __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator *asyncInfo, /* [in] */ AsyncStatus status);
    END_INTERFACE
} __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGeneratorVtbl;

interface __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator
{
    CONST_VTBL struct __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGeneratorVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_Invoke(This,asyncInfo,status)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,status) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_INTERFACE_DEFINED__)
#define ____FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_INTERFACE_DEFINED__

typedef interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator;

typedef struct __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGeneratorVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator * This, /* [in] */ __RPC__in_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator **handler);
    HRESULT ( STDMETHODCALLTYPE *GetResults )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator * This, /* [retval][out] */ __RPC__out __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator * *results);
    END_INTERFACE
} __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGeneratorVtbl;

interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator
{
    CONST_VTBL struct __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGeneratorVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_put_Completed(This,handler)	\
    ( (This)->lpVtbl -> put_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_get_Completed(This,handler)	\
    ( (This)->lpVtbl -> get_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_GetResults(This,results)	\
    ( (This)->lpVtbl -> GetResults(This,results) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_INTERFACE_DEFINED__)
#define ____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor;

// Forward declare the async operation.
typedef interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor;

typedef struct __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractorVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor * This,/* [in] */ __RPC__in_opt __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor *asyncInfo, /* [in] */ AsyncStatus status);
    END_INTERFACE
} __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractorVtbl;

interface __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor
{
    CONST_VTBL struct __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractorVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_Invoke(This,asyncInfo,status)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,status) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_INTERFACE_DEFINED__)
#define ____FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_INTERFACE_DEFINED__

typedef interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor;

typedef struct __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractorVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor * This, /* [in] */ __RPC__in_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor **handler);
    HRESULT ( STDMETHODCALLTYPE *GetResults )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor * This, /* [retval][out] */ __RPC__out __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor * *results);
    END_INTERFACE
} __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractorVtbl;

interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor
{
    CONST_VTBL struct __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractorVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_put_Completed(This,handler)	\
    ( (This)->lpVtbl -> put_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_get_Completed(This,handler)	\
    ( (This)->lpVtbl -> get_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_GetResults(This,results)	\
    ( (This)->lpVtbl -> GetResults(This,results) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_INTERFACE_DEFINED__)
#define ____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler;

// Forward declare the async operation.
typedef interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler;

typedef struct __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScalerVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler * This,/* [in] */ __RPC__in_opt __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler *asyncInfo, /* [in] */ AsyncStatus status);
    END_INTERFACE
} __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScalerVtbl;

interface __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler
{
    CONST_VTBL struct __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScalerVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_Invoke(This,asyncInfo,status)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,status) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_INTERFACE_DEFINED__)
#define ____FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_INTERFACE_DEFINED__

typedef interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler;

typedef struct __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScalerVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler * This, /* [in] */ __RPC__in_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CImageScaler **handler);
    HRESULT ( STDMETHODCALLTYPE *GetResults )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler * This, /* [retval][out] */ __RPC__out __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler * *results);
    END_INTERFACE
} __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScalerVtbl;

interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler
{
    CONST_VTBL struct __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScalerVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_put_Completed(This,handler)	\
    ( (This)->lpVtbl -> put_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_get_Completed(This,handler)	\
    ( (This)->lpVtbl -> get_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_GetResults(This,results)	\
    ( (This)->lpVtbl -> GetResults(This,results) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_INTERFACE_DEFINED__)
#define ____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText;

// Forward declare the async operation.
typedef interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText;

typedef struct __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedTextVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText * This,/* [in] */ __RPC__in_opt __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText *asyncInfo, /* [in] */ AsyncStatus status);
    END_INTERFACE
} __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedTextVtbl;

interface __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText
{
    CONST_VTBL struct __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedTextVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_Invoke(This,asyncInfo,status)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,status) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_INTERFACE_DEFINED__)
#define ____FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_INTERFACE_DEFINED__

typedef interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText;

typedef struct __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedTextVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText * This, /* [in] */ __RPC__in_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText **handler);
    HRESULT ( STDMETHODCALLTYPE *GetResults )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText * This, /* [retval][out] */ __RPC__out __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText * *results);
    END_INTERFACE
} __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedTextVtbl;

interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText
{
    CONST_VTBL struct __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedTextVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_put_Completed(This,handler)	\
    ( (This)->lpVtbl -> put_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_get_Completed(This,handler)	\
    ( (This)->lpVtbl -> get_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_GetResults(This,results)	\
    ( (This)->lpVtbl -> GetResults(This,results) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_INTERFACE_DEFINED__)
#define ____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer;

// Forward declare the async operation.
typedef interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer;

typedef struct __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizerVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer * This,/* [in] */ __RPC__in_opt __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer *asyncInfo, /* [in] */ AsyncStatus status);
    END_INTERFACE
} __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizerVtbl;

interface __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer
{
    CONST_VTBL struct __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizerVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_Invoke(This,asyncInfo,status)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,status) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_INTERFACE_DEFINED__)
#define ____FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_INTERFACE_DEFINED__

typedef interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer;

typedef struct __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizerVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer * This, /* [in] */ __RPC__in_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer **handler);
    HRESULT ( STDMETHODCALLTYPE *GetResults )(__RPC__in __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer * This, /* [retval][out] */ __RPC__out __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer * *results);
    END_INTERFACE
} __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizerVtbl;

interface __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer
{
    CONST_VTBL struct __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizerVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_put_Completed(This,handler)	\
    ( (This)->lpVtbl -> put_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_get_Completed(This,handler)	\
    ( (This)->lpVtbl -> get_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_GetResults(This,results)	\
    ( (This)->lpVtbl -> GetResults(This,results) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000

#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult __x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult_FWD_DEFINED__


#if MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__)
#define ____FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double;

typedef interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double;

typedef struct __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [in] */ __RPC__in_opt __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double *asyncInfo, /* [in] */ double progressInfo);
    END_INTERFACE
} __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl;

interface __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double
{
    CONST_VTBL struct __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_Invoke(This,asyncInfo,progressInfo)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,progressInfo) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__)
#define ____FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double;

//  Forward declare the async operation.
typedef interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double;

typedef struct __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [in] */ __RPC__in_opt __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double *asyncInfo, /* [in] */ AsyncStatus status);
    END_INTERFACE
} __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl;

interface __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double
{
    CONST_VTBL struct __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl *lpVtbl;
};



#ifdef COBJMACROS
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_Invoke(This,asyncInfo,status)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,status) ) 
#endif /* COBJMACROS */



#endif // ____FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000


#if MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000
#if !defined(____FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__)
#define ____FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double;

typedef struct __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Progress )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [in] */ __RPC__in_opt __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Progress )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationProgressHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double **handler);
    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Completed )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [in] */ __RPC__in_opt __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Completed )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationWithProgressCompletedHandler_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double **handler);
    HRESULT ( STDMETHODCALLTYPE *GetResults )(__RPC__in __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * This, /* [retval][out] */ __RPC__deref_out_opt __x_ABI_CMicrosoft_CWindows_CAI_CIAIFeatureReadyResult * *results);
    END_INTERFACE
} __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl;

interface __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double
{
    CONST_VTBL struct __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_doubleVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_put_Progress(This,handler)	\
    ( (This)->lpVtbl -> put_Progress(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_get_Progress(This,handler)	\
    ( (This)->lpVtbl -> get_Progress(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_put_Completed(This,handler)	\
    ( (This)->lpVtbl -> put_Completed(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_get_Completed(This,handler)	\
    ( (This)->lpVtbl -> get_Completed(This,handler) ) 
#define __FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_GetResults(This,results)	\
    ( (This)->lpVtbl -> GetResults(This,results) ) 
#endif /* COBJMACROS */



#endif // ____FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double_INTERFACE_DEFINED__

#endif // MICROSOFT_WINDOWS_AI_AIFEATUREREADYCONTRACT_VERSION >= 0x10000

struct __x_ABI_CWindows_CGraphics_CRectInt32;

#if !defined(____FIIterator_1_Windows__CGraphics__CRectInt32_INTERFACE_DEFINED__)
#define ____FIIterator_1_Windows__CGraphics__CRectInt32_INTERFACE_DEFINED__

typedef interface __FIIterator_1_Windows__CGraphics__CRectInt32 __FIIterator_1_Windows__CGraphics__CRectInt32;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterator_1_Windows__CGraphics__CRectInt32;

typedef struct __FIIterator_1_Windows__CGraphics__CRectInt32Vtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterator_1_Windows__CGraphics__CRectInt32 * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterator_1_Windows__CGraphics__CRectInt32 * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterator_1_Windows__CGraphics__CRectInt32 * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterator_1_Windows__CGraphics__CRectInt32 * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterator_1_Windows__CGraphics__CRectInt32 * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterator_1_Windows__CGraphics__CRectInt32 * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Current )(__RPC__in __FIIterator_1_Windows__CGraphics__CRectInt32 * This, /* [retval][out] */ __RPC__out struct __x_ABI_CWindows_CGraphics_CRectInt32 *current);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasCurrent )(__RPC__in __FIIterator_1_Windows__CGraphics__CRectInt32 * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *MoveNext )(__RPC__in __FIIterator_1_Windows__CGraphics__CRectInt32 * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *GetMany )(__RPC__in __FIIterator_1_Windows__CGraphics__CRectInt32 * This,
        /* [in] */ unsigned int capacity,
        /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) struct __x_ABI_CWindows_CGraphics_CRectInt32 *items,
        /* [retval][out] */ __RPC__out unsigned int *actual);

    END_INTERFACE
} __FIIterator_1_Windows__CGraphics__CRectInt32Vtbl;

interface __FIIterator_1_Windows__CGraphics__CRectInt32
{
    CONST_VTBL struct __FIIterator_1_Windows__CGraphics__CRectInt32Vtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIIterator_1_Windows__CGraphics__CRectInt32_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterator_1_Windows__CGraphics__CRectInt32_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterator_1_Windows__CGraphics__CRectInt32_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterator_1_Windows__CGraphics__CRectInt32_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterator_1_Windows__CGraphics__CRectInt32_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterator_1_Windows__CGraphics__CRectInt32_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterator_1_Windows__CGraphics__CRectInt32_get_Current(This,current)	\
    ( (This)->lpVtbl -> get_Current(This,current) ) 

#define __FIIterator_1_Windows__CGraphics__CRectInt32_get_HasCurrent(This,hasCurrent)	\
    ( (This)->lpVtbl -> get_HasCurrent(This,hasCurrent) ) 

#define __FIIterator_1_Windows__CGraphics__CRectInt32_MoveNext(This,hasCurrent)	\
    ( (This)->lpVtbl -> MoveNext(This,hasCurrent) ) 

#define __FIIterator_1_Windows__CGraphics__CRectInt32_GetMany(This,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,capacity,items,actual) ) 

#endif /* COBJMACROS */


#endif // ____FIIterator_1_Windows__CGraphics__CRectInt32_INTERFACE_DEFINED__



#if !defined(____FIIterable_1_Windows__CGraphics__CRectInt32_INTERFACE_DEFINED__)
#define ____FIIterable_1_Windows__CGraphics__CRectInt32_INTERFACE_DEFINED__

typedef interface __FIIterable_1_Windows__CGraphics__CRectInt32 __FIIterable_1_Windows__CGraphics__CRectInt32;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterable_1_Windows__CGraphics__CRectInt32;

typedef  struct __FIIterable_1_Windows__CGraphics__CRectInt32Vtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterable_1_Windows__CGraphics__CRectInt32 * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterable_1_Windows__CGraphics__CRectInt32 * This);

    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterable_1_Windows__CGraphics__CRectInt32 * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterable_1_Windows__CGraphics__CRectInt32 * This,
                                           /* [out] */ __RPC__out ULONG *iidCount,
                                           /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterable_1_Windows__CGraphics__CRectInt32 * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterable_1_Windows__CGraphics__CRectInt32 * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *First )(__RPC__in __FIIterable_1_Windows__CGraphics__CRectInt32 * This, /* [retval][out] */ __RPC__deref_out_opt __FIIterator_1_Windows__CGraphics__CRectInt32 **first);

    END_INTERFACE
} __FIIterable_1_Windows__CGraphics__CRectInt32Vtbl;

interface __FIIterable_1_Windows__CGraphics__CRectInt32
{
    CONST_VTBL struct __FIIterable_1_Windows__CGraphics__CRectInt32Vtbl *lpVtbl;
};

#ifdef COBJMACROS

#define __FIIterable_1_Windows__CGraphics__CRectInt32_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterable_1_Windows__CGraphics__CRectInt32_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterable_1_Windows__CGraphics__CRectInt32_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterable_1_Windows__CGraphics__CRectInt32_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterable_1_Windows__CGraphics__CRectInt32_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterable_1_Windows__CGraphics__CRectInt32_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterable_1_Windows__CGraphics__CRectInt32_First(This,first)	\
    ( (This)->lpVtbl -> First(This,first) ) 

#endif /* COBJMACROS */


#endif // ____FIIterable_1_Windows__CGraphics__CRectInt32_INTERFACE_DEFINED__



#if !defined(____FIVectorView_1_Windows__CGraphics__CRectInt32_INTERFACE_DEFINED__)
#define ____FIVectorView_1_Windows__CGraphics__CRectInt32_INTERFACE_DEFINED__

typedef interface __FIVectorView_1_Windows__CGraphics__CRectInt32 __FIVectorView_1_Windows__CGraphics__CRectInt32;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIVectorView_1_Windows__CGraphics__CRectInt32;

typedef struct __FIVectorView_1_Windows__CGraphics__CRectInt32Vtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIVectorView_1_Windows__CGraphics__CRectInt32 * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )( __RPC__in __FIVectorView_1_Windows__CGraphics__CRectInt32 * This);

    ULONG ( STDMETHODCALLTYPE *Release )( __RPC__in __FIVectorView_1_Windows__CGraphics__CRectInt32 * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )( __RPC__in __FIVectorView_1_Windows__CGraphics__CRectInt32 * This,
                                            /* [out] */ __RPC__out ULONG *iidCount,
                                            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
        __RPC__in __FIVectorView_1_Windows__CGraphics__CRectInt32 * This,
            /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
        __RPC__in __FIVectorView_1_Windows__CGraphics__CRectInt32 * This,
            /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *GetAt )( 
                                         __RPC__in __FIVectorView_1_Windows__CGraphics__CRectInt32 * This,
                                         /* [in] */ unsigned int index,
                                         /* [retval][out] */ __RPC__out struct __x_ABI_CWindows_CGraphics_CRectInt32 *item);

        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Size )( 
            __RPC__in __FIVectorView_1_Windows__CGraphics__CRectInt32 * This,
            /* [retval][out] */ __RPC__out unsigned int *size);

        HRESULT ( STDMETHODCALLTYPE *IndexOf )( 
                                               __RPC__in __FIVectorView_1_Windows__CGraphics__CRectInt32 * This,
            /* [in] */ struct __x_ABI_CWindows_CGraphics_CRectInt32 item,
            /* [out] */ __RPC__out unsigned int *index,
            /* [retval][out] */ __RPC__out boolean *found);

        HRESULT ( STDMETHODCALLTYPE *GetMany )( 
                                               __RPC__in __FIVectorView_1_Windows__CGraphics__CRectInt32 * This,
            /* [in] */ unsigned int startIndex,
            /* [in] */ unsigned int capacity,
            /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) struct __x_ABI_CWindows_CGraphics_CRectInt32 *items,
            /* [retval][out] */ __RPC__out unsigned int *actual);

        END_INTERFACE
} __FIVectorView_1_Windows__CGraphics__CRectInt32Vtbl;

interface __FIVectorView_1_Windows__CGraphics__CRectInt32
{
    CONST_VTBL struct __FIVectorView_1_Windows__CGraphics__CRectInt32Vtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIVectorView_1_Windows__CGraphics__CRectInt32_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIVectorView_1_Windows__CGraphics__CRectInt32_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIVectorView_1_Windows__CGraphics__CRectInt32_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIVectorView_1_Windows__CGraphics__CRectInt32_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIVectorView_1_Windows__CGraphics__CRectInt32_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIVectorView_1_Windows__CGraphics__CRectInt32_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIVectorView_1_Windows__CGraphics__CRectInt32_GetAt(This,index,item)	\
    ( (This)->lpVtbl -> GetAt(This,index,item) ) 

#define __FIVectorView_1_Windows__CGraphics__CRectInt32_get_Size(This,size)	\
    ( (This)->lpVtbl -> get_Size(This,size) ) 

#define __FIVectorView_1_Windows__CGraphics__CRectInt32_IndexOf(This,item,index,found)	\
    ( (This)->lpVtbl -> IndexOf(This,item,index,found) ) 

#define __FIVectorView_1_Windows__CGraphics__CRectInt32_GetMany(This,startIndex,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,startIndex,capacity,items,actual) ) 

#endif /* COBJMACROS */



#endif // ____FIVectorView_1_Windows__CGraphics__CRectInt32_INTERFACE_DEFINED__


struct __x_ABI_CWindows_CGraphics_CPointInt32;

#if !defined(____FIIterator_1_Windows__CGraphics__CPointInt32_INTERFACE_DEFINED__)
#define ____FIIterator_1_Windows__CGraphics__CPointInt32_INTERFACE_DEFINED__

typedef interface __FIIterator_1_Windows__CGraphics__CPointInt32 __FIIterator_1_Windows__CGraphics__CPointInt32;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterator_1_Windows__CGraphics__CPointInt32;

typedef struct __FIIterator_1_Windows__CGraphics__CPointInt32Vtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterator_1_Windows__CGraphics__CPointInt32 * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterator_1_Windows__CGraphics__CPointInt32 * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterator_1_Windows__CGraphics__CPointInt32 * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterator_1_Windows__CGraphics__CPointInt32 * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterator_1_Windows__CGraphics__CPointInt32 * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterator_1_Windows__CGraphics__CPointInt32 * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Current )(__RPC__in __FIIterator_1_Windows__CGraphics__CPointInt32 * This, /* [retval][out] */ __RPC__out struct __x_ABI_CWindows_CGraphics_CPointInt32 *current);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasCurrent )(__RPC__in __FIIterator_1_Windows__CGraphics__CPointInt32 * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *MoveNext )(__RPC__in __FIIterator_1_Windows__CGraphics__CPointInt32 * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *GetMany )(__RPC__in __FIIterator_1_Windows__CGraphics__CPointInt32 * This,
        /* [in] */ unsigned int capacity,
        /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) struct __x_ABI_CWindows_CGraphics_CPointInt32 *items,
        /* [retval][out] */ __RPC__out unsigned int *actual);

    END_INTERFACE
} __FIIterator_1_Windows__CGraphics__CPointInt32Vtbl;

interface __FIIterator_1_Windows__CGraphics__CPointInt32
{
    CONST_VTBL struct __FIIterator_1_Windows__CGraphics__CPointInt32Vtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIIterator_1_Windows__CGraphics__CPointInt32_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterator_1_Windows__CGraphics__CPointInt32_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterator_1_Windows__CGraphics__CPointInt32_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterator_1_Windows__CGraphics__CPointInt32_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterator_1_Windows__CGraphics__CPointInt32_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterator_1_Windows__CGraphics__CPointInt32_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterator_1_Windows__CGraphics__CPointInt32_get_Current(This,current)	\
    ( (This)->lpVtbl -> get_Current(This,current) ) 

#define __FIIterator_1_Windows__CGraphics__CPointInt32_get_HasCurrent(This,hasCurrent)	\
    ( (This)->lpVtbl -> get_HasCurrent(This,hasCurrent) ) 

#define __FIIterator_1_Windows__CGraphics__CPointInt32_MoveNext(This,hasCurrent)	\
    ( (This)->lpVtbl -> MoveNext(This,hasCurrent) ) 

#define __FIIterator_1_Windows__CGraphics__CPointInt32_GetMany(This,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,capacity,items,actual) ) 

#endif /* COBJMACROS */


#endif // ____FIIterator_1_Windows__CGraphics__CPointInt32_INTERFACE_DEFINED__



#if !defined(____FIIterable_1_Windows__CGraphics__CPointInt32_INTERFACE_DEFINED__)
#define ____FIIterable_1_Windows__CGraphics__CPointInt32_INTERFACE_DEFINED__

typedef interface __FIIterable_1_Windows__CGraphics__CPointInt32 __FIIterable_1_Windows__CGraphics__CPointInt32;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterable_1_Windows__CGraphics__CPointInt32;

typedef  struct __FIIterable_1_Windows__CGraphics__CPointInt32Vtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterable_1_Windows__CGraphics__CPointInt32 * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterable_1_Windows__CGraphics__CPointInt32 * This);

    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterable_1_Windows__CGraphics__CPointInt32 * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterable_1_Windows__CGraphics__CPointInt32 * This,
                                           /* [out] */ __RPC__out ULONG *iidCount,
                                           /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterable_1_Windows__CGraphics__CPointInt32 * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterable_1_Windows__CGraphics__CPointInt32 * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *First )(__RPC__in __FIIterable_1_Windows__CGraphics__CPointInt32 * This, /* [retval][out] */ __RPC__deref_out_opt __FIIterator_1_Windows__CGraphics__CPointInt32 **first);

    END_INTERFACE
} __FIIterable_1_Windows__CGraphics__CPointInt32Vtbl;

interface __FIIterable_1_Windows__CGraphics__CPointInt32
{
    CONST_VTBL struct __FIIterable_1_Windows__CGraphics__CPointInt32Vtbl *lpVtbl;
};

#ifdef COBJMACROS

#define __FIIterable_1_Windows__CGraphics__CPointInt32_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterable_1_Windows__CGraphics__CPointInt32_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterable_1_Windows__CGraphics__CPointInt32_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterable_1_Windows__CGraphics__CPointInt32_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterable_1_Windows__CGraphics__CPointInt32_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterable_1_Windows__CGraphics__CPointInt32_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterable_1_Windows__CGraphics__CPointInt32_First(This,first)	\
    ( (This)->lpVtbl -> First(This,first) ) 

#endif /* COBJMACROS */


#endif // ____FIIterable_1_Windows__CGraphics__CPointInt32_INTERFACE_DEFINED__



#if !defined(____FIVectorView_1_Windows__CGraphics__CPointInt32_INTERFACE_DEFINED__)
#define ____FIVectorView_1_Windows__CGraphics__CPointInt32_INTERFACE_DEFINED__

typedef interface __FIVectorView_1_Windows__CGraphics__CPointInt32 __FIVectorView_1_Windows__CGraphics__CPointInt32;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIVectorView_1_Windows__CGraphics__CPointInt32;

typedef struct __FIVectorView_1_Windows__CGraphics__CPointInt32Vtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIVectorView_1_Windows__CGraphics__CPointInt32 * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )( __RPC__in __FIVectorView_1_Windows__CGraphics__CPointInt32 * This);

    ULONG ( STDMETHODCALLTYPE *Release )( __RPC__in __FIVectorView_1_Windows__CGraphics__CPointInt32 * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )( __RPC__in __FIVectorView_1_Windows__CGraphics__CPointInt32 * This,
                                            /* [out] */ __RPC__out ULONG *iidCount,
                                            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
        __RPC__in __FIVectorView_1_Windows__CGraphics__CPointInt32 * This,
            /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
        __RPC__in __FIVectorView_1_Windows__CGraphics__CPointInt32 * This,
            /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *GetAt )( 
                                         __RPC__in __FIVectorView_1_Windows__CGraphics__CPointInt32 * This,
                                         /* [in] */ unsigned int index,
                                         /* [retval][out] */ __RPC__out struct __x_ABI_CWindows_CGraphics_CPointInt32 *item);

        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Size )( 
            __RPC__in __FIVectorView_1_Windows__CGraphics__CPointInt32 * This,
            /* [retval][out] */ __RPC__out unsigned int *size);

        HRESULT ( STDMETHODCALLTYPE *IndexOf )( 
                                               __RPC__in __FIVectorView_1_Windows__CGraphics__CPointInt32 * This,
            /* [in] */ struct __x_ABI_CWindows_CGraphics_CPointInt32 item,
            /* [out] */ __RPC__out unsigned int *index,
            /* [retval][out] */ __RPC__out boolean *found);

        HRESULT ( STDMETHODCALLTYPE *GetMany )( 
                                               __RPC__in __FIVectorView_1_Windows__CGraphics__CPointInt32 * This,
            /* [in] */ unsigned int startIndex,
            /* [in] */ unsigned int capacity,
            /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) struct __x_ABI_CWindows_CGraphics_CPointInt32 *items,
            /* [retval][out] */ __RPC__out unsigned int *actual);

        END_INTERFACE
} __FIVectorView_1_Windows__CGraphics__CPointInt32Vtbl;

interface __FIVectorView_1_Windows__CGraphics__CPointInt32
{
    CONST_VTBL struct __FIVectorView_1_Windows__CGraphics__CPointInt32Vtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIVectorView_1_Windows__CGraphics__CPointInt32_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIVectorView_1_Windows__CGraphics__CPointInt32_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIVectorView_1_Windows__CGraphics__CPointInt32_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIVectorView_1_Windows__CGraphics__CPointInt32_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIVectorView_1_Windows__CGraphics__CPointInt32_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIVectorView_1_Windows__CGraphics__CPointInt32_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIVectorView_1_Windows__CGraphics__CPointInt32_GetAt(This,index,item)	\
    ( (This)->lpVtbl -> GetAt(This,index,item) ) 

#define __FIVectorView_1_Windows__CGraphics__CPointInt32_get_Size(This,size)	\
    ( (This)->lpVtbl -> get_Size(This,size) ) 

#define __FIVectorView_1_Windows__CGraphics__CPointInt32_IndexOf(This,item,index,found)	\
    ( (This)->lpVtbl -> IndexOf(This,item,index,found) ) 

#define __FIVectorView_1_Windows__CGraphics__CPointInt32_GetMany(This,startIndex,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,startIndex,capacity,items,actual) ) 

#endif /* COBJMACROS */



#endif // ____FIVectorView_1_Windows__CGraphics__CPointInt32_INTERFACE_DEFINED__



#if !defined(____FIVector_1_Windows__CGraphics__CRectInt32_INTERFACE_DEFINED__)
#define ____FIVector_1_Windows__CGraphics__CRectInt32_INTERFACE_DEFINED__

typedef interface __FIVector_1_Windows__CGraphics__CRectInt32 __FIVector_1_Windows__CGraphics__CRectInt32;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIVector_1_Windows__CGraphics__CRectInt32;

typedef struct __FIVector_1_Windows__CGraphics__CRectInt32Vtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This,
            /* [in] */ __RPC__in REFIID riid,
            /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This, /* [out] */ __RPC__deref_out_opt struct __x_ABI_CWindows_CGraphics_CRectInt32 *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *GetAt )(__RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This,
        /* [in] */ unsigned int index,
        /* [retval][out] */ __RPC__deref_out_opt struct __x_ABI_CWindows_CGraphics_CRectInt32 *item);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Size )( 
        __RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This,
        /* [retval][out] */ __RPC__out unsigned int *size);

    HRESULT ( STDMETHODCALLTYPE *GetView )(__RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This, /* [retval][out] */ __RPC__deref_out_opt __FIVectorView_1_Windows__CGraphics__CRectInt32 **view);

    HRESULT ( STDMETHODCALLTYPE *IndexOf )(__RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This,
        /* [in] */ __RPC__in struct __x_ABI_CWindows_CGraphics_CRectInt32 item,
        /* [out] */ __RPC__out unsigned int *index,
        /* [retval][out] */ __RPC__out boolean *found);

    HRESULT ( STDMETHODCALLTYPE *SetAt )(__RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This,
        /* [in] */ unsigned int index,
        /* [in] */ __RPC__in struct __x_ABI_CWindows_CGraphics_CRectInt32 item);

    HRESULT ( STDMETHODCALLTYPE *InsertAt )(__RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This,
        /* [in] */ unsigned int index,
        /* [in] */ __RPC__in struct __x_ABI_CWindows_CGraphics_CRectInt32 item);

    HRESULT ( STDMETHODCALLTYPE *RemoveAt )(__RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This, /* [in] */ unsigned int index);
    HRESULT ( STDMETHODCALLTYPE *Append )(__RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This, /* [in] */ __RPC__in struct __x_ABI_CWindows_CGraphics_CRectInt32 item);
    HRESULT ( STDMETHODCALLTYPE *RemoveAtEnd )(__RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This);
    HRESULT ( STDMETHODCALLTYPE *Clear )(__RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This);
    HRESULT ( STDMETHODCALLTYPE *GetMany )(__RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This,
        /* [in] */ unsigned int startIndex,
        /* [in] */ unsigned int capacity,
        /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) struct __x_ABI_CWindows_CGraphics_CRectInt32 *items,
        /* [retval][out] */ __RPC__out unsigned int *actual);

    HRESULT ( STDMETHODCALLTYPE *ReplaceAll )(__RPC__in __FIVector_1_Windows__CGraphics__CRectInt32 * This,
        /* [in] */ unsigned int count,
        /* [size_is][in] */ __RPC__in_ecount_full(count) struct __x_ABI_CWindows_CGraphics_CRectInt32 *value);

    END_INTERFACE
} __FIVector_1_Windows__CGraphics__CRectInt32Vtbl;

interface __FIVector_1_Windows__CGraphics__CRectInt32
{
    CONST_VTBL struct __FIVector_1_Windows__CGraphics__CRectInt32Vtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIVector_1_Windows__CGraphics__CRectInt32_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIVector_1_Windows__CGraphics__CRectInt32_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIVector_1_Windows__CGraphics__CRectInt32_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIVector_1_Windows__CGraphics__CRectInt32_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIVector_1_Windows__CGraphics__CRectInt32_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIVector_1_Windows__CGraphics__CRectInt32_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIVector_1_Windows__CGraphics__CRectInt32_GetAt(This,index,item)	\
    ( (This)->lpVtbl -> GetAt(This,index,item) ) 

#define __FIVector_1_Windows__CGraphics__CRectInt32_get_Size(This,size)	\
    ( (This)->lpVtbl -> get_Size(This,size) ) 

#define __FIVector_1_Windows__CGraphics__CRectInt32_GetView(This,view)	\
    ( (This)->lpVtbl -> GetView(This,view) ) 

#define __FIVector_1_Windows__CGraphics__CRectInt32_IndexOf(This,item,index,found)	\
    ( (This)->lpVtbl -> IndexOf(This,item,index,found) ) 

#define __FIVector_1_Windows__CGraphics__CRectInt32_SetAt(This,index,item)	\
    ( (This)->lpVtbl -> SetAt(This,index,item) ) 

#define __FIVector_1_Windows__CGraphics__CRectInt32_InsertAt(This,index,item)	\
    ( (This)->lpVtbl -> InsertAt(This,index,item) ) 

#define __FIVector_1_Windows__CGraphics__CRectInt32_RemoveAt(This,index)	\
    ( (This)->lpVtbl -> RemoveAt(This,index) ) 

#define __FIVector_1_Windows__CGraphics__CRectInt32_Append(This,item)	\
    ( (This)->lpVtbl -> Append(This,item) ) 

#define __FIVector_1_Windows__CGraphics__CRectInt32_RemoveAtEnd(This)	\
    ( (This)->lpVtbl -> RemoveAtEnd(This) ) 

#define __FIVector_1_Windows__CGraphics__CRectInt32_Clear(This)	\
    ( (This)->lpVtbl -> Clear(This) ) 

#define __FIVector_1_Windows__CGraphics__CRectInt32_GetMany(This,startIndex,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,startIndex,capacity,items,actual) ) 

#define __FIVector_1_Windows__CGraphics__CRectInt32_ReplaceAll(This,count,value)	\
    ( (This)->lpVtbl -> ReplaceAll(This,count,value) ) 

#endif /* COBJMACROS */



#endif // ____FIVector_1_Windows__CGraphics__CRectInt32_INTERFACE_DEFINED__



#if !defined(____FIVector_1_Windows__CGraphics__CPointInt32_INTERFACE_DEFINED__)
#define ____FIVector_1_Windows__CGraphics__CPointInt32_INTERFACE_DEFINED__

typedef interface __FIVector_1_Windows__CGraphics__CPointInt32 __FIVector_1_Windows__CGraphics__CPointInt32;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIVector_1_Windows__CGraphics__CPointInt32;

typedef struct __FIVector_1_Windows__CGraphics__CPointInt32Vtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This,
            /* [in] */ __RPC__in REFIID riid,
            /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This, /* [out] */ __RPC__deref_out_opt struct __x_ABI_CWindows_CGraphics_CPointInt32 *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *GetAt )(__RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This,
        /* [in] */ unsigned int index,
        /* [retval][out] */ __RPC__deref_out_opt struct __x_ABI_CWindows_CGraphics_CPointInt32 *item);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Size )( 
        __RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This,
        /* [retval][out] */ __RPC__out unsigned int *size);

    HRESULT ( STDMETHODCALLTYPE *GetView )(__RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This, /* [retval][out] */ __RPC__deref_out_opt __FIVectorView_1_Windows__CGraphics__CPointInt32 **view);

    HRESULT ( STDMETHODCALLTYPE *IndexOf )(__RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This,
        /* [in] */ __RPC__in struct __x_ABI_CWindows_CGraphics_CPointInt32 item,
        /* [out] */ __RPC__out unsigned int *index,
        /* [retval][out] */ __RPC__out boolean *found);

    HRESULT ( STDMETHODCALLTYPE *SetAt )(__RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This,
        /* [in] */ unsigned int index,
        /* [in] */ __RPC__in struct __x_ABI_CWindows_CGraphics_CPointInt32 item);

    HRESULT ( STDMETHODCALLTYPE *InsertAt )(__RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This,
        /* [in] */ unsigned int index,
        /* [in] */ __RPC__in struct __x_ABI_CWindows_CGraphics_CPointInt32 item);

    HRESULT ( STDMETHODCALLTYPE *RemoveAt )(__RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This, /* [in] */ unsigned int index);
    HRESULT ( STDMETHODCALLTYPE *Append )(__RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This, /* [in] */ __RPC__in struct __x_ABI_CWindows_CGraphics_CPointInt32 item);
    HRESULT ( STDMETHODCALLTYPE *RemoveAtEnd )(__RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This);
    HRESULT ( STDMETHODCALLTYPE *Clear )(__RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This);
    HRESULT ( STDMETHODCALLTYPE *GetMany )(__RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This,
        /* [in] */ unsigned int startIndex,
        /* [in] */ unsigned int capacity,
        /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) struct __x_ABI_CWindows_CGraphics_CPointInt32 *items,
        /* [retval][out] */ __RPC__out unsigned int *actual);

    HRESULT ( STDMETHODCALLTYPE *ReplaceAll )(__RPC__in __FIVector_1_Windows__CGraphics__CPointInt32 * This,
        /* [in] */ unsigned int count,
        /* [size_is][in] */ __RPC__in_ecount_full(count) struct __x_ABI_CWindows_CGraphics_CPointInt32 *value);

    END_INTERFACE
} __FIVector_1_Windows__CGraphics__CPointInt32Vtbl;

interface __FIVector_1_Windows__CGraphics__CPointInt32
{
    CONST_VTBL struct __FIVector_1_Windows__CGraphics__CPointInt32Vtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIVector_1_Windows__CGraphics__CPointInt32_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIVector_1_Windows__CGraphics__CPointInt32_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIVector_1_Windows__CGraphics__CPointInt32_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIVector_1_Windows__CGraphics__CPointInt32_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIVector_1_Windows__CGraphics__CPointInt32_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIVector_1_Windows__CGraphics__CPointInt32_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIVector_1_Windows__CGraphics__CPointInt32_GetAt(This,index,item)	\
    ( (This)->lpVtbl -> GetAt(This,index,item) ) 

#define __FIVector_1_Windows__CGraphics__CPointInt32_get_Size(This,size)	\
    ( (This)->lpVtbl -> get_Size(This,size) ) 

#define __FIVector_1_Windows__CGraphics__CPointInt32_GetView(This,view)	\
    ( (This)->lpVtbl -> GetView(This,view) ) 

#define __FIVector_1_Windows__CGraphics__CPointInt32_IndexOf(This,item,index,found)	\
    ( (This)->lpVtbl -> IndexOf(This,item,index,found) ) 

#define __FIVector_1_Windows__CGraphics__CPointInt32_SetAt(This,index,item)	\
    ( (This)->lpVtbl -> SetAt(This,index,item) ) 

#define __FIVector_1_Windows__CGraphics__CPointInt32_InsertAt(This,index,item)	\
    ( (This)->lpVtbl -> InsertAt(This,index,item) ) 

#define __FIVector_1_Windows__CGraphics__CPointInt32_RemoveAt(This,index)	\
    ( (This)->lpVtbl -> RemoveAt(This,index) ) 

#define __FIVector_1_Windows__CGraphics__CPointInt32_Append(This,item)	\
    ( (This)->lpVtbl -> Append(This,item) ) 

#define __FIVector_1_Windows__CGraphics__CPointInt32_RemoveAtEnd(This)	\
    ( (This)->lpVtbl -> RemoveAtEnd(This) ) 

#define __FIVector_1_Windows__CGraphics__CPointInt32_Clear(This)	\
    ( (This)->lpVtbl -> Clear(This) ) 

#define __FIVector_1_Windows__CGraphics__CPointInt32_GetMany(This,startIndex,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,startIndex,capacity,items,actual) ) 

#define __FIVector_1_Windows__CGraphics__CPointInt32_ReplaceAll(This,count,value)	\
    ( (This)->lpVtbl -> ReplaceAll(This,count,value) ) 

#endif /* COBJMACROS */



#endif // ____FIVector_1_Windows__CGraphics__CPointInt32_INTERFACE_DEFINED__



#ifndef ____x_ABI_CMicrosoft_CGraphics_CImaging_CIImageBuffer_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CImaging_CIImageBuffer_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CImaging_CIImageBuffer __x_ABI_CMicrosoft_CGraphics_CImaging_CIImageBuffer;

#endif // ____x_ABI_CMicrosoft_CGraphics_CImaging_CIImageBuffer_FWD_DEFINED__







typedef enum __x_ABI_CMicrosoft_CWindows_CAI_CAIFeatureReadyState __x_ABI_CMicrosoft_CWindows_CAI_CAIFeatureReadyState;




#ifndef ____x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions __x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions;

#endif // ____x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions_FWD_DEFINED__






#ifndef ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CFoundation_CIClosable __x_ABI_CWindows_CFoundation_CIClosable;

#endif // ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__



typedef struct __x_ABI_CWindows_CFoundation_CPoint __x_ABI_CWindows_CFoundation_CPoint;



#ifndef ____x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap_FWD_DEFINED__
#define ____x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap __x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap;

#endif // ____x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap_FWD_DEFINED__






typedef struct __x_ABI_CWindows_CGraphics_CPointInt32 __x_ABI_CWindows_CGraphics_CPointInt32;


typedef struct __x_ABI_CWindows_CGraphics_CRectInt32 __x_ABI_CWindows_CGraphics_CRectInt32;








typedef enum __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CImageDescriptionKind __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CImageDescriptionKind;


typedef enum __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CImageDescriptionResultStatus __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CImageDescriptionResultStatus;


typedef enum __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CRecognizedLineStyle __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CRecognizedLineStyle;


typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CRecognizedTextBoundingBox __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CRecognizedTextBoundingBox;






































/*
 *
 * Struct Microsoft.Windows.AI.Imaging.ImageDescriptionKind
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageDescriptionContract in version 1.0
 *
 *
 */

#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000
/* [v1_enum, contract] */
enum __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CImageDescriptionKind
{
    ImageDescriptionKind_BriefDescription = 0,
    ImageDescriptionKind_DetailedDescription = 1,
    ImageDescriptionKind_DiagramDescription = 2,
    ImageDescriptionKind_AccessibleDescription = 3,
};
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Struct Microsoft.Windows.AI.Imaging.ImageDescriptionResultStatus
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageDescriptionContract in version 1.0
 *
 *
 */

#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000
/* [v1_enum, contract] */
enum __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CImageDescriptionResultStatus
{
    ImageDescriptionResultStatus_Complete = 0,
    ImageDescriptionResultStatus_InProgress = 1,
    ImageDescriptionResultStatus_BlockedByPolicy = 2,
    ImageDescriptionResultStatus_ImageBlockedByContentModeration = 3,
    ImageDescriptionResultStatus_TextInImageBlockedByContentModeration = 4,
    ImageDescriptionResultStatus_DescriptionTextBlockedByContentModeration = 5,
    ImageDescriptionResultStatus_ImageHasTooMuchText = 6,
    ImageDescriptionResultStatus_InternalError = 7,
};
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Struct Microsoft.Windows.AI.Imaging.RecognizedLineStyle
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 */

#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000
/* [v1_enum, contract] */
enum __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CRecognizedLineStyle
{
    RecognizedLineStyle_Handwritten = 0,
};
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Struct Microsoft.Windows.AI.Imaging.RecognizedTextBoundingBox
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000

/* [contract] */
struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CRecognizedTextBoundingBox
{
    __x_ABI_CWindows_CFoundation_CPoint BottomLeft;
    __x_ABI_CWindows_CFoundation_CPoint BottomRight;
    __x_ABI_CWindows_CFoundation_CPoint TopLeft;
    __x_ABI_CWindows_CFoundation_CPoint TopRight;
};
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageDescriptionGenerator
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageDescriptionContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageDescriptionGenerator
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageDescriptionGenerator[] = L"Microsoft.Windows.AI.Imaging.IImageDescriptionGenerator";
/* [object, uuid("576B989E-9829-5682-91B0-A7110FA7D51E"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *DescribeAsync )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CImaging_CIImageBuffer * image,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CAI_CImaging_CImageDescriptionKind kind,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CAI_CContentSafety_CIContentFilterOptions * contentFilterOptions,
        /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CImaging__CImageDescriptionResult_HSTRING * * operation
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_DescribeAsync(This,image,kind,contentFilterOptions,operation) \
    ( (This)->lpVtbl->DescribeAsync(This,image,kind,contentFilterOptions,operation) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGenerator_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageDescriptionGeneratorStatics
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageDescriptionContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageDescriptionGenerator
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageDescriptionGeneratorStatics[] = L"Microsoft.Windows.AI.Imaging.IImageDescriptionGeneratorStatics";
/* [object, uuid("5FB50B2A-5700-55A7-B413-6073B4B7F175"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *GetReadyState )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CAIFeatureReadyState * result
        );
    HRESULT ( STDMETHODCALLTYPE *EnsureReadyAsync )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics * This,
        /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * * operation
        );
    HRESULT ( STDMETHODCALLTYPE *CreateAsync )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics * This,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageDescriptionGenerator * * operation
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStaticsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_GetReadyState(This,result) \
    ( (This)->lpVtbl->GetReadyState(This,result) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_EnsureReadyAsync(This,operation) \
    ( (This)->lpVtbl->EnsureReadyAsync(This,operation) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_CreateAsync(This,operation) \
    ( (This)->lpVtbl->CreateAsync(This,operation) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionGeneratorStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageDescriptionResult
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageDescriptionContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageDescriptionResult
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageDescriptionResult[] = L"Microsoft.Windows.AI.Imaging.IImageDescriptionResult";
/* [object, uuid("A066DD0C-110B-5275-A635-52BED7519A2F"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResultVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Description )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Status )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CImaging_CImageDescriptionResultStatus * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResultVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResultVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_get_Description(This,value) \
    ( (This)->lpVtbl->get_Description(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_get_Status(This,value) \
    ( (This)->lpVtbl->get_Status(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageDescriptionResult_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageObjectExtractor
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageObjectExtractorContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageObjectExtractor
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageObjectExtractor[] = L"Microsoft.Windows.AI.Imaging.IImageObjectExtractor";
/* [object, uuid("2919FDC0-D772-5FD9-A8B7-FFB56010C99C"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *GetSoftwareBitmapObjectMask )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint * hint,
        /* [retval, out] */__x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap * * result
        );
    HRESULT ( STDMETHODCALLTYPE *GetImageBufferObjectMask )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint * hint,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CImaging_CIImageBuffer * * result
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_GetSoftwareBitmapObjectMask(This,hint,result) \
    ( (This)->lpVtbl->GetSoftwareBitmapObjectMask(This,hint,result) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_GetImageBufferObjectMask(This,hint,result) \
    ( (This)->lpVtbl->GetImageBufferObjectMask(This,hint,result) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractor_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageObjectExtractorHint
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageObjectExtractorContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageObjectExtractorHint
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageObjectExtractorHint[] = L"Microsoft.Windows.AI.Imaging.IImageObjectExtractorHint";
/* [object, uuid("1BD8D67C-8A7A-5FE7-98A5-CBDFEB509452"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_IncludeRects )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint * This,
        /* [retval, out] */__FIVectorView_1_Windows__CGraphics__CRectInt32 * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_IncludePoints )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint * This,
        /* [retval, out] */__FIVectorView_1_Windows__CGraphics__CPointInt32 * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_ExcludePoints )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint * This,
        /* [retval, out] */__FIVectorView_1_Windows__CGraphics__CPointInt32 * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_get_IncludeRects(This,value) \
    ( (This)->lpVtbl->get_IncludeRects(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_get_IncludePoints(This,value) \
    ( (This)->lpVtbl->get_IncludePoints(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_get_ExcludePoints(This,value) \
    ( (This)->lpVtbl->get_ExcludePoints(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageObjectExtractorHintFactory
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageObjectExtractorContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageObjectExtractorHint
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageObjectExtractorHintFactory[] = L"Microsoft.Windows.AI.Imaging.IImageObjectExtractorHintFactory";
/* [object, uuid("5028F206-145D-5A70-9A51-E17E60CFBAD8"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateInstance )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory * This,
        /* [in] */__FIVector_1_Windows__CGraphics__CRectInt32 * includeRects,
        /* [in] */__FIVector_1_Windows__CGraphics__CPointInt32 * includePoints,
        /* [in] */__FIVector_1_Windows__CGraphics__CPointInt32 * excludePoints,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHint * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactoryVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_CreateInstance(This,includeRects,includePoints,excludePoints,value) \
    ( (This)->lpVtbl->CreateInstance(This,includeRects,includePoints,excludePoints,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorHintFactory_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageObjectExtractorStatics
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageObjectExtractorContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageObjectExtractor
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageObjectExtractorStatics[] = L"Microsoft.Windows.AI.Imaging.IImageObjectExtractorStatics";
/* [object, uuid("38FA261E-2C33-54CB-9E10-98D50685743D"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateWithSoftwareBitmapAsync )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics * This,
        /* [in] */__x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap * softwareBitmap,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor * * operation
        );
    HRESULT ( STDMETHODCALLTYPE *CreateWithImageBufferAsync )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CImaging_CIImageBuffer * imageBuffer,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageObjectExtractor * * operation
        );
    HRESULT ( STDMETHODCALLTYPE *GetReadyState )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CAIFeatureReadyState * result
        );
    HRESULT ( STDMETHODCALLTYPE *EnsureReadyAsync )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics * This,
        /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * * operation
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStaticsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_CreateWithSoftwareBitmapAsync(This,softwareBitmap,operation) \
    ( (This)->lpVtbl->CreateWithSoftwareBitmapAsync(This,softwareBitmap,operation) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_CreateWithImageBufferAsync(This,imageBuffer,operation) \
    ( (This)->lpVtbl->CreateWithImageBufferAsync(This,imageBuffer,operation) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_GetReadyState(This,result) \
    ( (This)->lpVtbl->GetReadyState(This,result) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_EnsureReadyAsync(This,operation) \
    ( (This)->lpVtbl->EnsureReadyAsync(This,operation) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageObjectExtractorStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageScaler
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageScalerContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageScaler
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageScaler[] = L"Microsoft.Windows.AI.Imaging.IImageScaler";
/* [object, uuid("06EEC88E-91C5-5326-8128-2807FAAFA571"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *ScaleSoftwareBitmap )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler * This,
        /* [in] */__x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap * softwareBitmap,
        /* [in] */INT32 width,
        /* [in] */INT32 height,
        /* [retval, out] */__x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap * * result
        );
    HRESULT ( STDMETHODCALLTYPE *ScaleImageBuffer )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CImaging_CIImageBuffer * imageBuffer,
        /* [in] */INT32 width,
        /* [in] */INT32 height,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CImaging_CIImageBuffer * * result
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_MaxSupportedScaleFactor )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler * This,
        /* [retval, out] */INT32 * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_ScaleSoftwareBitmap(This,softwareBitmap,width,height,result) \
    ( (This)->lpVtbl->ScaleSoftwareBitmap(This,softwareBitmap,width,height,result) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_ScaleImageBuffer(This,imageBuffer,width,height,result) \
    ( (This)->lpVtbl->ScaleImageBuffer(This,imageBuffer,width,height,result) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_get_MaxSupportedScaleFactor(This,value) \
    ( (This)->lpVtbl->get_MaxSupportedScaleFactor(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScaler_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IImageScalerStatics
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageScalerContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.ImageScaler
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IImageScalerStatics[] = L"Microsoft.Windows.AI.Imaging.IImageScalerStatics";
/* [object, uuid("75380C81-9C7F-544B-9337-6E638CFB464A"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *GetReadyState )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CAIFeatureReadyState * result
        );
    HRESULT ( STDMETHODCALLTYPE *EnsureReadyAsync )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics * This,
        /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * * operation
        );
    HRESULT ( STDMETHODCALLTYPE *CreateAsync )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics * This,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CImageScaler * * operation
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStaticsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_GetReadyState(This,result) \
    ( (This)->lpVtbl->GetReadyState(This,result) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_EnsureReadyAsync(This,operation) \
    ( (This)->lpVtbl->EnsureReadyAsync(This,operation) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_CreateAsync(This,operation) \
    ( (This)->lpVtbl->CreateAsync(This,operation) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIImageScalerStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IRecognizedLine
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.RecognizedLine
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IRecognizedLine[] = L"Microsoft.Windows.AI.Imaging.IRecognizedLine";
/* [object, uuid("612A6BE6-F6BB-53C9-84CE-F0A5E565FAA7"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLineVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Text )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_BoundingBox )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CImaging_CRecognizedTextBoundingBox * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Words )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine * This,
        /* [out] */UINT32 * __valueSize,
        /* [size_is(, *(__valueSize)), retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord * * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Style )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CImaging_CRecognizedLineStyle * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LineStyleConfidence )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine * This,
        /* [retval, out] */FLOAT * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLineVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLineVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_get_Text(This,value) \
    ( (This)->lpVtbl->get_Text(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_get_BoundingBox(This,value) \
    ( (This)->lpVtbl->get_BoundingBox(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_get_Words(This,__valueSize,value) \
    ( (This)->lpVtbl->get_Words(This,__valueSize,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_get_Style(This,value) \
    ( (This)->lpVtbl->get_Style(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_get_LineStyleConfidence(This,value) \
    ( (This)->lpVtbl->get_LineStyleConfidence(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IRecognizedText
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.RecognizedText
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IRecognizedText[] = L"Microsoft.Windows.AI.Imaging.IRecognizedText";
/* [object, uuid("AE4766D3-2924-57A6-B3D3-B866F59B9972"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedTextVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Lines )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText * This,
        /* [out] */UINT32 * __valueSize,
        /* [size_is(, *(__valueSize)), retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedLine * * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_TextAngle )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText * This,
        /* [retval, out] */FLOAT * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedTextVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedTextVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_get_Lines(This,__valueSize,value) \
    ( (This)->lpVtbl->get_Lines(This,__valueSize,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_get_TextAngle(This,value) \
    ( (This)->lpVtbl->get_TextAngle(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.IRecognizedWord
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.RecognizedWord
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_IRecognizedWord[] = L"Microsoft.Windows.AI.Imaging.IRecognizedWord";
/* [object, uuid("6B53DAAB-3410-5088-826A-0788A1EE3B52"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWordVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Text )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_BoundingBox )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CImaging_CRecognizedTextBoundingBox * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_MatchConfidence )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord * This,
        /* [retval, out] */FLOAT * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWordVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWordVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_get_Text(This,value) \
    ( (This)->lpVtbl->get_Text(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_get_BoundingBox(This,value) \
    ( (This)->lpVtbl->get_BoundingBox(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_get_MatchConfidence(This,value) \
    ( (This)->lpVtbl->get_MatchConfidence(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedWord_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.ITextRecognizer
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.TextRecognizer
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_ITextRecognizer[] = L"Microsoft.Windows.AI.Imaging.ITextRecognizer";
/* [object, uuid("BE7BF6C0-30F6-570D-BD92-3FFE5665D933"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *RecognizeTextFromImageAsync )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CImaging_CIImageBuffer * imageBuffer,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CRecognizedText * * operation
        );
    HRESULT ( STDMETHODCALLTYPE *RecognizeTextFromImage )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CImaging_CIImageBuffer * imageBuffer,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CImaging_CIRecognizedText * * result
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_RecognizeTextFromImageAsync(This,imageBuffer,operation) \
    ( (This)->lpVtbl->RecognizeTextFromImageAsync(This,imageBuffer,operation) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_RecognizeTextFromImage(This,imageBuffer,result) \
    ( (This)->lpVtbl->RecognizeTextFromImage(This,imageBuffer,result) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizer_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.AI.Imaging.ITextRecognizerStatics
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.AI.Imaging.TextRecognizer
 *
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_AI_Imaging_ITextRecognizerStatics[] = L"Microsoft.Windows.AI.Imaging.ITextRecognizerStatics";
/* [object, uuid("3788C2FD-E496-53AB-85A7-E54A135824E9"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *GetReadyState )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CAI_CAIFeatureReadyState * result
        );
    HRESULT ( STDMETHODCALLTYPE *EnsureReadyAsync )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics * This,
        /* [retval, out] */__FIAsyncOperationWithProgress_2_Microsoft__CWindows__CAI__CAIFeatureReadyResult_double * * operation
        );
    HRESULT ( STDMETHODCALLTYPE *CreateAsync )(
        __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics * This,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CWindows__CAI__CImaging__CTextRecognizer * * operation
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStaticsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_GetReadyState(This,result) \
    ( (This)->lpVtbl->GetReadyState(This,result) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_EnsureReadyAsync(This,operation) \
    ( (This)->lpVtbl->EnsureReadyAsync(This,operation) )

#define __x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_CreateAsync(This,operation) \
    ( (This)->lpVtbl->CreateAsync(This,operation) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CAI_CImaging_CITextRecognizerStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.ImageDescriptionGenerator
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageDescriptionContract in version 1.0
 *
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.AI.Imaging.IImageDescriptionGeneratorStatics interface starting with version 1.0 of the Microsoft.Windows.AI.Imaging.ImageDescriptionContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.IImageDescriptionGenerator ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageDescriptionGenerator_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageDescriptionGenerator_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_ImageDescriptionGenerator[] = L"Microsoft.Windows.AI.Imaging.ImageDescriptionGenerator";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.ImageDescriptionResult
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageDescriptionContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.IImageDescriptionResult ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageDescriptionResult_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageDescriptionResult_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_ImageDescriptionResult[] = L"Microsoft.Windows.AI.Imaging.ImageDescriptionResult";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEDESCRIPTIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.ImageObjectExtractor
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageObjectExtractorContract in version 1.0
 *
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.AI.Imaging.IImageObjectExtractorStatics interface starting with version 1.0 of the Microsoft.Windows.AI.Imaging.ImageObjectExtractorContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.IImageObjectExtractor ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageObjectExtractor_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageObjectExtractor_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_ImageObjectExtractor[] = L"Microsoft.Windows.AI.Imaging.ImageObjectExtractor";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.ImageObjectExtractorHint
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageObjectExtractorContract in version 1.0
 *
 *
 * RuntimeClass can be activated.
 *   Type can be activated via the Microsoft.Windows.AI.Imaging.IImageObjectExtractorHintFactory interface starting with version 1.0 of the Microsoft.Windows.AI.Imaging.ImageObjectExtractorContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.IImageObjectExtractorHint ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageObjectExtractorHint_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageObjectExtractorHint_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_ImageObjectExtractorHint[] = L"Microsoft.Windows.AI.Imaging.ImageObjectExtractorHint";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGEOBJECTEXTRACTORCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.ImageScaler
 *
 * Introduced to Microsoft.Windows.AI.Imaging.ImageScalerContract in version 1.0
 *
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.AI.Imaging.IImageScalerStatics interface starting with version 1.0 of the Microsoft.Windows.AI.Imaging.ImageScalerContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.IImageScaler ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageScaler_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_ImageScaler_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_ImageScaler[] = L"Microsoft.Windows.AI.Imaging.ImageScaler";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_IMAGESCALERCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.RecognizedLine
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.IRecognizedLine ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_RecognizedLine_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_RecognizedLine_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_RecognizedLine[] = L"Microsoft.Windows.AI.Imaging.RecognizedLine";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.RecognizedText
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.IRecognizedText ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_RecognizedText_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_RecognizedText_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_RecognizedText[] = L"Microsoft.Windows.AI.Imaging.RecognizedText";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.RecognizedWord
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.IRecognizedWord ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_RecognizedWord_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_RecognizedWord_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_RecognizedWord[] = L"Microsoft.Windows.AI.Imaging.RecognizedWord";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.AI.Imaging.TextRecognizer
 *
 * Introduced to Microsoft.Windows.AI.Imaging.TextRecognitionContract in version 1.0
 *
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.AI.Imaging.ITextRecognizerStatics interface starting with version 1.0 of the Microsoft.Windows.AI.Imaging.TextRecognitionContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.AI.Imaging.ITextRecognizer ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000

#ifndef RUNTIMECLASS_Microsoft_Windows_AI_Imaging_TextRecognizer_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_AI_Imaging_TextRecognizer_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_AI_Imaging_TextRecognizer[] = L"Microsoft.Windows.AI.Imaging.TextRecognizer";
#endif
#endif // MICROSOFT_WINDOWS_AI_IMAGING_TEXTRECOGNITIONCONTRACT_VERSION >= 0x10000





#endif // defined(__cplusplus)
#pragma pop_macro("MIDL_CONST_ID")
// Restore the original value of the 'DEPRECATED' macro
#pragma pop_macro("DEPRECATED")

#ifdef __clang__
#pragma clang diagnostic pop // deprecated-declarations
#else
#pragma warning(pop)
#endif
#endif // __microsoft2Ewindows2Eai2Eimaging_p_h__

#endif // __microsoft2Ewindows2Eai2Eimaging_h__
