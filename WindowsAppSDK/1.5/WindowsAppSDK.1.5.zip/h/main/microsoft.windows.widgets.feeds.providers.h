
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

/* verify that the <rpcsal.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCSAL_H_VERSION__
#define __REQUIRED_RPCSAL_H_VERSION__ 100
#endif

#include <rpc.h>
#include <rpcndr.h>

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include <windows.h>
#include <ole2.h>
#endif /*COM_NO_WINDOWS_H*/
#ifndef __microsoft2Ewindows2Ewidgets2Efeeds2Eproviders_h__
#define __microsoft2Ewindows2Ewidgets2Efeeds2Eproviders_h__
#ifndef __microsoft2Ewindows2Ewidgets2Efeeds2Eproviders_p_h__
#define __microsoft2Ewindows2Ewidgets2Efeeds2Eproviders_p_h__


#pragma once

//
// Deprecated attribute support
//

#pragma push_macro("DEPRECATED")
#undef DEPRECATED

#if !defined(DISABLE_WINRT_DEPRECATION)
#if defined(__cplusplus)
#if __cplusplus >= 201402
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#elif defined(_MSC_VER)
#if _MSC_VER >= 1900
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#else
#define DEPRECATED(x) __declspec(deprecated(x))
#define DEPRECATEDENUMERATOR(x)
#endif // _MSC_VER >= 1900
#else // Not Standard C++ or MSVC, ignore the construct.
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  // C++ deprecation
#else // C - disable deprecation
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif
#else // Deprecation is disabled
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  /* DEPRECATED */

// Disable Deprecation for this header, MIDL verifies that cross-type access is acceptable
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#else
#pragma warning(push)
#pragma warning(disable: 4996)
#endif

// Ensure that the setting of the /ns_prefix command line switch is consistent for all headers.
// If you get an error from the compiler indicating "warning C4005: 'CHECK_NS_PREFIX_STATE': macro redefinition", this
// indicates that you have included two different headers with different settings for the /ns_prefix MIDL command line switch
#if !defined(DISABLE_NS_PREFIX_CHECKS)
#define CHECK_NS_PREFIX_STATE "always"
#endif // !defined(DISABLE_NS_PREFIX_CHECKS)


#pragma push_macro("MIDL_CONST_ID")
#undef MIDL_CONST_ID
#define MIDL_CONST_ID const __declspec(selectany)


//  API Contract Inclusion Definitions
#if !defined(SPECIFIC_API_CONTRACT_DEFINITIONS)
#if !defined(MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION)
#define MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION 0x40000
#endif // defined(MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION 0x50000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)
#define WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)
#define WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION 0xa0000
#endif // defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)
#define WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)
#define WINDOWS_PHONE_PHONECONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)
#define WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)

#if !defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)
#define WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)

#endif // defined(SPECIFIC_API_CONTRACT_DEFINITIONS)


// Header files for imported files
#include "inspectable.h"
#include "AsyncInfo.h"
#include "EventToken.h"
#include "windowscontracts.h"
#include "Windows.Foundation.h"
#include "Microsoft.Windows.Widgets.h"

#if defined(__cplusplus) && !defined(CINTERFACE)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        interface ICustomQueryParametersRequestedArgs;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs ABI::Microsoft::Windows::Widgets::Feeds::Providers::ICustomQueryParametersRequestedArgs

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        interface ICustomQueryParametersUpdateOptions;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions ABI::Microsoft::Windows::Widgets::Feeds::Providers::ICustomQueryParametersUpdateOptions

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        interface ICustomQueryParametersUpdateOptionsFactory;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory ABI::Microsoft::Windows::Widgets::Feeds::Providers::ICustomQueryParametersUpdateOptionsFactory

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        interface IFeedDisabledArgs;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs ABI::Microsoft::Windows::Widgets::Feeds::Providers::IFeedDisabledArgs

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        interface IFeedEnabledArgs;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs ABI::Microsoft::Windows::Widgets::Feeds::Providers::IFeedEnabledArgs

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        interface IFeedManager;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager ABI::Microsoft::Windows::Widgets::Feeds::Providers::IFeedManager

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        interface IFeedManagerStatics;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics ABI::Microsoft::Windows::Widgets::Feeds::Providers::IFeedManagerStatics

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        interface IFeedProvider;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider ABI::Microsoft::Windows::Widgets::Feeds::Providers::IFeedProvider

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        interface IFeedProviderDisabledArgs;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs ABI::Microsoft::Windows::Widgets::Feeds::Providers::IFeedProviderDisabledArgs

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        interface IFeedProviderEnabledArgs;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs ABI::Microsoft::Windows::Widgets::Feeds::Providers::IFeedProviderEnabledArgs

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        interface IFeedProviderInfo;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo ABI::Microsoft::Windows::Widgets::Feeds::Providers::IFeedProviderInfo

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_FWD_DEFINED__

















namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        class CustomQueryParametersRequestedArgs;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        class CustomQueryParametersUpdateOptions;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        class FeedDisabledArgs;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        class FeedEnabledArgs;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        class FeedManager;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        class FeedProviderDisabledArgs;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        class FeedProviderEnabledArgs;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        class FeedProviderInfo;
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */








/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersRequestedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.CustomQueryParametersRequestedArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_ICustomQueryParametersRequestedArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersRequestedArgs";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        /* [object, uuid("DC2B0CD8-7936-5346-9371-B21484C7D859"), exclusiveto, contract] */
                        MIDL_INTERFACE("DC2B0CD8-7936-5346-9371-B21484C7D859")
                        ICustomQueryParametersRequestedArgs : public IInspectable
                        {
                        public:
                            /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FeedProviderDefinitionId(
                                /* [retval, out] */HSTRING * value
                                ) = 0;
                            
                        };

                        extern MIDL_CONST_ID IID & IID_ICustomQueryParametersRequestedArgs=_uuidof(ICustomQueryParametersRequestedArgs);
                        
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersUpdateOptions
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.CustomQueryParametersUpdateOptions
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_ICustomQueryParametersUpdateOptions[] = L"Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersUpdateOptions";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        /* [object, uuid("753F1177-4909-568A-B070-98A3139205EC"), exclusiveto, contract] */
                        MIDL_INTERFACE("753F1177-4909-568A-B070-98A3139205EC")
                        ICustomQueryParametersUpdateOptions : public IInspectable
                        {
                        public:
                            /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FeedProviderDefinitionId(
                                /* [retval, out] */HSTRING * value
                                ) = 0;
                            /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_CustomQueryParameters(
                                /* [retval, out] */HSTRING * value
                                ) = 0;
                            
                        };

                        extern MIDL_CONST_ID IID & IID_ICustomQueryParametersUpdateOptions=_uuidof(ICustomQueryParametersUpdateOptions);
                        
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersUpdateOptionsFactory
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.CustomQueryParametersUpdateOptions
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_ICustomQueryParametersUpdateOptionsFactory[] = L"Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersUpdateOptionsFactory";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        /* [object, uuid("34E318CD-3884-53C0-911C-225F32228FAE"), exclusiveto, contract] */
                        MIDL_INTERFACE("34E318CD-3884-53C0-911C-225F32228FAE")
                        ICustomQueryParametersUpdateOptionsFactory : public IInspectable
                        {
                        public:
                            virtual HRESULT STDMETHODCALLTYPE CreateInstance(
                                /* [in] */HSTRING feedProviderDefinitionId,
                                /* [in] */HSTRING customQueryParameters,
                                /* [retval, out] */ABI::Microsoft::Windows::Widgets::Feeds::Providers::ICustomQueryParametersUpdateOptions * * value
                                ) = 0;
                            
                        };

                        extern MIDL_CONST_ID IID & IID_ICustomQueryParametersUpdateOptionsFactory=_uuidof(ICustomQueryParametersUpdateOptionsFactory);
                        
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.IFeedDisabledArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.FeedDisabledArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_IFeedDisabledArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.IFeedDisabledArgs";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        /* [object, uuid("95300612-ACA7-53C0-9CF6-D803689132C1"), exclusiveto, contract] */
                        MIDL_INTERFACE("95300612-ACA7-53C0-9CF6-D803689132C1")
                        IFeedDisabledArgs : public IInspectable
                        {
                        public:
                            /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FeedProviderDefinitionId(
                                /* [retval, out] */HSTRING * value
                                ) = 0;
                            /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FeedDefinitionId(
                                /* [retval, out] */HSTRING * value
                                ) = 0;
                            
                        };

                        extern MIDL_CONST_ID IID & IID_IFeedDisabledArgs=_uuidof(IFeedDisabledArgs);
                        
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.IFeedEnabledArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.FeedEnabledArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_IFeedEnabledArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.IFeedEnabledArgs";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        /* [object, uuid("EFF4B2D7-7347-5969-A77D-CAC433F0FDAE"), exclusiveto, contract] */
                        MIDL_INTERFACE("EFF4B2D7-7347-5969-A77D-CAC433F0FDAE")
                        IFeedEnabledArgs : public IInspectable
                        {
                        public:
                            /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FeedProviderDefinitionId(
                                /* [retval, out] */HSTRING * value
                                ) = 0;
                            /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FeedDefinitionId(
                                /* [retval, out] */HSTRING * value
                                ) = 0;
                            
                        };

                        extern MIDL_CONST_ID IID & IID_IFeedEnabledArgs=_uuidof(IFeedEnabledArgs);
                        
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.IFeedManager
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_IFeedManager[] = L"Microsoft.Windows.Widgets.Feeds.Providers.IFeedManager";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        /* [object, uuid("87DF6A84-15AA-45CB-8911-5CAFAB57F723"), contract] */
                        MIDL_INTERFACE("87DF6A84-15AA-45CB-8911-5CAFAB57F723")
                        IFeedManager : public IInspectable
                        {
                        public:
                            virtual HRESULT STDMETHODCALLTYPE GetEnabledFeedProviders(
                                /* [out] */UINT32 * __resultSize,
                                /* [size_is(, *(__resultSize)), retval, out] */ABI::Microsoft::Windows::Widgets::Feeds::Providers::IFeedProviderInfo * * * result
                                ) = 0;
                            virtual HRESULT STDMETHODCALLTYPE SetCustomQueryParameters(
                                /* [in] */ABI::Microsoft::Windows::Widgets::Feeds::Providers::ICustomQueryParametersUpdateOptions * options
                                ) = 0;
                            
                        };

                        extern MIDL_CONST_ID IID & IID_IFeedManager=_uuidof(IFeedManager);
                        
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.IFeedManagerStatics
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.FeedManager
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_IFeedManagerStatics[] = L"Microsoft.Windows.Widgets.Feeds.Providers.IFeedManagerStatics";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        /* [object, uuid("4BAF5174-77D6-5E2A-94EA-4F14CCDB1F2C"), exclusiveto, contract] */
                        MIDL_INTERFACE("4BAF5174-77D6-5E2A-94EA-4F14CCDB1F2C")
                        IFeedManagerStatics : public IInspectable
                        {
                        public:
                            virtual HRESULT STDMETHODCALLTYPE GetDefault(
                                /* [retval, out] */ABI::Microsoft::Windows::Widgets::Feeds::Providers::IFeedManager * * result
                                ) = 0;
                            
                        };

                        extern MIDL_CONST_ID IID & IID_IFeedManagerStatics=_uuidof(IFeedManagerStatics);
                        
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.IFeedProvider
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_IFeedProvider[] = L"Microsoft.Windows.Widgets.Feeds.Providers.IFeedProvider";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        /* [object, uuid("7293A12B-0329-458D-AC25-5332BE478FDE"), contract] */
                        MIDL_INTERFACE("7293A12B-0329-458D-AC25-5332BE478FDE")
                        IFeedProvider : public IInspectable
                        {
                        public:
                            virtual HRESULT STDMETHODCALLTYPE OnFeedProviderEnabled(
                                /* [in] */ABI::Microsoft::Windows::Widgets::Feeds::Providers::IFeedProviderEnabledArgs * args
                                ) = 0;
                            virtual HRESULT STDMETHODCALLTYPE OnFeedProviderDisabled(
                                /* [in] */ABI::Microsoft::Windows::Widgets::Feeds::Providers::IFeedProviderDisabledArgs * args
                                ) = 0;
                            virtual HRESULT STDMETHODCALLTYPE OnFeedEnabled(
                                /* [in] */ABI::Microsoft::Windows::Widgets::Feeds::Providers::IFeedEnabledArgs * args
                                ) = 0;
                            virtual HRESULT STDMETHODCALLTYPE OnFeedDisabled(
                                /* [in] */ABI::Microsoft::Windows::Widgets::Feeds::Providers::IFeedDisabledArgs * args
                                ) = 0;
                            virtual HRESULT STDMETHODCALLTYPE OnCustomQueryParametersRequested(
                                /* [in] */ABI::Microsoft::Windows::Widgets::Feeds::Providers::ICustomQueryParametersRequestedArgs * args
                                ) = 0;
                            
                        };

                        extern MIDL_CONST_ID IID & IID_IFeedProvider=_uuidof(IFeedProvider);
                        
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderDisabledArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderDisabledArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_IFeedProviderDisabledArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderDisabledArgs";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        /* [object, uuid("19B65AEC-E01D-5E8C-AB5F-324212E7CD30"), exclusiveto, contract] */
                        MIDL_INTERFACE("19B65AEC-E01D-5E8C-AB5F-324212E7CD30")
                        IFeedProviderDisabledArgs : public IInspectable
                        {
                        public:
                            /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FeedProviderDefinitionId(
                                /* [retval, out] */HSTRING * value
                                ) = 0;
                            
                        };

                        extern MIDL_CONST_ID IID & IID_IFeedProviderDisabledArgs=_uuidof(IFeedProviderDisabledArgs);
                        
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderEnabledArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderEnabledArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_IFeedProviderEnabledArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderEnabledArgs";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        /* [object, uuid("821FC9AF-0DE6-5A9B-9AE6-E179117B40E4"), exclusiveto, contract] */
                        MIDL_INTERFACE("821FC9AF-0DE6-5A9B-9AE6-E179117B40E4")
                        IFeedProviderEnabledArgs : public IInspectable
                        {
                        public:
                            /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FeedProviderDefinitionId(
                                /* [retval, out] */HSTRING * value
                                ) = 0;
                            
                        };

                        extern MIDL_CONST_ID IID & IID_IFeedProviderEnabledArgs=_uuidof(IFeedProviderEnabledArgs);
                        
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderInfo
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderInfo
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_IFeedProviderInfo[] = L"Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderInfo";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Widgets {
                namespace Feeds {
                    namespace Providers {
                        /* [object, uuid("73C37049-3C03-5896-8532-F9DFDAEB723F"), exclusiveto, contract] */
                        MIDL_INTERFACE("73C37049-3C03-5896-8532-F9DFDAEB723F")
                        IFeedProviderInfo : public IInspectable
                        {
                        public:
                            /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FeedProviderDefinitionId(
                                /* [retval, out] */HSTRING * value
                                ) = 0;
                            /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_EnabledFeedDefinitionIds(
                                /* [out] */UINT32 * __valueSize,
                                /* [size_is(, *(__valueSize)), retval, out] */HSTRING * * value
                                ) = 0;
                            
                        };

                        extern MIDL_CONST_ID IID & IID_IFeedProviderInfo=_uuidof(IFeedProviderInfo);
                        
                    } /* Providers */
                } /* Feeds */
            } /* Widgets */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Class Microsoft.Windows.Widgets.Feeds.Providers.CustomQueryParametersRequestedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersRequestedArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_CustomQueryParametersRequestedArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_CustomQueryParametersRequestedArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Feeds_Providers_CustomQueryParametersRequestedArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.CustomQueryParametersRequestedArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Class Microsoft.Windows.Widgets.Feeds.Providers.CustomQueryParametersUpdateOptions
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * RuntimeClass can be activated.
 *   Type can be activated via the Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersUpdateOptionsFactory interface starting with version 4.0 of the Microsoft.Windows.Widgets.WidgetContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersUpdateOptions ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_CustomQueryParametersUpdateOptions_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_CustomQueryParametersUpdateOptions_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Feeds_Providers_CustomQueryParametersUpdateOptions[] = L"Microsoft.Windows.Widgets.Feeds.Providers.CustomQueryParametersUpdateOptions";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Class Microsoft.Windows.Widgets.Feeds.Providers.FeedDisabledArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Feeds.Providers.IFeedDisabledArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedDisabledArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedDisabledArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Feeds_Providers_FeedDisabledArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.FeedDisabledArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Class Microsoft.Windows.Widgets.Feeds.Providers.FeedEnabledArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Feeds.Providers.IFeedEnabledArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedEnabledArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedEnabledArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Feeds_Providers_FeedEnabledArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.FeedEnabledArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Class Microsoft.Windows.Widgets.Feeds.Providers.FeedManager
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.Widgets.Feeds.Providers.IFeedManagerStatics interface starting with version 4.0 of the Microsoft.Windows.Widgets.WidgetContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Feeds.Providers.IFeedManager ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedManager_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedManager_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Feeds_Providers_FeedManager[] = L"Microsoft.Windows.Widgets.Feeds.Providers.FeedManager";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Class Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderDisabledArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderDisabledArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderDisabledArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderDisabledArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderDisabledArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderDisabledArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Class Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderEnabledArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderEnabledArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderEnabledArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderEnabledArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderEnabledArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderEnabledArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Class Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderInfo
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderInfo ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderInfo_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderInfo_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderInfo[] = L"Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderInfo";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000






#else // !defined(__cplusplus)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo;

#endif // ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_FWD_DEFINED__






























/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersRequestedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.CustomQueryParametersRequestedArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_ICustomQueryParametersRequestedArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersRequestedArgs";
/* [object, uuid("DC2B0CD8-7936-5346-9371-B21484C7D859"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FeedProviderDefinitionId )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs * This,
        /* [retval, out] */HSTRING * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_get_FeedProviderDefinitionId(This,value) \
    ( (This)->lpVtbl->get_FeedProviderDefinitionId(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersUpdateOptions
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.CustomQueryParametersUpdateOptions
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_ICustomQueryParametersUpdateOptions[] = L"Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersUpdateOptions";
/* [object, uuid("753F1177-4909-568A-B070-98A3139205EC"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FeedProviderDefinitionId )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_CustomQueryParameters )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions * This,
        /* [retval, out] */HSTRING * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_get_FeedProviderDefinitionId(This,value) \
    ( (This)->lpVtbl->get_FeedProviderDefinitionId(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_get_CustomQueryParameters(This,value) \
    ( (This)->lpVtbl->get_CustomQueryParameters(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersUpdateOptionsFactory
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.CustomQueryParametersUpdateOptions
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_ICustomQueryParametersUpdateOptionsFactory[] = L"Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersUpdateOptionsFactory";
/* [object, uuid("34E318CD-3884-53C0-911C-225F32228FAE"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateInstance )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory * This,
        /* [in] */HSTRING feedProviderDefinitionId,
        /* [in] */HSTRING customQueryParameters,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactoryVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_CreateInstance(This,feedProviderDefinitionId,customQueryParameters,value) \
    ( (This)->lpVtbl->CreateInstance(This,feedProviderDefinitionId,customQueryParameters,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptionsFactory_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.IFeedDisabledArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.FeedDisabledArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_IFeedDisabledArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.IFeedDisabledArgs";
/* [object, uuid("95300612-ACA7-53C0-9CF6-D803689132C1"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FeedProviderDefinitionId )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FeedDefinitionId )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs * This,
        /* [retval, out] */HSTRING * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_get_FeedProviderDefinitionId(This,value) \
    ( (This)->lpVtbl->get_FeedProviderDefinitionId(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_get_FeedDefinitionId(This,value) \
    ( (This)->lpVtbl->get_FeedDefinitionId(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.IFeedEnabledArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.FeedEnabledArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_IFeedEnabledArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.IFeedEnabledArgs";
/* [object, uuid("EFF4B2D7-7347-5969-A77D-CAC433F0FDAE"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FeedProviderDefinitionId )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FeedDefinitionId )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs * This,
        /* [retval, out] */HSTRING * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_get_FeedProviderDefinitionId(This,value) \
    ( (This)->lpVtbl->get_FeedProviderDefinitionId(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_get_FeedDefinitionId(This,value) \
    ( (This)->lpVtbl->get_FeedDefinitionId(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.IFeedManager
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_IFeedManager[] = L"Microsoft.Windows.Widgets.Feeds.Providers.IFeedManager";
/* [object, uuid("87DF6A84-15AA-45CB-8911-5CAFAB57F723"), contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *GetEnabledFeedProviders )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager * This,
        /* [out] */UINT32 * __resultSize,
        /* [size_is(, *(__resultSize)), retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo * * * result
        );
    HRESULT ( STDMETHODCALLTYPE *SetCustomQueryParameters )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersUpdateOptions * options
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_GetEnabledFeedProviders(This,__resultSize,result) \
    ( (This)->lpVtbl->GetEnabledFeedProviders(This,__resultSize,result) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_SetCustomQueryParameters(This,options) \
    ( (This)->lpVtbl->SetCustomQueryParameters(This,options) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.IFeedManagerStatics
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.FeedManager
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_IFeedManagerStatics[] = L"Microsoft.Windows.Widgets.Feeds.Providers.IFeedManagerStatics";
/* [object, uuid("4BAF5174-77D6-5E2A-94EA-4F14CCDB1F2C"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *GetDefault )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManager * * result
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStaticsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_GetDefault(This,result) \
    ( (This)->lpVtbl->GetDefault(This,result) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedManagerStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.IFeedProvider
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_IFeedProvider[] = L"Microsoft.Windows.Widgets.Feeds.Providers.IFeedProvider";
/* [object, uuid("7293A12B-0329-458D-AC25-5332BE478FDE"), contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *OnFeedProviderEnabled )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs * args
        );
    HRESULT ( STDMETHODCALLTYPE *OnFeedProviderDisabled )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs * args
        );
    HRESULT ( STDMETHODCALLTYPE *OnFeedEnabled )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedEnabledArgs * args
        );
    HRESULT ( STDMETHODCALLTYPE *OnFeedDisabled )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedDisabledArgs * args
        );
    HRESULT ( STDMETHODCALLTYPE *OnCustomQueryParametersRequested )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CICustomQueryParametersRequestedArgs * args
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_OnFeedProviderEnabled(This,args) \
    ( (This)->lpVtbl->OnFeedProviderEnabled(This,args) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_OnFeedProviderDisabled(This,args) \
    ( (This)->lpVtbl->OnFeedProviderDisabled(This,args) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_OnFeedEnabled(This,args) \
    ( (This)->lpVtbl->OnFeedEnabled(This,args) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_OnFeedDisabled(This,args) \
    ( (This)->lpVtbl->OnFeedDisabled(This,args) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_OnCustomQueryParametersRequested(This,args) \
    ( (This)->lpVtbl->OnCustomQueryParametersRequested(This,args) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProvider_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderDisabledArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderDisabledArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_IFeedProviderDisabledArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderDisabledArgs";
/* [object, uuid("19B65AEC-E01D-5E8C-AB5F-324212E7CD30"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FeedProviderDefinitionId )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs * This,
        /* [retval, out] */HSTRING * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_get_FeedProviderDefinitionId(This,value) \
    ( (This)->lpVtbl->get_FeedProviderDefinitionId(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderDisabledArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderEnabledArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderEnabledArgs
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_IFeedProviderEnabledArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderEnabledArgs";
/* [object, uuid("821FC9AF-0DE6-5A9B-9AE6-E179117B40E4"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FeedProviderDefinitionId )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs * This,
        /* [retval, out] */HSTRING * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_get_FeedProviderDefinitionId(This,value) \
    ( (This)->lpVtbl->get_FeedProviderDefinitionId(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderEnabledArgs_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Interface Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderInfo
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderInfo
 *
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000
#if !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Widgets_Feeds_Providers_IFeedProviderInfo[] = L"Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderInfo";
/* [object, uuid("73C37049-3C03-5896-8532-F9DFDAEB723F"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfoVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FeedProviderDefinitionId )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_EnabledFeedDefinitionIds )(
        __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo * This,
        /* [out] */UINT32 * __valueSize,
        /* [size_is(, *(__valueSize)), retval, out] */HSTRING * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfoVtbl;

interface __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfoVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_get_FeedProviderDefinitionId(This,value) \
    ( (This)->lpVtbl->get_FeedProviderDefinitionId(This,value) )

#define __x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_get_EnabledFeedDefinitionIds(This,__valueSize,value) \
    ( (This)->lpVtbl->get_EnabledFeedDefinitionIds(This,__valueSize,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CWidgets_CFeeds_CProviders_CIFeedProviderInfo_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Class Microsoft.Windows.Widgets.Feeds.Providers.CustomQueryParametersRequestedArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersRequestedArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_CustomQueryParametersRequestedArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_CustomQueryParametersRequestedArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Feeds_Providers_CustomQueryParametersRequestedArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.CustomQueryParametersRequestedArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Class Microsoft.Windows.Widgets.Feeds.Providers.CustomQueryParametersUpdateOptions
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * RuntimeClass can be activated.
 *   Type can be activated via the Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersUpdateOptionsFactory interface starting with version 4.0 of the Microsoft.Windows.Widgets.WidgetContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Feeds.Providers.ICustomQueryParametersUpdateOptions ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_CustomQueryParametersUpdateOptions_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_CustomQueryParametersUpdateOptions_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Feeds_Providers_CustomQueryParametersUpdateOptions[] = L"Microsoft.Windows.Widgets.Feeds.Providers.CustomQueryParametersUpdateOptions";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Class Microsoft.Windows.Widgets.Feeds.Providers.FeedDisabledArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Feeds.Providers.IFeedDisabledArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedDisabledArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedDisabledArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Feeds_Providers_FeedDisabledArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.FeedDisabledArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Class Microsoft.Windows.Widgets.Feeds.Providers.FeedEnabledArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Feeds.Providers.IFeedEnabledArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedEnabledArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedEnabledArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Feeds_Providers_FeedEnabledArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.FeedEnabledArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Class Microsoft.Windows.Widgets.Feeds.Providers.FeedManager
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.Widgets.Feeds.Providers.IFeedManagerStatics interface starting with version 4.0 of the Microsoft.Windows.Widgets.WidgetContract API contract
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Feeds.Providers.IFeedManager ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedManager_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedManager_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Feeds_Providers_FeedManager[] = L"Microsoft.Windows.Widgets.Feeds.Providers.FeedManager";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Class Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderDisabledArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderDisabledArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderDisabledArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderDisabledArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderDisabledArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderDisabledArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Class Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderEnabledArgs
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderEnabledArgs ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderEnabledArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderEnabledArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderEnabledArgs[] = L"Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderEnabledArgs";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000


/*
 *
 * Class Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderInfo
 *
 * Introduced to Microsoft.Windows.Widgets.WidgetContract in version 4.0
 *
 *
 * Class implements the following interfaces:
 *    Microsoft.Windows.Widgets.Feeds.Providers.IFeedProviderInfo ** Default Interface **
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000

#ifndef RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderInfo_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderInfo_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Widgets_Feeds_Providers_FeedProviderInfo[] = L"Microsoft.Windows.Widgets.Feeds.Providers.FeedProviderInfo";
#endif
#endif // MICROSOFT_WINDOWS_WIDGETS_WIDGETCONTRACT_VERSION >= 0x40000






#endif // defined(__cplusplus)
#pragma pop_macro("MIDL_CONST_ID")
// Restore the original value of the 'DEPRECATED' macro
#pragma pop_macro("DEPRECATED")

#ifdef __clang__
#pragma clang diagnostic pop // deprecated-declarations
#else
#pragma warning(pop)
#endif
#endif // __microsoft2Ewindows2Ewidgets2Efeeds2Eproviders_p_h__

#endif // __microsoft2Ewindows2Ewidgets2Efeeds2Eproviders_h__
