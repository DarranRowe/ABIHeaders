
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

/* verify that the <rpcsal.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCSAL_H_VERSION__
#define __REQUIRED_RPCSAL_H_VERSION__ 100
#endif

#include <rpc.h>
#include <rpcndr.h>

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include <windows.h>
#include <ole2.h>
#endif /*COM_NO_WINDOWS_H*/
#ifndef __microsoft2Egraphics2Ecanvas2Etext_h__
#define __microsoft2Egraphics2Ecanvas2Etext_h__
#ifndef __microsoft2Egraphics2Ecanvas2Etext_p_h__
#define __microsoft2Egraphics2Ecanvas2Etext_p_h__


#pragma once

//
// Deprecated attribute support
//

#pragma push_macro("DEPRECATED")
#undef DEPRECATED

#if !defined(DISABLE_WINRT_DEPRECATION)
#if defined(__cplusplus)
#if __cplusplus >= 201402
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#elif defined(_MSC_VER)
#if _MSC_VER >= 1900
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#else
#define DEPRECATED(x) __declspec(deprecated(x))
#define DEPRECATEDENUMERATOR(x)
#endif // _MSC_VER >= 1900
#else // Not Standard C++ or MSVC, ignore the construct.
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  // C++ deprecation
#else // C - disable deprecation
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif
#else // Deprecation is disabled
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  /* DEPRECATED */

// Disable Deprecation for this header, MIDL verifies that cross-type access is acceptable
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#else
#pragma warning(push)
#pragma warning(disable: 4996)
#endif

// Ensure that the setting of the /ns_prefix command line switch is consistent for all headers.
// If you get an error from the compiler indicating "warning C4005: 'CHECK_NS_PREFIX_STATE': macro redefinition", this
// indicates that you have included two different headers with different settings for the /ns_prefix MIDL command line switch
#if !defined(DISABLE_NS_PREFIX_CHECKS)
#define CHECK_NS_PREFIX_STATE "always"
#endif // !defined(DISABLE_NS_PREFIX_CHECKS)


#pragma push_macro("MIDL_CONST_ID")
#undef MIDL_CONST_ID
#define MIDL_CONST_ID const __declspec(selectany)


//  API Contract Inclusion Definitions
#if !defined(SPECIFIC_API_CONTRACT_DEFINITIONS)
#if !defined(MICROSOFT_FOUNDATION_WINDOWSAPPSDKCONTRACT_VERSION)
#define MICROSOFT_FOUNDATION_WINDOWSAPPSDKCONTRACT_VERSION 0x10005
#endif // defined(MICROSOFT_FOUNDATION_WINDOWSAPPSDKCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION 0x50000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION)
#define WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION)
#define WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION)
#define WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION)
#define WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION 0x60000
#endif // defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION)
#define WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)
#define WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)
#define WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION 0x130000
#endif // defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)

#if !defined(WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION)
#define WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION)

#if !defined(WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION)
#define WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION)
#define WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION)
#define WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION)
#define WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION)
#define WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)
#define WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)
#define WINDOWS_PHONE_PHONECONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)
#define WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)

#if !defined(WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION)
#define WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION 0x50000
#endif // defined(WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION)

#if !defined(WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION)
#define WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION)

#if !defined(WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION)
#define WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION)

#if !defined(WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION)
#define WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION)

#if !defined(WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION)
#define WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION)

#if !defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)
#define WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)

#endif // defined(SPECIFIC_API_CONTRACT_DEFINITIONS)


// Header files for imported files
#include "inspectable.h"
#include "AsyncInfo.h"
#include "EventToken.h"
#include "Windows.Foundation.h"
#include "Microsoft.Graphics.Canvas.h"
#include "Microsoft.Graphics.Canvas.Brushes.h"
#include "Windows.Foundation.Numerics.h"
#include "Windows.UI.h"
#include "Windows.UI.Text.h"
// Importing Collections header
#include <windows.foundation.collections.h>

#if defined(__cplusplus) && !defined(CINTERFACE)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasFontFace;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasFontSet;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontSet

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasFontSetFactory;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontSetFactory

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasFontSetStatics;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontSetStatics

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasNumberSubstitution;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution ABI::Microsoft::Graphics::Canvas::Text::ICanvasNumberSubstitution

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasNumberSubstitutionFactory;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory ABI::Microsoft::Graphics::Canvas::Text::ICanvasNumberSubstitutionFactory

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasScaledFont;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont ABI::Microsoft::Graphics::Canvas::Text::ICanvasScaledFont

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasTextAnalyzer;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextAnalyzer

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasTextAnalyzerFactory;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextAnalyzerFactory

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasTextAnalyzerOptions;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextAnalyzerOptions

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasTextFormat;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextFormat

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasTextFormatStatics;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextFormatStatics

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasTextInlineObject;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextInlineObject

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasTextLayout;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextLayout

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasTextLayoutFactory;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextLayoutFactory

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasTextLayoutStatics;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextLayoutStatics

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasTextRenderer;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextRenderer

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasTextRenderingParameters;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextRenderingParameters

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasTextRenderingParametersFactory;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextRenderingParametersFactory

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasTypography;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography ABI::Microsoft::Graphics::Canvas::Text::ICanvasTypography

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_FWD_DEFINED__

// Parameterized interface forward declarations (C++)

// Collection interface definitions
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    class CanvasFontFace;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */



#ifndef DEF___FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_USE
#define DEF___FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("ba9cfc0b-75d0-5455-9d9d-b88a73a806d0"))
IIterator<ABI::Microsoft::Graphics::Canvas::Text::CanvasFontFace*> : IIterator_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::Text::CanvasFontFace*, ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterator`1<Microsoft.Graphics.Canvas.Text.CanvasFontFace>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterator<ABI::Microsoft::Graphics::Canvas::Text::CanvasFontFace*> __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_t;
#define __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace ABI::Windows::Foundation::Collections::__FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace ABI::Windows::Foundation::Collections::IIterator<ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace*>
//#define __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_t ABI::Windows::Foundation::Collections::IIterator<ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_USE */





#ifndef DEF___FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_USE
#define DEF___FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("dadc03be-adec-5e2b-8056-e620ebd250a6"))
IIterable<ABI::Microsoft::Graphics::Canvas::Text::CanvasFontFace*> : IIterable_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::Text::CanvasFontFace*, ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterable`1<Microsoft.Graphics.Canvas.Text.CanvasFontFace>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterable<ABI::Microsoft::Graphics::Canvas::Text::CanvasFontFace*> __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_t;
#define __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace ABI::Windows::Foundation::Collections::__FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace ABI::Windows::Foundation::Collections::IIterable<ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace*>
//#define __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_t ABI::Windows::Foundation::Collections::IIterable<ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_USE */



namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    struct CanvasCharacterRange;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    struct CanvasAnalyzedBidi;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


#ifndef DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_USE
#define DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("9f5425b6-be6f-5f3d-9d65-ad8c61aa01de"))
IKeyValuePair<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,struct ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedBidi> : IKeyValuePair_impl<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,struct ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedBidi> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasAnalyzedBidi>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IKeyValuePair<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,struct ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedBidi> __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_t;
#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi ABI::Windows::Foundation::Collections::__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedBidi>
//#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_t ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedBidi>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_USE */





#ifndef DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_USE
#define DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("7e9530ef-eb03-5e8f-9d38-f2c62e31d4bc"))
IIterator<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi*> : IIterator_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasAnalyzedBidi>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterator<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi*> __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_t;
#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi ABI::Windows::Foundation::Collections::__FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedBidi>*>
//#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_t ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedBidi>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_USE */





#ifndef DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_USE
#define DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("51271225-b352-5aaa-ae19-95d387c9b6b7"))
IIterable<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi*> : IIterable_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasAnalyzedBidi>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterable<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi*> __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_t;
#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi ABI::Windows::Foundation::Collections::__FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedBidi>*>
//#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_t ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedBidi>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_USE */




namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    struct CanvasAnalyzedGlyphOrientation;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


#ifndef DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_USE
#define DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("a8240806-1266-51ae-9276-0d6eb62f403b"))
IKeyValuePair<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,struct ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedGlyphOrientation> : IKeyValuePair_impl<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,struct ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedGlyphOrientation> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasAnalyzedGlyphOrientation>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IKeyValuePair<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,struct ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedGlyphOrientation> __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_t;
#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation ABI::Windows::Foundation::Collections::__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedGlyphOrientation>
//#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_t ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedGlyphOrientation>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_USE */





#ifndef DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_USE
#define DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("6fa01beb-a02e-57b4-975d-0662230315e9"))
IIterator<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation*> : IIterator_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasAnalyzedGlyphOrientation>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterator<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation*> __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_t;
#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation ABI::Windows::Foundation::Collections::__FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedGlyphOrientation>*>
//#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_t ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedGlyphOrientation>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_USE */





#ifndef DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_USE
#define DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("bc2186a2-f834-5c78-8d4c-ec4166c46b40"))
IIterable<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation*> : IIterable_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasAnalyzedGlyphOrientation>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterable<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation*> __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_t;
#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation ABI::Windows::Foundation::Collections::__FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedGlyphOrientation>*>
//#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_t ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedGlyphOrientation>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_USE */




namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    struct CanvasAnalyzedScript;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


#ifndef DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_USE
#define DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("f113a468-5320-5b3d-b976-1c12d95d71fe"))
IKeyValuePair<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,struct ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript> : IKeyValuePair_impl<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,struct ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasAnalyzedScript>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IKeyValuePair<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,struct ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript> __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_t;
#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript ABI::Windows::Foundation::Collections::__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript>
//#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_t ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_USE */





#ifndef DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_USE
#define DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("d6dd13e4-d1e8-577c-bbcb-cf31b96f09ed"))
IIterator<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript*> : IIterator_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasAnalyzedScript>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterator<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript*> __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_t;
#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript ABI::Windows::Foundation::Collections::__FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript>*>
//#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_t ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_USE */





#ifndef DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_USE
#define DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("4b15169a-c4b5-51d3-b6c8-79ec3e177871"))
IIterable<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript*> : IIterable_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasAnalyzedScript>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterable<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript*> __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_t;
#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript ABI::Windows::Foundation::Collections::__FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript>*>
//#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_t ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_USE */




namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    class CanvasNumberSubstitution;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */



#ifndef DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_USE
#define DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("93f9a2ab-5b51-5468-8b38-4693d96b4255"))
IKeyValuePair<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasNumberSubstitution*> : IKeyValuePair_impl<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::Text::CanvasNumberSubstitution*, ABI::Microsoft::Graphics::Canvas::Text::ICanvasNumberSubstitution*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasNumberSubstitution>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IKeyValuePair<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasNumberSubstitution*> __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_t;
#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution ABI::Windows::Foundation::Collections::__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasNumberSubstitution*>
//#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_t ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasNumberSubstitution*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_USE */





#ifndef DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_USE
#define DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("c95c26dd-c066-543f-a3d4-a3fc9f0cad1a"))
IIterator<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution*> : IIterator_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasNumberSubstitution>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterator<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution*> __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_t;
#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution ABI::Windows::Foundation::Collections::__FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasNumberSubstitution*>*>
//#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_t ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasNumberSubstitution*>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_USE */





#ifndef DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_USE
#define DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("27f7d15b-8c80-5fa3-a202-899cef70e002"))
IIterable<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution*> : IIterable_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasNumberSubstitution>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterable<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution*> __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_t;
#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution ABI::Windows::Foundation::Collections::__FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasNumberSubstitution*>*>
//#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_t ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasNumberSubstitution*>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_USE */




namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    class CanvasScaledFont;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */



#ifndef DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_USE
#define DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("659fa7a9-d350-5c96-9eda-65d151127be6"))
IKeyValuePair<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasScaledFont*> : IKeyValuePair_impl<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::Text::CanvasScaledFont*, ABI::Microsoft::Graphics::Canvas::Text::ICanvasScaledFont*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasScaledFont>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IKeyValuePair<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasScaledFont*> __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_t;
#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont ABI::Windows::Foundation::Collections::__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasScaledFont*>
//#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_t ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasScaledFont*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_USE */





#ifndef DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_USE
#define DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("56051c10-f92f-5a6c-911e-367267245224"))
IIterator<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont*> : IIterator_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasScaledFont>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterator<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont*> __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_t;
#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont ABI::Windows::Foundation::Collections::__FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasScaledFont*>*>
//#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_t ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasScaledFont*>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_USE */





#ifndef DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_USE
#define DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("e13342d7-18ac-5a96-8f97-4ad9aa7cc211"))
IIterable<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont*> : IIterable_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasScaledFont>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterable<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont*> __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_t;
#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont ABI::Windows::Foundation::Collections::__FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasScaledFont*>*>
//#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_t ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasScaledFont*>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_USE */




namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    class CanvasTypography;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */



#ifndef DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_USE
#define DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("3e238e5e-5b0e-519e-b8ee-9524d51e0376"))
IKeyValuePair<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasTypography*> : IKeyValuePair_impl<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::Text::CanvasTypography*, ABI::Microsoft::Graphics::Canvas::Text::ICanvasTypography*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasTypography>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IKeyValuePair<struct ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasTypography*> __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_t;
#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography ABI::Windows::Foundation::Collections::__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasTypography*>
//#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_t ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasTypography*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_USE */





#ifndef DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_USE
#define DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("6bf99e32-7516-5e16-ad21-f83a89898c50"))
IIterator<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography*> : IIterator_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasTypography>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterator<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography*> __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_t;
#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography ABI::Windows::Foundation::Collections::__FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasTypography*>*>
//#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_t ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasTypography*>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_USE */





#ifndef DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_USE
#define DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("9101ecfa-8e8b-5236-b3c1-3ae419df1a4d"))
IIterable<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography*> : IIterable_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasTypography>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterable<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography*> __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_t;
#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography ABI::Windows::Foundation::Collections::__FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasTypography*>*>
//#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_t ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasTypography*>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_USE */





#ifndef DEF___FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_USE
#define DEF___FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("f90149d7-8a7e-5e74-a251-9e92f5a8084d"))
IVectorView<ABI::Microsoft::Graphics::Canvas::Text::CanvasFontFace*> : IVectorView_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::Text::CanvasFontFace*, ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IVectorView`1<Microsoft.Graphics.Canvas.Text.CanvasFontFace>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IVectorView<ABI::Microsoft::Graphics::Canvas::Text::CanvasFontFace*> __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_t;
#define __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace ABI::Windows::Foundation::Collections::__FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace ABI::Windows::Foundation::Collections::IVectorView<ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace*>
//#define __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_t ABI::Windows::Foundation::Collections::IVectorView<ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_USE */





#ifndef DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_USE
#define DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("67c4d9c7-c31e-51c1-ab1d-f8a0ebcd5552"))
IVectorView<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi*> : IVectorView_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasAnalyzedBidi>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IVectorView<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi*> __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_t;
#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi ABI::Windows::Foundation::Collections::__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi ABI::Windows::Foundation::Collections::IVectorView<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedBidi>*>
//#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_t ABI::Windows::Foundation::Collections::IVectorView<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedBidi>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_USE */





#ifndef DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_USE
#define DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("ce1ccf50-cc60-5c33-98d5-fb6ea38131bd"))
IVectorView<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation*> : IVectorView_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasAnalyzedGlyphOrientation>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IVectorView<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation*> __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_t;
#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation ABI::Windows::Foundation::Collections::__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation ABI::Windows::Foundation::Collections::IVectorView<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedGlyphOrientation>*>
//#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_t ABI::Windows::Foundation::Collections::IVectorView<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedGlyphOrientation>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_USE */





#ifndef DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_USE
#define DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("9b325f09-f744-53fd-acc7-d5e6fea523d7"))
IVectorView<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript*> : IVectorView_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasAnalyzedScript>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IVectorView<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript*> __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_t;
#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript ABI::Windows::Foundation::Collections::__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript ABI::Windows::Foundation::Collections::IVectorView<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript>*>
//#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_t ABI::Windows::Foundation::Collections::IVectorView<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_USE */





#ifndef DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_USE
#define DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("80a1114f-758f-5110-baa8-f1884a7bb922"))
IVectorView<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution*> : IVectorView_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasNumberSubstitution>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IVectorView<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution*> __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_t;
#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution ABI::Windows::Foundation::Collections::__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution ABI::Windows::Foundation::Collections::IVectorView<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasNumberSubstitution*>*>
//#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_t ABI::Windows::Foundation::Collections::IVectorView<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasNumberSubstitution*>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_USE */





#ifndef DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_USE
#define DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("f1eaee0a-1f12-5e87-9657-cb93e8827bb0"))
IVectorView<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont*> : IVectorView_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasScaledFont>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IVectorView<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont*> __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_t;
#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont ABI::Windows::Foundation::Collections::__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont ABI::Windows::Foundation::Collections::IVectorView<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasScaledFont*>*>
//#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_t ABI::Windows::Foundation::Collections::IVectorView<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasScaledFont*>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_USE */





#ifndef DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_USE
#define DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("08f216fc-38e5-5c04-bb90-ed0436cdf91d"))
IVectorView<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography*> : IVectorView_impl<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Collections.IKeyValuePair`2<Microsoft.Graphics.Canvas.Text.CanvasCharacterRange, Microsoft.Graphics.Canvas.Text.CanvasTypography>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IVectorView<__FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography*> __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_t;
#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography ABI::Windows::Foundation::Collections::__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography ABI::Windows::Foundation::Collections::IVectorView<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasTypography*>*>
//#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_t ABI::Windows::Foundation::Collections::IVectorView<ABI::Windows::Foundation::Collections::IKeyValuePair<ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange,ABI::Microsoft::Graphics::Canvas::Text::ICanvasTypography*>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_USE */




#ifndef DEF___FIKeyValuePair_2_HSTRING_HSTRING_USE
#define DEF___FIKeyValuePair_2_HSTRING_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("60310303-49c5-52e6-abc6-a9b36eccc716"))
IKeyValuePair<HSTRING,HSTRING> : IKeyValuePair_impl<HSTRING,HSTRING> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IKeyValuePair`2<String, String>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IKeyValuePair<HSTRING,HSTRING> __FIKeyValuePair_2_HSTRING_HSTRING_t;
#define __FIKeyValuePair_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::__FIKeyValuePair_2_HSTRING_HSTRING_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIKeyValuePair_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::IKeyValuePair<HSTRING,HSTRING>
//#define __FIKeyValuePair_2_HSTRING_HSTRING_t ABI::Windows::Foundation::Collections::IKeyValuePair<HSTRING,HSTRING>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIKeyValuePair_2_HSTRING_HSTRING_USE */





#ifndef DEF___FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_USE
#define DEF___FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("05eb86f1-7140-5517-b88d-cbaebe57e6b1"))
IIterator<__FIKeyValuePair_2_HSTRING_HSTRING*> : IIterator_impl<__FIKeyValuePair_2_HSTRING_HSTRING*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String, String>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterator<__FIKeyValuePair_2_HSTRING_HSTRING*> __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_t;
#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::__FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Foundation::Collections::IKeyValuePair<HSTRING,HSTRING>*>
//#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_t ABI::Windows::Foundation::Collections::IIterator<ABI::Windows::Foundation::Collections::IKeyValuePair<HSTRING,HSTRING>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_USE */





#ifndef DEF___FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_USE
#define DEF___FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("e9bdaaf0-cbf6-5c72-be90-29cbf3a1319b"))
IIterable<__FIKeyValuePair_2_HSTRING_HSTRING*> : IIterable_impl<__FIKeyValuePair_2_HSTRING_HSTRING*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String, String>>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterable<__FIKeyValuePair_2_HSTRING_HSTRING*> __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_t;
#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::__FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Foundation::Collections::IKeyValuePair<HSTRING,HSTRING>*>
//#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_t ABI::Windows::Foundation::Collections::IIterable<ABI::Windows::Foundation::Collections::IKeyValuePair<HSTRING,HSTRING>*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_USE */




#ifndef DEF___FIMapView_2_HSTRING_HSTRING_USE
#define DEF___FIMapView_2_HSTRING_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("ac7f26f2-feb7-5b2a-8ac4-345bc62caede"))
IMapView<HSTRING,HSTRING> : IMapView_impl<HSTRING,HSTRING> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IMapView`2<String, String>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IMapView<HSTRING,HSTRING> __FIMapView_2_HSTRING_HSTRING_t;
#define __FIMapView_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::__FIMapView_2_HSTRING_HSTRING_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIMapView_2_HSTRING_HSTRING ABI::Windows::Foundation::Collections::IMapView<HSTRING,HSTRING>
//#define __FIMapView_2_HSTRING_HSTRING_t ABI::Windows::Foundation::Collections::IMapView<HSTRING,HSTRING>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIMapView_2_HSTRING_HSTRING_USE */




#ifndef DEF___FIIterator_1_HSTRING_USE
#define DEF___FIIterator_1_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("8c304ebb-6615-50a4-8829-879ecd443236"))
IIterator<HSTRING> : IIterator_impl<HSTRING> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterator`1<String>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterator<HSTRING> __FIIterator_1_HSTRING_t;
#define __FIIterator_1_HSTRING ABI::Windows::Foundation::Collections::__FIIterator_1_HSTRING_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterator_1_HSTRING ABI::Windows::Foundation::Collections::IIterator<HSTRING>
//#define __FIIterator_1_HSTRING_t ABI::Windows::Foundation::Collections::IIterator<HSTRING>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterator_1_HSTRING_USE */




#ifndef DEF___FIIterable_1_HSTRING_USE
#define DEF___FIIterable_1_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("e2fcc7c1-3bfc-5a0b-b2b0-72e769d1cb7e"))
IIterable<HSTRING> : IIterable_impl<HSTRING> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IIterable`1<String>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IIterable<HSTRING> __FIIterable_1_HSTRING_t;
#define __FIIterable_1_HSTRING ABI::Windows::Foundation::Collections::__FIIterable_1_HSTRING_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIIterable_1_HSTRING ABI::Windows::Foundation::Collections::IIterable<HSTRING>
//#define __FIIterable_1_HSTRING_t ABI::Windows::Foundation::Collections::IIterable<HSTRING>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIIterable_1_HSTRING_USE */




#ifndef DEF___FIVectorView_1_HSTRING_USE
#define DEF___FIVectorView_1_HSTRING_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation { namespace Collections {
template <>
struct __declspec(uuid("2f13c006-a03a-5f69-b090-75a43e33423e"))
IVectorView<HSTRING> : IVectorView_impl<HSTRING> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.Collections.IVectorView`1<String>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IVectorView<HSTRING> __FIVectorView_1_HSTRING_t;
#define __FIVectorView_1_HSTRING ABI::Windows::Foundation::Collections::__FIVectorView_1_HSTRING_t
/* Collections */ } /* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIVectorView_1_HSTRING ABI::Windows::Foundation::Collections::IVectorView<HSTRING>
//#define __FIVectorView_1_HSTRING_t ABI::Windows::Foundation::Collections::IVectorView<HSTRING>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIVectorView_1_HSTRING_USE */





#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Brushes {
                    interface ICanvasBrush;
                } /* Brushes */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush_FWD_DEFINED__






namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasAntialiasing : int CanvasAntialiasing;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                class CanvasDevice;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasDevice;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice ABI::Microsoft::Graphics::Canvas::ICanvasDevice

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                class CanvasDrawingSession;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasDrawingSession;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession ABI::Microsoft::Graphics::Canvas::ICanvasDrawingSession

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__


#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasResourceCreator;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__





#ifndef ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Foundation {
            interface IClosable;
        } /* Foundation */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CFoundation_CIClosable ABI::Windows::Foundation::IClosable

#endif // ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__




namespace ABI {
    namespace Windows {
        namespace Foundation {
            namespace Numerics {
                
                typedef struct Matrix3x2 Matrix3x2;
                
            } /* Numerics */
        } /* Foundation */
    } /* Windows */
} /* ABI */

namespace ABI {
    namespace Windows {
        namespace Foundation {
            namespace Numerics {
                
                typedef struct Vector2 Vector2;
                
            } /* Numerics */
        } /* Foundation */
    } /* Windows */
} /* ABI */




namespace ABI {
    namespace Windows {
        namespace Foundation {
            
            typedef struct Rect Rect;
            
        } /* Foundation */
    } /* Windows */
} /* ABI */

namespace ABI {
    namespace Windows {
        namespace Foundation {
            
            typedef struct Size Size;
            
        } /* Foundation */
    } /* Windows */
} /* ABI */

namespace ABI {
    namespace Windows {
        namespace Foundation {
            class Uri;
        } /* Foundation */
    } /* Windows */
} /* ABI */

#ifndef ____x_ABI_CWindows_CFoundation_CIUriRuntimeClass_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIUriRuntimeClass_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Foundation {
            interface IUriRuntimeClass;
        } /* Foundation */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CFoundation_CIUriRuntimeClass ABI::Windows::Foundation::IUriRuntimeClass

#endif // ____x_ABI_CWindows_CFoundation_CIUriRuntimeClass_FWD_DEFINED__




namespace ABI {
    namespace Windows {
        namespace UI {
            
            typedef struct Color Color;
            
        } /* UI */
    } /* Windows */
} /* ABI */



namespace ABI {
    namespace Windows {
        namespace UI {
            namespace Text {
                
                typedef enum FontStretch : int FontStretch;
                
            } /* Text */
        } /* UI */
    } /* Windows */
} /* ABI */

namespace ABI {
    namespace Windows {
        namespace UI {
            namespace Text {
                
                typedef enum FontStyle : int FontStyle;
                
            } /* Text */
        } /* UI */
    } /* Windows */
} /* ABI */

namespace ABI {
    namespace Windows {
        namespace UI {
            namespace Text {
                
                typedef struct FontWeight FontWeight;
                
            } /* Text */
        } /* UI */
    } /* Windows */
} /* ABI */




namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasClusterProperties : unsigned int CanvasClusterProperties;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasDrawTextOptions : unsigned int CanvasDrawTextOptions;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasFontFileFormatType : int CanvasFontFileFormatType;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasFontInformation : int CanvasFontInformation;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasFontPropertyIdentifier : int CanvasFontPropertyIdentifier;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasFontSimulations : unsigned int CanvasFontSimulations;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasGlyphJustification : int CanvasGlyphJustification;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasGlyphOrientation : int CanvasGlyphOrientation;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasHorizontalAlignment : int CanvasHorizontalAlignment;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasLineBreakCondition : int CanvasLineBreakCondition;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasLineSpacingMode : int CanvasLineSpacingMode;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasNumberSubstitutionMethod : int CanvasNumberSubstitutionMethod;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasOpticalAlignment : int CanvasOpticalAlignment;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasScriptShape : int CanvasScriptShape;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasTextAntialiasing : int CanvasTextAntialiasing;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasTextDirection : int CanvasTextDirection;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasTextGridFit : int CanvasTextGridFit;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasTextMeasuringMode : int CanvasTextMeasuringMode;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasTextRenderingMode : int CanvasTextRenderingMode;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasTextTrimmingGranularity : int CanvasTextTrimmingGranularity;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasTrimmingSign : int CanvasTrimmingSign;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasTypographyFeatureName : int CanvasTypographyFeatureName;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasVerticalAlignment : int CanvasVerticalAlignment;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasVerticalGlyphOrientation : int CanvasVerticalGlyphOrientation;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasWordWrapping : int CanvasWordWrapping;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasAnalyzedBidi CanvasAnalyzedBidi;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasAnalyzedBreakpoint CanvasAnalyzedBreakpoint;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasAnalyzedGlyphOrientation CanvasAnalyzedGlyphOrientation;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasAnalyzedScript CanvasAnalyzedScript;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasCharacterRange CanvasCharacterRange;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasClusterMetrics CanvasClusterMetrics;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasFontProperty CanvasFontProperty;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasGlyph CanvasGlyph;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasGlyphMetrics CanvasGlyphMetrics;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasGlyphShaping CanvasGlyphShaping;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasJustificationOpportunity CanvasJustificationOpportunity;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasLineMetrics CanvasLineMetrics;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasScriptProperties CanvasScriptProperties;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasTextLayoutRegion CanvasTextLayoutRegion;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasTypographyFeature CanvasTypographyFeature;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasUnicodeRange CanvasUnicodeRange;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */






















namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    class CanvasFontSet;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */




namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    class CanvasTextAnalyzer;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    class CanvasTextFormat;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    class CanvasTextLayout;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    class CanvasTextRenderingParameters;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */













/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasClusterProperties
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version, flags] */
                    enum CanvasClusterProperties : unsigned int
                    {
                        CanvasClusterProperties_None = 0,
                        CanvasClusterProperties_CanWrapLineAfter = 0x1,
                        CanvasClusterProperties_Whitespace = 0x2,
                        CanvasClusterProperties_Newline = 0x4,
                        CanvasClusterProperties_SoftHyphen = 0x8,
                        CanvasClusterProperties_RightToLeft = 0x10,
                    };
                    
                    DEFINE_ENUM_FLAG_OPERATORS(CanvasClusterProperties)
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasDrawTextOptions
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version, flags] */
                    enum CanvasDrawTextOptions : unsigned int
                    {
                        CanvasDrawTextOptions_Default = 0,
                        CanvasDrawTextOptions_NoPixelSnap = 0x1,
                        CanvasDrawTextOptions_Clip = 0x2,
                        CanvasDrawTextOptions_EnableColorFont = 0x4,
                    };
                    
                    DEFINE_ENUM_FLAG_OPERATORS(CanvasDrawTextOptions)
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasFontFileFormatType
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasFontFileFormatType : int
                    {
                        CanvasFontFileFormatType_Cff = 0,
                        CanvasFontFileFormatType_TrueType = 1,
                        CanvasFontFileFormatType_TrueTypeCollection = 2,
                        CanvasFontFileFormatType_Type1 = 3,
                        CanvasFontFileFormatType_Vector = 4,
                        CanvasFontFileFormatType_Bitmap = 5,
                        CanvasFontFileFormatType_Unknown = 6,
                        CanvasFontFileFormatType_RawCff = 7,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasFontInformation
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasFontInformation : int
                    {
                        CanvasFontInformation_None = 0,
                        CanvasFontInformation_CopyrightNotice = 1,
                        CanvasFontInformation_VersionStrings = 2,
                        CanvasFontInformation_Trademark = 3,
                        CanvasFontInformation_Manufacturer = 4,
                        CanvasFontInformation_Designer = 5,
                        CanvasFontInformation_DesignerUrl = 6,
                        CanvasFontInformation_Description = 7,
                        CanvasFontInformation_FontVendorUrl = 8,
                        CanvasFontInformation_LicenseDescription = 9,
                        CanvasFontInformation_LicenseInfoUrl = 10,
                        CanvasFontInformation_Win32FamilyNames = 11,
                        CanvasFontInformation_Win32SubfamilyNames = 12,
                        CanvasFontInformation_PreferredFamilyNames = 13,
                        CanvasFontInformation_PreferredSubfamilyNames = 14,
                        CanvasFontInformation_SampleText = 15,
                        CanvasFontInformation_FullName = 16,
                        CanvasFontInformation_PostscriptName = 17,
                        CanvasFontInformation_PostscriptCidName = 18,
                        CanvasFontInformation_WwsFamilyName = 19,
                        CanvasFontInformation_DesignScriptLanguageTag = 20,
                        CanvasFontInformation_SupportedScriptLanguageTag = 21,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasFontPropertyIdentifier
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasFontPropertyIdentifier : int
                    {
                        CanvasFontPropertyIdentifier_None = 0,
                        CanvasFontPropertyIdentifier_FamilyName = 1,
                        CanvasFontPropertyIdentifier_PreferredFamilyName = 2,
                        CanvasFontPropertyIdentifier_FaceName = 3,
                        CanvasFontPropertyIdentifier_FullName = 4,
                        CanvasFontPropertyIdentifier_Win32FamilyName = 5,
                        CanvasFontPropertyIdentifier_PostscriptName = 6,
                        CanvasFontPropertyIdentifier_DesignScriptLanguageTag = 7,
                        CanvasFontPropertyIdentifier_SupportedScriptLanguageTag = 8,
                        CanvasFontPropertyIdentifier_SemanticTag = 9,
                        CanvasFontPropertyIdentifier_Weight = 10,
                        CanvasFontPropertyIdentifier_Stretch = 11,
                        CanvasFontPropertyIdentifier_Style = 12,
                        CanvasFontPropertyIdentifier_Total = 13,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasFontSimulations
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version, flags] */
                    enum CanvasFontSimulations : unsigned int
                    {
                        CanvasFontSimulations_None = 0,
                        CanvasFontSimulations_Bold = 0x1,
                        CanvasFontSimulations_Oblique = 0x2,
                    };
                    
                    DEFINE_ENUM_FLAG_OPERATORS(CanvasFontSimulations)
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasGlyphJustification
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasGlyphJustification : int
                    {
                        CanvasGlyphJustification_None = 0,
                        CanvasGlyphJustification_ArabicBlank = 1,
                        CanvasGlyphJustification_Character = 2,
                        CanvasGlyphJustification_Blank = 4,
                        CanvasGlyphJustification_ArabicNormal = 7,
                        CanvasGlyphJustification_ArabicKashida = 8,
                        CanvasGlyphJustification_ArabicAlef = 9,
                        CanvasGlyphJustification_ArabicHa = 10,
                        CanvasGlyphJustification_ArabicRa = 11,
                        CanvasGlyphJustification_ArabicBa = 12,
                        CanvasGlyphJustification_ArabicBara = 13,
                        CanvasGlyphJustification_ArabicSeen = 14,
                        CanvasGlyphJustification_ArabicSeenM = 15,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasGlyphOrientation
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasGlyphOrientation : int
                    {
                        CanvasGlyphOrientation_Upright = 0,
                        CanvasGlyphOrientation_Clockwise90Degrees = 1,
                        CanvasGlyphOrientation_Clockwise180Degrees = 2,
                        CanvasGlyphOrientation_Clockwise270Degrees = 3,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasHorizontalAlignment
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasHorizontalAlignment : int
                    {
                        CanvasHorizontalAlignment_Left = 0,
                        CanvasHorizontalAlignment_Right = 1,
                        CanvasHorizontalAlignment_Center = 2,
                        CanvasHorizontalAlignment_Justified = 3,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasLineBreakCondition
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasLineBreakCondition : int
                    {
                        CanvasLineBreakCondition_Neutral = 0,
                        CanvasLineBreakCondition_CanBreak = 1,
                        CanvasLineBreakCondition_CannotBreak = 2,
                        CanvasLineBreakCondition_MustBreak = 3,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasLineSpacingMode
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasLineSpacingMode : int
                    {
                        CanvasLineSpacingMode_Default = 0,
                        CanvasLineSpacingMode_Uniform = 1,
                        CanvasLineSpacingMode_Proportional = 2,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasNumberSubstitutionMethod
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasNumberSubstitutionMethod : int
                    {
                        CanvasNumberSubstitutionMethod_FromCulture = 0,
                        CanvasNumberSubstitutionMethod_Contextual = 1,
                        CanvasNumberSubstitutionMethod_Disabled = 2,
                        CanvasNumberSubstitutionMethod_National = 3,
                        CanvasNumberSubstitutionMethod_Traditional = 4,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasOpticalAlignment
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasOpticalAlignment : int
                    {
                        CanvasOpticalAlignment_Default = 0,
                        CanvasOpticalAlignment_NoSideBearings = 1,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasScriptShape
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasScriptShape : int
                    {
                        CanvasScriptShape_Default = 0,
                        CanvasScriptShape_NoVisual = 1,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTextAntialiasing
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasTextAntialiasing : int
                    {
                        CanvasTextAntialiasing_Auto = 0,
                        CanvasTextAntialiasing_ClearType = 1,
                        CanvasTextAntialiasing_Grayscale = 2,
                        CanvasTextAntialiasing_Aliased = 3,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTextDirection
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasTextDirection : int
                    {
                        CanvasTextDirection_LeftToRightThenTopToBottom = 0,
                        CanvasTextDirection_RightToLeftThenTopToBottom = 1,
                        CanvasTextDirection_LeftToRightThenBottomToTop = 2,
                        CanvasTextDirection_RightToLeftThenBottomToTop = 3,
                        CanvasTextDirection_TopToBottomThenLeftToRight = 4,
                        CanvasTextDirection_BottomToTopThenLeftToRight = 5,
                        CanvasTextDirection_TopToBottomThenRightToLeft = 6,
                        CanvasTextDirection_BottomToTopThenRightToLeft = 7,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTextGridFit
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasTextGridFit : int
                    {
                        CanvasTextGridFit_Default = 0,
                        CanvasTextGridFit_Disable = 1,
                        CanvasTextGridFit_Enable = 2,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTextMeasuringMode
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasTextMeasuringMode : int
                    {
                        CanvasTextMeasuringMode_Natural = 0,
                        CanvasTextMeasuringMode_GdiClassic = 1,
                        CanvasTextMeasuringMode_GdiNatural = 2,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTextRenderingMode
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasTextRenderingMode : int
                    {
                        CanvasTextRenderingMode_Default = 0,
                        CanvasTextRenderingMode_Aliased = 1,
                        CanvasTextRenderingMode_GdiClassic = 2,
                        CanvasTextRenderingMode_GdiNatural = 3,
                        CanvasTextRenderingMode_Natural = 4,
                        CanvasTextRenderingMode_NaturalSymmetric = 5,
                        CanvasTextRenderingMode_Outline = 6,
                        CanvasTextRenderingMode_NaturalSymmetricDownsampled = 7,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTextTrimmingGranularity
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasTextTrimmingGranularity : int
                    {
                        CanvasTextTrimmingGranularity_None = 0,
                        CanvasTextTrimmingGranularity_Character = 1,
                        CanvasTextTrimmingGranularity_Word = 2,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTrimmingSign
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasTrimmingSign : int
                    {
                        CanvasTrimmingSign_None = 0,
                        CanvasTrimmingSign_Ellipsis = 1,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTypographyFeatureName
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasTypographyFeatureName : int
                    {
                        CanvasTypographyFeatureName_None = 0,
                        CanvasTypographyFeatureName_Default = 1953261156,
                        CanvasTypographyFeatureName_VerticalWriting = 1953654134,
                        CanvasTypographyFeatureName_VerticalAlternatesAndRotation = 846492278,
                        CanvasTypographyFeatureName_AlternativeFractions = 1668441697,
                        CanvasTypographyFeatureName_PetiteCapitalsFromCapitals = 1668297315,
                        CanvasTypographyFeatureName_SmallCapitalsFromCapitals = 1668493923,
                        CanvasTypographyFeatureName_ContextualAlternates = 1953259875,
                        CanvasTypographyFeatureName_CaseSensitiveForms = 1702060387,
                        CanvasTypographyFeatureName_GlyphCompositionDecomposition = 1886217059,
                        CanvasTypographyFeatureName_ContextualLigatures = 1734962275,
                        CanvasTypographyFeatureName_CapitalSpacing = 1886613603,
                        CanvasTypographyFeatureName_ContextualSwash = 1752658787,
                        CanvasTypographyFeatureName_CursivePositioning = 1936880995,
                        CanvasTypographyFeatureName_DiscretionaryLigatures = 1734962276,
                        CanvasTypographyFeatureName_ExpertForms = 1953527909,
                        CanvasTypographyFeatureName_Fractions = 1667330662,
                        CanvasTypographyFeatureName_FullWidth = 1684633446,
                        CanvasTypographyFeatureName_HalfForms = 1718378856,
                        CanvasTypographyFeatureName_HalantForms = 1852596584,
                        CanvasTypographyFeatureName_AlternateHalfWidth = 1953259880,
                        CanvasTypographyFeatureName_HistoricalForms = 1953720680,
                        CanvasTypographyFeatureName_HorizontalKanaAlternates = 1634626408,
                        CanvasTypographyFeatureName_HistoricalLigatures = 1734962280,
                        CanvasTypographyFeatureName_HalfWidth = 1684633448,
                        CanvasTypographyFeatureName_HojoKanjiForms = 1869246312,
                        CanvasTypographyFeatureName_Jis04Forms = 875589738,
                        CanvasTypographyFeatureName_Jis78Forms = 943157354,
                        CanvasTypographyFeatureName_Jis83Forms = 859336810,
                        CanvasTypographyFeatureName_Jis90Forms = 809070698,
                        CanvasTypographyFeatureName_Kerning = 1852990827,
                        CanvasTypographyFeatureName_StandardLigatures = 1634167148,
                        CanvasTypographyFeatureName_LiningFigures = 1836412524,
                        CanvasTypographyFeatureName_LocalizedForms = 1818455916,
                        CanvasTypographyFeatureName_MarkPositioning = 1802658157,
                        CanvasTypographyFeatureName_MathematicalGreek = 1802659693,
                        CanvasTypographyFeatureName_MarkToMarkPositioning = 1802333037,
                        CanvasTypographyFeatureName_AlternateAnnotationForms = 1953259886,
                        CanvasTypographyFeatureName_NlcKanjiForms = 1801677934,
                        CanvasTypographyFeatureName_OldStyleFigures = 1836412527,
                        CanvasTypographyFeatureName_Ordinals = 1852076655,
                        CanvasTypographyFeatureName_ProportionalAlternateWidth = 1953259888,
                        CanvasTypographyFeatureName_PetiteCapitals = 1885430640,
                        CanvasTypographyFeatureName_ProportionalFigures = 1836412528,
                        CanvasTypographyFeatureName_ProportionalWidths = 1684633456,
                        CanvasTypographyFeatureName_QuarterWidths = 1684633457,
                        CanvasTypographyFeatureName_RequiredLigatures = 1734962290,
                        CanvasTypographyFeatureName_RubyNotationForms = 2036495730,
                        CanvasTypographyFeatureName_StylisticAlternates = 1953259891,
                        CanvasTypographyFeatureName_ScientificInferiors = 1718511987,
                        CanvasTypographyFeatureName_SmallCapitals = 1885564275,
                        CanvasTypographyFeatureName_SimplifiedForms = 1819307379,
                        CanvasTypographyFeatureName_StylisticSet1 = 825258867,
                        CanvasTypographyFeatureName_StylisticSet2 = 842036083,
                        CanvasTypographyFeatureName_StylisticSet3 = 858813299,
                        CanvasTypographyFeatureName_StylisticSet4 = 875590515,
                        CanvasTypographyFeatureName_StylisticSet5 = 892367731,
                        CanvasTypographyFeatureName_StylisticSet6 = 909144947,
                        CanvasTypographyFeatureName_StylisticSet7 = 925922163,
                        CanvasTypographyFeatureName_StylisticSet8 = 942699379,
                        CanvasTypographyFeatureName_StylisticSet9 = 959476595,
                        CanvasTypographyFeatureName_StylisticSet10 = 808547187,
                        CanvasTypographyFeatureName_StylisticSet11 = 825324403,
                        CanvasTypographyFeatureName_StylisticSet12 = 842101619,
                        CanvasTypographyFeatureName_StylisticSet13 = 858878835,
                        CanvasTypographyFeatureName_StylisticSet14 = 875656051,
                        CanvasTypographyFeatureName_StylisticSet15 = 892433267,
                        CanvasTypographyFeatureName_StylisticSet16 = 909210483,
                        CanvasTypographyFeatureName_StylisticSet17 = 925987699,
                        CanvasTypographyFeatureName_StylisticSet18 = 942764915,
                        CanvasTypographyFeatureName_StylisticSet19 = 959542131,
                        CanvasTypographyFeatureName_StylisticSet20 = 808612723,
                        CanvasTypographyFeatureName_Subscript = 1935832435,
                        CanvasTypographyFeatureName_Superscript = 1936749939,
                        CanvasTypographyFeatureName_Swash = 1752397683,
                        CanvasTypographyFeatureName_Titling = 1819568500,
                        CanvasTypographyFeatureName_TraditionalNameForms = 1835101812,
                        CanvasTypographyFeatureName_TabularFigures = 1836412532,
                        CanvasTypographyFeatureName_TraditionalForms = 1684107892,
                        CanvasTypographyFeatureName_ThirdWidths = 1684633460,
                        CanvasTypographyFeatureName_Unicase = 1667853941,
                        CanvasTypographyFeatureName_SlashedZero = 1869768058,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasVerticalAlignment
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasVerticalAlignment : int
                    {
                        CanvasVerticalAlignment_Top = 0,
                        CanvasVerticalAlignment_Bottom = 1,
                        CanvasVerticalAlignment_Center = 2,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasVerticalGlyphOrientation
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasVerticalGlyphOrientation : int
                    {
                        CanvasVerticalGlyphOrientation_Default = 0,
                        CanvasVerticalGlyphOrientation_Stacked = 1,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasWordWrapping
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [v1_enum, version] */
                    enum CanvasWordWrapping : int
                    {
                        CanvasWordWrapping_Wrap = 0,
                        CanvasWordWrapping_NoWrap = 1,
                        CanvasWordWrapping_EmergencyBreak = 2,
                        CanvasWordWrapping_WholeWord = 3,
                        CanvasWordWrapping_Character = 4,
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasAnalyzedBidi
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [version] */
                    struct CanvasAnalyzedBidi
                    {
                        UINT32 ExplicitLevel;
                        UINT32 ResolvedLevel;
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasAnalyzedBreakpoint
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [version] */
                    struct CanvasAnalyzedBreakpoint
                    {
                        ABI::Microsoft::Graphics::Canvas::Text::CanvasLineBreakCondition BreakBefore;
                        ABI::Microsoft::Graphics::Canvas::Text::CanvasLineBreakCondition BreakAfter;
                        ::boolean IsWhitespace;
                        ::boolean IsSoftHyphen;
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasAnalyzedGlyphOrientation
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [version] */
                    struct CanvasAnalyzedGlyphOrientation
                    {
                        ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyphOrientation GlyphOrientation;
                        UINT32 AdjustedBidiLevel;
                        ::boolean IsSideways;
                        ::boolean IsRightToLeft;
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasAnalyzedScript
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [version] */
                    struct CanvasAnalyzedScript
                    {
                        INT32 ScriptIdentifier;
                        ABI::Microsoft::Graphics::Canvas::Text::CanvasScriptShape Shape;
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasCharacterRange
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [version] */
                    struct CanvasCharacterRange
                    {
                        INT32 CharacterIndex;
                        INT32 CharacterCount;
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasClusterMetrics
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [version] */
                    struct CanvasClusterMetrics
                    {
                        INT32 CharacterCount;
                        FLOAT Width;
                        ABI::Microsoft::Graphics::Canvas::Text::CanvasClusterProperties Properties;
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasFontProperty
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [version] */
                    struct CanvasFontProperty
                    {
                        ABI::Microsoft::Graphics::Canvas::Text::CanvasFontPropertyIdentifier Identifier;
                        HSTRING Value;
                        HSTRING Locale;
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasGlyph
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [version] */
                    struct CanvasGlyph
                    {
                        INT32 Index;
                        FLOAT Advance;
                        FLOAT AdvanceOffset;
                        FLOAT AscenderOffset;
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasGlyphMetrics
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [version] */
                    struct CanvasGlyphMetrics
                    {
                        FLOAT LeftSideBearing;
                        FLOAT AdvanceWidth;
                        FLOAT RightSideBearing;
                        FLOAT TopSideBearing;
                        FLOAT AdvanceHeight;
                        FLOAT BottomSideBearing;
                        FLOAT VerticalOrigin;
                        ABI::Windows::Foundation::Rect DrawBounds;
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasGlyphShaping
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [version] */
                    struct CanvasGlyphShaping
                    {
                        ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyphJustification Justification;
                        ::boolean IsClusterStart;
                        ::boolean IsDiacritic;
                        ::boolean IsZeroWidthSpace;
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasJustificationOpportunity
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [version] */
                    struct CanvasJustificationOpportunity
                    {
                        FLOAT ExpansionMinimum;
                        FLOAT ExpansionMaximum;
                        FLOAT CompressionMaximum;
                        BYTE ExpansionPriority;
                        BYTE CompressionPriority;
                        ::boolean AllowResidualExpansion;
                        ::boolean AllowResidualCompression;
                        ::boolean ApplyToLeadingEdge;
                        ::boolean ApplyToTrailingEdge;
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasLineMetrics
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [version] */
                    struct CanvasLineMetrics
                    {
                        INT32 CharacterCount;
                        INT32 TrailingWhitespaceCount;
                        INT32 TerminalNewlineCount;
                        FLOAT Height;
                        FLOAT Baseline;
                        ::boolean IsTrimmed;
                        FLOAT LeadingWhitespaceBefore;
                        FLOAT LeadingWhitespaceAfter;
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasScriptProperties
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [version] */
                    struct CanvasScriptProperties
                    {
                        HSTRING IsoScriptCode;
                        INT32 IsoScriptNumber;
                        INT32 ClusterLookahead;
                        HSTRING JustificationCharacter;
                        ::boolean RestrictCaretToClusters;
                        ::boolean UsesWordDividers;
                        ::boolean IsDiscreteWriting;
                        ::boolean IsBlockWriting;
                        ::boolean IsDistributedWithinCluster;
                        ::boolean IsConnectedWriting;
                        ::boolean IsCursiveWriting;
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTextLayoutRegion
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [version] */
                    struct CanvasTextLayoutRegion
                    {
                        INT32 CharacterIndex;
                        INT32 CharacterCount;
                        ABI::Windows::Foundation::Rect LayoutBounds;
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTypographyFeature
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [version] */
                    struct CanvasTypographyFeature
                    {
                        ABI::Microsoft::Graphics::Canvas::Text::CanvasTypographyFeatureName Name;
                        UINT32 Parameter;
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasUnicodeRange
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [version] */
                    struct CanvasUnicodeRange
                    {
                        UINT32 First;
                        UINT32 Last;
                    };
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasFontFace
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasFontFace
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasFontFace[] = L"Microsoft.Graphics.Canvas.Text.ICanvasFontFace";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("5199D129-4EF9-4DEE-B74C-4DC910201A7F"), exclusiveto] */
                    MIDL_INTERFACE("5199D129-4EF9-4DEE-B74C-4DC910201A7F")
                    ICanvasFontFace : public IInspectable
                    {
                    public:
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetRecommendedRenderingMode(
                            /* [in] */FLOAT fontSize,
                            /* [in] */FLOAT dpi,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextMeasuringMode measuringMode,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextRenderingParameters * renderingParameters,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextRenderingMode * renderingMode
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetRecommendedRenderingModeWithAllOptions(
                            /* [in] */FLOAT fontSize,
                            /* [in] */FLOAT dpi,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextMeasuringMode measuringMode,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextRenderingParameters * renderingParameters,
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                            /* [in] */::boolean isSideways,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasAntialiasing outlineThreshold,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextRenderingMode * renderingMode
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetRecommendedGridFit(
                            /* [in] */FLOAT fontSize,
                            /* [in] */FLOAT dpi,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextMeasuringMode measuringMode,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextRenderingParameters * renderingParameters,
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                            /* [in] */::boolean isSideways,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasAntialiasing outlineThreshold,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextGridFit * gridFit
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_GlyphBox(
                            /* [retval, out] */ABI::Windows::Foundation::Rect * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_SubscriptPosition(
                            /* [retval, out] */ABI::Windows::Foundation::Numerics::Vector2 * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_SubscriptSize(
                            /* [retval, out] */ABI::Windows::Foundation::Size * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_SuperscriptPosition(
                            /* [retval, out] */ABI::Windows::Foundation::Numerics::Vector2 * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_SuperscriptSize(
                            /* [retval, out] */ABI::Windows::Foundation::Size * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_HasTypographicMetrics(
                            /* [retval, out] */::boolean * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Ascent(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Descent(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LineGap(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_CapHeight(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LowercaseLetterHeight(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_UnderlinePosition(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_UnderlineThickness(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_StrikethroughPosition(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_StrikethroughThickness(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_CaretSlopeRise(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_CaretSlopeRun(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_CaretOffset(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_UnicodeRanges(
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasUnicodeRange * * valueElements
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_IsMonospaced(
                            /* [retval, out] */::boolean * value
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetVerticalGlyphVariants(
                            /* [in] */UINT32 __inputElementsSize,
                            /* [size_is(__inputElementsSize), in] */INT32 * inputElements,
                            /* [out] */UINT32 * __outputElementsSize,
                            /* [size_is(, *(__outputElementsSize)), retval, out] */INT32 * * outputElements
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_HasVerticalGlyphVariants(
                            /* [retval, out] */::boolean * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FileFormatType(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasFontFileFormatType * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Simulations(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasFontSimulations * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_IsSymbolFont(
                            /* [retval, out] */::boolean * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_GlyphCount(
                            /* [retval, out] */UINT32 * value
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetGlyphIndices(
                            /* [in] */UINT32 __inputElementsSize,
                            /* [size_is(__inputElementsSize), in] */UINT32 * inputElements,
                            /* [out] */UINT32 * __outputElementsSize,
                            /* [size_is(, *(__outputElementsSize)), retval, out] */INT32 * * outputElements
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetGlyphMetrics(
                            /* [in] */UINT32 __inputElementsSize,
                            /* [size_is(__inputElementsSize), in] */INT32 * inputElements,
                            /* [in] */::boolean isSideways,
                            /* [out] */UINT32 * __outputElementsSize,
                            /* [size_is(, *(__outputElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyphMetrics * * outputElements
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetGdiCompatibleGlyphMetrics(
                            /* [in] */FLOAT fontSize,
                            /* [in] */FLOAT dpi,
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                            /* [in] */::boolean useGdiNatural,
                            /* [in] */UINT32 __inputElementsSize,
                            /* [size_is(__inputElementsSize), in] */INT32 * inputElements,
                            /* [in] */::boolean isSideways,
                            /* [out] */UINT32 * __outputElementsSize,
                            /* [size_is(, *(__outputElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyphMetrics * * outputElements
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Weight(
                            /* [retval, out] */ABI::Windows::UI::Text::FontWeight * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Stretch(
                            /* [retval, out] */ABI::Windows::UI::Text::FontStretch * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Style(
                            /* [retval, out] */ABI::Windows::UI::Text::FontStyle * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FamilyNames(
                            /* [retval, out] */__FIMapView_2_HSTRING_HSTRING * * values
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FaceNames(
                            /* [retval, out] */__FIMapView_2_HSTRING_HSTRING * * values
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetInformationalStrings(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasFontInformation fontInformation,
                            /* [retval, out] */__FIMapView_2_HSTRING_HSTRING * * values
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE HasCharacter(
                            /* [in] */UINT32 unicodeValue,
                            /* [retval, out] */::boolean * value
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetGlyphRunBounds(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasDrawingSession * drawingSession,
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                            /* [in] */FLOAT fontSize,
                            /* [in] */UINT32 __glyphsSize,
                            /* [size_is(__glyphsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * glyphs,
                            /* [in] */::boolean isSideways,
                            /* [in] */UINT32 bidiLevel,
                            /* [retval, out] */ABI::Windows::Foundation::Rect * bounds
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetGlyphRunBoundsWithMeasuringMode(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasDrawingSession * drawingSession,
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                            /* [in] */FLOAT fontSize,
                            /* [in] */UINT32 __glyphsSize,
                            /* [size_is(__glyphsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * glyphs,
                            /* [in] */::boolean isSideways,
                            /* [in] */UINT32 bidiLevel,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextMeasuringMode measuringMode,
                            /* [retval, out] */ABI::Windows::Foundation::Rect * bounds
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Panose(
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */BYTE * * valueElements
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetSupportedTypographicFeatureNames(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript script,
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTypographyFeatureName * * valueElements
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetSupportedTypographicFeatureNamesWithLocale(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript script,
                            /* [in] */HSTRING locale,
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTypographyFeatureName * * valueElements
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetTypographicFeatureGlyphSupport(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript script,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTypographyFeatureName typographicFeatureName,
                            /* [in] */UINT32 __glyphsElementsSize,
                            /* [size_is(__glyphsElementsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * glyphsElements,
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */::boolean * * valueElements
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetTypographicFeatureGlyphSupportWithLocale(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript script,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTypographyFeatureName typographicFeatureName,
                            /* [in] */UINT32 __glyphsElementsSize,
                            /* [size_is(__glyphsElementsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * glyphsElements,
                            /* [in] */HSTRING locale,
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */::boolean * * valueElements
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasFontFace=__uuidof(ICanvasFontFace);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasFontSet
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasFontSet
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasFontSet[] = L"Microsoft.Graphics.Canvas.Text.ICanvasFontSet";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("0A5BFB92-1F3C-459F-9D7E-A6289DD093C0"), exclusiveto] */
                    MIDL_INTERFACE("0A5BFB92-1F3C-459F-9D7E-A6289DD093C0")
                    ICanvasFontSet : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Fonts(
                            /* [retval, out] */__FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * * value
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE TryFindFontFace(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace * fontFace,
                            /* [out] */INT32 * index,
                            /* [retval, out] */::boolean * succeeded
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetMatchingFontsFromProperties(
                            /* [in] */UINT32 __propertyElementsSize,
                            /* [size_is(__propertyElementsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasFontProperty * propertyElements,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontSet * * matchingFonts
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetMatchingFontsFromWwsFamily(
                            /* [in] */HSTRING familyName,
                            /* [in] */ABI::Windows::UI::Text::FontWeight weight,
                            /* [in] */ABI::Windows::UI::Text::FontStretch stretch,
                            /* [in] */ABI::Windows::UI::Text::FontStyle style,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontSet * * matchingFonts
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE CountFontsMatchingProperty(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasFontProperty property,
                            /* [retval, out] */UINT32 * count
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE GetPropertyValuesFromIndex(
                            /* [in] */UINT32 fontIndex,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasFontPropertyIdentifier propertyIdentifier,
                            /* [retval, out] */__FIMapView_2_HSTRING_HSTRING * * values
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetPropertyValuesFromIdentifier(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasFontPropertyIdentifier propertyIdentifier,
                            /* [in] */HSTRING preferredLocaleNames,
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasFontProperty * * valueElements
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetPropertyValues(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasFontPropertyIdentifier propertyIdentifier,
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasFontProperty * * valueElements
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasFontSet=__uuidof(ICanvasFontSet);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasFontSetFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasFontSet
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasFontSetFactory[] = L"Microsoft.Graphics.Canvas.Text.ICanvasFontSetFactory";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("3C9C9BDA-70F9-4FF9-AAB2-3B42923286EE"), exclusiveto] */
                    MIDL_INTERFACE("3C9C9BDA-70F9-4FF9-AAB2-3B42923286EE")
                    ICanvasFontSetFactory : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE Create(
                            /* [in] */ABI::Windows::Foundation::IUriRuntimeClass * uri,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontSet * * fontSet
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasFontSetFactory=__uuidof(ICanvasFontSetFactory);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasFontSetStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasFontSet
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasFontSetStatics[] = L"Microsoft.Graphics.Canvas.Text.ICanvasFontSetStatics";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("5F4275CE-BCFA-48C5-9E67-FBE9866D4924"), exclusiveto] */
                    MIDL_INTERFACE("5F4275CE-BCFA-48C5-9E67-FBE9866D4924")
                    ICanvasFontSetStatics : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE GetSystemFontSet(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontSet * * fontSet
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasFontSetStatics=__uuidof(ICanvasFontSetStatics);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasNumberSubstitution
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasNumberSubstitution
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasNumberSubstitution[] = L"Microsoft.Graphics.Canvas.Text.ICanvasNumberSubstitution";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("C81A67AD-0639-4F8F-878B-D937F8A14293"), exclusiveto] */
                    MIDL_INTERFACE("C81A67AD-0639-4F8F-878B-D937F8A14293")
                    ICanvasNumberSubstitution : public IInspectable
                    {
                    public:
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasNumberSubstitution=__uuidof(ICanvasNumberSubstitution);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasNumberSubstitutionFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasNumberSubstitution
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasNumberSubstitutionFactory[] = L"Microsoft.Graphics.Canvas.Text.ICanvasNumberSubstitutionFactory";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("7496A822-C781-4EB0-AAFB-C078E7FA8E24"), exclusiveto] */
                    MIDL_INTERFACE("7496A822-C781-4EB0-AAFB-C078E7FA8E24")
                    ICanvasNumberSubstitutionFactory : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE Create(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasNumberSubstitutionMethod method,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasNumberSubstitution * * canvasNumberSubstitution
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE CreateWithLocaleAndIgnoreOverrides(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasNumberSubstitutionMethod method,
                            /* [in] */HSTRING localeName,
                            /* [in] */::boolean ignoreEnvironmentOverrides,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasNumberSubstitution * * canvasNumberSubstitution
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasNumberSubstitutionFactory=__uuidof(ICanvasNumberSubstitutionFactory);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasScaledFont
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasScaledFont
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasScaledFont[] = L"Microsoft.Graphics.Canvas.Text.ICanvasScaledFont";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("BBC4F8D2-EB2B-45F1-AC2A-CFC1F598BAE3"), exclusiveto] */
                    MIDL_INTERFACE("BBC4F8D2-EB2B-45F1-AC2A-CFC1F598BAE3")
                    ICanvasScaledFont : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FontFace(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_ScaleFactor(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasScaledFont=__uuidof(ICanvasScaledFont);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextAnalyzer
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextAnalyzer
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextAnalyzer[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextAnalyzer";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("4298F3D1-645B-40E3-B91B-81986D767FC0"), exclusiveto] */
                    MIDL_INTERFACE("4298F3D1-645B-40E3-B91B-81986D767FC0")
                    ICanvasTextAnalyzer : public IInspectable
                    {
                    public:
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetFontsUsingSystemFontSet(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextFormat * textFormat,
                            /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * * values
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetFonts(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextFormat * textFormat,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontSet * fontSet,
                            /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * * values
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetBidi(
                            /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * * values
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetBidiWithLocale(
                            /* [in] */HSTRING locale,
                            /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * * values
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetBreakpoints(
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedBreakpoint * * valueElements
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetBreakpointsWithLocale(
                            /* [in] */HSTRING locale,
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedBreakpoint * * valueElements
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetNumberSubstitutions(
                            /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * * values
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetScript(
                            /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * * values
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetScriptWithLocale(
                            /* [in] */HSTRING locale,
                            /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * * values
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetGlyphOrientations(
                            /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * * values
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetGlyphOrientationsWithLocale(
                            /* [in] */HSTRING locale,
                            /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * * values
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetScriptProperties(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript analyzedScript,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasScriptProperties * scriptProperties
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetGlyphs(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange characterRange,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace * fontFace,
                            /* [in] */FLOAT fontSize,
                            /* [in] */::boolean isSideways,
                            /* [in] */::boolean isRightToLeft,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript script,
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * * valueElements
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetGlyphsWithAllOptions(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange characterRange,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace * fontFace,
                            /* [in] */FLOAT fontSize,
                            /* [in] */::boolean isSideways,
                            /* [in] */::boolean isRightToLeft,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript script,
                            /* [in] */HSTRING locale,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasNumberSubstitution * numberSubstitution,
                            /* [in] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * typographyRanges,
                            /* [out] */UINT32 * __clusterMapIndicesElementsSize,
                            /* [size_is(, *(__clusterMapIndicesElementsSize)), out] */INT32 * * clusterMapIndicesElements,
                            /* [out] */UINT32 * __isShapedAloneGlyphsElementsSize,
                            /* [size_is(, *(__isShapedAloneGlyphsElementsSize)), out] */::boolean * * isShapedAloneGlyphsElements,
                            /* [out] */UINT32 * __glyphShapingResultsElementsSize,
                            /* [size_is(, *(__glyphShapingResultsElementsSize)), out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyphShaping * * glyphShapingResultsElements,
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * * valueElements
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetJustificationOpportunities(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasCharacterRange characterRange,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace * fontFace,
                            /* [in] */FLOAT fontSize,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript script,
                            /* [in] */UINT32 __clusterMapIndicesElementsSize,
                            /* [size_is(__clusterMapIndicesElementsSize), in] */INT32 * clusterMapIndicesElements,
                            /* [in] */UINT32 __glyphShapingResultsElementsSize,
                            /* [size_is(__glyphShapingResultsElementsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyphShaping * glyphShapingResultsElements,
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasJustificationOpportunity * * valueElements
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE ApplyJustificationOpportunities(
                            /* [in] */FLOAT lineWidth,
                            /* [in] */UINT32 __justificationOpportunitiesElementsSize,
                            /* [size_is(__justificationOpportunitiesElementsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasJustificationOpportunity * justificationOpportunitiesElements,
                            /* [in] */UINT32 __sourceGlyphsElementsSize,
                            /* [size_is(__sourceGlyphsElementsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * sourceGlyphsElements,
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * * valueElements
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE AddGlyphsAfterJustification(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace * fontFace,
                            /* [in] */FLOAT fontSize,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript script,
                            /* [in] */UINT32 __clusterMapIndicesElementsSize,
                            /* [size_is(__clusterMapIndicesElementsSize), in] */INT32 * clusterMapIndicesElements,
                            /* [in] */UINT32 __originalGlyphsElementsSize,
                            /* [size_is(__originalGlyphsElementsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * originalGlyphsElements,
                            /* [in] */UINT32 __justifiedGlyphsElementsSize,
                            /* [size_is(__justifiedGlyphsElementsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * justifiedGlyphsElements,
                            /* [in] */UINT32 __glyphShapingResultsElementsSize,
                            /* [size_is(__glyphShapingResultsElementsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyphShaping * glyphShapingResultsElements,
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * * valueElements
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE AddGlyphsAfterJustificationWithClusterMap(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace * fontFace,
                            /* [in] */FLOAT fontSize,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasAnalyzedScript script,
                            /* [in] */UINT32 __clusterMapIndicesElementsSize,
                            /* [size_is(__clusterMapIndicesElementsSize), in] */INT32 * clusterMapIndicesElements,
                            /* [in] */UINT32 __originalGlyphsElementsSize,
                            /* [size_is(__originalGlyphsElementsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * originalGlyphsElements,
                            /* [in] */UINT32 __justifiedGlyphsElementsSize,
                            /* [size_is(__justifiedGlyphsElementsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * justifiedGlyphsElements,
                            /* [in] */UINT32 __glyphShapingResultsElementsSize,
                            /* [size_is(__glyphShapingResultsElementsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyphShaping * glyphShapingResultsElements,
                            /* [out] */UINT32 * __outputClusterMapIndicesElementsSize,
                            /* [size_is(, *(__outputClusterMapIndicesElementsSize)), out] */INT32 * * outputClusterMapIndicesElements,
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * * valueElements
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasTextAnalyzer=__uuidof(ICanvasTextAnalyzer);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextAnalyzerFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextAnalyzer
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextAnalyzerFactory[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextAnalyzerFactory";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("521E433F-F698-44C0-8D7F-FE374FE539E1"), exclusiveto] */
                    MIDL_INTERFACE("521E433F-F698-44C0-8D7F-FE374FE539E1")
                    ICanvasTextAnalyzerFactory : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE Create(
                            /* [in] */HSTRING text,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextDirection textDirection,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextAnalyzer * * canvasTextAnalyzer
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE CreateWithNumberSubstitutionAndVerticalGlyphOrientationAndBidiLevel(
                            /* [in] */HSTRING text,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextDirection textDirection,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasNumberSubstitution * numberSubstitution,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasVerticalGlyphOrientation verticalGlyphOrientation,
                            /* [in] */UINT32 bidiLevel,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextAnalyzer * * canvasTextAnalyzer
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE CreateWithOptions(
                            /* [in] */HSTRING text,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextDirection textDirection,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextAnalyzerOptions * options,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextAnalyzer * * canvasTextAnalyzer
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasTextAnalyzerFactory=__uuidof(ICanvasTextAnalyzerFactory);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextAnalyzerOptions
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextAnalyzerOptions[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextAnalyzerOptions";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("31F2406A-8C5F-4E12-8BD6-CFBBC7214D02")] */
                    MIDL_INTERFACE("31F2406A-8C5F-4E12-8BD6-CFBBC7214D02")
                    ICanvasTextAnalyzerOptions : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE GetLocaleName(
                            /* [in] */INT32 characterIndex,
                            /* [out] */INT32 * characterCount,
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetNumberSubstitution(
                            /* [in] */INT32 characterIndex,
                            /* [out] */INT32 * characterCount,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasNumberSubstitution * * value
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetVerticalGlyphOrientation(
                            /* [in] */INT32 characterIndex,
                            /* [out] */INT32 * characterCount,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasVerticalGlyphOrientation * value
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetBidiLevel(
                            /* [in] */INT32 characterIndex,
                            /* [out] */INT32 * characterCount,
                            /* [retval, out] */UINT32 * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasTextAnalyzerOptions=__uuidof(ICanvasTextAnalyzerOptions);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextFormat
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextFormat
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextFormat[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextFormat";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("AF61BFDC-EABB-4D38-BA1B-AFB340612D33"), exclusiveto] */
                    MIDL_INTERFACE("AF61BFDC-EABB-4D38-BA1B-AFB340612D33")
                    ICanvasTextFormat : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Direction(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextDirection * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Direction(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextDirection value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FontFamily(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_FontFamily(
                            /* [in] */HSTRING value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FontSize(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_FontSize(
                            /* [in] */FLOAT value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FontStretch(
                            /* [retval, out] */ABI::Windows::UI::Text::FontStretch * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_FontStretch(
                            /* [in] */ABI::Windows::UI::Text::FontStretch value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FontStyle(
                            /* [retval, out] */ABI::Windows::UI::Text::FontStyle * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_FontStyle(
                            /* [in] */ABI::Windows::UI::Text::FontStyle value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FontWeight(
                            /* [retval, out] */ABI::Windows::UI::Text::FontWeight * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_FontWeight(
                            /* [in] */ABI::Windows::UI::Text::FontWeight value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_IncrementalTabStop(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_IncrementalTabStop(
                            /* [in] */FLOAT value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LineSpacing(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_LineSpacing(
                            /* [in] */FLOAT value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LineSpacingBaseline(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_LineSpacingBaseline(
                            /* [in] */FLOAT value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LocaleName(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_LocaleName(
                            /* [in] */HSTRING value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_VerticalAlignment(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasVerticalAlignment * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_VerticalAlignment(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasVerticalAlignment value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_HorizontalAlignment(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasHorizontalAlignment * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_HorizontalAlignment(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasHorizontalAlignment value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_TrimmingGranularity(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextTrimmingGranularity * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_TrimmingGranularity(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextTrimmingGranularity value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_TrimmingDelimiter(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_TrimmingDelimiter(
                            /* [in] */HSTRING value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_TrimmingDelimiterCount(
                            /* [retval, out] */INT32 * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_TrimmingDelimiterCount(
                            /* [in] */INT32 value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_WordWrapping(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasWordWrapping * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_WordWrapping(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasWordWrapping value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Options(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasDrawTextOptions * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Options(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasDrawTextOptions value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_VerticalGlyphOrientation(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasVerticalGlyphOrientation * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_VerticalGlyphOrientation(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasVerticalGlyphOrientation value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_OpticalAlignment(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasOpticalAlignment * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_OpticalAlignment(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasOpticalAlignment value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LastLineWrapping(
                            /* [retval, out] */::boolean * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_LastLineWrapping(
                            /* [in] */::boolean value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LineSpacingMode(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasLineSpacingMode * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_LineSpacingMode(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasLineSpacingMode value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_TrimmingSign(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTrimmingSign * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_TrimmingSign(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTrimmingSign value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_CustomTrimmingSign(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextInlineObject * * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_CustomTrimmingSign(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextInlineObject * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasTextFormat=__uuidof(ICanvasTextFormat);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextFormatStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextFormat
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextFormatStatics[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextFormatStatics";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("8A927515-33FC-4C92-A6AA-94A8F29C140B"), exclusiveto] */
                    MIDL_INTERFACE("8A927515-33FC-4C92-A6AA-94A8F29C140B")
                    ICanvasTextFormatStatics : public IInspectable
                    {
                    public:
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetSystemFontFamilies(
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */HSTRING * * valueElements
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetSystemFontFamiliesFromLocaleList(
                            /* [in] */__FIVectorView_1_HSTRING * localeList,
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */HSTRING * * valueElements
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasTextFormatStatics=__uuidof(ICanvasTextFormatStatics);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextInlineObject
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextInlineObject[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextInlineObject";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("7A89EE99-CE2A-47FA-9DD2-0A6825F6053F")] */
                    MIDL_INTERFACE("7A89EE99-CE2A-47FA-9DD2-0A6825F6053F")
                    ICanvasTextInlineObject : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE Draw(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextRenderer * textRenderer,
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                            /* [in] */::boolean isSideways,
                            /* [in] */::boolean isRightToLeft,
                            /* [in] */IInspectable * brush
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Size(
                            /* [retval, out] */ABI::Windows::Foundation::Size * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Baseline(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_SupportsSideways(
                            /* [retval, out] */::boolean * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_DrawBounds(
                            /* [retval, out] */ABI::Windows::Foundation::Rect * bounds
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_BreakBefore(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasLineBreakCondition * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_BreakAfter(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasLineBreakCondition * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasTextInlineObject=__uuidof(ICanvasTextInlineObject);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextLayout
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextLayout
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextLayout[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextLayout";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("BAE63E54-48AE-4446-A2C7-B6EF93806C20"), exclusiveto] */
                    MIDL_INTERFACE("BAE63E54-48AE-4446-A2C7-B6EF93806C20")
                    ICanvasTextLayout : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE GetFormatChangeIndices(
                            /* [out] */UINT32 * __stopsSize,
                            /* [size_is(, *(__stopsSize)), retval, out] */INT32 * * stops
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Direction(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextDirection * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Direction(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextDirection value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_DefaultFontFamily(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_DefaultFontSize(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_DefaultFontStretch(
                            /* [retval, out] */ABI::Windows::UI::Text::FontStretch * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_DefaultFontStyle(
                            /* [retval, out] */ABI::Windows::UI::Text::FontStyle * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_DefaultFontWeight(
                            /* [retval, out] */ABI::Windows::UI::Text::FontWeight * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_IncrementalTabStop(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_IncrementalTabStop(
                            /* [in] */FLOAT value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LineSpacing(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_LineSpacing(
                            /* [in] */FLOAT value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LineSpacingBaseline(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_LineSpacingBaseline(
                            /* [in] */FLOAT value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_DefaultLocaleName(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_VerticalAlignment(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasVerticalAlignment * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_VerticalAlignment(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasVerticalAlignment value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_HorizontalAlignment(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasHorizontalAlignment * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_HorizontalAlignment(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasHorizontalAlignment value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_TrimmingGranularity(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextTrimmingGranularity * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_TrimmingGranularity(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextTrimmingGranularity value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_TrimmingDelimiter(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_TrimmingDelimiter(
                            /* [in] */HSTRING value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_TrimmingDelimiterCount(
                            /* [retval, out] */INT32 * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_TrimmingDelimiterCount(
                            /* [in] */INT32 value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_WordWrapping(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasWordWrapping * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_WordWrapping(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasWordWrapping value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Options(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasDrawTextOptions * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Options(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasDrawTextOptions value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LineSpacingMode(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasLineSpacingMode * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_LineSpacingMode(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasLineSpacingMode value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_TrimmingSign(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTrimmingSign * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_TrimmingSign(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTrimmingSign value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_CustomTrimmingSign(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextInlineObject * * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_CustomTrimmingSign(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextInlineObject * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_RequestedSize(
                            /* [retval, out] */ABI::Windows::Foundation::Size * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_RequestedSize(
                            /* [in] */ABI::Windows::Foundation::Size value
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetMinimumLineLength(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetBrush(
                            /* [in] */INT32 characterIndex,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * * brush
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetCustomBrush(
                            /* [in] */INT32 characterIndex,
                            /* [retval, out] */IInspectable * * brush
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetFontFamily(
                            /* [in] */INT32 characterIndex,
                            /* [retval, out] */HSTRING * fontFamily
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetFontSize(
                            /* [in] */INT32 characterIndex,
                            /* [retval, out] */FLOAT * fontSize
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetFontStretch(
                            /* [in] */INT32 characterIndex,
                            /* [retval, out] */ABI::Windows::UI::Text::FontStretch * fontStretch
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetFontStyle(
                            /* [in] */INT32 characterIndex,
                            /* [retval, out] */ABI::Windows::UI::Text::FontStyle * fontStyle
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetFontWeight(
                            /* [in] */INT32 characterIndex,
                            /* [retval, out] */ABI::Windows::UI::Text::FontWeight * fontWeight
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetLocaleName(
                            /* [in] */INT32 characterIndex,
                            /* [retval, out] */HSTRING * localeName
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetStrikethrough(
                            /* [in] */INT32 characterIndex,
                            /* [retval, out] */::boolean * hasStrikethrough
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetUnderline(
                            /* [in] */INT32 characterIndex,
                            /* [retval, out] */::boolean * hasUnderline
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetInlineObject(
                            /* [in] */INT32 characterIndex,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextInlineObject * * inlineObject
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetColor(
                            /* [in] */INT32 characterIndex,
                            /* [in] */INT32 characterCount,
                            /* [in] */ABI::Windows::UI::Color color
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetBrush(
                            /* [in] */INT32 characterIndex,
                            /* [in] */INT32 characterCount,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetCustomBrush(
                            /* [in] */INT32 characterIndex,
                            /* [in] */INT32 characterCount,
                            /* [in] */IInspectable * brush
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetFontFamily(
                            /* [in] */INT32 characterIndex,
                            /* [in] */INT32 characterCount,
                            /* [in] */HSTRING fontFamily
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetFontSize(
                            /* [in] */INT32 characterIndex,
                            /* [in] */INT32 characterCount,
                            /* [in] */FLOAT fontSize
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetFontStretch(
                            /* [in] */INT32 characterIndex,
                            /* [in] */INT32 characterCount,
                            /* [in] */ABI::Windows::UI::Text::FontStretch fontStretch
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetFontStyle(
                            /* [in] */INT32 characterIndex,
                            /* [in] */INT32 characterCount,
                            /* [in] */ABI::Windows::UI::Text::FontStyle fontStyle
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetFontWeight(
                            /* [in] */INT32 characterIndex,
                            /* [in] */INT32 characterCount,
                            /* [in] */ABI::Windows::UI::Text::FontWeight fontWeight
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetLocaleName(
                            /* [in] */INT32 characterIndex,
                            /* [in] */INT32 characterCount,
                            /* [in] */HSTRING name
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetStrikethrough(
                            /* [in] */INT32 characterIndex,
                            /* [in] */INT32 characterCount,
                            /* [in] */::boolean hasStrikethrough
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetUnderline(
                            /* [in] */INT32 characterIndex,
                            /* [in] */INT32 characterCount,
                            /* [in] */::boolean hasUnderline
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetInlineObject(
                            /* [in] */INT32 characterIndex,
                            /* [in] */INT32 characterCount,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextInlineObject * inlineObject
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawToTextRenderer(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextRenderer * textRenderer,
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 position
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawToTextRendererWithCoords(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextRenderer * textRenderer,
                            /* [in] */FLOAT x,
                            /* [in] */FLOAT y
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LineMetrics(
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasLineMetrics * * valueElements
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_ClusterMetrics(
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasClusterMetrics * * valueElements
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetTypography(
                            /* [in] */INT32 characterIndex,
                            /* [in] */INT32 characterCount,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTypography * typography
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetTypography(
                            /* [in] */INT32 characterIndex,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTypography * * typography
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LayoutBounds(
                            /* [retval, out] */ABI::Windows::Foundation::Rect * bounds
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LayoutBoundsIncludingTrailingWhitespace(
                            /* [retval, out] */ABI::Windows::Foundation::Rect * bounds
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LineCount(
                            /* [retval, out] */INT32 * lineCount
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_MaximumBidiReorderingDepth(
                            /* [retval, out] */INT32 * depth
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_DrawBounds(
                            /* [retval, out] */ABI::Windows::Foundation::Rect * bounds
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE HitTest(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                            /* [retval, out] */::boolean * isHit
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE HitTestWithCoords(
                            /* [in] */FLOAT x,
                            /* [in] */FLOAT y,
                            /* [retval, out] */::boolean * isHit
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE HitTestWithDescription(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                            /* [out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextLayoutRegion * textLayoutRegion,
                            /* [retval, out] */::boolean * isHit
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE HitTestWithDescriptionAndCoords(
                            /* [in] */FLOAT x,
                            /* [in] */FLOAT y,
                            /* [out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextLayoutRegion * textLayoutRegion,
                            /* [retval, out] */::boolean * isHit
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE HitTestWithDescriptionAndTrailingSide(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                            /* [out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextLayoutRegion * textLayoutRegion,
                            /* [out] */::boolean * trailingSideOfCharacter,
                            /* [retval, out] */::boolean * isHit
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE HitTestWithDescriptionAndCoordsAndTrailingSide(
                            /* [in] */FLOAT x,
                            /* [in] */FLOAT y,
                            /* [out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextLayoutRegion * textLayoutRegion,
                            /* [out] */::boolean * trailingSideOfCharacter,
                            /* [retval, out] */::boolean * isHit
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetCaretPosition(
                            /* [in] */INT32 characterIndex,
                            /* [in] */::boolean trailingSideOfCharacter,
                            /* [retval, out] */ABI::Windows::Foundation::Numerics::Vector2 * location
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE GetCaretPositionWithDescription(
                            /* [in] */INT32 characterIndex,
                            /* [in] */::boolean trailingSideOfCharacter,
                            /* [out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextLayoutRegion * textLayoutRegion,
                            /* [retval, out] */ABI::Windows::Foundation::Numerics::Vector2 * location
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE GetCharacterRegions(
                            /* [in] */INT32 characterIndex,
                            /* [in] */INT32 characterCount,
                            /* [out] */UINT32 * __hitTestDescriptionsSize,
                            /* [size_is(, *(__hitTestDescriptionsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextLayoutRegion * * hitTestDescriptions
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetPairKerning(
                            /* [in] */INT32 characterIndex,
                            /* [retval, out] */::boolean * hasPairKerning
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetPairKerning(
                            /* [in] */INT32 characterIndex,
                            /* [in] */INT32 characterCount,
                            /* [in] */::boolean hasPairKerning
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetLeadingCharacterSpacing(
                            /* [in] */INT32 characterIndex,
                            /* [retval, out] */FLOAT * leadingSpacing
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetTrailingCharacterSpacing(
                            /* [in] */INT32 characterIndex,
                            /* [retval, out] */FLOAT * trailingSpacing
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetMinimumCharacterAdvance(
                            /* [in] */INT32 characterIndex,
                            /* [retval, out] */FLOAT * minimumAdvance
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetCharacterSpacing(
                            /* [in] */INT32 characterIndex,
                            /* [in] */INT32 characterCount,
                            /* [in] */FLOAT leadingSpacing,
                            /* [in] */FLOAT trailingSpacing,
                            /* [in] */FLOAT minimumAdvance
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_VerticalGlyphOrientation(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasVerticalGlyphOrientation * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_VerticalGlyphOrientation(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasVerticalGlyphOrientation value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_OpticalAlignment(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasOpticalAlignment * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_OpticalAlignment(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasOpticalAlignment value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LastLineWrapping(
                            /* [retval, out] */::boolean * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_LastLineWrapping(
                            /* [in] */::boolean value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Device(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasTextLayout=__uuidof(ICanvasTextLayout);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextLayoutFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextLayout
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextLayoutFactory[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextLayoutFactory";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("9C1F7179-ACD0-4680-93D5-95A6247E8F6B"), exclusiveto] */
                    MIDL_INTERFACE("9C1F7179-ACD0-4680-93D5-95A6247E8F6B")
                    ICanvasTextLayoutFactory : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE Create(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [in] */HSTRING textString,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextFormat * textFormat,
                            /* [in] */FLOAT requestedWidth,
                            /* [in] */FLOAT requestedHeight,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextLayout * * canvasTextLayout
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasTextLayoutFactory=__uuidof(ICanvasTextLayoutFactory);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextLayoutStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextLayout
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextLayoutStatics[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextLayoutStatics";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("7F2B8FFD-6935-4F60-B409-6394A19C5EBC"), exclusiveto] */
                    MIDL_INTERFACE("7F2B8FFD-6935-4F60-B409-6394A19C5EBC")
                    ICanvasTextLayoutStatics : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE GetGlyphOrientationTransform(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyphOrientation glyphOrientation,
                            /* [in] */::boolean isSideways,
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 position,
                            /* [retval, out] */ABI::Windows::Foundation::Numerics::Matrix3x2 * transform
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasTextLayoutStatics=__uuidof(ICanvasTextLayoutStatics);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextRenderer
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextRenderer[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextRenderer";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("9AAEECE5-8D09-4A64-B322-AF030421B2E4")] */
                    MIDL_INTERFACE("9AAEECE5-8D09-4A64-B322-AF030421B2E4")
                    ICanvasTextRenderer : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE DrawGlyphRun(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace * fontFace,
                            /* [in] */FLOAT fontSize,
                            /* [in] */UINT32 __glyphsSize,
                            /* [size_is(__glyphsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * glyphs,
                            /* [in] */::boolean isSideways,
                            /* [in] */UINT32 bidiLevel,
                            /* [in] */IInspectable * brush,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextMeasuringMode measuringMode,
                            /* [in] */HSTRING localeName,
                            /* [in] */HSTRING textString,
                            /* [in] */UINT32 __clusterMapIndicesSize,
                            /* [size_is(__clusterMapIndicesSize), in] */INT32 * clusterMapIndices,
                            /* [in] */UINT32 characterIndex,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyphOrientation glyphOrientation
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE DrawStrikethrough(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                            /* [in] */FLOAT strikethroughWidth,
                            /* [in] */FLOAT strikethroughThickness,
                            /* [in] */FLOAT strikethroughOffset,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextDirection textDirection,
                            /* [in] */IInspectable * brush,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextMeasuringMode textMeasuringMode,
                            /* [in] */HSTRING localeName,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyphOrientation glyphOrientation
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE DrawUnderline(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                            /* [in] */FLOAT underlineWidth,
                            /* [in] */FLOAT underlineThickness,
                            /* [in] */FLOAT underlineOffset,
                            /* [in] */FLOAT runHeight,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextDirection textDirection,
                            /* [in] */IInspectable * brush,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextMeasuringMode textMeasuringMode,
                            /* [in] */HSTRING localeName,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyphOrientation glyphOrientation
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE DrawInlineObject(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextInlineObject * inlineObject,
                            /* [in] */::boolean isSideways,
                            /* [in] */::boolean isRightToLeft,
                            /* [in] */IInspectable * brush,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyphOrientation glyphOrientation
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_PixelSnappingDisabled(
                            /* [retval, out] */::boolean * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Transform(
                            /* [retval, out] */ABI::Windows::Foundation::Numerics::Matrix3x2 * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Dpi(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasTextRenderer=__uuidof(ICanvasTextRenderer);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextRenderingParameters
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextRenderingParameters
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextRenderingParameters[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextRenderingParameters";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("B20BF738-EDB9-4EEC-A12F-B6AE32E8ACE6"), exclusiveto] */
                    MIDL_INTERFACE("B20BF738-EDB9-4EEC-A12F-B6AE32E8ACE6")
                    ICanvasTextRenderingParameters : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_RenderingMode(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextRenderingMode * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_GridFit(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextGridFit * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasTextRenderingParameters=__uuidof(ICanvasTextRenderingParameters);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextRenderingParametersFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextRenderingParameters
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextRenderingParametersFactory[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextRenderingParametersFactory";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("D240AC25-4D23-4964-9D9A-DB2FC8AF185D"), exclusiveto] */
                    MIDL_INTERFACE("D240AC25-4D23-4964-9D9A-DB2FC8AF185D")
                    ICanvasTextRenderingParametersFactory : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE Create(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextRenderingMode textRenderingMode,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextGridFit gridFit,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextRenderingParameters * * textRenderingParameters
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasTextRenderingParametersFactory=__uuidof(ICanvasTextRenderingParametersFactory);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTypography
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTypography
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTypography[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTypography";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    /* [object, version, uuid("F15BC312-447F-44ED-8BEC-7E40F4A4DFC8"), exclusiveto] */
                    MIDL_INTERFACE("F15BC312-447F-44ED-8BEC-7E40F4A4DFC8")
                    ICanvasTypography : public IInspectable
                    {
                    public:
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE AddFeature(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTypographyFeature feature
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE AddFeatureWithNameAndParameter(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTypographyFeatureName name,
                            /* [in] */UINT32 parameter
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetFeatures(
                            /* [out] */UINT32 * __featuresSize,
                            /* [size_is(, *(__featuresSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTypographyFeature * * features
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasTypography=__uuidof(ICanvasTypography);
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_INTERFACE_DEFINED__) */


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasFontFace
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasFontFace ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasFontFace_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasFontFace_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasFontFace[] = L"Microsoft.Graphics.Canvas.Text.CanvasFontFace";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasFontSet
 *
 * RuntimeClass can be activated.
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasFontSet ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasFontSet_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasFontSet_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasFontSet[] = L"Microsoft.Graphics.Canvas.Text.CanvasFontSet";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasNumberSubstitution
 *
 * RuntimeClass can be activated.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasNumberSubstitution ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasNumberSubstitution_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasNumberSubstitution_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasNumberSubstitution[] = L"Microsoft.Graphics.Canvas.Text.CanvasNumberSubstitution";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasScaledFont
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasScaledFont ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasScaledFont_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasScaledFont_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasScaledFont[] = L"Microsoft.Graphics.Canvas.Text.CanvasScaledFont";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasTextAnalyzer
 *
 * RuntimeClass can be activated.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasTextAnalyzer ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTextAnalyzer_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTextAnalyzer_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasTextAnalyzer[] = L"Microsoft.Graphics.Canvas.Text.CanvasTextAnalyzer";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasTextFormat
 *
 * RuntimeClass can be activated.
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasTextFormat ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTextFormat_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTextFormat_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasTextFormat[] = L"Microsoft.Graphics.Canvas.Text.CanvasTextFormat";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasTextLayout
 *
 * RuntimeClass can be activated.
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasTextLayout ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTextLayout_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTextLayout_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasTextLayout[] = L"Microsoft.Graphics.Canvas.Text.CanvasTextLayout";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasTextRenderingParameters
 *
 * RuntimeClass can be activated.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasTextRenderingParameters ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTextRenderingParameters_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTextRenderingParameters_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasTextRenderingParameters[] = L"Microsoft.Graphics.Canvas.Text.CanvasTextRenderingParameters";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasTypography
 *
 * RuntimeClass can be activated.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasTypography ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTypography_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTypography_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasTypography[] = L"Microsoft.Graphics.Canvas.Text.CanvasTypography";
#endif





#else // !defined(__cplusplus)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_FWD_DEFINED__

// Parameterized interface forward declarations (C)

// Collection interface definitions

#if !defined(____FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_INTERFACE_DEFINED__)
#define ____FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_INTERFACE_DEFINED__

typedef interface __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace;

typedef struct __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFaceVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Current )(__RPC__in __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This, /* [retval][out] */ __RPC__out __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * *current);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasCurrent )(__RPC__in __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *MoveNext )(__RPC__in __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *GetMany )(__RPC__in __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This,
        /* [in] */ unsigned int capacity,
        /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * *items,
        /* [retval][out] */ __RPC__out unsigned int *actual);

    END_INTERFACE
} __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFaceVtbl;

interface __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace
{
    CONST_VTBL struct __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFaceVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_get_Current(This,current)	\
    ( (This)->lpVtbl -> get_Current(This,current) ) 

#define __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_get_HasCurrent(This,hasCurrent)	\
    ( (This)->lpVtbl -> get_HasCurrent(This,hasCurrent) ) 

#define __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_MoveNext(This,hasCurrent)	\
    ( (This)->lpVtbl -> MoveNext(This,hasCurrent) ) 

#define __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_GetMany(This,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,capacity,items,actual) ) 

#endif /* COBJMACROS */


#endif // ____FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_INTERFACE_DEFINED__



#if !defined(____FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_INTERFACE_DEFINED__)
#define ____FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_INTERFACE_DEFINED__

typedef interface __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace;

typedef  struct __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFaceVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This);

    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This,
                                           /* [out] */ __RPC__out ULONG *iidCount,
                                           /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *First )(__RPC__in __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This, /* [retval][out] */ __RPC__deref_out_opt __FIIterator_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace **first);

    END_INTERFACE
} __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFaceVtbl;

interface __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace
{
    CONST_VTBL struct __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFaceVtbl *lpVtbl;
};

#ifdef COBJMACROS

#define __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_First(This,first)	\
    ( (This)->lpVtbl -> First(This,first) ) 

#endif /* COBJMACROS */


#endif // ____FIIterable_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_INTERFACE_DEFINED__


struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasCharacterRange;

struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedBidi;

#if !defined(____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_INTERFACE_DEFINED__)
#define ____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_INTERFACE_DEFINED__

typedef interface __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi;

typedef struct __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidiVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This,
            /* [out] */ __RPC__out ULONG *iidCount,
            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Key )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This, /* [retval][out] */ __RPC__out struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasCharacterRange *key);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Value )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This, /* [retval][out] */ __RPC__deref_out_opt struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedBidi *value);
    END_INTERFACE
} __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidiVtbl;

interface __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi
{
    CONST_VTBL struct __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidiVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_get_Key(This,key)	\
    ( (This)->lpVtbl -> get_Key(This,key) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_get_Value(This,value)	\
    ( (This)->lpVtbl -> get_Value(This,value) ) 
#endif /* COBJMACROS */


#endif // ____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_INTERFACE_DEFINED__



#if !defined(____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_INTERFACE_DEFINED__)
#define ____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_INTERFACE_DEFINED__

typedef interface __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi;

typedef struct __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidiVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Current )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This, /* [retval][out] */ __RPC__out __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * *current);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasCurrent )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *MoveNext )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *GetMany )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This,
        /* [in] */ unsigned int capacity,
        /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * *items,
        /* [retval][out] */ __RPC__out unsigned int *actual);

    END_INTERFACE
} __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidiVtbl;

interface __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi
{
    CONST_VTBL struct __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidiVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_get_Current(This,current)	\
    ( (This)->lpVtbl -> get_Current(This,current) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_get_HasCurrent(This,hasCurrent)	\
    ( (This)->lpVtbl -> get_HasCurrent(This,hasCurrent) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_MoveNext(This,hasCurrent)	\
    ( (This)->lpVtbl -> MoveNext(This,hasCurrent) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_GetMany(This,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,capacity,items,actual) ) 

#endif /* COBJMACROS */


#endif // ____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_INTERFACE_DEFINED__



#if !defined(____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_INTERFACE_DEFINED__)
#define ____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_INTERFACE_DEFINED__

typedef interface __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi;

typedef  struct __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidiVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This);

    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This,
                                           /* [out] */ __RPC__out ULONG *iidCount,
                                           /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *First )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This, /* [retval][out] */ __RPC__deref_out_opt __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi **first);

    END_INTERFACE
} __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidiVtbl;

interface __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi
{
    CONST_VTBL struct __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidiVtbl *lpVtbl;
};

#ifdef COBJMACROS

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_First(This,first)	\
    ( (This)->lpVtbl -> First(This,first) ) 

#endif /* COBJMACROS */


#endif // ____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_INTERFACE_DEFINED__



struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedGlyphOrientation;

#if !defined(____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_INTERFACE_DEFINED__)
#define ____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_INTERFACE_DEFINED__

typedef interface __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation;

typedef struct __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientationVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This,
            /* [out] */ __RPC__out ULONG *iidCount,
            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Key )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This, /* [retval][out] */ __RPC__out struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasCharacterRange *key);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Value )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This, /* [retval][out] */ __RPC__deref_out_opt struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedGlyphOrientation *value);
    END_INTERFACE
} __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientationVtbl;

interface __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation
{
    CONST_VTBL struct __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientationVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_get_Key(This,key)	\
    ( (This)->lpVtbl -> get_Key(This,key) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_get_Value(This,value)	\
    ( (This)->lpVtbl -> get_Value(This,value) ) 
#endif /* COBJMACROS */


#endif // ____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_INTERFACE_DEFINED__



#if !defined(____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_INTERFACE_DEFINED__)
#define ____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_INTERFACE_DEFINED__

typedef interface __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation;

typedef struct __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientationVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Current )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This, /* [retval][out] */ __RPC__out __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * *current);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasCurrent )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *MoveNext )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *GetMany )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This,
        /* [in] */ unsigned int capacity,
        /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * *items,
        /* [retval][out] */ __RPC__out unsigned int *actual);

    END_INTERFACE
} __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientationVtbl;

interface __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation
{
    CONST_VTBL struct __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientationVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_get_Current(This,current)	\
    ( (This)->lpVtbl -> get_Current(This,current) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_get_HasCurrent(This,hasCurrent)	\
    ( (This)->lpVtbl -> get_HasCurrent(This,hasCurrent) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_MoveNext(This,hasCurrent)	\
    ( (This)->lpVtbl -> MoveNext(This,hasCurrent) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_GetMany(This,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,capacity,items,actual) ) 

#endif /* COBJMACROS */


#endif // ____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_INTERFACE_DEFINED__



#if !defined(____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_INTERFACE_DEFINED__)
#define ____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_INTERFACE_DEFINED__

typedef interface __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation;

typedef  struct __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientationVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This);

    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This,
                                           /* [out] */ __RPC__out ULONG *iidCount,
                                           /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *First )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This, /* [retval][out] */ __RPC__deref_out_opt __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation **first);

    END_INTERFACE
} __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientationVtbl;

interface __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation
{
    CONST_VTBL struct __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientationVtbl *lpVtbl;
};

#ifdef COBJMACROS

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_First(This,first)	\
    ( (This)->lpVtbl -> First(This,first) ) 

#endif /* COBJMACROS */


#endif // ____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_INTERFACE_DEFINED__



struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedScript;

#if !defined(____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_INTERFACE_DEFINED__)
#define ____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_INTERFACE_DEFINED__

typedef interface __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript;

typedef struct __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScriptVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This,
            /* [out] */ __RPC__out ULONG *iidCount,
            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Key )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This, /* [retval][out] */ __RPC__out struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasCharacterRange *key);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Value )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This, /* [retval][out] */ __RPC__deref_out_opt struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedScript *value);
    END_INTERFACE
} __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScriptVtbl;

interface __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript
{
    CONST_VTBL struct __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScriptVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_get_Key(This,key)	\
    ( (This)->lpVtbl -> get_Key(This,key) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_get_Value(This,value)	\
    ( (This)->lpVtbl -> get_Value(This,value) ) 
#endif /* COBJMACROS */


#endif // ____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_INTERFACE_DEFINED__



#if !defined(____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_INTERFACE_DEFINED__)
#define ____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_INTERFACE_DEFINED__

typedef interface __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript;

typedef struct __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScriptVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Current )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This, /* [retval][out] */ __RPC__out __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * *current);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasCurrent )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *MoveNext )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *GetMany )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This,
        /* [in] */ unsigned int capacity,
        /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * *items,
        /* [retval][out] */ __RPC__out unsigned int *actual);

    END_INTERFACE
} __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScriptVtbl;

interface __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript
{
    CONST_VTBL struct __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScriptVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_get_Current(This,current)	\
    ( (This)->lpVtbl -> get_Current(This,current) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_get_HasCurrent(This,hasCurrent)	\
    ( (This)->lpVtbl -> get_HasCurrent(This,hasCurrent) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_MoveNext(This,hasCurrent)	\
    ( (This)->lpVtbl -> MoveNext(This,hasCurrent) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_GetMany(This,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,capacity,items,actual) ) 

#endif /* COBJMACROS */


#endif // ____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_INTERFACE_DEFINED__



#if !defined(____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_INTERFACE_DEFINED__)
#define ____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_INTERFACE_DEFINED__

typedef interface __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript;

typedef  struct __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScriptVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This);

    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This,
                                           /* [out] */ __RPC__out ULONG *iidCount,
                                           /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *First )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This, /* [retval][out] */ __RPC__deref_out_opt __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript **first);

    END_INTERFACE
} __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScriptVtbl;

interface __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript
{
    CONST_VTBL struct __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScriptVtbl *lpVtbl;
};

#ifdef COBJMACROS

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_First(This,first)	\
    ( (This)->lpVtbl -> First(This,first) ) 

#endif /* COBJMACROS */


#endif // ____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_INTERFACE_DEFINED__




#if !defined(____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_INTERFACE_DEFINED__)
#define ____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_INTERFACE_DEFINED__

typedef interface __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution;

typedef struct __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitutionVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This,
            /* [out] */ __RPC__out ULONG *iidCount,
            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Key )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This, /* [retval][out] */ __RPC__out struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasCharacterRange *key);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Value )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This, /* [retval][out] */ __RPC__deref_out_opt __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution * *value);
    END_INTERFACE
} __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitutionVtbl;

interface __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution
{
    CONST_VTBL struct __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitutionVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_get_Key(This,key)	\
    ( (This)->lpVtbl -> get_Key(This,key) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_get_Value(This,value)	\
    ( (This)->lpVtbl -> get_Value(This,value) ) 
#endif /* COBJMACROS */


#endif // ____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_INTERFACE_DEFINED__



#if !defined(____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_INTERFACE_DEFINED__)
#define ____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_INTERFACE_DEFINED__

typedef interface __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution;

typedef struct __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitutionVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Current )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This, /* [retval][out] */ __RPC__out __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * *current);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasCurrent )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *MoveNext )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *GetMany )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This,
        /* [in] */ unsigned int capacity,
        /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * *items,
        /* [retval][out] */ __RPC__out unsigned int *actual);

    END_INTERFACE
} __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitutionVtbl;

interface __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution
{
    CONST_VTBL struct __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitutionVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_get_Current(This,current)	\
    ( (This)->lpVtbl -> get_Current(This,current) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_get_HasCurrent(This,hasCurrent)	\
    ( (This)->lpVtbl -> get_HasCurrent(This,hasCurrent) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_MoveNext(This,hasCurrent)	\
    ( (This)->lpVtbl -> MoveNext(This,hasCurrent) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_GetMany(This,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,capacity,items,actual) ) 

#endif /* COBJMACROS */


#endif // ____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_INTERFACE_DEFINED__



#if !defined(____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_INTERFACE_DEFINED__)
#define ____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_INTERFACE_DEFINED__

typedef interface __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution;

typedef  struct __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitutionVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This);

    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This,
                                           /* [out] */ __RPC__out ULONG *iidCount,
                                           /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *First )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This, /* [retval][out] */ __RPC__deref_out_opt __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution **first);

    END_INTERFACE
} __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitutionVtbl;

interface __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution
{
    CONST_VTBL struct __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitutionVtbl *lpVtbl;
};

#ifdef COBJMACROS

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_First(This,first)	\
    ( (This)->lpVtbl -> First(This,first) ) 

#endif /* COBJMACROS */


#endif // ____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_INTERFACE_DEFINED__




#if !defined(____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_INTERFACE_DEFINED__)
#define ____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_INTERFACE_DEFINED__

typedef interface __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont;

typedef struct __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFontVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This,
            /* [out] */ __RPC__out ULONG *iidCount,
            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Key )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This, /* [retval][out] */ __RPC__out struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasCharacterRange *key);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Value )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This, /* [retval][out] */ __RPC__deref_out_opt __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont * *value);
    END_INTERFACE
} __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFontVtbl;

interface __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont
{
    CONST_VTBL struct __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFontVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_get_Key(This,key)	\
    ( (This)->lpVtbl -> get_Key(This,key) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_get_Value(This,value)	\
    ( (This)->lpVtbl -> get_Value(This,value) ) 
#endif /* COBJMACROS */


#endif // ____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_INTERFACE_DEFINED__



#if !defined(____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_INTERFACE_DEFINED__)
#define ____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_INTERFACE_DEFINED__

typedef interface __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont;

typedef struct __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFontVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Current )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This, /* [retval][out] */ __RPC__out __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * *current);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasCurrent )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *MoveNext )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *GetMany )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This,
        /* [in] */ unsigned int capacity,
        /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * *items,
        /* [retval][out] */ __RPC__out unsigned int *actual);

    END_INTERFACE
} __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFontVtbl;

interface __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont
{
    CONST_VTBL struct __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFontVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_get_Current(This,current)	\
    ( (This)->lpVtbl -> get_Current(This,current) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_get_HasCurrent(This,hasCurrent)	\
    ( (This)->lpVtbl -> get_HasCurrent(This,hasCurrent) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_MoveNext(This,hasCurrent)	\
    ( (This)->lpVtbl -> MoveNext(This,hasCurrent) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_GetMany(This,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,capacity,items,actual) ) 

#endif /* COBJMACROS */


#endif // ____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_INTERFACE_DEFINED__



#if !defined(____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_INTERFACE_DEFINED__)
#define ____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_INTERFACE_DEFINED__

typedef interface __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont;

typedef  struct __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFontVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This);

    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This,
                                           /* [out] */ __RPC__out ULONG *iidCount,
                                           /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *First )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This, /* [retval][out] */ __RPC__deref_out_opt __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont **first);

    END_INTERFACE
} __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFontVtbl;

interface __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont
{
    CONST_VTBL struct __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFontVtbl *lpVtbl;
};

#ifdef COBJMACROS

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_First(This,first)	\
    ( (This)->lpVtbl -> First(This,first) ) 

#endif /* COBJMACROS */


#endif // ____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_INTERFACE_DEFINED__




#if !defined(____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_INTERFACE_DEFINED__)
#define ____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_INTERFACE_DEFINED__

typedef interface __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography;

typedef struct __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypographyVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This,
            /* [out] */ __RPC__out ULONG *iidCount,
            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Key )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This, /* [retval][out] */ __RPC__out struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasCharacterRange *key);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Value )(__RPC__in __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This, /* [retval][out] */ __RPC__deref_out_opt __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography * *value);
    END_INTERFACE
} __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypographyVtbl;

interface __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography
{
    CONST_VTBL struct __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypographyVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_get_Key(This,key)	\
    ( (This)->lpVtbl -> get_Key(This,key) ) 

#define __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_get_Value(This,value)	\
    ( (This)->lpVtbl -> get_Value(This,value) ) 
#endif /* COBJMACROS */


#endif // ____FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_INTERFACE_DEFINED__



#if !defined(____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_INTERFACE_DEFINED__)
#define ____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_INTERFACE_DEFINED__

typedef interface __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography;

typedef struct __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypographyVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Current )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This, /* [retval][out] */ __RPC__out __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * *current);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasCurrent )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *MoveNext )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *GetMany )(__RPC__in __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This,
        /* [in] */ unsigned int capacity,
        /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * *items,
        /* [retval][out] */ __RPC__out unsigned int *actual);

    END_INTERFACE
} __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypographyVtbl;

interface __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography
{
    CONST_VTBL struct __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypographyVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_get_Current(This,current)	\
    ( (This)->lpVtbl -> get_Current(This,current) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_get_HasCurrent(This,hasCurrent)	\
    ( (This)->lpVtbl -> get_HasCurrent(This,hasCurrent) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_MoveNext(This,hasCurrent)	\
    ( (This)->lpVtbl -> MoveNext(This,hasCurrent) ) 

#define __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_GetMany(This,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,capacity,items,actual) ) 

#endif /* COBJMACROS */


#endif // ____FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_INTERFACE_DEFINED__



#if !defined(____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_INTERFACE_DEFINED__)
#define ____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_INTERFACE_DEFINED__

typedef interface __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography;

typedef  struct __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypographyVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This);

    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This,
                                           /* [out] */ __RPC__out ULONG *iidCount,
                                           /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *First )(__RPC__in __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This, /* [retval][out] */ __RPC__deref_out_opt __FIIterator_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography **first);

    END_INTERFACE
} __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypographyVtbl;

interface __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography
{
    CONST_VTBL struct __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypographyVtbl *lpVtbl;
};

#ifdef COBJMACROS

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_First(This,first)	\
    ( (This)->lpVtbl -> First(This,first) ) 

#endif /* COBJMACROS */


#endif // ____FIIterable_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_INTERFACE_DEFINED__



#if !defined(____FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_INTERFACE_DEFINED__)
#define ____FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_INTERFACE_DEFINED__

typedef interface __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace;

typedef struct __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFaceVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )( __RPC__in __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This);

    ULONG ( STDMETHODCALLTYPE *Release )( __RPC__in __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )( __RPC__in __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This,
                                            /* [out] */ __RPC__out ULONG *iidCount,
                                            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
        __RPC__in __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This,
            /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
        __RPC__in __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This,
            /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *GetAt )( 
                                         __RPC__in __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This,
                                         /* [in] */ unsigned int index,
                                         /* [retval][out] */ __RPC__out __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * *item);

        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Size )( 
            __RPC__in __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This,
            /* [retval][out] */ __RPC__out unsigned int *size);

        HRESULT ( STDMETHODCALLTYPE *IndexOf )( 
                                               __RPC__in __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This,
            /* [in] */ __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * item,
            /* [out] */ __RPC__out unsigned int *index,
            /* [retval][out] */ __RPC__out boolean *found);

        HRESULT ( STDMETHODCALLTYPE *GetMany )( 
                                               __RPC__in __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * This,
            /* [in] */ unsigned int startIndex,
            /* [in] */ unsigned int capacity,
            /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * *items,
            /* [retval][out] */ __RPC__out unsigned int *actual);

        END_INTERFACE
} __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFaceVtbl;

interface __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace
{
    CONST_VTBL struct __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFaceVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_GetAt(This,index,item)	\
    ( (This)->lpVtbl -> GetAt(This,index,item) ) 

#define __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_get_Size(This,size)	\
    ( (This)->lpVtbl -> get_Size(This,size) ) 

#define __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_IndexOf(This,item,index,found)	\
    ( (This)->lpVtbl -> IndexOf(This,item,index,found) ) 

#define __FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_GetMany(This,startIndex,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,startIndex,capacity,items,actual) ) 

#endif /* COBJMACROS */



#endif // ____FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace_INTERFACE_DEFINED__



#if !defined(____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_INTERFACE_DEFINED__)
#define ____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_INTERFACE_DEFINED__

typedef interface __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi;

typedef struct __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidiVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This);

    ULONG ( STDMETHODCALLTYPE *Release )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This,
                                            /* [out] */ __RPC__out ULONG *iidCount,
                                            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This,
            /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This,
            /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *GetAt )( 
                                         __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This,
                                         /* [in] */ unsigned int index,
                                         /* [retval][out] */ __RPC__out __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * *item);

        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Size )( 
            __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This,
            /* [retval][out] */ __RPC__out unsigned int *size);

        HRESULT ( STDMETHODCALLTYPE *IndexOf )( 
                                               __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This,
            /* [in] */ __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * item,
            /* [out] */ __RPC__out unsigned int *index,
            /* [retval][out] */ __RPC__out boolean *found);

        HRESULT ( STDMETHODCALLTYPE *GetMany )( 
                                               __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * This,
            /* [in] */ unsigned int startIndex,
            /* [in] */ unsigned int capacity,
            /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * *items,
            /* [retval][out] */ __RPC__out unsigned int *actual);

        END_INTERFACE
} __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidiVtbl;

interface __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi
{
    CONST_VTBL struct __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidiVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_GetAt(This,index,item)	\
    ( (This)->lpVtbl -> GetAt(This,index,item) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_get_Size(This,size)	\
    ( (This)->lpVtbl -> get_Size(This,size) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_IndexOf(This,item,index,found)	\
    ( (This)->lpVtbl -> IndexOf(This,item,index,found) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_GetMany(This,startIndex,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,startIndex,capacity,items,actual) ) 

#endif /* COBJMACROS */



#endif // ____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi_INTERFACE_DEFINED__



#if !defined(____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_INTERFACE_DEFINED__)
#define ____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_INTERFACE_DEFINED__

typedef interface __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation;

typedef struct __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientationVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This);

    ULONG ( STDMETHODCALLTYPE *Release )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This,
                                            /* [out] */ __RPC__out ULONG *iidCount,
                                            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This,
            /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This,
            /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *GetAt )( 
                                         __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This,
                                         /* [in] */ unsigned int index,
                                         /* [retval][out] */ __RPC__out __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * *item);

        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Size )( 
            __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This,
            /* [retval][out] */ __RPC__out unsigned int *size);

        HRESULT ( STDMETHODCALLTYPE *IndexOf )( 
                                               __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This,
            /* [in] */ __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * item,
            /* [out] */ __RPC__out unsigned int *index,
            /* [retval][out] */ __RPC__out boolean *found);

        HRESULT ( STDMETHODCALLTYPE *GetMany )( 
                                               __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * This,
            /* [in] */ unsigned int startIndex,
            /* [in] */ unsigned int capacity,
            /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * *items,
            /* [retval][out] */ __RPC__out unsigned int *actual);

        END_INTERFACE
} __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientationVtbl;

interface __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation
{
    CONST_VTBL struct __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientationVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_GetAt(This,index,item)	\
    ( (This)->lpVtbl -> GetAt(This,index,item) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_get_Size(This,size)	\
    ( (This)->lpVtbl -> get_Size(This,size) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_IndexOf(This,item,index,found)	\
    ( (This)->lpVtbl -> IndexOf(This,item,index,found) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_GetMany(This,startIndex,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,startIndex,capacity,items,actual) ) 

#endif /* COBJMACROS */



#endif // ____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation_INTERFACE_DEFINED__



#if !defined(____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_INTERFACE_DEFINED__)
#define ____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_INTERFACE_DEFINED__

typedef interface __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript;

typedef struct __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScriptVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This);

    ULONG ( STDMETHODCALLTYPE *Release )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This,
                                            /* [out] */ __RPC__out ULONG *iidCount,
                                            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This,
            /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This,
            /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *GetAt )( 
                                         __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This,
                                         /* [in] */ unsigned int index,
                                         /* [retval][out] */ __RPC__out __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * *item);

        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Size )( 
            __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This,
            /* [retval][out] */ __RPC__out unsigned int *size);

        HRESULT ( STDMETHODCALLTYPE *IndexOf )( 
                                               __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This,
            /* [in] */ __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * item,
            /* [out] */ __RPC__out unsigned int *index,
            /* [retval][out] */ __RPC__out boolean *found);

        HRESULT ( STDMETHODCALLTYPE *GetMany )( 
                                               __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * This,
            /* [in] */ unsigned int startIndex,
            /* [in] */ unsigned int capacity,
            /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * *items,
            /* [retval][out] */ __RPC__out unsigned int *actual);

        END_INTERFACE
} __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScriptVtbl;

interface __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript
{
    CONST_VTBL struct __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScriptVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_GetAt(This,index,item)	\
    ( (This)->lpVtbl -> GetAt(This,index,item) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_get_Size(This,size)	\
    ( (This)->lpVtbl -> get_Size(This,size) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_IndexOf(This,item,index,found)	\
    ( (This)->lpVtbl -> IndexOf(This,item,index,found) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_GetMany(This,startIndex,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,startIndex,capacity,items,actual) ) 

#endif /* COBJMACROS */



#endif // ____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript_INTERFACE_DEFINED__



#if !defined(____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_INTERFACE_DEFINED__)
#define ____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_INTERFACE_DEFINED__

typedef interface __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution;

typedef struct __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitutionVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This);

    ULONG ( STDMETHODCALLTYPE *Release )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This,
                                            /* [out] */ __RPC__out ULONG *iidCount,
                                            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This,
            /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This,
            /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *GetAt )( 
                                         __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This,
                                         /* [in] */ unsigned int index,
                                         /* [retval][out] */ __RPC__out __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * *item);

        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Size )( 
            __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This,
            /* [retval][out] */ __RPC__out unsigned int *size);

        HRESULT ( STDMETHODCALLTYPE *IndexOf )( 
                                               __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This,
            /* [in] */ __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * item,
            /* [out] */ __RPC__out unsigned int *index,
            /* [retval][out] */ __RPC__out boolean *found);

        HRESULT ( STDMETHODCALLTYPE *GetMany )( 
                                               __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * This,
            /* [in] */ unsigned int startIndex,
            /* [in] */ unsigned int capacity,
            /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * *items,
            /* [retval][out] */ __RPC__out unsigned int *actual);

        END_INTERFACE
} __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitutionVtbl;

interface __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution
{
    CONST_VTBL struct __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitutionVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_GetAt(This,index,item)	\
    ( (This)->lpVtbl -> GetAt(This,index,item) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_get_Size(This,size)	\
    ( (This)->lpVtbl -> get_Size(This,size) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_IndexOf(This,item,index,found)	\
    ( (This)->lpVtbl -> IndexOf(This,item,index,found) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_GetMany(This,startIndex,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,startIndex,capacity,items,actual) ) 

#endif /* COBJMACROS */



#endif // ____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution_INTERFACE_DEFINED__



#if !defined(____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_INTERFACE_DEFINED__)
#define ____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_INTERFACE_DEFINED__

typedef interface __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont;

typedef struct __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFontVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This);

    ULONG ( STDMETHODCALLTYPE *Release )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This,
                                            /* [out] */ __RPC__out ULONG *iidCount,
                                            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This,
            /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This,
            /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *GetAt )( 
                                         __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This,
                                         /* [in] */ unsigned int index,
                                         /* [retval][out] */ __RPC__out __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * *item);

        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Size )( 
            __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This,
            /* [retval][out] */ __RPC__out unsigned int *size);

        HRESULT ( STDMETHODCALLTYPE *IndexOf )( 
                                               __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This,
            /* [in] */ __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * item,
            /* [out] */ __RPC__out unsigned int *index,
            /* [retval][out] */ __RPC__out boolean *found);

        HRESULT ( STDMETHODCALLTYPE *GetMany )( 
                                               __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * This,
            /* [in] */ unsigned int startIndex,
            /* [in] */ unsigned int capacity,
            /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * *items,
            /* [retval][out] */ __RPC__out unsigned int *actual);

        END_INTERFACE
} __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFontVtbl;

interface __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont
{
    CONST_VTBL struct __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFontVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_GetAt(This,index,item)	\
    ( (This)->lpVtbl -> GetAt(This,index,item) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_get_Size(This,size)	\
    ( (This)->lpVtbl -> get_Size(This,size) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_IndexOf(This,item,index,found)	\
    ( (This)->lpVtbl -> IndexOf(This,item,index,found) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_GetMany(This,startIndex,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,startIndex,capacity,items,actual) ) 

#endif /* COBJMACROS */



#endif // ____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont_INTERFACE_DEFINED__



#if !defined(____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_INTERFACE_DEFINED__)
#define ____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_INTERFACE_DEFINED__

typedef interface __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography;

typedef struct __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypographyVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This);

    ULONG ( STDMETHODCALLTYPE *Release )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )( __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This,
                                            /* [out] */ __RPC__out ULONG *iidCount,
                                            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This,
            /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
        __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This,
            /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *GetAt )( 
                                         __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This,
                                         /* [in] */ unsigned int index,
                                         /* [retval][out] */ __RPC__out __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * *item);

        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Size )( 
            __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This,
            /* [retval][out] */ __RPC__out unsigned int *size);

        HRESULT ( STDMETHODCALLTYPE *IndexOf )( 
                                               __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This,
            /* [in] */ __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * item,
            /* [out] */ __RPC__out unsigned int *index,
            /* [retval][out] */ __RPC__out boolean *found);

        HRESULT ( STDMETHODCALLTYPE *GetMany )( 
                                               __RPC__in __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * This,
            /* [in] */ unsigned int startIndex,
            /* [in] */ unsigned int capacity,
            /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) __FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * *items,
            /* [retval][out] */ __RPC__out unsigned int *actual);

        END_INTERFACE
} __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypographyVtbl;

interface __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography
{
    CONST_VTBL struct __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypographyVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_GetAt(This,index,item)	\
    ( (This)->lpVtbl -> GetAt(This,index,item) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_get_Size(This,size)	\
    ( (This)->lpVtbl -> get_Size(This,size) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_IndexOf(This,item,index,found)	\
    ( (This)->lpVtbl -> IndexOf(This,item,index,found) ) 

#define __FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_GetMany(This,startIndex,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,startIndex,capacity,items,actual) ) 

#endif /* COBJMACROS */



#endif // ____FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography_INTERFACE_DEFINED__


#if !defined(____FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__)
#define ____FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__

typedef interface __FIKeyValuePair_2_HSTRING_HSTRING __FIKeyValuePair_2_HSTRING_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIKeyValuePair_2_HSTRING_HSTRING;

typedef struct __FIKeyValuePair_2_HSTRING_HSTRINGVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIKeyValuePair_2_HSTRING_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIKeyValuePair_2_HSTRING_HSTRING * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIKeyValuePair_2_HSTRING_HSTRING * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIKeyValuePair_2_HSTRING_HSTRING * This,
            /* [out] */ __RPC__out ULONG *iidCount,
            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIKeyValuePair_2_HSTRING_HSTRING * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIKeyValuePair_2_HSTRING_HSTRING * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Key )(__RPC__in __FIKeyValuePair_2_HSTRING_HSTRING * This, /* [retval][out] */ __RPC__out HSTRING *key);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Value )(__RPC__in __FIKeyValuePair_2_HSTRING_HSTRING * This, /* [retval][out] */ __RPC__deref_out_opt HSTRING *value);
    END_INTERFACE
} __FIKeyValuePair_2_HSTRING_HSTRINGVtbl;

interface __FIKeyValuePair_2_HSTRING_HSTRING
{
    CONST_VTBL struct __FIKeyValuePair_2_HSTRING_HSTRINGVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIKeyValuePair_2_HSTRING_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIKeyValuePair_2_HSTRING_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIKeyValuePair_2_HSTRING_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIKeyValuePair_2_HSTRING_HSTRING_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIKeyValuePair_2_HSTRING_HSTRING_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIKeyValuePair_2_HSTRING_HSTRING_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIKeyValuePair_2_HSTRING_HSTRING_get_Key(This,key)	\
    ( (This)->lpVtbl -> get_Key(This,key) ) 

#define __FIKeyValuePair_2_HSTRING_HSTRING_get_Value(This,value)	\
    ( (This)->lpVtbl -> get_Value(This,value) ) 
#endif /* COBJMACROS */


#endif // ____FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__



#if !defined(____FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__)
#define ____FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__

typedef interface __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING;

typedef struct __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRINGVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Current )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This, /* [retval][out] */ __RPC__out __FIKeyValuePair_2_HSTRING_HSTRING * *current);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasCurrent )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *MoveNext )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *GetMany )(__RPC__in __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING * This,
        /* [in] */ unsigned int capacity,
        /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) __FIKeyValuePair_2_HSTRING_HSTRING * *items,
        /* [retval][out] */ __RPC__out unsigned int *actual);

    END_INTERFACE
} __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRINGVtbl;

interface __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING
{
    CONST_VTBL struct __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRINGVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_get_Current(This,current)	\
    ( (This)->lpVtbl -> get_Current(This,current) ) 

#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_get_HasCurrent(This,hasCurrent)	\
    ( (This)->lpVtbl -> get_HasCurrent(This,hasCurrent) ) 

#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_MoveNext(This,hasCurrent)	\
    ( (This)->lpVtbl -> MoveNext(This,hasCurrent) ) 

#define __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_GetMany(This,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,capacity,items,actual) ) 

#endif /* COBJMACROS */


#endif // ____FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__



#if !defined(____FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__)
#define ____FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__

typedef interface __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING;

typedef  struct __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRINGVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING * This);

    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING * This,
                                           /* [out] */ __RPC__out ULONG *iidCount,
                                           /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *First )(__RPC__in __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING * This, /* [retval][out] */ __RPC__deref_out_opt __FIIterator_1___FIKeyValuePair_2_HSTRING_HSTRING **first);

    END_INTERFACE
} __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRINGVtbl;

interface __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING
{
    CONST_VTBL struct __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRINGVtbl *lpVtbl;
};

#ifdef COBJMACROS

#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_First(This,first)	\
    ( (This)->lpVtbl -> First(This,first) ) 

#endif /* COBJMACROS */


#endif // ____FIIterable_1___FIKeyValuePair_2_HSTRING_HSTRING_INTERFACE_DEFINED__


#if !defined(____FIMapView_2_HSTRING_HSTRING_INTERFACE_DEFINED__)
#define ____FIMapView_2_HSTRING_HSTRING_INTERFACE_DEFINED__

typedef interface __FIMapView_2_HSTRING_HSTRING __FIMapView_2_HSTRING_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIMapView_2_HSTRING_HSTRING;

typedef struct __FIMapView_2_HSTRING_HSTRINGVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This);

    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This,/* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *Lookup )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This,
        /* [in] */ __RPC__in HSTRING key,
        /* [retval][out] */ __RPC__deref_out_opt HSTRING *value);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Size )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This, /* [retval][out] */ __RPC__out unsigned int *size);
    HRESULT ( STDMETHODCALLTYPE *HasKey )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This, /* [in] */ __RPC__in HSTRING key, /* [retval][out] */ __RPC__out boolean *found);
    HRESULT ( STDMETHODCALLTYPE *Split )(__RPC__in __FIMapView_2_HSTRING_HSTRING * This,/* [out] */ __RPC__deref_out_opt __FIMapView_2_HSTRING_HSTRING **firstPartition,
        /* [out] */ __RPC__deref_out_opt __FIMapView_2_HSTRING_HSTRING **secondPartition);
    END_INTERFACE
} __FIMapView_2_HSTRING_HSTRINGVtbl;

interface __FIMapView_2_HSTRING_HSTRING
{
    CONST_VTBL struct __FIMapView_2_HSTRING_HSTRINGVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIMapView_2_HSTRING_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIMapView_2_HSTRING_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIMapView_2_HSTRING_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIMapView_2_HSTRING_HSTRING_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIMapView_2_HSTRING_HSTRING_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIMapView_2_HSTRING_HSTRING_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIMapView_2_HSTRING_HSTRING_Lookup(This,key,value)	\
    ( (This)->lpVtbl -> Lookup(This,key,value) ) 
#define __FIMapView_2_HSTRING_HSTRING_get_Size(This,size)	\
    ( (This)->lpVtbl -> get_Size(This,size) ) 
#define __FIMapView_2_HSTRING_HSTRING_HasKey(This,key,found)	\
    ( (This)->lpVtbl -> HasKey(This,key,found) ) 
#define __FIMapView_2_HSTRING_HSTRING_Split(This,firstPartition,secondPartition)	\
    ( (This)->lpVtbl -> Split(This,firstPartition,secondPartition) ) 
#endif /* COBJMACROS */


#endif // ____FIMapView_2_HSTRING_HSTRING_INTERFACE_DEFINED__


#if !defined(____FIIterator_1_HSTRING_INTERFACE_DEFINED__)
#define ____FIIterator_1_HSTRING_INTERFACE_DEFINED__

typedef interface __FIIterator_1_HSTRING __FIIterator_1_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterator_1_HSTRING;

typedef struct __FIIterator_1_HSTRINGVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterator_1_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterator_1_HSTRING * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterator_1_HSTRING * This);
    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterator_1_HSTRING * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterator_1_HSTRING * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterator_1_HSTRING * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Current )(__RPC__in __FIIterator_1_HSTRING * This, /* [retval][out] */ __RPC__out HSTRING *current);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasCurrent )(__RPC__in __FIIterator_1_HSTRING * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *MoveNext )(__RPC__in __FIIterator_1_HSTRING * This, /* [retval][out] */ __RPC__out boolean *hasCurrent);
    HRESULT ( STDMETHODCALLTYPE *GetMany )(__RPC__in __FIIterator_1_HSTRING * This,
        /* [in] */ unsigned int capacity,
        /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) HSTRING *items,
        /* [retval][out] */ __RPC__out unsigned int *actual);

    END_INTERFACE
} __FIIterator_1_HSTRINGVtbl;

interface __FIIterator_1_HSTRING
{
    CONST_VTBL struct __FIIterator_1_HSTRINGVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIIterator_1_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterator_1_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterator_1_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterator_1_HSTRING_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterator_1_HSTRING_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterator_1_HSTRING_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterator_1_HSTRING_get_Current(This,current)	\
    ( (This)->lpVtbl -> get_Current(This,current) ) 

#define __FIIterator_1_HSTRING_get_HasCurrent(This,hasCurrent)	\
    ( (This)->lpVtbl -> get_HasCurrent(This,hasCurrent) ) 

#define __FIIterator_1_HSTRING_MoveNext(This,hasCurrent)	\
    ( (This)->lpVtbl -> MoveNext(This,hasCurrent) ) 

#define __FIIterator_1_HSTRING_GetMany(This,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,capacity,items,actual) ) 

#endif /* COBJMACROS */


#endif // ____FIIterator_1_HSTRING_INTERFACE_DEFINED__


#if !defined(____FIIterable_1_HSTRING_INTERFACE_DEFINED__)
#define ____FIIterable_1_HSTRING_INTERFACE_DEFINED__

typedef interface __FIIterable_1_HSTRING __FIIterable_1_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIIterable_1_HSTRING;

typedef  struct __FIIterable_1_HSTRINGVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIIterable_1_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIIterable_1_HSTRING * This);

    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIIterable_1_HSTRING * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIIterable_1_HSTRING * This,
                                           /* [out] */ __RPC__out ULONG *iidCount,
                                           /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIIterable_1_HSTRING * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIIterable_1_HSTRING * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *First )(__RPC__in __FIIterable_1_HSTRING * This, /* [retval][out] */ __RPC__deref_out_opt __FIIterator_1_HSTRING **first);

    END_INTERFACE
} __FIIterable_1_HSTRINGVtbl;

interface __FIIterable_1_HSTRING
{
    CONST_VTBL struct __FIIterable_1_HSTRINGVtbl *lpVtbl;
};

#ifdef COBJMACROS

#define __FIIterable_1_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIIterable_1_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIIterable_1_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIIterable_1_HSTRING_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIIterable_1_HSTRING_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIIterable_1_HSTRING_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIIterable_1_HSTRING_First(This,first)	\
    ( (This)->lpVtbl -> First(This,first) ) 

#endif /* COBJMACROS */


#endif // ____FIIterable_1_HSTRING_INTERFACE_DEFINED__


#if !defined(____FIVectorView_1_HSTRING_INTERFACE_DEFINED__)
#define ____FIVectorView_1_HSTRING_INTERFACE_DEFINED__

typedef interface __FIVectorView_1_HSTRING __FIVectorView_1_HSTRING;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIVectorView_1_HSTRING;

typedef struct __FIVectorView_1_HSTRINGVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
        __RPC__in __FIVectorView_1_HSTRING * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);

    ULONG ( STDMETHODCALLTYPE *AddRef )( __RPC__in __FIVectorView_1_HSTRING * This);

    ULONG ( STDMETHODCALLTYPE *Release )( __RPC__in __FIVectorView_1_HSTRING * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )( __RPC__in __FIVectorView_1_HSTRING * This,
                                            /* [out] */ __RPC__out ULONG *iidCount,
                                            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);

    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
        __RPC__in __FIVectorView_1_HSTRING * This,
            /* [out] */ __RPC__deref_out_opt HSTRING *className);

    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
        __RPC__in __FIVectorView_1_HSTRING * This,
            /* [out] */ __RPC__out TrustLevel *trustLevel);

    HRESULT ( STDMETHODCALLTYPE *GetAt )( 
                                         __RPC__in __FIVectorView_1_HSTRING * This,
                                         /* [in] */ unsigned int index,
                                         /* [retval][out] */ __RPC__out HSTRING *item);

        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Size )( 
            __RPC__in __FIVectorView_1_HSTRING * This,
            /* [retval][out] */ __RPC__out unsigned int *size);

        HRESULT ( STDMETHODCALLTYPE *IndexOf )( 
                                               __RPC__in __FIVectorView_1_HSTRING * This,
            /* [in] */ HSTRING item,
            /* [out] */ __RPC__out unsigned int *index,
            /* [retval][out] */ __RPC__out boolean *found);

        HRESULT ( STDMETHODCALLTYPE *GetMany )( 
                                               __RPC__in __FIVectorView_1_HSTRING * This,
            /* [in] */ unsigned int startIndex,
            /* [in] */ unsigned int capacity,
            /* [size_is][length_is][out] */ __RPC__out_ecount_part(capacity, *actual) HSTRING *items,
            /* [retval][out] */ __RPC__out unsigned int *actual);

        END_INTERFACE
} __FIVectorView_1_HSTRINGVtbl;

interface __FIVectorView_1_HSTRING
{
    CONST_VTBL struct __FIVectorView_1_HSTRINGVtbl *lpVtbl;
};



#ifdef COBJMACROS


#define __FIVectorView_1_HSTRING_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FIVectorView_1_HSTRING_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FIVectorView_1_HSTRING_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FIVectorView_1_HSTRING_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define __FIVectorView_1_HSTRING_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define __FIVectorView_1_HSTRING_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define __FIVectorView_1_HSTRING_GetAt(This,index,item)	\
    ( (This)->lpVtbl -> GetAt(This,index,item) ) 

#define __FIVectorView_1_HSTRING_get_Size(This,size)	\
    ( (This)->lpVtbl -> get_Size(This,size) ) 

#define __FIVectorView_1_HSTRING_IndexOf(This,item,index,found)	\
    ( (This)->lpVtbl -> IndexOf(This,item,index,found) ) 

#define __FIVectorView_1_HSTRING_GetMany(This,startIndex,capacity,items,actual)	\
    ( (This)->lpVtbl -> GetMany(This,startIndex,capacity,items,actual) ) 

#endif /* COBJMACROS */



#endif // ____FIVectorView_1_HSTRING_INTERFACE_DEFINED__



#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush __x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush_FWD_DEFINED__







typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAntialiasing __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAntialiasing;

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__


#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__


#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__





#ifndef ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CFoundation_CIClosable __x_ABI_CWindows_CFoundation_CIClosable;

#endif // ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__





typedef struct __x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 __x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2;


typedef struct __x_ABI_CWindows_CFoundation_CNumerics_CVector2 __x_ABI_CWindows_CFoundation_CNumerics_CVector2;





typedef struct __x_ABI_CWindows_CFoundation_CRect __x_ABI_CWindows_CFoundation_CRect;


typedef struct __x_ABI_CWindows_CFoundation_CSize __x_ABI_CWindows_CFoundation_CSize;

#ifndef ____x_ABI_CWindows_CFoundation_CIUriRuntimeClass_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIUriRuntimeClass_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CFoundation_CIUriRuntimeClass __x_ABI_CWindows_CFoundation_CIUriRuntimeClass;

#endif // ____x_ABI_CWindows_CFoundation_CIUriRuntimeClass_FWD_DEFINED__





typedef struct __x_ABI_CWindows_CUI_CColor __x_ABI_CWindows_CUI_CColor;




typedef enum __x_ABI_CWindows_CUI_CText_CFontStretch __x_ABI_CWindows_CUI_CText_CFontStretch;


typedef enum __x_ABI_CWindows_CUI_CText_CFontStyle __x_ABI_CWindows_CUI_CText_CFontStyle;


typedef struct __x_ABI_CWindows_CUI_CText_CFontWeight __x_ABI_CWindows_CUI_CText_CFontWeight;





typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasClusterProperties __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasClusterProperties;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasDrawTextOptions __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasDrawTextOptions;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontFileFormatType __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontFileFormatType;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontInformation __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontInformation;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontPropertyIdentifier __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontPropertyIdentifier;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontSimulations __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontSimulations;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphJustification __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphJustification;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphOrientation __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphOrientation;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasHorizontalAlignment __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasHorizontalAlignment;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineBreakCondition __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineBreakCondition;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineSpacingMode __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineSpacingMode;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasNumberSubstitutionMethod __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasNumberSubstitutionMethod;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasOpticalAlignment __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasOpticalAlignment;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasScriptShape __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasScriptShape;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextAntialiasing __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextAntialiasing;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextDirection __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextDirection;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextGridFit __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextGridFit;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextMeasuringMode __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextMeasuringMode;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextRenderingMode __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextRenderingMode;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextTrimmingGranularity __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextTrimmingGranularity;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTrimmingSign __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTrimmingSign;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTypographyFeatureName __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTypographyFeatureName;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasVerticalAlignment __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasVerticalAlignment;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasVerticalGlyphOrientation __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasVerticalGlyphOrientation;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasWordWrapping __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasWordWrapping;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedBidi __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedBidi;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedBreakpoint __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedBreakpoint;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedGlyphOrientation __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedGlyphOrientation;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedScript __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedScript;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasCharacterRange __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasCharacterRange;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasClusterMetrics __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasClusterMetrics;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontProperty __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontProperty;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphMetrics __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphMetrics;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphShaping __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphShaping;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasJustificationOpportunity __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasJustificationOpportunity;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineMetrics __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineMetrics;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasScriptProperties __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasScriptProperties;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextLayoutRegion __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextLayoutRegion;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTypographyFeature __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTypographyFeature;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasUnicodeRange __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasUnicodeRange;








































/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasClusterProperties
 *
 */

/* [v1_enum, version, flags] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasClusterProperties
{
    CanvasClusterProperties_None = 0,
    CanvasClusterProperties_CanWrapLineAfter = 0x1,
    CanvasClusterProperties_Whitespace = 0x2,
    CanvasClusterProperties_Newline = 0x4,
    CanvasClusterProperties_SoftHyphen = 0x8,
    CanvasClusterProperties_RightToLeft = 0x10,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasDrawTextOptions
 *
 */

/* [v1_enum, version, flags] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasDrawTextOptions
{
    CanvasDrawTextOptions_Default = 0,
    CanvasDrawTextOptions_NoPixelSnap = 0x1,
    CanvasDrawTextOptions_Clip = 0x2,
    CanvasDrawTextOptions_EnableColorFont = 0x4,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasFontFileFormatType
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontFileFormatType
{
    CanvasFontFileFormatType_Cff = 0,
    CanvasFontFileFormatType_TrueType = 1,
    CanvasFontFileFormatType_TrueTypeCollection = 2,
    CanvasFontFileFormatType_Type1 = 3,
    CanvasFontFileFormatType_Vector = 4,
    CanvasFontFileFormatType_Bitmap = 5,
    CanvasFontFileFormatType_Unknown = 6,
    CanvasFontFileFormatType_RawCff = 7,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasFontInformation
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontInformation
{
    CanvasFontInformation_None = 0,
    CanvasFontInformation_CopyrightNotice = 1,
    CanvasFontInformation_VersionStrings = 2,
    CanvasFontInformation_Trademark = 3,
    CanvasFontInformation_Manufacturer = 4,
    CanvasFontInformation_Designer = 5,
    CanvasFontInformation_DesignerUrl = 6,
    CanvasFontInformation_Description = 7,
    CanvasFontInformation_FontVendorUrl = 8,
    CanvasFontInformation_LicenseDescription = 9,
    CanvasFontInformation_LicenseInfoUrl = 10,
    CanvasFontInformation_Win32FamilyNames = 11,
    CanvasFontInformation_Win32SubfamilyNames = 12,
    CanvasFontInformation_PreferredFamilyNames = 13,
    CanvasFontInformation_PreferredSubfamilyNames = 14,
    CanvasFontInformation_SampleText = 15,
    CanvasFontInformation_FullName = 16,
    CanvasFontInformation_PostscriptName = 17,
    CanvasFontInformation_PostscriptCidName = 18,
    CanvasFontInformation_WwsFamilyName = 19,
    CanvasFontInformation_DesignScriptLanguageTag = 20,
    CanvasFontInformation_SupportedScriptLanguageTag = 21,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasFontPropertyIdentifier
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontPropertyIdentifier
{
    CanvasFontPropertyIdentifier_None = 0,
    CanvasFontPropertyIdentifier_FamilyName = 1,
    CanvasFontPropertyIdentifier_PreferredFamilyName = 2,
    CanvasFontPropertyIdentifier_FaceName = 3,
    CanvasFontPropertyIdentifier_FullName = 4,
    CanvasFontPropertyIdentifier_Win32FamilyName = 5,
    CanvasFontPropertyIdentifier_PostscriptName = 6,
    CanvasFontPropertyIdentifier_DesignScriptLanguageTag = 7,
    CanvasFontPropertyIdentifier_SupportedScriptLanguageTag = 8,
    CanvasFontPropertyIdentifier_SemanticTag = 9,
    CanvasFontPropertyIdentifier_Weight = 10,
    CanvasFontPropertyIdentifier_Stretch = 11,
    CanvasFontPropertyIdentifier_Style = 12,
    CanvasFontPropertyIdentifier_Total = 13,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasFontSimulations
 *
 */

/* [v1_enum, version, flags] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontSimulations
{
    CanvasFontSimulations_None = 0,
    CanvasFontSimulations_Bold = 0x1,
    CanvasFontSimulations_Oblique = 0x2,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasGlyphJustification
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphJustification
{
    CanvasGlyphJustification_None = 0,
    CanvasGlyphJustification_ArabicBlank = 1,
    CanvasGlyphJustification_Character = 2,
    CanvasGlyphJustification_Blank = 4,
    CanvasGlyphJustification_ArabicNormal = 7,
    CanvasGlyphJustification_ArabicKashida = 8,
    CanvasGlyphJustification_ArabicAlef = 9,
    CanvasGlyphJustification_ArabicHa = 10,
    CanvasGlyphJustification_ArabicRa = 11,
    CanvasGlyphJustification_ArabicBa = 12,
    CanvasGlyphJustification_ArabicBara = 13,
    CanvasGlyphJustification_ArabicSeen = 14,
    CanvasGlyphJustification_ArabicSeenM = 15,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasGlyphOrientation
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphOrientation
{
    CanvasGlyphOrientation_Upright = 0,
    CanvasGlyphOrientation_Clockwise90Degrees = 1,
    CanvasGlyphOrientation_Clockwise180Degrees = 2,
    CanvasGlyphOrientation_Clockwise270Degrees = 3,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasHorizontalAlignment
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasHorizontalAlignment
{
    CanvasHorizontalAlignment_Left = 0,
    CanvasHorizontalAlignment_Right = 1,
    CanvasHorizontalAlignment_Center = 2,
    CanvasHorizontalAlignment_Justified = 3,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasLineBreakCondition
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineBreakCondition
{
    CanvasLineBreakCondition_Neutral = 0,
    CanvasLineBreakCondition_CanBreak = 1,
    CanvasLineBreakCondition_CannotBreak = 2,
    CanvasLineBreakCondition_MustBreak = 3,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasLineSpacingMode
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineSpacingMode
{
    CanvasLineSpacingMode_Default = 0,
    CanvasLineSpacingMode_Uniform = 1,
    CanvasLineSpacingMode_Proportional = 2,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasNumberSubstitutionMethod
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasNumberSubstitutionMethod
{
    CanvasNumberSubstitutionMethod_FromCulture = 0,
    CanvasNumberSubstitutionMethod_Contextual = 1,
    CanvasNumberSubstitutionMethod_Disabled = 2,
    CanvasNumberSubstitutionMethod_National = 3,
    CanvasNumberSubstitutionMethod_Traditional = 4,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasOpticalAlignment
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasOpticalAlignment
{
    CanvasOpticalAlignment_Default = 0,
    CanvasOpticalAlignment_NoSideBearings = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasScriptShape
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasScriptShape
{
    CanvasScriptShape_Default = 0,
    CanvasScriptShape_NoVisual = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTextAntialiasing
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextAntialiasing
{
    CanvasTextAntialiasing_Auto = 0,
    CanvasTextAntialiasing_ClearType = 1,
    CanvasTextAntialiasing_Grayscale = 2,
    CanvasTextAntialiasing_Aliased = 3,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTextDirection
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextDirection
{
    CanvasTextDirection_LeftToRightThenTopToBottom = 0,
    CanvasTextDirection_RightToLeftThenTopToBottom = 1,
    CanvasTextDirection_LeftToRightThenBottomToTop = 2,
    CanvasTextDirection_RightToLeftThenBottomToTop = 3,
    CanvasTextDirection_TopToBottomThenLeftToRight = 4,
    CanvasTextDirection_BottomToTopThenLeftToRight = 5,
    CanvasTextDirection_TopToBottomThenRightToLeft = 6,
    CanvasTextDirection_BottomToTopThenRightToLeft = 7,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTextGridFit
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextGridFit
{
    CanvasTextGridFit_Default = 0,
    CanvasTextGridFit_Disable = 1,
    CanvasTextGridFit_Enable = 2,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTextMeasuringMode
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextMeasuringMode
{
    CanvasTextMeasuringMode_Natural = 0,
    CanvasTextMeasuringMode_GdiClassic = 1,
    CanvasTextMeasuringMode_GdiNatural = 2,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTextRenderingMode
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextRenderingMode
{
    CanvasTextRenderingMode_Default = 0,
    CanvasTextRenderingMode_Aliased = 1,
    CanvasTextRenderingMode_GdiClassic = 2,
    CanvasTextRenderingMode_GdiNatural = 3,
    CanvasTextRenderingMode_Natural = 4,
    CanvasTextRenderingMode_NaturalSymmetric = 5,
    CanvasTextRenderingMode_Outline = 6,
    CanvasTextRenderingMode_NaturalSymmetricDownsampled = 7,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTextTrimmingGranularity
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextTrimmingGranularity
{
    CanvasTextTrimmingGranularity_None = 0,
    CanvasTextTrimmingGranularity_Character = 1,
    CanvasTextTrimmingGranularity_Word = 2,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTrimmingSign
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTrimmingSign
{
    CanvasTrimmingSign_None = 0,
    CanvasTrimmingSign_Ellipsis = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTypographyFeatureName
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTypographyFeatureName
{
    CanvasTypographyFeatureName_None = 0,
    CanvasTypographyFeatureName_Default = 1953261156,
    CanvasTypographyFeatureName_VerticalWriting = 1953654134,
    CanvasTypographyFeatureName_VerticalAlternatesAndRotation = 846492278,
    CanvasTypographyFeatureName_AlternativeFractions = 1668441697,
    CanvasTypographyFeatureName_PetiteCapitalsFromCapitals = 1668297315,
    CanvasTypographyFeatureName_SmallCapitalsFromCapitals = 1668493923,
    CanvasTypographyFeatureName_ContextualAlternates = 1953259875,
    CanvasTypographyFeatureName_CaseSensitiveForms = 1702060387,
    CanvasTypographyFeatureName_GlyphCompositionDecomposition = 1886217059,
    CanvasTypographyFeatureName_ContextualLigatures = 1734962275,
    CanvasTypographyFeatureName_CapitalSpacing = 1886613603,
    CanvasTypographyFeatureName_ContextualSwash = 1752658787,
    CanvasTypographyFeatureName_CursivePositioning = 1936880995,
    CanvasTypographyFeatureName_DiscretionaryLigatures = 1734962276,
    CanvasTypographyFeatureName_ExpertForms = 1953527909,
    CanvasTypographyFeatureName_Fractions = 1667330662,
    CanvasTypographyFeatureName_FullWidth = 1684633446,
    CanvasTypographyFeatureName_HalfForms = 1718378856,
    CanvasTypographyFeatureName_HalantForms = 1852596584,
    CanvasTypographyFeatureName_AlternateHalfWidth = 1953259880,
    CanvasTypographyFeatureName_HistoricalForms = 1953720680,
    CanvasTypographyFeatureName_HorizontalKanaAlternates = 1634626408,
    CanvasTypographyFeatureName_HistoricalLigatures = 1734962280,
    CanvasTypographyFeatureName_HalfWidth = 1684633448,
    CanvasTypographyFeatureName_HojoKanjiForms = 1869246312,
    CanvasTypographyFeatureName_Jis04Forms = 875589738,
    CanvasTypographyFeatureName_Jis78Forms = 943157354,
    CanvasTypographyFeatureName_Jis83Forms = 859336810,
    CanvasTypographyFeatureName_Jis90Forms = 809070698,
    CanvasTypographyFeatureName_Kerning = 1852990827,
    CanvasTypographyFeatureName_StandardLigatures = 1634167148,
    CanvasTypographyFeatureName_LiningFigures = 1836412524,
    CanvasTypographyFeatureName_LocalizedForms = 1818455916,
    CanvasTypographyFeatureName_MarkPositioning = 1802658157,
    CanvasTypographyFeatureName_MathematicalGreek = 1802659693,
    CanvasTypographyFeatureName_MarkToMarkPositioning = 1802333037,
    CanvasTypographyFeatureName_AlternateAnnotationForms = 1953259886,
    CanvasTypographyFeatureName_NlcKanjiForms = 1801677934,
    CanvasTypographyFeatureName_OldStyleFigures = 1836412527,
    CanvasTypographyFeatureName_Ordinals = 1852076655,
    CanvasTypographyFeatureName_ProportionalAlternateWidth = 1953259888,
    CanvasTypographyFeatureName_PetiteCapitals = 1885430640,
    CanvasTypographyFeatureName_ProportionalFigures = 1836412528,
    CanvasTypographyFeatureName_ProportionalWidths = 1684633456,
    CanvasTypographyFeatureName_QuarterWidths = 1684633457,
    CanvasTypographyFeatureName_RequiredLigatures = 1734962290,
    CanvasTypographyFeatureName_RubyNotationForms = 2036495730,
    CanvasTypographyFeatureName_StylisticAlternates = 1953259891,
    CanvasTypographyFeatureName_ScientificInferiors = 1718511987,
    CanvasTypographyFeatureName_SmallCapitals = 1885564275,
    CanvasTypographyFeatureName_SimplifiedForms = 1819307379,
    CanvasTypographyFeatureName_StylisticSet1 = 825258867,
    CanvasTypographyFeatureName_StylisticSet2 = 842036083,
    CanvasTypographyFeatureName_StylisticSet3 = 858813299,
    CanvasTypographyFeatureName_StylisticSet4 = 875590515,
    CanvasTypographyFeatureName_StylisticSet5 = 892367731,
    CanvasTypographyFeatureName_StylisticSet6 = 909144947,
    CanvasTypographyFeatureName_StylisticSet7 = 925922163,
    CanvasTypographyFeatureName_StylisticSet8 = 942699379,
    CanvasTypographyFeatureName_StylisticSet9 = 959476595,
    CanvasTypographyFeatureName_StylisticSet10 = 808547187,
    CanvasTypographyFeatureName_StylisticSet11 = 825324403,
    CanvasTypographyFeatureName_StylisticSet12 = 842101619,
    CanvasTypographyFeatureName_StylisticSet13 = 858878835,
    CanvasTypographyFeatureName_StylisticSet14 = 875656051,
    CanvasTypographyFeatureName_StylisticSet15 = 892433267,
    CanvasTypographyFeatureName_StylisticSet16 = 909210483,
    CanvasTypographyFeatureName_StylisticSet17 = 925987699,
    CanvasTypographyFeatureName_StylisticSet18 = 942764915,
    CanvasTypographyFeatureName_StylisticSet19 = 959542131,
    CanvasTypographyFeatureName_StylisticSet20 = 808612723,
    CanvasTypographyFeatureName_Subscript = 1935832435,
    CanvasTypographyFeatureName_Superscript = 1936749939,
    CanvasTypographyFeatureName_Swash = 1752397683,
    CanvasTypographyFeatureName_Titling = 1819568500,
    CanvasTypographyFeatureName_TraditionalNameForms = 1835101812,
    CanvasTypographyFeatureName_TabularFigures = 1836412532,
    CanvasTypographyFeatureName_TraditionalForms = 1684107892,
    CanvasTypographyFeatureName_ThirdWidths = 1684633460,
    CanvasTypographyFeatureName_Unicase = 1667853941,
    CanvasTypographyFeatureName_SlashedZero = 1869768058,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasVerticalAlignment
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasVerticalAlignment
{
    CanvasVerticalAlignment_Top = 0,
    CanvasVerticalAlignment_Bottom = 1,
    CanvasVerticalAlignment_Center = 2,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasVerticalGlyphOrientation
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasVerticalGlyphOrientation
{
    CanvasVerticalGlyphOrientation_Default = 0,
    CanvasVerticalGlyphOrientation_Stacked = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasWordWrapping
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasWordWrapping
{
    CanvasWordWrapping_Wrap = 0,
    CanvasWordWrapping_NoWrap = 1,
    CanvasWordWrapping_EmergencyBreak = 2,
    CanvasWordWrapping_WholeWord = 3,
    CanvasWordWrapping_Character = 4,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasAnalyzedBidi
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedBidi
{
    UINT32 ExplicitLevel;
    UINT32 ResolvedLevel;
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasAnalyzedBreakpoint
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedBreakpoint
{
    __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineBreakCondition BreakBefore;
    __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineBreakCondition BreakAfter;
    boolean IsWhitespace;
    boolean IsSoftHyphen;
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasAnalyzedGlyphOrientation
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedGlyphOrientation
{
    __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphOrientation GlyphOrientation;
    UINT32 AdjustedBidiLevel;
    boolean IsSideways;
    boolean IsRightToLeft;
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasAnalyzedScript
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedScript
{
    INT32 ScriptIdentifier;
    __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasScriptShape Shape;
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasCharacterRange
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasCharacterRange
{
    INT32 CharacterIndex;
    INT32 CharacterCount;
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasClusterMetrics
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasClusterMetrics
{
    INT32 CharacterCount;
    FLOAT Width;
    __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasClusterProperties Properties;
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasFontProperty
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontProperty
{
    __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontPropertyIdentifier Identifier;
    HSTRING Value;
    HSTRING Locale;
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasGlyph
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph
{
    INT32 Index;
    FLOAT Advance;
    FLOAT AdvanceOffset;
    FLOAT AscenderOffset;
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasGlyphMetrics
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphMetrics
{
    FLOAT LeftSideBearing;
    FLOAT AdvanceWidth;
    FLOAT RightSideBearing;
    FLOAT TopSideBearing;
    FLOAT AdvanceHeight;
    FLOAT BottomSideBearing;
    FLOAT VerticalOrigin;
    __x_ABI_CWindows_CFoundation_CRect DrawBounds;
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasGlyphShaping
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphShaping
{
    __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphJustification Justification;
    boolean IsClusterStart;
    boolean IsDiacritic;
    boolean IsZeroWidthSpace;
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasJustificationOpportunity
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasJustificationOpportunity
{
    FLOAT ExpansionMinimum;
    FLOAT ExpansionMaximum;
    FLOAT CompressionMaximum;
    BYTE ExpansionPriority;
    BYTE CompressionPriority;
    boolean AllowResidualExpansion;
    boolean AllowResidualCompression;
    boolean ApplyToLeadingEdge;
    boolean ApplyToTrailingEdge;
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasLineMetrics
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineMetrics
{
    INT32 CharacterCount;
    INT32 TrailingWhitespaceCount;
    INT32 TerminalNewlineCount;
    FLOAT Height;
    FLOAT Baseline;
    boolean IsTrimmed;
    FLOAT LeadingWhitespaceBefore;
    FLOAT LeadingWhitespaceAfter;
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasScriptProperties
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasScriptProperties
{
    HSTRING IsoScriptCode;
    INT32 IsoScriptNumber;
    INT32 ClusterLookahead;
    HSTRING JustificationCharacter;
    boolean RestrictCaretToClusters;
    boolean UsesWordDividers;
    boolean IsDiscreteWriting;
    boolean IsBlockWriting;
    boolean IsDistributedWithinCluster;
    boolean IsConnectedWriting;
    boolean IsCursiveWriting;
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTextLayoutRegion
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextLayoutRegion
{
    INT32 CharacterIndex;
    INT32 CharacterCount;
    __x_ABI_CWindows_CFoundation_CRect LayoutBounds;
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasTypographyFeature
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTypographyFeature
{
    __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTypographyFeatureName Name;
    UINT32 Parameter;
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Text.CanvasUnicodeRange
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasUnicodeRange
{
    UINT32 First;
    UINT32 Last;
};


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasFontFace
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasFontFace
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasFontFace[] = L"Microsoft.Graphics.Canvas.Text.ICanvasFontFace";
/* [object, version, uuid("5199D129-4EF9-4DEE-B74C-4DC910201A7F"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFaceVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload] */HRESULT ( STDMETHODCALLTYPE *GetRecommendedRenderingMode )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [in] */FLOAT fontSize,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextMeasuringMode measuringMode,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters * renderingParameters,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextRenderingMode * renderingMode
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetRecommendedRenderingModeWithAllOptions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [in] */FLOAT fontSize,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextMeasuringMode measuringMode,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters * renderingParameters,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */boolean isSideways,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAntialiasing outlineThreshold,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextRenderingMode * renderingMode
        );
    HRESULT ( STDMETHODCALLTYPE *GetRecommendedGridFit )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [in] */FLOAT fontSize,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextMeasuringMode measuringMode,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters * renderingParameters,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */boolean isSideways,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAntialiasing outlineThreshold,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextGridFit * gridFit
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_GlyphBox )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_SubscriptPosition )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_SubscriptSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CSize * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_SuperscriptPosition )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_SuperscriptSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CSize * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_HasTypographicMetrics )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */boolean * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Ascent )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Descent )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LineGap )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_CapHeight )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LowercaseLetterHeight )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_UnderlinePosition )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_UnderlineThickness )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_StrikethroughPosition )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_StrikethroughThickness )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_CaretSlopeRise )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_CaretSlopeRun )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_CaretOffset )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_UnicodeRanges )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasUnicodeRange * * valueElements
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_IsMonospaced )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */boolean * value
        );
    HRESULT ( STDMETHODCALLTYPE *GetVerticalGlyphVariants )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [in] */UINT32 __inputElementsSize,
        /* [size_is(__inputElementsSize), in] */INT32 * inputElements,
        /* [out] */UINT32 * __outputElementsSize,
        /* [size_is(, *(__outputElementsSize)), retval, out] */INT32 * * outputElements
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_HasVerticalGlyphVariants )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */boolean * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FileFormatType )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontFileFormatType * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Simulations )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontSimulations * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_IsSymbolFont )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */boolean * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_GlyphCount )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */UINT32 * value
        );
    HRESULT ( STDMETHODCALLTYPE *GetGlyphIndices )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [in] */UINT32 __inputElementsSize,
        /* [size_is(__inputElementsSize), in] */UINT32 * inputElements,
        /* [out] */UINT32 * __outputElementsSize,
        /* [size_is(, *(__outputElementsSize)), retval, out] */INT32 * * outputElements
        );
    HRESULT ( STDMETHODCALLTYPE *GetGlyphMetrics )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [in] */UINT32 __inputElementsSize,
        /* [size_is(__inputElementsSize), in] */INT32 * inputElements,
        /* [in] */boolean isSideways,
        /* [out] */UINT32 * __outputElementsSize,
        /* [size_is(, *(__outputElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphMetrics * * outputElements
        );
    HRESULT ( STDMETHODCALLTYPE *GetGdiCompatibleGlyphMetrics )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [in] */FLOAT fontSize,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */boolean useGdiNatural,
        /* [in] */UINT32 __inputElementsSize,
        /* [size_is(__inputElementsSize), in] */INT32 * inputElements,
        /* [in] */boolean isSideways,
        /* [out] */UINT32 * __outputElementsSize,
        /* [size_is(, *(__outputElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphMetrics * * outputElements
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Weight )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */__x_ABI_CWindows_CUI_CText_CFontWeight * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Stretch )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */__x_ABI_CWindows_CUI_CText_CFontStretch * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Style )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */__x_ABI_CWindows_CUI_CText_CFontStyle * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FamilyNames )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */__FIMapView_2_HSTRING_HSTRING * * values
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FaceNames )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [retval, out] */__FIMapView_2_HSTRING_HSTRING * * values
        );
    HRESULT ( STDMETHODCALLTYPE *GetInformationalStrings )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontInformation fontInformation,
        /* [retval, out] */__FIMapView_2_HSTRING_HSTRING * * values
        );
    HRESULT ( STDMETHODCALLTYPE *HasCharacter )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [in] */UINT32 unicodeValue,
        /* [retval, out] */boolean * value
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetGlyphRunBounds )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * drawingSession,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */FLOAT fontSize,
        /* [in] */UINT32 __glyphsSize,
        /* [size_is(__glyphsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * glyphs,
        /* [in] */boolean isSideways,
        /* [in] */UINT32 bidiLevel,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * bounds
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetGlyphRunBoundsWithMeasuringMode )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * drawingSession,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */FLOAT fontSize,
        /* [in] */UINT32 __glyphsSize,
        /* [size_is(__glyphsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * glyphs,
        /* [in] */boolean isSideways,
        /* [in] */UINT32 bidiLevel,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextMeasuringMode measuringMode,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * bounds
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Panose )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */BYTE * * valueElements
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetSupportedTypographicFeatureNames )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedScript script,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTypographyFeatureName * * valueElements
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetSupportedTypographicFeatureNamesWithLocale )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedScript script,
        /* [in] */HSTRING locale,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTypographyFeatureName * * valueElements
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetTypographicFeatureGlyphSupport )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedScript script,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTypographyFeatureName typographicFeatureName,
        /* [in] */UINT32 __glyphsElementsSize,
        /* [size_is(__glyphsElementsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * glyphsElements,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */boolean * * valueElements
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetTypographicFeatureGlyphSupportWithLocale )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedScript script,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTypographyFeatureName typographicFeatureName,
        /* [in] */UINT32 __glyphsElementsSize,
        /* [size_is(__glyphsElementsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * glyphsElements,
        /* [in] */HSTRING locale,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */boolean * * valueElements
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFaceVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFaceVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_GetRecommendedRenderingMode(This,fontSize,dpi,measuringMode,renderingParameters,renderingMode) \
    ( (This)->lpVtbl->GetRecommendedRenderingMode(This,fontSize,dpi,measuringMode,renderingParameters,renderingMode) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_GetRecommendedRenderingModeWithAllOptions(This,fontSize,dpi,measuringMode,renderingParameters,transform,isSideways,outlineThreshold,renderingMode) \
    ( (This)->lpVtbl->GetRecommendedRenderingModeWithAllOptions(This,fontSize,dpi,measuringMode,renderingParameters,transform,isSideways,outlineThreshold,renderingMode) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_GetRecommendedGridFit(This,fontSize,dpi,measuringMode,renderingParameters,transform,isSideways,outlineThreshold,gridFit) \
    ( (This)->lpVtbl->GetRecommendedGridFit(This,fontSize,dpi,measuringMode,renderingParameters,transform,isSideways,outlineThreshold,gridFit) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_GlyphBox(This,value) \
    ( (This)->lpVtbl->get_GlyphBox(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_SubscriptPosition(This,value) \
    ( (This)->lpVtbl->get_SubscriptPosition(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_SubscriptSize(This,value) \
    ( (This)->lpVtbl->get_SubscriptSize(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_SuperscriptPosition(This,value) \
    ( (This)->lpVtbl->get_SuperscriptPosition(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_SuperscriptSize(This,value) \
    ( (This)->lpVtbl->get_SuperscriptSize(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_HasTypographicMetrics(This,value) \
    ( (This)->lpVtbl->get_HasTypographicMetrics(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_Ascent(This,value) \
    ( (This)->lpVtbl->get_Ascent(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_Descent(This,value) \
    ( (This)->lpVtbl->get_Descent(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_LineGap(This,value) \
    ( (This)->lpVtbl->get_LineGap(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_CapHeight(This,value) \
    ( (This)->lpVtbl->get_CapHeight(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_LowercaseLetterHeight(This,value) \
    ( (This)->lpVtbl->get_LowercaseLetterHeight(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_UnderlinePosition(This,value) \
    ( (This)->lpVtbl->get_UnderlinePosition(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_UnderlineThickness(This,value) \
    ( (This)->lpVtbl->get_UnderlineThickness(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_StrikethroughPosition(This,value) \
    ( (This)->lpVtbl->get_StrikethroughPosition(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_StrikethroughThickness(This,value) \
    ( (This)->lpVtbl->get_StrikethroughThickness(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_CaretSlopeRise(This,value) \
    ( (This)->lpVtbl->get_CaretSlopeRise(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_CaretSlopeRun(This,value) \
    ( (This)->lpVtbl->get_CaretSlopeRun(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_CaretOffset(This,value) \
    ( (This)->lpVtbl->get_CaretOffset(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_UnicodeRanges(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->get_UnicodeRanges(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_IsMonospaced(This,value) \
    ( (This)->lpVtbl->get_IsMonospaced(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_GetVerticalGlyphVariants(This,__inputElementsSize,inputElements,__outputElementsSize,outputElements) \
    ( (This)->lpVtbl->GetVerticalGlyphVariants(This,__inputElementsSize,inputElements,__outputElementsSize,outputElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_HasVerticalGlyphVariants(This,value) \
    ( (This)->lpVtbl->get_HasVerticalGlyphVariants(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_FileFormatType(This,value) \
    ( (This)->lpVtbl->get_FileFormatType(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_Simulations(This,value) \
    ( (This)->lpVtbl->get_Simulations(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_IsSymbolFont(This,value) \
    ( (This)->lpVtbl->get_IsSymbolFont(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_GlyphCount(This,value) \
    ( (This)->lpVtbl->get_GlyphCount(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_GetGlyphIndices(This,__inputElementsSize,inputElements,__outputElementsSize,outputElements) \
    ( (This)->lpVtbl->GetGlyphIndices(This,__inputElementsSize,inputElements,__outputElementsSize,outputElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_GetGlyphMetrics(This,__inputElementsSize,inputElements,isSideways,__outputElementsSize,outputElements) \
    ( (This)->lpVtbl->GetGlyphMetrics(This,__inputElementsSize,inputElements,isSideways,__outputElementsSize,outputElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_GetGdiCompatibleGlyphMetrics(This,fontSize,dpi,transform,useGdiNatural,__inputElementsSize,inputElements,isSideways,__outputElementsSize,outputElements) \
    ( (This)->lpVtbl->GetGdiCompatibleGlyphMetrics(This,fontSize,dpi,transform,useGdiNatural,__inputElementsSize,inputElements,isSideways,__outputElementsSize,outputElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_Weight(This,value) \
    ( (This)->lpVtbl->get_Weight(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_Stretch(This,value) \
    ( (This)->lpVtbl->get_Stretch(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_Style(This,value) \
    ( (This)->lpVtbl->get_Style(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_FamilyNames(This,values) \
    ( (This)->lpVtbl->get_FamilyNames(This,values) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_FaceNames(This,values) \
    ( (This)->lpVtbl->get_FaceNames(This,values) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_GetInformationalStrings(This,fontInformation,values) \
    ( (This)->lpVtbl->GetInformationalStrings(This,fontInformation,values) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_HasCharacter(This,unicodeValue,value) \
    ( (This)->lpVtbl->HasCharacter(This,unicodeValue,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_GetGlyphRunBounds(This,drawingSession,point,fontSize,__glyphsSize,glyphs,isSideways,bidiLevel,bounds) \
    ( (This)->lpVtbl->GetGlyphRunBounds(This,drawingSession,point,fontSize,__glyphsSize,glyphs,isSideways,bidiLevel,bounds) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_GetGlyphRunBoundsWithMeasuringMode(This,drawingSession,point,fontSize,__glyphsSize,glyphs,isSideways,bidiLevel,measuringMode,bounds) \
    ( (This)->lpVtbl->GetGlyphRunBoundsWithMeasuringMode(This,drawingSession,point,fontSize,__glyphsSize,glyphs,isSideways,bidiLevel,measuringMode,bounds) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_get_Panose(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->get_Panose(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_GetSupportedTypographicFeatureNames(This,script,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetSupportedTypographicFeatureNames(This,script,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_GetSupportedTypographicFeatureNamesWithLocale(This,script,locale,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetSupportedTypographicFeatureNamesWithLocale(This,script,locale,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_GetTypographicFeatureGlyphSupport(This,script,typographicFeatureName,__glyphsElementsSize,glyphsElements,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetTypographicFeatureGlyphSupport(This,script,typographicFeatureName,__glyphsElementsSize,glyphsElements,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_GetTypographicFeatureGlyphSupportWithLocale(This,script,typographicFeatureName,__glyphsElementsSize,glyphsElements,locale,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetTypographicFeatureGlyphSupportWithLocale(This,script,typographicFeatureName,__glyphsElementsSize,glyphsElements,locale,__valueElementsSize,valueElements) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasFontSet
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasFontSet
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasFontSet[] = L"Microsoft.Graphics.Canvas.Text.ICanvasFontSet";
/* [object, version, uuid("0A5BFB92-1F3C-459F-9D7E-A6289DD093C0"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Fonts )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * This,
        /* [retval, out] */__FIVectorView_1_Microsoft__CGraphics__CCanvas__CText__CCanvasFontFace * * value
        );
    HRESULT ( STDMETHODCALLTYPE *TryFindFontFace )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * fontFace,
        /* [out] */INT32 * index,
        /* [retval, out] */boolean * succeeded
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetMatchingFontsFromProperties )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * This,
        /* [in] */UINT32 __propertyElementsSize,
        /* [size_is(__propertyElementsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontProperty * propertyElements,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * * matchingFonts
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetMatchingFontsFromWwsFamily )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * This,
        /* [in] */HSTRING familyName,
        /* [in] */__x_ABI_CWindows_CUI_CText_CFontWeight weight,
        /* [in] */__x_ABI_CWindows_CUI_CText_CFontStretch stretch,
        /* [in] */__x_ABI_CWindows_CUI_CText_CFontStyle style,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * * matchingFonts
        );
    HRESULT ( STDMETHODCALLTYPE *CountFontsMatchingProperty )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontProperty property,
        /* [retval, out] */UINT32 * count
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *GetPropertyValuesFromIndex )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * This,
        /* [in] */UINT32 fontIndex,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontPropertyIdentifier propertyIdentifier,
        /* [retval, out] */__FIMapView_2_HSTRING_HSTRING * * values
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetPropertyValuesFromIdentifier )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontPropertyIdentifier propertyIdentifier,
        /* [in] */HSTRING preferredLocaleNames,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontProperty * * valueElements
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetPropertyValues )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontPropertyIdentifier propertyIdentifier,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasFontProperty * * valueElements
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_get_Fonts(This,value) \
    ( (This)->lpVtbl->get_Fonts(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_TryFindFontFace(This,fontFace,index,succeeded) \
    ( (This)->lpVtbl->TryFindFontFace(This,fontFace,index,succeeded) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_GetMatchingFontsFromProperties(This,__propertyElementsSize,propertyElements,matchingFonts) \
    ( (This)->lpVtbl->GetMatchingFontsFromProperties(This,__propertyElementsSize,propertyElements,matchingFonts) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_GetMatchingFontsFromWwsFamily(This,familyName,weight,stretch,style,matchingFonts) \
    ( (This)->lpVtbl->GetMatchingFontsFromWwsFamily(This,familyName,weight,stretch,style,matchingFonts) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_CountFontsMatchingProperty(This,property,count) \
    ( (This)->lpVtbl->CountFontsMatchingProperty(This,property,count) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_GetPropertyValuesFromIndex(This,fontIndex,propertyIdentifier,values) \
    ( (This)->lpVtbl->GetPropertyValuesFromIndex(This,fontIndex,propertyIdentifier,values) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_GetPropertyValuesFromIdentifier(This,propertyIdentifier,preferredLocaleNames,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetPropertyValuesFromIdentifier(This,propertyIdentifier,preferredLocaleNames,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_GetPropertyValues(This,propertyIdentifier,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetPropertyValues(This,propertyIdentifier,__valueElementsSize,valueElements) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasFontSetFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasFontSet
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasFontSetFactory[] = L"Microsoft.Graphics.Canvas.Text.ICanvasFontSetFactory";
/* [object, version, uuid("3C9C9BDA-70F9-4FF9-AAB2-3B42923286EE"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *Create )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CIUriRuntimeClass * uri,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * * fontSet
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactoryVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_Create(This,uri,fontSet) \
    ( (This)->lpVtbl->Create(This,uri,fontSet) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasFontSetStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasFontSet
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasFontSetStatics[] = L"Microsoft.Graphics.Canvas.Text.ICanvasFontSetStatics";
/* [object, version, uuid("5F4275CE-BCFA-48C5-9E67-FBE9866D4924"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *GetSystemFontSet )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * * fontSet
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStaticsVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_GetSystemFontSet(This,fontSet) \
    ( (This)->lpVtbl->GetSystemFontSet(This,fontSet) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSetStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasNumberSubstitution
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasNumberSubstitution
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasNumberSubstitution[] = L"Microsoft.Graphics.Canvas.Text.ICanvasNumberSubstitution";
/* [object, version, uuid("C81A67AD-0639-4F8F-878B-D937F8A14293"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasNumberSubstitutionFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasNumberSubstitution
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasNumberSubstitutionFactory[] = L"Microsoft.Graphics.Canvas.Text.ICanvasNumberSubstitutionFactory";
/* [object, version, uuid("7496A822-C781-4EB0-AAFB-C078E7FA8E24"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *Create )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasNumberSubstitutionMethod method,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution * * canvasNumberSubstitution
        );
    HRESULT ( STDMETHODCALLTYPE *CreateWithLocaleAndIgnoreOverrides )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasNumberSubstitutionMethod method,
        /* [in] */HSTRING localeName,
        /* [in] */boolean ignoreEnvironmentOverrides,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution * * canvasNumberSubstitution
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactoryVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_Create(This,method,canvasNumberSubstitution) \
    ( (This)->lpVtbl->Create(This,method,canvasNumberSubstitution) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_CreateWithLocaleAndIgnoreOverrides(This,method,localeName,ignoreEnvironmentOverrides,canvasNumberSubstitution) \
    ( (This)->lpVtbl->CreateWithLocaleAndIgnoreOverrides(This,method,localeName,ignoreEnvironmentOverrides,canvasNumberSubstitution) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitutionFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasScaledFont
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasScaledFont
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasScaledFont[] = L"Microsoft.Graphics.Canvas.Text.ICanvasScaledFont";
/* [object, version, uuid("BBC4F8D2-EB2B-45F1-AC2A-CFC1F598BAE3"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFontVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FontFace )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_ScaleFactor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont * This,
        /* [retval, out] */FLOAT * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFontVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFontVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_get_FontFace(This,value) \
    ( (This)->lpVtbl->get_FontFace(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_get_ScaleFactor(This,value) \
    ( (This)->lpVtbl->get_ScaleFactor(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasScaledFont_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextAnalyzer
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextAnalyzer
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextAnalyzer[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextAnalyzer";
/* [object, version, uuid("4298F3D1-645B-40E3-B91B-81986D767FC0"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload] */HRESULT ( STDMETHODCALLTYPE *GetFontsUsingSystemFontSet )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * textFormat,
        /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * * values
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetFonts )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * textFormat,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontSet * fontSet,
        /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasScaledFont * * values
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetBidi )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * * values
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetBidiWithLocale )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [in] */HSTRING locale,
        /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedBidi * * values
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetBreakpoints )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedBreakpoint * * valueElements
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetBreakpointsWithLocale )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [in] */HSTRING locale,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedBreakpoint * * valueElements
        );
    HRESULT ( STDMETHODCALLTYPE *GetNumberSubstitutions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasNumberSubstitution * * values
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetScript )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * * values
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetScriptWithLocale )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [in] */HSTRING locale,
        /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedScript * * values
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetGlyphOrientations )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * * values
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetGlyphOrientationsWithLocale )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [in] */HSTRING locale,
        /* [retval, out] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasAnalyzedGlyphOrientation * * values
        );
    HRESULT ( STDMETHODCALLTYPE *GetScriptProperties )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedScript analyzedScript,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasScriptProperties * scriptProperties
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetGlyphs )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasCharacterRange characterRange,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * fontFace,
        /* [in] */FLOAT fontSize,
        /* [in] */boolean isSideways,
        /* [in] */boolean isRightToLeft,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedScript script,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * * valueElements
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetGlyphsWithAllOptions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasCharacterRange characterRange,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * fontFace,
        /* [in] */FLOAT fontSize,
        /* [in] */boolean isSideways,
        /* [in] */boolean isRightToLeft,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedScript script,
        /* [in] */HSTRING locale,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution * numberSubstitution,
        /* [in] */__FIVectorView_1___FIKeyValuePair_2_Microsoft__CGraphics__CCanvas__CText__CCanvasCharacterRange_Microsoft__CGraphics__CCanvas__CText__CCanvasTypography * typographyRanges,
        /* [out] */UINT32 * __clusterMapIndicesElementsSize,
        /* [size_is(, *(__clusterMapIndicesElementsSize)), out] */INT32 * * clusterMapIndicesElements,
        /* [out] */UINT32 * __isShapedAloneGlyphsElementsSize,
        /* [size_is(, *(__isShapedAloneGlyphsElementsSize)), out] */boolean * * isShapedAloneGlyphsElements,
        /* [out] */UINT32 * __glyphShapingResultsElementsSize,
        /* [size_is(, *(__glyphShapingResultsElementsSize)), out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphShaping * * glyphShapingResultsElements,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * * valueElements
        );
    HRESULT ( STDMETHODCALLTYPE *GetJustificationOpportunities )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasCharacterRange characterRange,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * fontFace,
        /* [in] */FLOAT fontSize,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedScript script,
        /* [in] */UINT32 __clusterMapIndicesElementsSize,
        /* [size_is(__clusterMapIndicesElementsSize), in] */INT32 * clusterMapIndicesElements,
        /* [in] */UINT32 __glyphShapingResultsElementsSize,
        /* [size_is(__glyphShapingResultsElementsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphShaping * glyphShapingResultsElements,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasJustificationOpportunity * * valueElements
        );
    HRESULT ( STDMETHODCALLTYPE *ApplyJustificationOpportunities )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [in] */FLOAT lineWidth,
        /* [in] */UINT32 __justificationOpportunitiesElementsSize,
        /* [size_is(__justificationOpportunitiesElementsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasJustificationOpportunity * justificationOpportunitiesElements,
        /* [in] */UINT32 __sourceGlyphsElementsSize,
        /* [size_is(__sourceGlyphsElementsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * sourceGlyphsElements,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * * valueElements
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *AddGlyphsAfterJustification )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * fontFace,
        /* [in] */FLOAT fontSize,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedScript script,
        /* [in] */UINT32 __clusterMapIndicesElementsSize,
        /* [size_is(__clusterMapIndicesElementsSize), in] */INT32 * clusterMapIndicesElements,
        /* [in] */UINT32 __originalGlyphsElementsSize,
        /* [size_is(__originalGlyphsElementsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * originalGlyphsElements,
        /* [in] */UINT32 __justifiedGlyphsElementsSize,
        /* [size_is(__justifiedGlyphsElementsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * justifiedGlyphsElements,
        /* [in] */UINT32 __glyphShapingResultsElementsSize,
        /* [size_is(__glyphShapingResultsElementsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphShaping * glyphShapingResultsElements,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * * valueElements
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *AddGlyphsAfterJustificationWithClusterMap )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * fontFace,
        /* [in] */FLOAT fontSize,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasAnalyzedScript script,
        /* [in] */UINT32 __clusterMapIndicesElementsSize,
        /* [size_is(__clusterMapIndicesElementsSize), in] */INT32 * clusterMapIndicesElements,
        /* [in] */UINT32 __originalGlyphsElementsSize,
        /* [size_is(__originalGlyphsElementsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * originalGlyphsElements,
        /* [in] */UINT32 __justifiedGlyphsElementsSize,
        /* [size_is(__justifiedGlyphsElementsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * justifiedGlyphsElements,
        /* [in] */UINT32 __glyphShapingResultsElementsSize,
        /* [size_is(__glyphShapingResultsElementsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphShaping * glyphShapingResultsElements,
        /* [out] */UINT32 * __outputClusterMapIndicesElementsSize,
        /* [size_is(, *(__outputClusterMapIndicesElementsSize)), out] */INT32 * * outputClusterMapIndicesElements,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * * valueElements
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetFontsUsingSystemFontSet(This,textFormat,values) \
    ( (This)->lpVtbl->GetFontsUsingSystemFontSet(This,textFormat,values) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetFonts(This,textFormat,fontSet,values) \
    ( (This)->lpVtbl->GetFonts(This,textFormat,fontSet,values) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetBidi(This,values) \
    ( (This)->lpVtbl->GetBidi(This,values) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetBidiWithLocale(This,locale,values) \
    ( (This)->lpVtbl->GetBidiWithLocale(This,locale,values) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetBreakpoints(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetBreakpoints(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetBreakpointsWithLocale(This,locale,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetBreakpointsWithLocale(This,locale,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetNumberSubstitutions(This,values) \
    ( (This)->lpVtbl->GetNumberSubstitutions(This,values) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetScript(This,values) \
    ( (This)->lpVtbl->GetScript(This,values) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetScriptWithLocale(This,locale,values) \
    ( (This)->lpVtbl->GetScriptWithLocale(This,locale,values) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetGlyphOrientations(This,values) \
    ( (This)->lpVtbl->GetGlyphOrientations(This,values) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetGlyphOrientationsWithLocale(This,locale,values) \
    ( (This)->lpVtbl->GetGlyphOrientationsWithLocale(This,locale,values) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetScriptProperties(This,analyzedScript,scriptProperties) \
    ( (This)->lpVtbl->GetScriptProperties(This,analyzedScript,scriptProperties) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetGlyphs(This,characterRange,fontFace,fontSize,isSideways,isRightToLeft,script,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetGlyphs(This,characterRange,fontFace,fontSize,isSideways,isRightToLeft,script,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetGlyphsWithAllOptions(This,characterRange,fontFace,fontSize,isSideways,isRightToLeft,script,locale,numberSubstitution,typographyRanges,__clusterMapIndicesElementsSize,clusterMapIndicesElements,__isShapedAloneGlyphsElementsSize,isShapedAloneGlyphsElements,__glyphShapingResultsElementsSize,glyphShapingResultsElements,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetGlyphsWithAllOptions(This,characterRange,fontFace,fontSize,isSideways,isRightToLeft,script,locale,numberSubstitution,typographyRanges,__clusterMapIndicesElementsSize,clusterMapIndicesElements,__isShapedAloneGlyphsElementsSize,isShapedAloneGlyphsElements,__glyphShapingResultsElementsSize,glyphShapingResultsElements,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_GetJustificationOpportunities(This,characterRange,fontFace,fontSize,script,__clusterMapIndicesElementsSize,clusterMapIndicesElements,__glyphShapingResultsElementsSize,glyphShapingResultsElements,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetJustificationOpportunities(This,characterRange,fontFace,fontSize,script,__clusterMapIndicesElementsSize,clusterMapIndicesElements,__glyphShapingResultsElementsSize,glyphShapingResultsElements,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_ApplyJustificationOpportunities(This,lineWidth,__justificationOpportunitiesElementsSize,justificationOpportunitiesElements,__sourceGlyphsElementsSize,sourceGlyphsElements,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->ApplyJustificationOpportunities(This,lineWidth,__justificationOpportunitiesElementsSize,justificationOpportunitiesElements,__sourceGlyphsElementsSize,sourceGlyphsElements,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_AddGlyphsAfterJustification(This,fontFace,fontSize,script,__clusterMapIndicesElementsSize,clusterMapIndicesElements,__originalGlyphsElementsSize,originalGlyphsElements,__justifiedGlyphsElementsSize,justifiedGlyphsElements,__glyphShapingResultsElementsSize,glyphShapingResultsElements,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->AddGlyphsAfterJustification(This,fontFace,fontSize,script,__clusterMapIndicesElementsSize,clusterMapIndicesElements,__originalGlyphsElementsSize,originalGlyphsElements,__justifiedGlyphsElementsSize,justifiedGlyphsElements,__glyphShapingResultsElementsSize,glyphShapingResultsElements,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_AddGlyphsAfterJustificationWithClusterMap(This,fontFace,fontSize,script,__clusterMapIndicesElementsSize,clusterMapIndicesElements,__originalGlyphsElementsSize,originalGlyphsElements,__justifiedGlyphsElementsSize,justifiedGlyphsElements,__glyphShapingResultsElementsSize,glyphShapingResultsElements,__outputClusterMapIndicesElementsSize,outputClusterMapIndicesElements,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->AddGlyphsAfterJustificationWithClusterMap(This,fontFace,fontSize,script,__clusterMapIndicesElementsSize,clusterMapIndicesElements,__originalGlyphsElementsSize,originalGlyphsElements,__justifiedGlyphsElementsSize,justifiedGlyphsElements,__glyphShapingResultsElementsSize,glyphShapingResultsElements,__outputClusterMapIndicesElementsSize,outputClusterMapIndicesElements,__valueElementsSize,valueElements) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextAnalyzerFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextAnalyzer
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextAnalyzerFactory[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextAnalyzerFactory";
/* [object, version, uuid("521E433F-F698-44C0-8D7F-FE374FE539E1"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *Create )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory * This,
        /* [in] */HSTRING text,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextDirection textDirection,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * * canvasTextAnalyzer
        );
    HRESULT ( STDMETHODCALLTYPE *CreateWithNumberSubstitutionAndVerticalGlyphOrientationAndBidiLevel )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory * This,
        /* [in] */HSTRING text,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextDirection textDirection,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution * numberSubstitution,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasVerticalGlyphOrientation verticalGlyphOrientation,
        /* [in] */UINT32 bidiLevel,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * * canvasTextAnalyzer
        );
    HRESULT ( STDMETHODCALLTYPE *CreateWithOptions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory * This,
        /* [in] */HSTRING text,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextDirection textDirection,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions * options,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzer * * canvasTextAnalyzer
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactoryVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_Create(This,text,textDirection,canvasTextAnalyzer) \
    ( (This)->lpVtbl->Create(This,text,textDirection,canvasTextAnalyzer) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_CreateWithNumberSubstitutionAndVerticalGlyphOrientationAndBidiLevel(This,text,textDirection,numberSubstitution,verticalGlyphOrientation,bidiLevel,canvasTextAnalyzer) \
    ( (This)->lpVtbl->CreateWithNumberSubstitutionAndVerticalGlyphOrientationAndBidiLevel(This,text,textDirection,numberSubstitution,verticalGlyphOrientation,bidiLevel,canvasTextAnalyzer) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_CreateWithOptions(This,text,textDirection,options,canvasTextAnalyzer) \
    ( (This)->lpVtbl->CreateWithOptions(This,text,textDirection,options,canvasTextAnalyzer) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextAnalyzerOptions
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextAnalyzerOptions[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextAnalyzerOptions";
/* [object, version, uuid("31F2406A-8C5F-4E12-8BD6-CFBBC7214D02")] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptionsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *GetLocaleName )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions * This,
        /* [in] */INT32 characterIndex,
        /* [out] */INT32 * characterCount,
        /* [retval, out] */HSTRING * value
        );
    HRESULT ( STDMETHODCALLTYPE *GetNumberSubstitution )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions * This,
        /* [in] */INT32 characterIndex,
        /* [out] */INT32 * characterCount,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasNumberSubstitution * * value
        );
    HRESULT ( STDMETHODCALLTYPE *GetVerticalGlyphOrientation )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions * This,
        /* [in] */INT32 characterIndex,
        /* [out] */INT32 * characterCount,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasVerticalGlyphOrientation * value
        );
    HRESULT ( STDMETHODCALLTYPE *GetBidiLevel )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions * This,
        /* [in] */INT32 characterIndex,
        /* [out] */INT32 * characterCount,
        /* [retval, out] */UINT32 * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptionsVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptionsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_GetLocaleName(This,characterIndex,characterCount,value) \
    ( (This)->lpVtbl->GetLocaleName(This,characterIndex,characterCount,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_GetNumberSubstitution(This,characterIndex,characterCount,value) \
    ( (This)->lpVtbl->GetNumberSubstitution(This,characterIndex,characterCount,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_GetVerticalGlyphOrientation(This,characterIndex,characterCount,value) \
    ( (This)->lpVtbl->GetVerticalGlyphOrientation(This,characterIndex,characterCount,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_GetBidiLevel(This,characterIndex,characterCount,value) \
    ( (This)->lpVtbl->GetBidiLevel(This,characterIndex,characterCount,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextAnalyzerOptions_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextFormat
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextFormat
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextFormat[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextFormat";
/* [object, version, uuid("AF61BFDC-EABB-4D38-BA1B-AFB340612D33"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Direction )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextDirection * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Direction )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextDirection value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FontFamily )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_FontFamily )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */HSTRING value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FontSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_FontSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */FLOAT value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FontStretch )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */__x_ABI_CWindows_CUI_CText_CFontStretch * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_FontStretch )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */__x_ABI_CWindows_CUI_CText_CFontStretch value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FontStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */__x_ABI_CWindows_CUI_CText_CFontStyle * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_FontStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */__x_ABI_CWindows_CUI_CText_CFontStyle value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FontWeight )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */__x_ABI_CWindows_CUI_CText_CFontWeight * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_FontWeight )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */__x_ABI_CWindows_CUI_CText_CFontWeight value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_IncrementalTabStop )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_IncrementalTabStop )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */FLOAT value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LineSpacing )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_LineSpacing )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */FLOAT value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LineSpacingBaseline )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_LineSpacingBaseline )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */FLOAT value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LocaleName )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_LocaleName )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */HSTRING value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_VerticalAlignment )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasVerticalAlignment * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_VerticalAlignment )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasVerticalAlignment value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_HorizontalAlignment )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasHorizontalAlignment * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_HorizontalAlignment )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasHorizontalAlignment value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_TrimmingGranularity )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextTrimmingGranularity * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_TrimmingGranularity )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextTrimmingGranularity value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_TrimmingDelimiter )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_TrimmingDelimiter )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */HSTRING value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_TrimmingDelimiterCount )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */INT32 * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_TrimmingDelimiterCount )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */INT32 value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_WordWrapping )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasWordWrapping * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_WordWrapping )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasWordWrapping value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Options )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasDrawTextOptions * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Options )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasDrawTextOptions value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_VerticalGlyphOrientation )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasVerticalGlyphOrientation * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_VerticalGlyphOrientation )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasVerticalGlyphOrientation value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_OpticalAlignment )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasOpticalAlignment * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_OpticalAlignment )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasOpticalAlignment value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LastLineWrapping )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */boolean * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_LastLineWrapping )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */boolean value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LineSpacingMode )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineSpacingMode * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_LineSpacingMode )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineSpacingMode value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_TrimmingSign )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTrimmingSign * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_TrimmingSign )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTrimmingSign value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_CustomTrimmingSign )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_CustomTrimmingSign )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_Direction(This,value) \
    ( (This)->lpVtbl->get_Direction(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_Direction(This,value) \
    ( (This)->lpVtbl->put_Direction(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_FontFamily(This,value) \
    ( (This)->lpVtbl->get_FontFamily(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_FontFamily(This,value) \
    ( (This)->lpVtbl->put_FontFamily(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_FontSize(This,value) \
    ( (This)->lpVtbl->get_FontSize(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_FontSize(This,value) \
    ( (This)->lpVtbl->put_FontSize(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_FontStretch(This,value) \
    ( (This)->lpVtbl->get_FontStretch(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_FontStretch(This,value) \
    ( (This)->lpVtbl->put_FontStretch(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_FontStyle(This,value) \
    ( (This)->lpVtbl->get_FontStyle(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_FontStyle(This,value) \
    ( (This)->lpVtbl->put_FontStyle(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_FontWeight(This,value) \
    ( (This)->lpVtbl->get_FontWeight(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_FontWeight(This,value) \
    ( (This)->lpVtbl->put_FontWeight(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_IncrementalTabStop(This,value) \
    ( (This)->lpVtbl->get_IncrementalTabStop(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_IncrementalTabStop(This,value) \
    ( (This)->lpVtbl->put_IncrementalTabStop(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_LineSpacing(This,value) \
    ( (This)->lpVtbl->get_LineSpacing(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_LineSpacing(This,value) \
    ( (This)->lpVtbl->put_LineSpacing(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_LineSpacingBaseline(This,value) \
    ( (This)->lpVtbl->get_LineSpacingBaseline(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_LineSpacingBaseline(This,value) \
    ( (This)->lpVtbl->put_LineSpacingBaseline(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_LocaleName(This,value) \
    ( (This)->lpVtbl->get_LocaleName(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_LocaleName(This,value) \
    ( (This)->lpVtbl->put_LocaleName(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_VerticalAlignment(This,value) \
    ( (This)->lpVtbl->get_VerticalAlignment(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_VerticalAlignment(This,value) \
    ( (This)->lpVtbl->put_VerticalAlignment(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_HorizontalAlignment(This,value) \
    ( (This)->lpVtbl->get_HorizontalAlignment(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_HorizontalAlignment(This,value) \
    ( (This)->lpVtbl->put_HorizontalAlignment(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_TrimmingGranularity(This,value) \
    ( (This)->lpVtbl->get_TrimmingGranularity(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_TrimmingGranularity(This,value) \
    ( (This)->lpVtbl->put_TrimmingGranularity(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_TrimmingDelimiter(This,value) \
    ( (This)->lpVtbl->get_TrimmingDelimiter(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_TrimmingDelimiter(This,value) \
    ( (This)->lpVtbl->put_TrimmingDelimiter(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_TrimmingDelimiterCount(This,value) \
    ( (This)->lpVtbl->get_TrimmingDelimiterCount(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_TrimmingDelimiterCount(This,value) \
    ( (This)->lpVtbl->put_TrimmingDelimiterCount(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_WordWrapping(This,value) \
    ( (This)->lpVtbl->get_WordWrapping(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_WordWrapping(This,value) \
    ( (This)->lpVtbl->put_WordWrapping(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_Options(This,value) \
    ( (This)->lpVtbl->get_Options(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_Options(This,value) \
    ( (This)->lpVtbl->put_Options(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_VerticalGlyphOrientation(This,value) \
    ( (This)->lpVtbl->get_VerticalGlyphOrientation(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_VerticalGlyphOrientation(This,value) \
    ( (This)->lpVtbl->put_VerticalGlyphOrientation(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_OpticalAlignment(This,value) \
    ( (This)->lpVtbl->get_OpticalAlignment(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_OpticalAlignment(This,value) \
    ( (This)->lpVtbl->put_OpticalAlignment(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_LastLineWrapping(This,value) \
    ( (This)->lpVtbl->get_LastLineWrapping(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_LastLineWrapping(This,value) \
    ( (This)->lpVtbl->put_LastLineWrapping(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_LineSpacingMode(This,value) \
    ( (This)->lpVtbl->get_LineSpacingMode(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_LineSpacingMode(This,value) \
    ( (This)->lpVtbl->put_LineSpacingMode(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_TrimmingSign(This,value) \
    ( (This)->lpVtbl->get_TrimmingSign(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_TrimmingSign(This,value) \
    ( (This)->lpVtbl->put_TrimmingSign(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_get_CustomTrimmingSign(This,value) \
    ( (This)->lpVtbl->get_CustomTrimmingSign(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_put_CustomTrimmingSign(This,value) \
    ( (This)->lpVtbl->put_CustomTrimmingSign(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextFormatStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextFormat
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextFormatStatics[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextFormatStatics";
/* [object, version, uuid("8A927515-33FC-4C92-A6AA-94A8F29C140B"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload] */HRESULT ( STDMETHODCALLTYPE *GetSystemFontFamilies )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics * This,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */HSTRING * * valueElements
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetSystemFontFamiliesFromLocaleList )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics * This,
        /* [in] */__FIVectorView_1_HSTRING * localeList,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */HSTRING * * valueElements
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStaticsVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_GetSystemFontFamilies(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetSystemFontFamilies(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_GetSystemFontFamiliesFromLocaleList(This,localeList,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetSystemFontFamiliesFromLocaleList(This,localeList,__valueElementsSize,valueElements) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormatStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextInlineObject
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextInlineObject[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextInlineObject";
/* [object, version, uuid("7A89EE99-CE2A-47FA-9DD2-0A6825F6053F")] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObjectVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *Draw )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer * textRenderer,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */boolean isSideways,
        /* [in] */boolean isRightToLeft,
        /* [in] */IInspectable * brush
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Size )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CSize * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Baseline )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_SupportsSideways )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * This,
        /* [retval, out] */boolean * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_DrawBounds )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * bounds
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_BreakBefore )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineBreakCondition * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_BreakAfter )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineBreakCondition * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObjectVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObjectVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_Draw(This,textRenderer,point,isSideways,isRightToLeft,brush) \
    ( (This)->lpVtbl->Draw(This,textRenderer,point,isSideways,isRightToLeft,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_get_Size(This,value) \
    ( (This)->lpVtbl->get_Size(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_get_Baseline(This,value) \
    ( (This)->lpVtbl->get_Baseline(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_get_SupportsSideways(This,value) \
    ( (This)->lpVtbl->get_SupportsSideways(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_get_DrawBounds(This,bounds) \
    ( (This)->lpVtbl->get_DrawBounds(This,bounds) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_get_BreakBefore(This,value) \
    ( (This)->lpVtbl->get_BreakBefore(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_get_BreakAfter(This,value) \
    ( (This)->lpVtbl->get_BreakAfter(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextLayout
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextLayout
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextLayout[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextLayout";
/* [object, version, uuid("BAE63E54-48AE-4446-A2C7-B6EF93806C20"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *GetFormatChangeIndices )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [out] */UINT32 * __stopsSize,
        /* [size_is(, *(__stopsSize)), retval, out] */INT32 * * stops
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Direction )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextDirection * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Direction )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextDirection value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_DefaultFontFamily )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_DefaultFontSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_DefaultFontStretch )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CWindows_CUI_CText_CFontStretch * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_DefaultFontStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CWindows_CUI_CText_CFontStyle * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_DefaultFontWeight )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CWindows_CUI_CText_CFontWeight * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_IncrementalTabStop )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_IncrementalTabStop )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */FLOAT value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LineSpacing )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_LineSpacing )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */FLOAT value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LineSpacingBaseline )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_LineSpacingBaseline )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */FLOAT value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_DefaultLocaleName )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_VerticalAlignment )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasVerticalAlignment * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_VerticalAlignment )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasVerticalAlignment value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_HorizontalAlignment )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasHorizontalAlignment * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_HorizontalAlignment )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasHorizontalAlignment value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_TrimmingGranularity )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextTrimmingGranularity * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_TrimmingGranularity )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextTrimmingGranularity value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_TrimmingDelimiter )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_TrimmingDelimiter )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */HSTRING value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_TrimmingDelimiterCount )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */INT32 * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_TrimmingDelimiterCount )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_WordWrapping )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasWordWrapping * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_WordWrapping )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasWordWrapping value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Options )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasDrawTextOptions * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Options )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasDrawTextOptions value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LineSpacingMode )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineSpacingMode * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_LineSpacingMode )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineSpacingMode value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_TrimmingSign )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTrimmingSign * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_TrimmingSign )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTrimmingSign value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_CustomTrimmingSign )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_CustomTrimmingSign )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_RequestedSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CSize * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_RequestedSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CSize value
        );
    HRESULT ( STDMETHODCALLTYPE *GetMinimumLineLength )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */FLOAT * value
        );
    HRESULT ( STDMETHODCALLTYPE *GetBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * * brush
        );
    HRESULT ( STDMETHODCALLTYPE *GetCustomBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [retval, out] */IInspectable * * brush
        );
    HRESULT ( STDMETHODCALLTYPE *GetFontFamily )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [retval, out] */HSTRING * fontFamily
        );
    HRESULT ( STDMETHODCALLTYPE *GetFontSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [retval, out] */FLOAT * fontSize
        );
    HRESULT ( STDMETHODCALLTYPE *GetFontStretch )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [retval, out] */__x_ABI_CWindows_CUI_CText_CFontStretch * fontStretch
        );
    HRESULT ( STDMETHODCALLTYPE *GetFontStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [retval, out] */__x_ABI_CWindows_CUI_CText_CFontStyle * fontStyle
        );
    HRESULT ( STDMETHODCALLTYPE *GetFontWeight )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [retval, out] */__x_ABI_CWindows_CUI_CText_CFontWeight * fontWeight
        );
    HRESULT ( STDMETHODCALLTYPE *GetLocaleName )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [retval, out] */HSTRING * localeName
        );
    HRESULT ( STDMETHODCALLTYPE *GetStrikethrough )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [retval, out] */boolean * hasStrikethrough
        );
    HRESULT ( STDMETHODCALLTYPE *GetUnderline )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [retval, out] */boolean * hasUnderline
        );
    HRESULT ( STDMETHODCALLTYPE *GetInlineObject )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * * inlineObject
        );
    HRESULT ( STDMETHODCALLTYPE *SetColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */INT32 characterCount,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    HRESULT ( STDMETHODCALLTYPE *SetBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */INT32 characterCount,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    HRESULT ( STDMETHODCALLTYPE *SetCustomBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */INT32 characterCount,
        /* [in] */IInspectable * brush
        );
    HRESULT ( STDMETHODCALLTYPE *SetFontFamily )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */INT32 characterCount,
        /* [in] */HSTRING fontFamily
        );
    HRESULT ( STDMETHODCALLTYPE *SetFontSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */INT32 characterCount,
        /* [in] */FLOAT fontSize
        );
    HRESULT ( STDMETHODCALLTYPE *SetFontStretch )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */INT32 characterCount,
        /* [in] */__x_ABI_CWindows_CUI_CText_CFontStretch fontStretch
        );
    HRESULT ( STDMETHODCALLTYPE *SetFontStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */INT32 characterCount,
        /* [in] */__x_ABI_CWindows_CUI_CText_CFontStyle fontStyle
        );
    HRESULT ( STDMETHODCALLTYPE *SetFontWeight )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */INT32 characterCount,
        /* [in] */__x_ABI_CWindows_CUI_CText_CFontWeight fontWeight
        );
    HRESULT ( STDMETHODCALLTYPE *SetLocaleName )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */INT32 characterCount,
        /* [in] */HSTRING name
        );
    HRESULT ( STDMETHODCALLTYPE *SetStrikethrough )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */INT32 characterCount,
        /* [in] */boolean hasStrikethrough
        );
    HRESULT ( STDMETHODCALLTYPE *SetUnderline )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */INT32 characterCount,
        /* [in] */boolean hasUnderline
        );
    HRESULT ( STDMETHODCALLTYPE *SetInlineObject )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */INT32 characterCount,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * inlineObject
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawToTextRenderer )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer * textRenderer,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 position
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawToTextRendererWithCoords )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer * textRenderer,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LineMetrics )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasLineMetrics * * valueElements
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_ClusterMetrics )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasClusterMetrics * * valueElements
        );
    HRESULT ( STDMETHODCALLTYPE *SetTypography )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */INT32 characterCount,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography * typography
        );
    HRESULT ( STDMETHODCALLTYPE *GetTypography )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography * * typography
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LayoutBounds )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * bounds
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LayoutBoundsIncludingTrailingWhitespace )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * bounds
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LineCount )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */INT32 * lineCount
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_MaximumBidiReorderingDepth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */INT32 * depth
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_DrawBounds )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * bounds
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *HitTest )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [retval, out] */boolean * isHit
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *HitTestWithCoords )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [retval, out] */boolean * isHit
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *HitTestWithDescription )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextLayoutRegion * textLayoutRegion,
        /* [retval, out] */boolean * isHit
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *HitTestWithDescriptionAndCoords )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextLayoutRegion * textLayoutRegion,
        /* [retval, out] */boolean * isHit
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *HitTestWithDescriptionAndTrailingSide )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextLayoutRegion * textLayoutRegion,
        /* [out] */boolean * trailingSideOfCharacter,
        /* [retval, out] */boolean * isHit
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *HitTestWithDescriptionAndCoordsAndTrailingSide )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextLayoutRegion * textLayoutRegion,
        /* [out] */boolean * trailingSideOfCharacter,
        /* [retval, out] */boolean * isHit
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetCaretPosition )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */boolean trailingSideOfCharacter,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 * location
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *GetCaretPositionWithDescription )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */boolean trailingSideOfCharacter,
        /* [out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextLayoutRegion * textLayoutRegion,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 * location
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *GetCharacterRegions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */INT32 characterCount,
        /* [out] */UINT32 * __hitTestDescriptionsSize,
        /* [size_is(, *(__hitTestDescriptionsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextLayoutRegion * * hitTestDescriptions
        );
    HRESULT ( STDMETHODCALLTYPE *GetPairKerning )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [retval, out] */boolean * hasPairKerning
        );
    HRESULT ( STDMETHODCALLTYPE *SetPairKerning )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */INT32 characterCount,
        /* [in] */boolean hasPairKerning
        );
    HRESULT ( STDMETHODCALLTYPE *GetLeadingCharacterSpacing )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [retval, out] */FLOAT * leadingSpacing
        );
    HRESULT ( STDMETHODCALLTYPE *GetTrailingCharacterSpacing )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [retval, out] */FLOAT * trailingSpacing
        );
    HRESULT ( STDMETHODCALLTYPE *GetMinimumCharacterAdvance )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [retval, out] */FLOAT * minimumAdvance
        );
    HRESULT ( STDMETHODCALLTYPE *SetCharacterSpacing )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */INT32 characterIndex,
        /* [in] */INT32 characterCount,
        /* [in] */FLOAT leadingSpacing,
        /* [in] */FLOAT trailingSpacing,
        /* [in] */FLOAT minimumAdvance
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_VerticalGlyphOrientation )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasVerticalGlyphOrientation * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_VerticalGlyphOrientation )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasVerticalGlyphOrientation value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_OpticalAlignment )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasOpticalAlignment * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_OpticalAlignment )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasOpticalAlignment value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LastLineWrapping )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */boolean * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_LastLineWrapping )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [in] */boolean value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Device )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetFormatChangeIndices(This,__stopsSize,stops) \
    ( (This)->lpVtbl->GetFormatChangeIndices(This,__stopsSize,stops) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_Direction(This,value) \
    ( (This)->lpVtbl->get_Direction(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_Direction(This,value) \
    ( (This)->lpVtbl->put_Direction(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_DefaultFontFamily(This,value) \
    ( (This)->lpVtbl->get_DefaultFontFamily(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_DefaultFontSize(This,value) \
    ( (This)->lpVtbl->get_DefaultFontSize(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_DefaultFontStretch(This,value) \
    ( (This)->lpVtbl->get_DefaultFontStretch(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_DefaultFontStyle(This,value) \
    ( (This)->lpVtbl->get_DefaultFontStyle(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_DefaultFontWeight(This,value) \
    ( (This)->lpVtbl->get_DefaultFontWeight(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_IncrementalTabStop(This,value) \
    ( (This)->lpVtbl->get_IncrementalTabStop(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_IncrementalTabStop(This,value) \
    ( (This)->lpVtbl->put_IncrementalTabStop(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_LineSpacing(This,value) \
    ( (This)->lpVtbl->get_LineSpacing(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_LineSpacing(This,value) \
    ( (This)->lpVtbl->put_LineSpacing(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_LineSpacingBaseline(This,value) \
    ( (This)->lpVtbl->get_LineSpacingBaseline(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_LineSpacingBaseline(This,value) \
    ( (This)->lpVtbl->put_LineSpacingBaseline(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_DefaultLocaleName(This,value) \
    ( (This)->lpVtbl->get_DefaultLocaleName(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_VerticalAlignment(This,value) \
    ( (This)->lpVtbl->get_VerticalAlignment(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_VerticalAlignment(This,value) \
    ( (This)->lpVtbl->put_VerticalAlignment(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_HorizontalAlignment(This,value) \
    ( (This)->lpVtbl->get_HorizontalAlignment(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_HorizontalAlignment(This,value) \
    ( (This)->lpVtbl->put_HorizontalAlignment(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_TrimmingGranularity(This,value) \
    ( (This)->lpVtbl->get_TrimmingGranularity(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_TrimmingGranularity(This,value) \
    ( (This)->lpVtbl->put_TrimmingGranularity(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_TrimmingDelimiter(This,value) \
    ( (This)->lpVtbl->get_TrimmingDelimiter(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_TrimmingDelimiter(This,value) \
    ( (This)->lpVtbl->put_TrimmingDelimiter(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_TrimmingDelimiterCount(This,value) \
    ( (This)->lpVtbl->get_TrimmingDelimiterCount(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_TrimmingDelimiterCount(This,value) \
    ( (This)->lpVtbl->put_TrimmingDelimiterCount(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_WordWrapping(This,value) \
    ( (This)->lpVtbl->get_WordWrapping(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_WordWrapping(This,value) \
    ( (This)->lpVtbl->put_WordWrapping(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_Options(This,value) \
    ( (This)->lpVtbl->get_Options(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_Options(This,value) \
    ( (This)->lpVtbl->put_Options(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_LineSpacingMode(This,value) \
    ( (This)->lpVtbl->get_LineSpacingMode(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_LineSpacingMode(This,value) \
    ( (This)->lpVtbl->put_LineSpacingMode(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_TrimmingSign(This,value) \
    ( (This)->lpVtbl->get_TrimmingSign(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_TrimmingSign(This,value) \
    ( (This)->lpVtbl->put_TrimmingSign(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_CustomTrimmingSign(This,value) \
    ( (This)->lpVtbl->get_CustomTrimmingSign(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_CustomTrimmingSign(This,value) \
    ( (This)->lpVtbl->put_CustomTrimmingSign(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_RequestedSize(This,value) \
    ( (This)->lpVtbl->get_RequestedSize(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_RequestedSize(This,value) \
    ( (This)->lpVtbl->put_RequestedSize(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetMinimumLineLength(This,value) \
    ( (This)->lpVtbl->GetMinimumLineLength(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetBrush(This,characterIndex,brush) \
    ( (This)->lpVtbl->GetBrush(This,characterIndex,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetCustomBrush(This,characterIndex,brush) \
    ( (This)->lpVtbl->GetCustomBrush(This,characterIndex,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetFontFamily(This,characterIndex,fontFamily) \
    ( (This)->lpVtbl->GetFontFamily(This,characterIndex,fontFamily) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetFontSize(This,characterIndex,fontSize) \
    ( (This)->lpVtbl->GetFontSize(This,characterIndex,fontSize) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetFontStretch(This,characterIndex,fontStretch) \
    ( (This)->lpVtbl->GetFontStretch(This,characterIndex,fontStretch) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetFontStyle(This,characterIndex,fontStyle) \
    ( (This)->lpVtbl->GetFontStyle(This,characterIndex,fontStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetFontWeight(This,characterIndex,fontWeight) \
    ( (This)->lpVtbl->GetFontWeight(This,characterIndex,fontWeight) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetLocaleName(This,characterIndex,localeName) \
    ( (This)->lpVtbl->GetLocaleName(This,characterIndex,localeName) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetStrikethrough(This,characterIndex,hasStrikethrough) \
    ( (This)->lpVtbl->GetStrikethrough(This,characterIndex,hasStrikethrough) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetUnderline(This,characterIndex,hasUnderline) \
    ( (This)->lpVtbl->GetUnderline(This,characterIndex,hasUnderline) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetInlineObject(This,characterIndex,inlineObject) \
    ( (This)->lpVtbl->GetInlineObject(This,characterIndex,inlineObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_SetColor(This,characterIndex,characterCount,color) \
    ( (This)->lpVtbl->SetColor(This,characterIndex,characterCount,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_SetBrush(This,characterIndex,characterCount,brush) \
    ( (This)->lpVtbl->SetBrush(This,characterIndex,characterCount,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_SetCustomBrush(This,characterIndex,characterCount,brush) \
    ( (This)->lpVtbl->SetCustomBrush(This,characterIndex,characterCount,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_SetFontFamily(This,characterIndex,characterCount,fontFamily) \
    ( (This)->lpVtbl->SetFontFamily(This,characterIndex,characterCount,fontFamily) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_SetFontSize(This,characterIndex,characterCount,fontSize) \
    ( (This)->lpVtbl->SetFontSize(This,characterIndex,characterCount,fontSize) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_SetFontStretch(This,characterIndex,characterCount,fontStretch) \
    ( (This)->lpVtbl->SetFontStretch(This,characterIndex,characterCount,fontStretch) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_SetFontStyle(This,characterIndex,characterCount,fontStyle) \
    ( (This)->lpVtbl->SetFontStyle(This,characterIndex,characterCount,fontStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_SetFontWeight(This,characterIndex,characterCount,fontWeight) \
    ( (This)->lpVtbl->SetFontWeight(This,characterIndex,characterCount,fontWeight) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_SetLocaleName(This,characterIndex,characterCount,name) \
    ( (This)->lpVtbl->SetLocaleName(This,characterIndex,characterCount,name) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_SetStrikethrough(This,characterIndex,characterCount,hasStrikethrough) \
    ( (This)->lpVtbl->SetStrikethrough(This,characterIndex,characterCount,hasStrikethrough) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_SetUnderline(This,characterIndex,characterCount,hasUnderline) \
    ( (This)->lpVtbl->SetUnderline(This,characterIndex,characterCount,hasUnderline) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_SetInlineObject(This,characterIndex,characterCount,inlineObject) \
    ( (This)->lpVtbl->SetInlineObject(This,characterIndex,characterCount,inlineObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_DrawToTextRenderer(This,textRenderer,position) \
    ( (This)->lpVtbl->DrawToTextRenderer(This,textRenderer,position) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_DrawToTextRendererWithCoords(This,textRenderer,x,y) \
    ( (This)->lpVtbl->DrawToTextRendererWithCoords(This,textRenderer,x,y) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_LineMetrics(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->get_LineMetrics(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_ClusterMetrics(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->get_ClusterMetrics(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_SetTypography(This,characterIndex,characterCount,typography) \
    ( (This)->lpVtbl->SetTypography(This,characterIndex,characterCount,typography) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetTypography(This,characterIndex,typography) \
    ( (This)->lpVtbl->GetTypography(This,characterIndex,typography) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_LayoutBounds(This,bounds) \
    ( (This)->lpVtbl->get_LayoutBounds(This,bounds) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_LayoutBoundsIncludingTrailingWhitespace(This,bounds) \
    ( (This)->lpVtbl->get_LayoutBoundsIncludingTrailingWhitespace(This,bounds) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_LineCount(This,lineCount) \
    ( (This)->lpVtbl->get_LineCount(This,lineCount) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_MaximumBidiReorderingDepth(This,depth) \
    ( (This)->lpVtbl->get_MaximumBidiReorderingDepth(This,depth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_DrawBounds(This,bounds) \
    ( (This)->lpVtbl->get_DrawBounds(This,bounds) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_HitTest(This,point,isHit) \
    ( (This)->lpVtbl->HitTest(This,point,isHit) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_HitTestWithCoords(This,x,y,isHit) \
    ( (This)->lpVtbl->HitTestWithCoords(This,x,y,isHit) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_HitTestWithDescription(This,point,textLayoutRegion,isHit) \
    ( (This)->lpVtbl->HitTestWithDescription(This,point,textLayoutRegion,isHit) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_HitTestWithDescriptionAndCoords(This,x,y,textLayoutRegion,isHit) \
    ( (This)->lpVtbl->HitTestWithDescriptionAndCoords(This,x,y,textLayoutRegion,isHit) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_HitTestWithDescriptionAndTrailingSide(This,point,textLayoutRegion,trailingSideOfCharacter,isHit) \
    ( (This)->lpVtbl->HitTestWithDescriptionAndTrailingSide(This,point,textLayoutRegion,trailingSideOfCharacter,isHit) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_HitTestWithDescriptionAndCoordsAndTrailingSide(This,x,y,textLayoutRegion,trailingSideOfCharacter,isHit) \
    ( (This)->lpVtbl->HitTestWithDescriptionAndCoordsAndTrailingSide(This,x,y,textLayoutRegion,trailingSideOfCharacter,isHit) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetCaretPosition(This,characterIndex,trailingSideOfCharacter,location) \
    ( (This)->lpVtbl->GetCaretPosition(This,characterIndex,trailingSideOfCharacter,location) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetCaretPositionWithDescription(This,characterIndex,trailingSideOfCharacter,textLayoutRegion,location) \
    ( (This)->lpVtbl->GetCaretPositionWithDescription(This,characterIndex,trailingSideOfCharacter,textLayoutRegion,location) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetCharacterRegions(This,characterIndex,characterCount,__hitTestDescriptionsSize,hitTestDescriptions) \
    ( (This)->lpVtbl->GetCharacterRegions(This,characterIndex,characterCount,__hitTestDescriptionsSize,hitTestDescriptions) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetPairKerning(This,characterIndex,hasPairKerning) \
    ( (This)->lpVtbl->GetPairKerning(This,characterIndex,hasPairKerning) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_SetPairKerning(This,characterIndex,characterCount,hasPairKerning) \
    ( (This)->lpVtbl->SetPairKerning(This,characterIndex,characterCount,hasPairKerning) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetLeadingCharacterSpacing(This,characterIndex,leadingSpacing) \
    ( (This)->lpVtbl->GetLeadingCharacterSpacing(This,characterIndex,leadingSpacing) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetTrailingCharacterSpacing(This,characterIndex,trailingSpacing) \
    ( (This)->lpVtbl->GetTrailingCharacterSpacing(This,characterIndex,trailingSpacing) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_GetMinimumCharacterAdvance(This,characterIndex,minimumAdvance) \
    ( (This)->lpVtbl->GetMinimumCharacterAdvance(This,characterIndex,minimumAdvance) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_SetCharacterSpacing(This,characterIndex,characterCount,leadingSpacing,trailingSpacing,minimumAdvance) \
    ( (This)->lpVtbl->SetCharacterSpacing(This,characterIndex,characterCount,leadingSpacing,trailingSpacing,minimumAdvance) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_VerticalGlyphOrientation(This,value) \
    ( (This)->lpVtbl->get_VerticalGlyphOrientation(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_VerticalGlyphOrientation(This,value) \
    ( (This)->lpVtbl->put_VerticalGlyphOrientation(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_OpticalAlignment(This,value) \
    ( (This)->lpVtbl->get_OpticalAlignment(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_OpticalAlignment(This,value) \
    ( (This)->lpVtbl->put_OpticalAlignment(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_LastLineWrapping(This,value) \
    ( (This)->lpVtbl->get_LastLineWrapping(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_put_LastLineWrapping(This,value) \
    ( (This)->lpVtbl->put_LastLineWrapping(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_get_Device(This,value) \
    ( (This)->lpVtbl->get_Device(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextLayoutFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextLayout
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextLayoutFactory[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextLayoutFactory";
/* [object, version, uuid("9C1F7179-ACD0-4680-93D5-95A6247E8F6B"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *Create )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */HSTRING textString,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * textFormat,
        /* [in] */FLOAT requestedWidth,
        /* [in] */FLOAT requestedHeight,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * * canvasTextLayout
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactoryVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_Create(This,resourceCreator,textString,textFormat,requestedWidth,requestedHeight,canvasTextLayout) \
    ( (This)->lpVtbl->Create(This,resourceCreator,textString,textFormat,requestedWidth,requestedHeight,canvasTextLayout) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextLayoutStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextLayout
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextLayoutStatics[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextLayoutStatics";
/* [object, version, uuid("7F2B8FFD-6935-4F60-B409-6394A19C5EBC"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *GetGlyphOrientationTransform )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphOrientation glyphOrientation,
        /* [in] */boolean isSideways,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 position,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 * transform
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStaticsVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_GetGlyphOrientationTransform(This,glyphOrientation,isSideways,position,transform) \
    ( (This)->lpVtbl->GetGlyphOrientationTransform(This,glyphOrientation,isSideways,position,transform) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayoutStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextRenderer
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextRenderer[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextRenderer";
/* [object, version, uuid("9AAEECE5-8D09-4A64-B322-AF030421B2E4")] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRendererVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *DrawGlyphRun )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * fontFace,
        /* [in] */FLOAT fontSize,
        /* [in] */UINT32 __glyphsSize,
        /* [size_is(__glyphsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * glyphs,
        /* [in] */boolean isSideways,
        /* [in] */UINT32 bidiLevel,
        /* [in] */IInspectable * brush,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextMeasuringMode measuringMode,
        /* [in] */HSTRING localeName,
        /* [in] */HSTRING textString,
        /* [in] */UINT32 __clusterMapIndicesSize,
        /* [size_is(__clusterMapIndicesSize), in] */INT32 * clusterMapIndices,
        /* [in] */UINT32 characterIndex,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphOrientation glyphOrientation
        );
    HRESULT ( STDMETHODCALLTYPE *DrawStrikethrough )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */FLOAT strikethroughWidth,
        /* [in] */FLOAT strikethroughThickness,
        /* [in] */FLOAT strikethroughOffset,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextDirection textDirection,
        /* [in] */IInspectable * brush,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextMeasuringMode textMeasuringMode,
        /* [in] */HSTRING localeName,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphOrientation glyphOrientation
        );
    HRESULT ( STDMETHODCALLTYPE *DrawUnderline )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */FLOAT underlineWidth,
        /* [in] */FLOAT underlineThickness,
        /* [in] */FLOAT underlineOffset,
        /* [in] */FLOAT runHeight,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextDirection textDirection,
        /* [in] */IInspectable * brush,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextMeasuringMode textMeasuringMode,
        /* [in] */HSTRING localeName,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphOrientation glyphOrientation
        );
    HRESULT ( STDMETHODCALLTYPE *DrawInlineObject )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextInlineObject * inlineObject,
        /* [in] */boolean isSideways,
        /* [in] */boolean isRightToLeft,
        /* [in] */IInspectable * brush,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphOrientation glyphOrientation
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_PixelSnappingDisabled )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer * This,
        /* [retval, out] */boolean * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Transform )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Dpi )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer * This,
        /* [retval, out] */FLOAT * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRendererVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRendererVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_DrawGlyphRun(This,point,fontFace,fontSize,__glyphsSize,glyphs,isSideways,bidiLevel,brush,measuringMode,localeName,textString,__clusterMapIndicesSize,clusterMapIndices,characterIndex,glyphOrientation) \
    ( (This)->lpVtbl->DrawGlyphRun(This,point,fontFace,fontSize,__glyphsSize,glyphs,isSideways,bidiLevel,brush,measuringMode,localeName,textString,__clusterMapIndicesSize,clusterMapIndices,characterIndex,glyphOrientation) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_DrawStrikethrough(This,point,strikethroughWidth,strikethroughThickness,strikethroughOffset,textDirection,brush,textMeasuringMode,localeName,glyphOrientation) \
    ( (This)->lpVtbl->DrawStrikethrough(This,point,strikethroughWidth,strikethroughThickness,strikethroughOffset,textDirection,brush,textMeasuringMode,localeName,glyphOrientation) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_DrawUnderline(This,point,underlineWidth,underlineThickness,underlineOffset,runHeight,textDirection,brush,textMeasuringMode,localeName,glyphOrientation) \
    ( (This)->lpVtbl->DrawUnderline(This,point,underlineWidth,underlineThickness,underlineOffset,runHeight,textDirection,brush,textMeasuringMode,localeName,glyphOrientation) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_DrawInlineObject(This,point,inlineObject,isSideways,isRightToLeft,brush,glyphOrientation) \
    ( (This)->lpVtbl->DrawInlineObject(This,point,inlineObject,isSideways,isRightToLeft,brush,glyphOrientation) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_get_PixelSnappingDisabled(This,value) \
    ( (This)->lpVtbl->get_PixelSnappingDisabled(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_get_Transform(This,value) \
    ( (This)->lpVtbl->get_Transform(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_get_Dpi(This,value) \
    ( (This)->lpVtbl->get_Dpi(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderer_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextRenderingParameters
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextRenderingParameters
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextRenderingParameters[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextRenderingParameters";
/* [object, version, uuid("B20BF738-EDB9-4EEC-A12F-B6AE32E8ACE6"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_RenderingMode )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextRenderingMode * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_GridFit )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextGridFit * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_get_RenderingMode(This,value) \
    ( (This)->lpVtbl->get_RenderingMode(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_get_GridFit(This,value) \
    ( (This)->lpVtbl->get_GridFit(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTextRenderingParametersFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTextRenderingParameters
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTextRenderingParametersFactory[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTextRenderingParametersFactory";
/* [object, version, uuid("D240AC25-4D23-4964-9D9A-DB2FC8AF185D"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *Create )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextRenderingMode textRenderingMode,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextGridFit gridFit,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters * * textRenderingParameters
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactoryVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_Create(This,textRenderingMode,gridFit,textRenderingParameters) \
    ( (This)->lpVtbl->Create(This,textRenderingMode,gridFit,textRenderingParameters) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParametersFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Text.ICanvasTypography
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Text.CanvasTypography
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Text_ICanvasTypography[] = L"Microsoft.Graphics.Canvas.Text.ICanvasTypography";
/* [object, version, uuid("F15BC312-447F-44ED-8BEC-7E40F4A4DFC8"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypographyVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload] */HRESULT ( STDMETHODCALLTYPE *AddFeature )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTypographyFeature feature
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *AddFeatureWithNameAndParameter )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTypographyFeatureName name,
        /* [in] */UINT32 parameter
        );
    HRESULT ( STDMETHODCALLTYPE *GetFeatures )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography * This,
        /* [out] */UINT32 * __featuresSize,
        /* [size_is(, *(__featuresSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTypographyFeature * * features
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypographyVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypographyVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_AddFeature(This,feature) \
    ( (This)->lpVtbl->AddFeature(This,feature) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_AddFeatureWithNameAndParameter(This,name,parameter) \
    ( (This)->lpVtbl->AddFeatureWithNameAndParameter(This,name,parameter) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_GetFeatures(This,__featuresSize,features) \
    ( (This)->lpVtbl->GetFeatures(This,__featuresSize,features) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTypography_INTERFACE_DEFINED__) */


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasFontFace
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasFontFace ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasFontFace_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasFontFace_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasFontFace[] = L"Microsoft.Graphics.Canvas.Text.CanvasFontFace";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasFontSet
 *
 * RuntimeClass can be activated.
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasFontSet ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasFontSet_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasFontSet_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasFontSet[] = L"Microsoft.Graphics.Canvas.Text.CanvasFontSet";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasNumberSubstitution
 *
 * RuntimeClass can be activated.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasNumberSubstitution ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasNumberSubstitution_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasNumberSubstitution_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasNumberSubstitution[] = L"Microsoft.Graphics.Canvas.Text.CanvasNumberSubstitution";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasScaledFont
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasScaledFont ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasScaledFont_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasScaledFont_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasScaledFont[] = L"Microsoft.Graphics.Canvas.Text.CanvasScaledFont";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasTextAnalyzer
 *
 * RuntimeClass can be activated.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasTextAnalyzer ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTextAnalyzer_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTextAnalyzer_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasTextAnalyzer[] = L"Microsoft.Graphics.Canvas.Text.CanvasTextAnalyzer";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasTextFormat
 *
 * RuntimeClass can be activated.
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasTextFormat ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTextFormat_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTextFormat_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasTextFormat[] = L"Microsoft.Graphics.Canvas.Text.CanvasTextFormat";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasTextLayout
 *
 * RuntimeClass can be activated.
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasTextLayout ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTextLayout_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTextLayout_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasTextLayout[] = L"Microsoft.Graphics.Canvas.Text.CanvasTextLayout";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasTextRenderingParameters
 *
 * RuntimeClass can be activated.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasTextRenderingParameters ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTextRenderingParameters_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTextRenderingParameters_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasTextRenderingParameters[] = L"Microsoft.Graphics.Canvas.Text.CanvasTextRenderingParameters";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Text.CanvasTypography
 *
 * RuntimeClass can be activated.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Text.ICanvasTypography ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTypography_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Text_CanvasTypography_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Text_CanvasTypography[] = L"Microsoft.Graphics.Canvas.Text.CanvasTypography";
#endif





#endif // defined(__cplusplus)
#pragma pop_macro("MIDL_CONST_ID")
// Restore the original value of the 'DEPRECATED' macro
#pragma pop_macro("DEPRECATED")

#ifdef __clang__
#pragma clang diagnostic pop // deprecated-declarations
#else
#pragma warning(pop)
#endif
#endif // __microsoft2Egraphics2Ecanvas2Etext_p_h__

#endif // __microsoft2Egraphics2Ecanvas2Etext_h__
