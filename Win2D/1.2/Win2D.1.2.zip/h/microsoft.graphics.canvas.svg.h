
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

/* verify that the <rpcsal.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCSAL_H_VERSION__
#define __REQUIRED_RPCSAL_H_VERSION__ 100
#endif

#include <rpc.h>
#include <rpcndr.h>

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include <windows.h>
#include <ole2.h>
#endif /*COM_NO_WINDOWS_H*/
#ifndef __microsoft2Egraphics2Ecanvas2Esvg_h__
#define __microsoft2Egraphics2Ecanvas2Esvg_h__
#ifndef __microsoft2Egraphics2Ecanvas2Esvg_p_h__
#define __microsoft2Egraphics2Ecanvas2Esvg_p_h__


#pragma once

//
// Deprecated attribute support
//

#pragma push_macro("DEPRECATED")
#undef DEPRECATED

#if !defined(DISABLE_WINRT_DEPRECATION)
#if defined(__cplusplus)
#if __cplusplus >= 201402
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#elif defined(_MSC_VER)
#if _MSC_VER >= 1900
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#else
#define DEPRECATED(x) __declspec(deprecated(x))
#define DEPRECATEDENUMERATOR(x)
#endif // _MSC_VER >= 1900
#else // Not Standard C++ or MSVC, ignore the construct.
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  // C++ deprecation
#else // C - disable deprecation
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif
#else // Deprecation is disabled
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  /* DEPRECATED */

// Disable Deprecation for this header, MIDL verifies that cross-type access is acceptable
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#else
#pragma warning(push)
#pragma warning(disable: 4996)
#endif

// Ensure that the setting of the /ns_prefix command line switch is consistent for all headers.
// If you get an error from the compiler indicating "warning C4005: 'CHECK_NS_PREFIX_STATE': macro redefinition", this
// indicates that you have included two different headers with different settings for the /ns_prefix MIDL command line switch
#if !defined(DISABLE_NS_PREFIX_CHECKS)
#define CHECK_NS_PREFIX_STATE "always"
#endif // !defined(DISABLE_NS_PREFIX_CHECKS)


#pragma push_macro("MIDL_CONST_ID")
#undef MIDL_CONST_ID
#define MIDL_CONST_ID const __declspec(selectany)


//  API Contract Inclusion Definitions
#if !defined(SPECIFIC_API_CONTRACT_DEFINITIONS)
#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION 0x50000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION)
#define WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION)
#define WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION)
#define WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION)
#define WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION 0x60000
#endif // defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION)
#define WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)
#define WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)
#define WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION 0x130000
#endif // defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)

#if !defined(WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION)
#define WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION)

#if !defined(WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION)
#define WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION)
#define WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION)
#define WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION)
#define WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION)
#define WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)
#define WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)
#define WINDOWS_PHONE_PHONECONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)
#define WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)

#if !defined(WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION)
#define WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION 0x50000
#endif // defined(WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION)

#if !defined(WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION)
#define WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION)

#if !defined(WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION)
#define WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION)

#if !defined(WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION)
#define WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION)

#if !defined(WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION)
#define WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION)

#if !defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)
#define WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)

#endif // defined(SPECIFIC_API_CONTRACT_DEFINITIONS)


// Header files for imported files
#include "inspectable.h"
#include "AsyncInfo.h"
#include "EventToken.h"
#include "Windows.Foundation.h"
#include "Microsoft.Graphics.Canvas.h"
#include "Microsoft.Graphics.Canvas.Geometry.h"
#include "Windows.Foundation.Numerics.h"
#include "Windows.Storage.Streams.h"
#include "Windows.UI.h"
// Importing Collections header
#include <windows.foundation.collections.h>

#if defined(__cplusplus) && !defined(CINTERFACE)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    interface ICanvasSvgAttribute;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgAttribute

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    interface ICanvasSvgDocument;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgDocument

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    interface ICanvasSvgDocumentFactory;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgDocumentFactory

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    interface ICanvasSvgDocumentStatics;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgDocumentStatics

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    interface ICanvasSvgElement;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgElement

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    interface ICanvasSvgNamedElement;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgNamedElement

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    interface ICanvasSvgPaintAttribute;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgPaintAttribute

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    interface ICanvasSvgPathAttribute;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgPathAttribute

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    interface ICanvasSvgPointsAttribute;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgPointsAttribute

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    interface ICanvasSvgStrokeDashArrayAttribute;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgStrokeDashArrayAttribute

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    interface ICanvasSvgTextElement;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgTextElement

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_FWD_DEFINED__

// Parameterized interface forward declarations (C++)

// Collection interface definitions
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    class CanvasSvgDocument;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */



#ifndef DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_USE
#define DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("45ebe17c-efb1-5ba2-9280-84134cea38f9"))
IAsyncOperationCompletedHandler<ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgDocument*> : IAsyncOperationCompletedHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgDocument*, ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgDocument*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationCompletedHandler`1<Microsoft.Graphics.Canvas.Svg.CanvasSvgDocument>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationCompletedHandler<ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgDocument*> __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_t;
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument ABI::Windows::Foundation::__FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgDocument*>
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_t ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgDocument*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_USE */





#ifndef DEF___FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_USE
#define DEF___FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("63adbeeb-f748-5aec-a9d3-5fd731b2bc67"))
IAsyncOperation<ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgDocument*> : IAsyncOperation_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgDocument*, ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgDocument*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IAsyncOperation`1<Microsoft.Graphics.Canvas.Svg.CanvasSvgDocument>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperation<ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgDocument*> __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_t;
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument ABI::Windows::Foundation::__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgDocument*>
//#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_t ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgDocument*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_USE */



namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    class CanvasSvgNamedElement;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */



#ifndef DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_USE
#define DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("76b5a817-1bef-5f3e-91bb-5697a3ba6e51"))
IAsyncOperationCompletedHandler<ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgNamedElement*> : IAsyncOperationCompletedHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgNamedElement*, ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgNamedElement*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationCompletedHandler`1<Microsoft.Graphics.Canvas.Svg.CanvasSvgNamedElement>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationCompletedHandler<ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgNamedElement*> __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_t;
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement ABI::Windows::Foundation::__FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgNamedElement*>
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_t ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgNamedElement*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_USE */





#ifndef DEF___FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_USE
#define DEF___FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("68a752f6-827a-5816-8e65-0b3342673075"))
IAsyncOperation<ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgNamedElement*> : IAsyncOperation_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgNamedElement*, ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgNamedElement*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IAsyncOperation`1<Microsoft.Graphics.Canvas.Svg.CanvasSvgNamedElement>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperation<ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgNamedElement*> __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_t;
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement ABI::Windows::Foundation::__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgNamedElement*>
//#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_t ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgNamedElement*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_USE */





namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                class CanvasDevice;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasDevice;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice ABI::Microsoft::Graphics::Canvas::ICanvasDevice

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasEdgeBehavior : int CanvasEdgeBehavior;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */




namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef enum CanvasCapStyle : int CanvasCapStyle;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef enum CanvasFilledRegionDetermination : int CanvasFilledRegionDetermination;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    class CanvasGeometry;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    interface ICanvasGeometry;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef enum CanvasLineJoin : int CanvasLineJoin;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */





#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasResourceCreator;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__





#ifndef ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Foundation {
            interface IAsyncAction;
        } /* Foundation */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CFoundation_CIAsyncAction ABI::Windows::Foundation::IAsyncAction

#endif // ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__


#ifndef ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Foundation {
            interface IClosable;
        } /* Foundation */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CFoundation_CIClosable ABI::Windows::Foundation::IClosable

#endif // ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__




namespace ABI {
    namespace Windows {
        namespace Foundation {
            namespace Numerics {
                
                typedef struct Matrix3x2 Matrix3x2;
                
            } /* Numerics */
        } /* Foundation */
    } /* Windows */
} /* ABI */

namespace ABI {
    namespace Windows {
        namespace Foundation {
            namespace Numerics {
                
                typedef struct Vector2 Vector2;
                
            } /* Numerics */
        } /* Foundation */
    } /* Windows */
} /* ABI */




namespace ABI {
    namespace Windows {
        namespace Foundation {
            
            typedef struct Rect Rect;
            
        } /* Foundation */
    } /* Windows */
} /* ABI */



#ifndef ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream_FWD_DEFINED__
#define ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Storage {
            namespace Streams {
                interface IRandomAccessStream;
            } /* Streams */
        } /* Storage */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream ABI::Windows::Storage::Streams::IRandomAccessStream

#endif // ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream_FWD_DEFINED__





namespace ABI {
    namespace Windows {
        namespace UI {
            
            typedef struct Color Color;
            
        } /* UI */
    } /* Windows */
} /* ABI */



namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    
                    typedef enum CanvasSvgAspectAlignment : int CanvasSvgAspectAlignment;
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    
                    typedef enum CanvasSvgAspectScaling : int CanvasSvgAspectScaling;
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    
                    typedef enum CanvasSvgDisplay : int CanvasSvgDisplay;
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    
                    typedef enum CanvasSvgLengthUnits : int CanvasSvgLengthUnits;
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    
                    typedef enum CanvasSvgOverflow : int CanvasSvgOverflow;
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    
                    typedef enum CanvasSvgPaintType : int CanvasSvgPaintType;
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    
                    typedef enum CanvasSvgPathCommand : int CanvasSvgPathCommand;
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    
                    typedef enum CanvasSvgUnits : int CanvasSvgUnits;
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    
                    typedef enum CanvasSvgVisibility : int CanvasSvgVisibility;
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */














namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    class CanvasSvgPaintAttribute;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    class CanvasSvgPathAttribute;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    class CanvasSvgPointsAttribute;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    class CanvasSvgStrokeDashArrayAttribute;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    class CanvasSvgTextElement;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */












/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgAspectAlignment
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [v1_enum, version] */
                    enum CanvasSvgAspectAlignment : int
                    {
                        CanvasSvgAspectAlignment_None = 0,
                        CanvasSvgAspectAlignment_XMinYMin = 1,
                        CanvasSvgAspectAlignment_XMidYMin = 2,
                        CanvasSvgAspectAlignment_XMaxYMin = 3,
                        CanvasSvgAspectAlignment_XMinYMid = 4,
                        CanvasSvgAspectAlignment_XMidYMid = 5,
                        CanvasSvgAspectAlignment_XMaxYMid = 6,
                        CanvasSvgAspectAlignment_XMinYMax = 7,
                        CanvasSvgAspectAlignment_XMidYMax = 8,
                        CanvasSvgAspectAlignment_XMaxYMax = 9,
                    };
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgAspectScaling
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [v1_enum, version] */
                    enum CanvasSvgAspectScaling : int
                    {
                        CanvasSvgAspectScaling_Meet = 0,
                        CanvasSvgAspectScaling_Slice = 1,
                    };
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgDisplay
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [v1_enum, version] */
                    enum CanvasSvgDisplay : int
                    {
                        CanvasSvgDisplay_Inline = 0,
                        CanvasSvgDisplay_None = 1,
                    };
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgLengthUnits
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [v1_enum, version] */
                    enum CanvasSvgLengthUnits : int
                    {
                        CanvasSvgLengthUnits_Number = 0,
                        CanvasSvgLengthUnits_Percentage = 1,
                    };
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgOverflow
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [v1_enum, version] */
                    enum CanvasSvgOverflow : int
                    {
                        CanvasSvgOverflow_DoNotClipToViewport = 0,
                        CanvasSvgOverflow_ClipToViewport = 1,
                    };
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgPaintType
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [v1_enum, version] */
                    enum CanvasSvgPaintType : int
                    {
                        CanvasSvgPaintType_None = 0,
                        CanvasSvgPaintType_Color = 1,
                        CanvasSvgPaintType_CurrentColor = 2,
                        CanvasSvgPaintType_Uri = 3,
                        CanvasSvgPaintType_UriThenNone = 4,
                        CanvasSvgPaintType_UriThenColor = 5,
                        CanvasSvgPaintType_UriThenCurrentColor = 6,
                    };
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgPathCommand
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [v1_enum, version] */
                    enum CanvasSvgPathCommand : int
                    {
                        CanvasSvgPathCommand_ClosePath = 0,
                        CanvasSvgPathCommand_MoveAbsolute = 1,
                        CanvasSvgPathCommand_MoveRelative = 2,
                        CanvasSvgPathCommand_LineAbsolute = 3,
                        CanvasSvgPathCommand_LineRelative = 4,
                        CanvasSvgPathCommand_CubicAbsolute = 5,
                        CanvasSvgPathCommand_CubicRelative = 6,
                        CanvasSvgPathCommand_QuadraticAbsolute = 7,
                        CanvasSvgPathCommand_QuadraticRelative = 8,
                        CanvasSvgPathCommand_ArcAbsolute = 9,
                        CanvasSvgPathCommand_ArcRelative = 10,
                        CanvasSvgPathCommand_HorizontalAbsolute = 11,
                        CanvasSvgPathCommand_HorizontalRelative = 12,
                        CanvasSvgPathCommand_VerticalAbsolute = 13,
                        CanvasSvgPathCommand_VerticalRelative = 14,
                        CanvasSvgPathCommand_CubicSmoothAbsolute = 15,
                        CanvasSvgPathCommand_CubicSmoothRelative = 16,
                        CanvasSvgPathCommand_QuadraticSmoothAbsolute = 17,
                        CanvasSvgPathCommand_QuadraticSmoothRelative = 18,
                    };
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgUnits
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [v1_enum, version] */
                    enum CanvasSvgUnits : int
                    {
                        CanvasSvgUnits_UserSpaceOnUse = 0,
                        CanvasSvgUnits_ObjectBoundingBox = 1,
                    };
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgVisibility
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [v1_enum, version] */
                    enum CanvasSvgVisibility : int
                    {
                        CanvasSvgVisibility_Visible = 0,
                        CanvasSvgVisibility_Hidden = 1,
                    };
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgAttribute[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [object, version, uuid("652786A8-F3AB-4083-991D-9748AA86BD6E")] */
                    MIDL_INTERFACE("652786A8-F3AB-4083-991D-9748AA86BD6E")
                    ICanvasSvgAttribute : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE Clone(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgAttribute * * result
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetElement(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgNamedElement * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Device(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasSvgAttribute=__uuidof(ICanvasSvgAttribute);
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgDocument
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgDocument
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgDocument[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgDocument";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [object, version, uuid("A0E34929-3551-44FE-A670-D9B3FD800516"), exclusiveto] */
                    MIDL_INTERFACE("A0E34929-3551-44FE-A670-D9B3FD800516")
                    ICanvasSvgDocument : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Device(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * * value
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetXml(
                            /* [retval, out] */HSTRING * xmlString
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SaveAsync(
                            /* [in] */ABI::Windows::Storage::Streams::IRandomAccessStream * stream,
                            /* [retval, out] */ABI::Windows::Foundation::IAsyncAction * * asyncAction
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Root(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgNamedElement * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Root(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgNamedElement * * value
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE FindElementById(
                            /* [in] */HSTRING id,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgNamedElement * * element
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreatePaintAttributeWithDefaults(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgPaintAttribute * * result
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreatePaintAttribute(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgPaintType paintType,
                            /* [in] */ABI::Windows::UI::Color color,
                            /* [in] */HSTRING id,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgPaintAttribute * * result
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreatePathAttributeWithDefaults(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgPathAttribute * * result
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreatePathAttribute(
                            /* [in] */UINT32 __segmentDataSize,
                            /* [size_is(__segmentDataSize), in] */FLOAT * segmentData,
                            /* [in] */UINT32 __commandsSize,
                            /* [size_is(__commandsSize), in] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgPathCommand * commands,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgPathAttribute * * result
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreatePointsAttributeWithDefaults(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgPointsAttribute * * result
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreatePointsAttribute(
                            /* [in] */UINT32 __pointsSize,
                            /* [size_is(__pointsSize), in] */ABI::Windows::Foundation::Numerics::Vector2 * points,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgPointsAttribute * * result
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateStrokeDashArrayAttributeWithDefaults(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgStrokeDashArrayAttribute * * result
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreateStrokeDashArrayAttribute(
                            /* [in] */UINT32 __dashValuesSize,
                            /* [size_is(__dashValuesSize), in] */FLOAT * dashValues,
                            /* [in] */UINT32 __unitValuesSize,
                            /* [size_is(__unitValuesSize), in] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgLengthUnits * unitValues,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgStrokeDashArrayAttribute * * result
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE LoadElementFromXml(
                            /* [in] */HSTRING xmlString,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgNamedElement * * svgElement
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE LoadElementAsync(
                            /* [in] */ABI::Windows::Storage::Streams::IRandomAccessStream * stream,
                            /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement * * svgElement
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasSvgDocument=__uuidof(ICanvasSvgDocument);
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgDocumentFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgDocument
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgDocumentFactory[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgDocumentFactory";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [object, version, uuid("BAB0F16D-4050-4EF6-8022-8A07E9E74A9D"), exclusiveto] */
                    MIDL_INTERFACE("BAB0F16D-4050-4EF6-8022-8A07E9E74A9D")
                    ICanvasSvgDocumentFactory : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE CreateEmpty(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgDocument * * canvasSvgDocument
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasSvgDocumentFactory=__uuidof(ICanvasSvgDocumentFactory);
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgDocumentStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgDocument
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgDocumentStatics[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgDocumentStatics";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [object, version, uuid("7740E748-CB9A-453F-A678-8B3B3A7254D3"), exclusiveto] */
                    MIDL_INTERFACE("7740E748-CB9A-453F-A678-8B3B3A7254D3")
                    ICanvasSvgDocumentStatics : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE LoadFromXml(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [in] */HSTRING xmlString,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgDocument * * svgDocument
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE LoadAsync(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [in] */ABI::Windows::Storage::Streams::IRandomAccessStream * stream,
                            /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument * * svgDocument
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE IsSupported(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * device,
                            /* [retval, out] */::boolean * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasSvgDocumentStatics=__uuidof(ICanvasSvgDocumentStatics);
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgElement
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgElement[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgElement";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [object, version, uuid("0775CB81-C555-45BF-9795-0FF59151C3BE")] */
                    MIDL_INTERFACE("0775CB81-C555-45BF-9795-0FF59151C3BE")
                    ICanvasSvgElement : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_ContainingDocument(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgDocument * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Parent(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgNamedElement * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Device(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasSvgElement=__uuidof(ICanvasSvgElement);
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgNamedElement
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgNamedElement
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Microsoft.Graphics.Canvas.Svg.ICanvasSvgElement
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgNamedElement[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgNamedElement";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [object, version, uuid("D8B7CB94-8167-495D-9C71-5E97E5D08D2B"), exclusiveto] */
                    MIDL_INTERFACE("D8B7CB94-8167-495D-9C71-5E97E5D08D2B")
                    ICanvasSvgNamedElement : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE AppendChild(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgElement * child
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE CreateAndAppendNamedChildElement(
                            /* [in] */HSTRING childName,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgNamedElement * * childElement
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE CreateAndAppendTextChildElement(
                            /* [in] */HSTRING textContent,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgTextElement * * childElement
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_FirstChild(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgElement * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LastChild(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgElement * * value
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetPreviousSibling(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgElement * child,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgElement * * value
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetNextSibling(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgElement * child,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgElement * * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_SpecifiedAttributes(
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */HSTRING * * valueElements
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Tag(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_HasChildren(
                            /* [retval, out] */::boolean * value
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE InsertChildBefore(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgElement * child,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgElement * referenceChild
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE IsAttributeSpecified(
                            /* [in] */HSTRING attributeName,
                            /* [retval, out] */::boolean * value
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE IsAttributeSpecifiedWithInherhited(
                            /* [in] */HSTRING attributeName,
                            /* [in] */::boolean inherited,
                            /* [retval, out] */::boolean * value
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE RemoveAttribute(
                            /* [in] */HSTRING attributeName
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE RemoveChild(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgElement * child
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE ReplaceChild(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgElement * newChild,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgElement * oldChild
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetStringAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [in] */HSTRING attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetStringAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [retval, out] */HSTRING * attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgAttribute * attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgAttribute * * attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetIdAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [in] */HSTRING attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetIdAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [retval, out] */HSTRING * attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetFloatAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [in] */FLOAT attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetFloatAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [retval, out] */FLOAT * attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetColorAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [in] */ABI::Windows::UI::Color attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetColorAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [retval, out] */ABI::Windows::UI::Color * attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetFilledRegionDeterminationAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasFilledRegionDetermination attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetFilledRegionDeterminationAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasFilledRegionDetermination * attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetDisplayAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgDisplay attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetDisplayAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgDisplay * attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetOverflowAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgOverflow attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetOverflowAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgOverflow * attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetCapStyleAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasCapStyle attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetCapStyleAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasCapStyle * attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetLineJoinAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasLineJoin attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetLineJoinAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasLineJoin * attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetVisibilityAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgVisibility attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetVisibilityAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgVisibility * attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetTransformAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetTransformAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [retval, out] */ABI::Windows::Foundation::Numerics::Matrix3x2 * attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetUnitsAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgUnits attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetUnitsAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgUnits * attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetEdgeBehaviorAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasEdgeBehavior attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetEdgeBehaviorAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::CanvasEdgeBehavior * attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetRectangleAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [in] */ABI::Windows::Foundation::Rect attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetRectangleAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [retval, out] */ABI::Windows::Foundation::Rect * attributeValue
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetLengthAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [in] */FLOAT value,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgLengthUnits units
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetLengthAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [out] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgLengthUnits * units,
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetAspectRatioAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgAspectAlignment alignment,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgAspectScaling meetOrSlice
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetAspectRatioAttribute(
                            /* [in] */HSTRING attributeName,
                            /* [out] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgAspectScaling * meetOrSlice,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgAspectAlignment * alignment
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasSvgNamedElement=__uuidof(ICanvasSvgNamedElement);
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgPaintAttribute
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgPaintAttribute
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgPaintAttribute[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgPaintAttribute";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [object, version, uuid("653786A8-F3AB-4083-991D-9748AA86BD6E"), exclusiveto] */
                    MIDL_INTERFACE("653786A8-F3AB-4083-991D-9748AA86BD6E")
                    ICanvasSvgPaintAttribute : public IInspectable
                    {
                    public:
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_PaintType(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgPaintType value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_PaintType(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgPaintType * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Color(
                            /* [in] */ABI::Windows::UI::Color value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Color(
                            /* [retval, out] */ABI::Windows::UI::Color * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Id(
                            /* [in] */HSTRING value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Id(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasSvgPaintAttribute=__uuidof(ICanvasSvgPaintAttribute);
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgPathAttribute
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgPathAttribute
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgPathAttribute[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgPathAttribute";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [object, version, uuid("652786A8-F3AB-4083-991D-9748AB86BD6E"), exclusiveto] */
                    MIDL_INTERFACE("652786A8-F3AB-4083-991D-9748AB86BD6E")
                    ICanvasSvgPathAttribute : public IInspectable
                    {
                    public:
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreatePathGeometry(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * outputGeometry
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreatePathGeometryWithFill(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasFilledRegionDetermination fill,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * outputGeometry
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Commands(
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgPathCommand * * valueElements
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetCommands(
                            /* [in] */INT32 startIndex,
                            /* [in] */INT32 elementCount,
                            /* [out] */UINT32 * __outputValueElementsSize,
                            /* [size_is(, *(__outputValueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgPathCommand * * outputValueElements
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_SegmentData(
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */FLOAT * * valueElements
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetSegmentData(
                            /* [in] */INT32 startIndex,
                            /* [in] */INT32 elementCount,
                            /* [out] */UINT32 * __outputValueElementsSize,
                            /* [size_is(, *(__outputValueElementsSize)), retval, out] */FLOAT * * outputValueElements
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE RemoveCommandsAtEnd(
                            /* [in] */INT32 commandsCount
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE RemoveSegmentDataAtEnd(
                            /* [in] */INT32 commandsCount
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetCommands(
                            /* [in] */INT32 startIndex,
                            /* [in] */UINT32 __commandsSize,
                            /* [size_is(__commandsSize), in] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgPathCommand * commands
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetSegmentData(
                            /* [in] */INT32 startIndex,
                            /* [in] */UINT32 __segmentDataSize,
                            /* [size_is(__segmentDataSize), in] */FLOAT * segmentData
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasSvgPathAttribute=__uuidof(ICanvasSvgPathAttribute);
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgPointsAttribute
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgPointsAttribute
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgPointsAttribute[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgPointsAttribute";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [object, version, uuid("652786A8-F3AB-4083-991D-9748AA86BD6F"), exclusiveto] */
                    MIDL_INTERFACE("652786A8-F3AB-4083-991D-9748AA86BD6F")
                    ICanvasSvgPointsAttribute : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Points(
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Windows::Foundation::Numerics::Vector2 * * valueElements
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetPoints(
                            /* [in] */INT32 startIndex,
                            /* [in] */INT32 elementCount,
                            /* [out] */UINT32 * __outputValueElementsSize,
                            /* [size_is(, *(__outputValueElementsSize)), retval, out] */ABI::Windows::Foundation::Numerics::Vector2 * * outputValueElements
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE RemovePointsAtEnd(
                            /* [in] */INT32 pointCount
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetPoints(
                            /* [in] */INT32 startIndex,
                            /* [in] */UINT32 __pointsSize,
                            /* [size_is(__pointsSize), in] */ABI::Windows::Foundation::Numerics::Vector2 * points
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasSvgPointsAttribute=__uuidof(ICanvasSvgPointsAttribute);
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgStrokeDashArrayAttribute
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgStrokeDashArrayAttribute
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgStrokeDashArrayAttribute[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgStrokeDashArrayAttribute";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [object, version, uuid("652786A8-F3AB-4083-991D-9748AA86BD70"), exclusiveto] */
                    MIDL_INTERFACE("652786A8-F3AB-4083-991D-9748AA86BD70")
                    ICanvasSvgStrokeDashArrayAttribute : public IInspectable
                    {
                    public:
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetDashes(
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */FLOAT * * valueElements
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE GetDashesWithUnits(
                            /* [in] */INT32 startIndex,
                            /* [in] */INT32 elementCount,
                            /* [out] */UINT32 * __outputUnitsElementsSize,
                            /* [size_is(, *(__outputUnitsElementsSize)), out] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgLengthUnits * * outputUnitsElements,
                            /* [out] */UINT32 * __outputValueElementsSize,
                            /* [size_is(, *(__outputValueElementsSize)), retval, out] */FLOAT * * outputValueElements
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE RemoveDashesAtEnd(
                            /* [in] */INT32 dashCount
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE SetDashes(
                            /* [in] */INT32 startIndex,
                            /* [in] */UINT32 __dashesSize,
                            /* [size_is(__dashesSize), in] */FLOAT * dashes
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE SetDashesWithUnit(
                            /* [in] */INT32 startIndex,
                            /* [in] */UINT32 __dashesSize,
                            /* [size_is(__dashesSize), in] */FLOAT * dashes,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgLengthUnits units
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE SetDashesWithUnits(
                            /* [in] */INT32 startIndex,
                            /* [in] */UINT32 __dashValuesSize,
                            /* [size_is(__dashValuesSize), in] */FLOAT * dashValues,
                            /* [in] */UINT32 __unitValuesSize,
                            /* [size_is(__unitValuesSize), in] */ABI::Microsoft::Graphics::Canvas::Svg::CanvasSvgLengthUnits * unitValues
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasSvgStrokeDashArrayAttribute=__uuidof(ICanvasSvgStrokeDashArrayAttribute);
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgTextElement
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgTextElement
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgTextElement[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgTextElement";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    /* [object, version, uuid("652786A8-F3AB-4083-991D-9748AA86BD6D"), exclusiveto] */
                    MIDL_INTERFACE("652786A8-F3AB-4083-991D-9748AA86BD6D")
                    ICanvasSvgTextElement : public IInspectable
                    {
                    public:
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Text(
                            /* [in] */HSTRING value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Text(
                            /* [retval, out] */HSTRING * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasSvgTextElement=__uuidof(ICanvasSvgTextElement);
                    
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_INTERFACE_DEFINED__) */


/*
 *
 * Class Microsoft.Graphics.Canvas.Svg.CanvasSvgDocument
 *
 * RuntimeClass can be activated.
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgDocument ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgDocument_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgDocument_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Svg_CanvasSvgDocument[] = L"Microsoft.Graphics.Canvas.Svg.CanvasSvgDocument";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Svg.CanvasSvgNamedElement
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgNamedElement ** Default Interface **
 *    Windows.Foundation.IClosable
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgElement
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgNamedElement_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgNamedElement_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Svg_CanvasSvgNamedElement[] = L"Microsoft.Graphics.Canvas.Svg.CanvasSvgNamedElement";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Svg.CanvasSvgPaintAttribute
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgPaintAttribute ** Default Interface **
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgPaintAttribute_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgPaintAttribute_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Svg_CanvasSvgPaintAttribute[] = L"Microsoft.Graphics.Canvas.Svg.CanvasSvgPaintAttribute";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Svg.CanvasSvgPathAttribute
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgPathAttribute ** Default Interface **
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgPathAttribute_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgPathAttribute_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Svg_CanvasSvgPathAttribute[] = L"Microsoft.Graphics.Canvas.Svg.CanvasSvgPathAttribute";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Svg.CanvasSvgPointsAttribute
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgPointsAttribute ** Default Interface **
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgPointsAttribute_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgPointsAttribute_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Svg_CanvasSvgPointsAttribute[] = L"Microsoft.Graphics.Canvas.Svg.CanvasSvgPointsAttribute";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Svg.CanvasSvgStrokeDashArrayAttribute
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgStrokeDashArrayAttribute ** Default Interface **
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgStrokeDashArrayAttribute_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgStrokeDashArrayAttribute_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Svg_CanvasSvgStrokeDashArrayAttribute[] = L"Microsoft.Graphics.Canvas.Svg.CanvasSvgStrokeDashArrayAttribute";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Svg.CanvasSvgTextElement
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgTextElement ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgTextElement_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgTextElement_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Svg_CanvasSvgTextElement[] = L"Microsoft.Graphics.Canvas.Svg.CanvasSvgTextElement";
#endif





#else // !defined(__cplusplus)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_FWD_DEFINED__

// Parameterized interface forward declarations (C)

// Collection interface definitions

#if !defined(____FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_INTERFACE_DEFINED__)
#define ____FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument;

// Forward declare the async operation.
typedef interface __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument;

typedef struct __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocumentVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument * This,/* [in] */ __RPC__in_opt __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument *asyncInfo, /* [in] */ AsyncStatus status);
    END_INTERFACE
} __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocumentVtbl;

interface __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument
{
    CONST_VTBL struct __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocumentVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_Invoke(This,asyncInfo,status)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,status) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_INTERFACE_DEFINED__



#if !defined(____FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_INTERFACE_DEFINED__)
#define ____FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_INTERFACE_DEFINED__

typedef interface __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument;

typedef struct __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocumentVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument * This, /* [in] */ __RPC__in_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument **handler);
    HRESULT ( STDMETHODCALLTYPE *GetResults )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument * This, /* [retval][out] */ __RPC__out __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * *results);
    END_INTERFACE
} __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocumentVtbl;

interface __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument
{
    CONST_VTBL struct __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocumentVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_put_Completed(This,handler)	\
    ( (This)->lpVtbl -> put_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_get_Completed(This,handler)	\
    ( (This)->lpVtbl -> get_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_GetResults(This,results)	\
    ( (This)->lpVtbl -> GetResults(This,results) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument_INTERFACE_DEFINED__



#if !defined(____FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_INTERFACE_DEFINED__)
#define ____FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement;

// Forward declare the async operation.
typedef interface __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement;

typedef struct __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElementVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement * This,/* [in] */ __RPC__in_opt __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement *asyncInfo, /* [in] */ AsyncStatus status);
    END_INTERFACE
} __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElementVtbl;

interface __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement
{
    CONST_VTBL struct __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElementVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_Invoke(This,asyncInfo,status)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,status) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_INTERFACE_DEFINED__



#if !defined(____FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_INTERFACE_DEFINED__)
#define ____FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_INTERFACE_DEFINED__

typedef interface __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement;

typedef struct __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElementVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement * This, /* [in] */ __RPC__in_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement **handler);
    HRESULT ( STDMETHODCALLTYPE *GetResults )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement * This, /* [retval][out] */ __RPC__out __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * *results);
    END_INTERFACE
} __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElementVtbl;

interface __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement
{
    CONST_VTBL struct __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElementVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_put_Completed(This,handler)	\
    ( (This)->lpVtbl -> put_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_get_Completed(This,handler)	\
    ( (This)->lpVtbl -> get_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_GetResults(This,results)	\
    ( (This)->lpVtbl -> GetResults(This,results) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement_INTERFACE_DEFINED__



#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__



typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasEdgeBehavior __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasEdgeBehavior;





typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasCapStyle __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasCapStyle;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFilledRegionDetermination __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFilledRegionDetermination;

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__



typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasLineJoin __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasLineJoin;





#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__





#ifndef ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CFoundation_CIAsyncAction __x_ABI_CWindows_CFoundation_CIAsyncAction;

#endif // ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__


#ifndef ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CFoundation_CIClosable __x_ABI_CWindows_CFoundation_CIClosable;

#endif // ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__





typedef struct __x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 __x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2;


typedef struct __x_ABI_CWindows_CFoundation_CNumerics_CVector2 __x_ABI_CWindows_CFoundation_CNumerics_CVector2;





typedef struct __x_ABI_CWindows_CFoundation_CRect __x_ABI_CWindows_CFoundation_CRect;



#ifndef ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream_FWD_DEFINED__
#define ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream __x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream;

#endif // ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream_FWD_DEFINED__






typedef struct __x_ABI_CWindows_CUI_CColor __x_ABI_CWindows_CUI_CColor;




typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgAspectAlignment __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgAspectAlignment;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgAspectScaling __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgAspectScaling;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgDisplay __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgDisplay;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgLengthUnits __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgLengthUnits;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgOverflow __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgOverflow;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgPaintType __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgPaintType;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgPathCommand __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgPathCommand;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgUnits __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgUnits;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgVisibility __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgVisibility;





























/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgAspectAlignment
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgAspectAlignment
{
    CanvasSvgAspectAlignment_None = 0,
    CanvasSvgAspectAlignment_XMinYMin = 1,
    CanvasSvgAspectAlignment_XMidYMin = 2,
    CanvasSvgAspectAlignment_XMaxYMin = 3,
    CanvasSvgAspectAlignment_XMinYMid = 4,
    CanvasSvgAspectAlignment_XMidYMid = 5,
    CanvasSvgAspectAlignment_XMaxYMid = 6,
    CanvasSvgAspectAlignment_XMinYMax = 7,
    CanvasSvgAspectAlignment_XMidYMax = 8,
    CanvasSvgAspectAlignment_XMaxYMax = 9,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgAspectScaling
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgAspectScaling
{
    CanvasSvgAspectScaling_Meet = 0,
    CanvasSvgAspectScaling_Slice = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgDisplay
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgDisplay
{
    CanvasSvgDisplay_Inline = 0,
    CanvasSvgDisplay_None = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgLengthUnits
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgLengthUnits
{
    CanvasSvgLengthUnits_Number = 0,
    CanvasSvgLengthUnits_Percentage = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgOverflow
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgOverflow
{
    CanvasSvgOverflow_DoNotClipToViewport = 0,
    CanvasSvgOverflow_ClipToViewport = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgPaintType
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgPaintType
{
    CanvasSvgPaintType_None = 0,
    CanvasSvgPaintType_Color = 1,
    CanvasSvgPaintType_CurrentColor = 2,
    CanvasSvgPaintType_Uri = 3,
    CanvasSvgPaintType_UriThenNone = 4,
    CanvasSvgPaintType_UriThenColor = 5,
    CanvasSvgPaintType_UriThenCurrentColor = 6,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgPathCommand
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgPathCommand
{
    CanvasSvgPathCommand_ClosePath = 0,
    CanvasSvgPathCommand_MoveAbsolute = 1,
    CanvasSvgPathCommand_MoveRelative = 2,
    CanvasSvgPathCommand_LineAbsolute = 3,
    CanvasSvgPathCommand_LineRelative = 4,
    CanvasSvgPathCommand_CubicAbsolute = 5,
    CanvasSvgPathCommand_CubicRelative = 6,
    CanvasSvgPathCommand_QuadraticAbsolute = 7,
    CanvasSvgPathCommand_QuadraticRelative = 8,
    CanvasSvgPathCommand_ArcAbsolute = 9,
    CanvasSvgPathCommand_ArcRelative = 10,
    CanvasSvgPathCommand_HorizontalAbsolute = 11,
    CanvasSvgPathCommand_HorizontalRelative = 12,
    CanvasSvgPathCommand_VerticalAbsolute = 13,
    CanvasSvgPathCommand_VerticalRelative = 14,
    CanvasSvgPathCommand_CubicSmoothAbsolute = 15,
    CanvasSvgPathCommand_CubicSmoothRelative = 16,
    CanvasSvgPathCommand_QuadraticSmoothAbsolute = 17,
    CanvasSvgPathCommand_QuadraticSmoothRelative = 18,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgUnits
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgUnits
{
    CanvasSvgUnits_UserSpaceOnUse = 0,
    CanvasSvgUnits_ObjectBoundingBox = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Svg.CanvasSvgVisibility
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgVisibility
{
    CanvasSvgVisibility_Visible = 0,
    CanvasSvgVisibility_Hidden = 1,
};


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgAttribute[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute";
/* [object, version, uuid("652786A8-F3AB-4083-991D-9748AA86BD6E")] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttributeVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *Clone )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute * * result
        );
    HRESULT ( STDMETHODCALLTYPE *GetElement )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Device )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttributeVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttributeVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_Clone(This,result) \
    ( (This)->lpVtbl->Clone(This,result) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_GetElement(This,value) \
    ( (This)->lpVtbl->GetElement(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_get_Device(This,value) \
    ( (This)->lpVtbl->get_Device(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgDocument
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgDocument
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgDocument[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgDocument";
/* [object, version, uuid("A0E34929-3551-44FE-A670-D9B3FD800516"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Device )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * * value
        );
    HRESULT ( STDMETHODCALLTYPE *GetXml )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
        /* [retval, out] */HSTRING * xmlString
        );
    HRESULT ( STDMETHODCALLTYPE *SaveAsync )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream * stream,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CIAsyncAction * * asyncAction
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Root )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Root )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * * value
        );
    HRESULT ( STDMETHODCALLTYPE *FindElementById )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
        /* [in] */HSTRING id,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * * element
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreatePaintAttributeWithDefaults )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute * * result
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreatePaintAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgPaintType paintType,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */HSTRING id,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute * * result
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreatePathAttributeWithDefaults )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * * result
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreatePathAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
        /* [in] */UINT32 __segmentDataSize,
        /* [size_is(__segmentDataSize), in] */FLOAT * segmentData,
        /* [in] */UINT32 __commandsSize,
        /* [size_is(__commandsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgPathCommand * commands,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * * result
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreatePointsAttributeWithDefaults )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute * * result
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreatePointsAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
        /* [in] */UINT32 __pointsSize,
        /* [size_is(__pointsSize), in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 * points,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute * * result
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateStrokeDashArrayAttributeWithDefaults )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute * * result
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreateStrokeDashArrayAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
        /* [in] */UINT32 __dashValuesSize,
        /* [size_is(__dashValuesSize), in] */FLOAT * dashValues,
        /* [in] */UINT32 __unitValuesSize,
        /* [size_is(__unitValuesSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgLengthUnits * unitValues,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute * * result
        );
    HRESULT ( STDMETHODCALLTYPE *LoadElementFromXml )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
        /* [in] */HSTRING xmlString,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * * svgElement
        );
    HRESULT ( STDMETHODCALLTYPE *LoadElementAsync )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * This,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream * stream,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgNamedElement * * svgElement
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_get_Device(This,value) \
    ( (This)->lpVtbl->get_Device(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_GetXml(This,xmlString) \
    ( (This)->lpVtbl->GetXml(This,xmlString) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_SaveAsync(This,stream,asyncAction) \
    ( (This)->lpVtbl->SaveAsync(This,stream,asyncAction) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_put_Root(This,value) \
    ( (This)->lpVtbl->put_Root(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_get_Root(This,value) \
    ( (This)->lpVtbl->get_Root(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_FindElementById(This,id,element) \
    ( (This)->lpVtbl->FindElementById(This,id,element) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_CreatePaintAttributeWithDefaults(This,result) \
    ( (This)->lpVtbl->CreatePaintAttributeWithDefaults(This,result) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_CreatePaintAttribute(This,paintType,color,id,result) \
    ( (This)->lpVtbl->CreatePaintAttribute(This,paintType,color,id,result) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_CreatePathAttributeWithDefaults(This,result) \
    ( (This)->lpVtbl->CreatePathAttributeWithDefaults(This,result) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_CreatePathAttribute(This,__segmentDataSize,segmentData,__commandsSize,commands,result) \
    ( (This)->lpVtbl->CreatePathAttribute(This,__segmentDataSize,segmentData,__commandsSize,commands,result) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_CreatePointsAttributeWithDefaults(This,result) \
    ( (This)->lpVtbl->CreatePointsAttributeWithDefaults(This,result) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_CreatePointsAttribute(This,__pointsSize,points,result) \
    ( (This)->lpVtbl->CreatePointsAttribute(This,__pointsSize,points,result) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_CreateStrokeDashArrayAttributeWithDefaults(This,result) \
    ( (This)->lpVtbl->CreateStrokeDashArrayAttributeWithDefaults(This,result) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_CreateStrokeDashArrayAttribute(This,__dashValuesSize,dashValues,__unitValuesSize,unitValues,result) \
    ( (This)->lpVtbl->CreateStrokeDashArrayAttribute(This,__dashValuesSize,dashValues,__unitValuesSize,unitValues,result) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_LoadElementFromXml(This,xmlString,svgElement) \
    ( (This)->lpVtbl->LoadElementFromXml(This,xmlString,svgElement) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_LoadElementAsync(This,stream,svgElement) \
    ( (This)->lpVtbl->LoadElementAsync(This,stream,svgElement) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgDocumentFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgDocument
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgDocumentFactory[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgDocumentFactory";
/* [object, version, uuid("BAB0F16D-4050-4EF6-8022-8A07E9E74A9D"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateEmpty )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * * canvasSvgDocument
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactoryVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_CreateEmpty(This,resourceCreator,canvasSvgDocument) \
    ( (This)->lpVtbl->CreateEmpty(This,resourceCreator,canvasSvgDocument) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgDocumentStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgDocument
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgDocumentStatics[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgDocumentStatics";
/* [object, version, uuid("7740E748-CB9A-453F-A678-8B3B3A7254D3"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *LoadFromXml )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */HSTRING xmlString,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * * svgDocument
        );
    HRESULT ( STDMETHODCALLTYPE *LoadAsync )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream * stream,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CSvg__CCanvasSvgDocument * * svgDocument
        );
    HRESULT ( STDMETHODCALLTYPE *IsSupported )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * device,
        /* [retval, out] */boolean * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStaticsVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_LoadFromXml(This,resourceCreator,xmlString,svgDocument) \
    ( (This)->lpVtbl->LoadFromXml(This,resourceCreator,xmlString,svgDocument) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_LoadAsync(This,resourceCreator,stream,svgDocument) \
    ( (This)->lpVtbl->LoadAsync(This,resourceCreator,stream,svgDocument) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_IsSupported(This,device,value) \
    ( (This)->lpVtbl->IsSupported(This,device,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocumentStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgElement
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgElement[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgElement";
/* [object, version, uuid("0775CB81-C555-45BF-9795-0FF59151C3BE")] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElementVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_ContainingDocument )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Parent )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Device )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElementVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElementVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_get_ContainingDocument(This,value) \
    ( (This)->lpVtbl->get_ContainingDocument(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_get_Parent(This,value) \
    ( (This)->lpVtbl->get_Parent(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_get_Device(This,value) \
    ( (This)->lpVtbl->get_Device(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgNamedElement
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgNamedElement
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Microsoft.Graphics.Canvas.Svg.ICanvasSvgElement
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgNamedElement[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgNamedElement";
/* [object, version, uuid("D8B7CB94-8167-495D-9C71-5E97E5D08D2B"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElementVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *AppendChild )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * child
        );
    HRESULT ( STDMETHODCALLTYPE *CreateAndAppendNamedChildElement )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING childName,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * * childElement
        );
    HRESULT ( STDMETHODCALLTYPE *CreateAndAppendTextChildElement )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING textContent,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement * * childElement
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_FirstChild )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LastChild )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * * value
        );
    HRESULT ( STDMETHODCALLTYPE *GetPreviousSibling )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * child,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * * value
        );
    HRESULT ( STDMETHODCALLTYPE *GetNextSibling )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * child,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_SpecifiedAttributes )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */HSTRING * * valueElements
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Tag )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [retval, out] */HSTRING * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_HasChildren )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [retval, out] */boolean * value
        );
    HRESULT ( STDMETHODCALLTYPE *InsertChildBefore )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * child,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * referenceChild
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *IsAttributeSpecified )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [retval, out] */boolean * value
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *IsAttributeSpecifiedWithInherhited )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */boolean inherited,
        /* [retval, out] */boolean * value
        );
    HRESULT ( STDMETHODCALLTYPE *RemoveAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName
        );
    HRESULT ( STDMETHODCALLTYPE *RemoveChild )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * child
        );
    HRESULT ( STDMETHODCALLTYPE *ReplaceChild )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * newChild,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgElement * oldChild
        );
    HRESULT ( STDMETHODCALLTYPE *SetStringAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */HSTRING attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *GetStringAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [retval, out] */HSTRING * attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *SetAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute * attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *GetAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgAttribute * * attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *SetIdAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */HSTRING attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *GetIdAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [retval, out] */HSTRING * attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *SetFloatAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */FLOAT attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *GetFloatAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [retval, out] */FLOAT * attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *SetColorAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */__x_ABI_CWindows_CUI_CColor attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *GetColorAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [retval, out] */__x_ABI_CWindows_CUI_CColor * attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *SetFilledRegionDeterminationAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFilledRegionDetermination attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *GetFilledRegionDeterminationAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFilledRegionDetermination * attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *SetDisplayAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgDisplay attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *GetDisplayAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgDisplay * attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *SetOverflowAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgOverflow attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *GetOverflowAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgOverflow * attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *SetCapStyleAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasCapStyle attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *GetCapStyleAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasCapStyle * attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *SetLineJoinAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasLineJoin attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *GetLineJoinAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasLineJoin * attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *SetVisibilityAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgVisibility attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *GetVisibilityAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgVisibility * attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *SetTransformAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *GetTransformAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 * attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *SetUnitsAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgUnits attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *GetUnitsAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgUnits * attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *SetEdgeBehaviorAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasEdgeBehavior attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *GetEdgeBehaviorAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasEdgeBehavior * attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *SetRectangleAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *GetRectangleAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * attributeValue
        );
    HRESULT ( STDMETHODCALLTYPE *SetLengthAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */FLOAT value,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgLengthUnits units
        );
    HRESULT ( STDMETHODCALLTYPE *GetLengthAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgLengthUnits * units,
        /* [retval, out] */FLOAT * value
        );
    HRESULT ( STDMETHODCALLTYPE *SetAspectRatioAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgAspectAlignment alignment,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgAspectScaling meetOrSlice
        );
    HRESULT ( STDMETHODCALLTYPE *GetAspectRatioAttribute )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement * This,
        /* [in] */HSTRING attributeName,
        /* [out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgAspectScaling * meetOrSlice,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgAspectAlignment * alignment
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElementVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElementVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_AppendChild(This,child) \
    ( (This)->lpVtbl->AppendChild(This,child) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_CreateAndAppendNamedChildElement(This,childName,childElement) \
    ( (This)->lpVtbl->CreateAndAppendNamedChildElement(This,childName,childElement) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_CreateAndAppendTextChildElement(This,textContent,childElement) \
    ( (This)->lpVtbl->CreateAndAppendTextChildElement(This,textContent,childElement) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_get_FirstChild(This,value) \
    ( (This)->lpVtbl->get_FirstChild(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_get_LastChild(This,value) \
    ( (This)->lpVtbl->get_LastChild(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetPreviousSibling(This,child,value) \
    ( (This)->lpVtbl->GetPreviousSibling(This,child,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetNextSibling(This,child,value) \
    ( (This)->lpVtbl->GetNextSibling(This,child,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_get_SpecifiedAttributes(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->get_SpecifiedAttributes(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_get_Tag(This,value) \
    ( (This)->lpVtbl->get_Tag(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_get_HasChildren(This,value) \
    ( (This)->lpVtbl->get_HasChildren(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_InsertChildBefore(This,child,referenceChild) \
    ( (This)->lpVtbl->InsertChildBefore(This,child,referenceChild) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_IsAttributeSpecified(This,attributeName,value) \
    ( (This)->lpVtbl->IsAttributeSpecified(This,attributeName,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_IsAttributeSpecifiedWithInherhited(This,attributeName,inherited,value) \
    ( (This)->lpVtbl->IsAttributeSpecifiedWithInherhited(This,attributeName,inherited,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_RemoveAttribute(This,attributeName) \
    ( (This)->lpVtbl->RemoveAttribute(This,attributeName) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_RemoveChild(This,child) \
    ( (This)->lpVtbl->RemoveChild(This,child) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_ReplaceChild(This,newChild,oldChild) \
    ( (This)->lpVtbl->ReplaceChild(This,newChild,oldChild) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_SetStringAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->SetStringAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetStringAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->GetStringAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_SetAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->SetAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->GetAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_SetIdAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->SetIdAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetIdAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->GetIdAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_SetFloatAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->SetFloatAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetFloatAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->GetFloatAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_SetColorAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->SetColorAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetColorAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->GetColorAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_SetFilledRegionDeterminationAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->SetFilledRegionDeterminationAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetFilledRegionDeterminationAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->GetFilledRegionDeterminationAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_SetDisplayAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->SetDisplayAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetDisplayAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->GetDisplayAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_SetOverflowAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->SetOverflowAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetOverflowAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->GetOverflowAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_SetCapStyleAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->SetCapStyleAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetCapStyleAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->GetCapStyleAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_SetLineJoinAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->SetLineJoinAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetLineJoinAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->GetLineJoinAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_SetVisibilityAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->SetVisibilityAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetVisibilityAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->GetVisibilityAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_SetTransformAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->SetTransformAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetTransformAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->GetTransformAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_SetUnitsAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->SetUnitsAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetUnitsAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->GetUnitsAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_SetEdgeBehaviorAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->SetEdgeBehaviorAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetEdgeBehaviorAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->GetEdgeBehaviorAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_SetRectangleAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->SetRectangleAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetRectangleAttribute(This,attributeName,attributeValue) \
    ( (This)->lpVtbl->GetRectangleAttribute(This,attributeName,attributeValue) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_SetLengthAttribute(This,attributeName,value,units) \
    ( (This)->lpVtbl->SetLengthAttribute(This,attributeName,value,units) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetLengthAttribute(This,attributeName,units,value) \
    ( (This)->lpVtbl->GetLengthAttribute(This,attributeName,units,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_SetAspectRatioAttribute(This,attributeName,alignment,meetOrSlice) \
    ( (This)->lpVtbl->SetAspectRatioAttribute(This,attributeName,alignment,meetOrSlice) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_GetAspectRatioAttribute(This,attributeName,meetOrSlice,alignment) \
    ( (This)->lpVtbl->GetAspectRatioAttribute(This,attributeName,meetOrSlice,alignment) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgNamedElement_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgPaintAttribute
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgPaintAttribute
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgPaintAttribute[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgPaintAttribute";
/* [object, version, uuid("653786A8-F3AB-4083-991D-9748AA86BD6E"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttributeVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propput] */HRESULT ( STDMETHODCALLTYPE *put_PaintType )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgPaintType value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_PaintType )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgPaintType * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Color )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute * This,
        /* [in] */__x_ABI_CWindows_CUI_CColor value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Color )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute * This,
        /* [retval, out] */__x_ABI_CWindows_CUI_CColor * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Id )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute * This,
        /* [in] */HSTRING value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Id )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute * This,
        /* [retval, out] */HSTRING * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttributeVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttributeVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_put_PaintType(This,value) \
    ( (This)->lpVtbl->put_PaintType(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_get_PaintType(This,value) \
    ( (This)->lpVtbl->get_PaintType(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_put_Color(This,value) \
    ( (This)->lpVtbl->put_Color(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_get_Color(This,value) \
    ( (This)->lpVtbl->get_Color(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_put_Id(This,value) \
    ( (This)->lpVtbl->put_Id(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_get_Id(This,value) \
    ( (This)->lpVtbl->get_Id(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPaintAttribute_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgPathAttribute
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgPathAttribute
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgPathAttribute[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgPathAttribute";
/* [object, version, uuid("652786A8-F3AB-4083-991D-9748AB86BD6E"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttributeVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload] */HRESULT ( STDMETHODCALLTYPE *CreatePathGeometry )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * outputGeometry
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreatePathGeometryWithFill )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFilledRegionDetermination fill,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * outputGeometry
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Commands )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * This,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgPathCommand * * valueElements
        );
    HRESULT ( STDMETHODCALLTYPE *GetCommands )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * This,
        /* [in] */INT32 startIndex,
        /* [in] */INT32 elementCount,
        /* [out] */UINT32 * __outputValueElementsSize,
        /* [size_is(, *(__outputValueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgPathCommand * * outputValueElements
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_SegmentData )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * This,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */FLOAT * * valueElements
        );
    HRESULT ( STDMETHODCALLTYPE *GetSegmentData )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * This,
        /* [in] */INT32 startIndex,
        /* [in] */INT32 elementCount,
        /* [out] */UINT32 * __outputValueElementsSize,
        /* [size_is(, *(__outputValueElementsSize)), retval, out] */FLOAT * * outputValueElements
        );
    HRESULT ( STDMETHODCALLTYPE *RemoveCommandsAtEnd )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * This,
        /* [in] */INT32 commandsCount
        );
    HRESULT ( STDMETHODCALLTYPE *RemoveSegmentDataAtEnd )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * This,
        /* [in] */INT32 commandsCount
        );
    HRESULT ( STDMETHODCALLTYPE *SetCommands )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * This,
        /* [in] */INT32 startIndex,
        /* [in] */UINT32 __commandsSize,
        /* [size_is(__commandsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgPathCommand * commands
        );
    HRESULT ( STDMETHODCALLTYPE *SetSegmentData )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute * This,
        /* [in] */INT32 startIndex,
        /* [in] */UINT32 __segmentDataSize,
        /* [size_is(__segmentDataSize), in] */FLOAT * segmentData
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttributeVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttributeVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_CreatePathGeometry(This,outputGeometry) \
    ( (This)->lpVtbl->CreatePathGeometry(This,outputGeometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_CreatePathGeometryWithFill(This,fill,outputGeometry) \
    ( (This)->lpVtbl->CreatePathGeometryWithFill(This,fill,outputGeometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_get_Commands(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->get_Commands(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_GetCommands(This,startIndex,elementCount,__outputValueElementsSize,outputValueElements) \
    ( (This)->lpVtbl->GetCommands(This,startIndex,elementCount,__outputValueElementsSize,outputValueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_get_SegmentData(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->get_SegmentData(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_GetSegmentData(This,startIndex,elementCount,__outputValueElementsSize,outputValueElements) \
    ( (This)->lpVtbl->GetSegmentData(This,startIndex,elementCount,__outputValueElementsSize,outputValueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_RemoveCommandsAtEnd(This,commandsCount) \
    ( (This)->lpVtbl->RemoveCommandsAtEnd(This,commandsCount) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_RemoveSegmentDataAtEnd(This,commandsCount) \
    ( (This)->lpVtbl->RemoveSegmentDataAtEnd(This,commandsCount) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_SetCommands(This,startIndex,__commandsSize,commands) \
    ( (This)->lpVtbl->SetCommands(This,startIndex,__commandsSize,commands) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_SetSegmentData(This,startIndex,__segmentDataSize,segmentData) \
    ( (This)->lpVtbl->SetSegmentData(This,startIndex,__segmentDataSize,segmentData) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPathAttribute_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgPointsAttribute
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgPointsAttribute
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgPointsAttribute[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgPointsAttribute";
/* [object, version, uuid("652786A8-F3AB-4083-991D-9748AA86BD6F"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttributeVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Points )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute * This,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 * * valueElements
        );
    HRESULT ( STDMETHODCALLTYPE *GetPoints )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute * This,
        /* [in] */INT32 startIndex,
        /* [in] */INT32 elementCount,
        /* [out] */UINT32 * __outputValueElementsSize,
        /* [size_is(, *(__outputValueElementsSize)), retval, out] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 * * outputValueElements
        );
    HRESULT ( STDMETHODCALLTYPE *RemovePointsAtEnd )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute * This,
        /* [in] */INT32 pointCount
        );
    HRESULT ( STDMETHODCALLTYPE *SetPoints )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute * This,
        /* [in] */INT32 startIndex,
        /* [in] */UINT32 __pointsSize,
        /* [size_is(__pointsSize), in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 * points
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttributeVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttributeVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_get_Points(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->get_Points(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_GetPoints(This,startIndex,elementCount,__outputValueElementsSize,outputValueElements) \
    ( (This)->lpVtbl->GetPoints(This,startIndex,elementCount,__outputValueElementsSize,outputValueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_RemovePointsAtEnd(This,pointCount) \
    ( (This)->lpVtbl->RemovePointsAtEnd(This,pointCount) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_SetPoints(This,startIndex,__pointsSize,points) \
    ( (This)->lpVtbl->SetPoints(This,startIndex,__pointsSize,points) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgPointsAttribute_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgStrokeDashArrayAttribute
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgStrokeDashArrayAttribute
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgStrokeDashArrayAttribute[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgStrokeDashArrayAttribute";
/* [object, version, uuid("652786A8-F3AB-4083-991D-9748AA86BD70"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttributeVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload] */HRESULT ( STDMETHODCALLTYPE *GetDashes )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute * This,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */FLOAT * * valueElements
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *GetDashesWithUnits )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute * This,
        /* [in] */INT32 startIndex,
        /* [in] */INT32 elementCount,
        /* [out] */UINT32 * __outputUnitsElementsSize,
        /* [size_is(, *(__outputUnitsElementsSize)), out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgLengthUnits * * outputUnitsElements,
        /* [out] */UINT32 * __outputValueElementsSize,
        /* [size_is(, *(__outputValueElementsSize)), retval, out] */FLOAT * * outputValueElements
        );
    HRESULT ( STDMETHODCALLTYPE *RemoveDashesAtEnd )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute * This,
        /* [in] */INT32 dashCount
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *SetDashes )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute * This,
        /* [in] */INT32 startIndex,
        /* [in] */UINT32 __dashesSize,
        /* [size_is(__dashesSize), in] */FLOAT * dashes
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *SetDashesWithUnit )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute * This,
        /* [in] */INT32 startIndex,
        /* [in] */UINT32 __dashesSize,
        /* [size_is(__dashesSize), in] */FLOAT * dashes,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgLengthUnits units
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *SetDashesWithUnits )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute * This,
        /* [in] */INT32 startIndex,
        /* [in] */UINT32 __dashValuesSize,
        /* [size_is(__dashValuesSize), in] */FLOAT * dashValues,
        /* [in] */UINT32 __unitValuesSize,
        /* [size_is(__unitValuesSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CCanvasSvgLengthUnits * unitValues
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttributeVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttributeVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_GetDashes(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetDashes(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_GetDashesWithUnits(This,startIndex,elementCount,__outputUnitsElementsSize,outputUnitsElements,__outputValueElementsSize,outputValueElements) \
    ( (This)->lpVtbl->GetDashesWithUnits(This,startIndex,elementCount,__outputUnitsElementsSize,outputUnitsElements,__outputValueElementsSize,outputValueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_RemoveDashesAtEnd(This,dashCount) \
    ( (This)->lpVtbl->RemoveDashesAtEnd(This,dashCount) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_SetDashes(This,startIndex,__dashesSize,dashes) \
    ( (This)->lpVtbl->SetDashes(This,startIndex,__dashesSize,dashes) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_SetDashesWithUnit(This,startIndex,__dashesSize,dashes,units) \
    ( (This)->lpVtbl->SetDashesWithUnit(This,startIndex,__dashesSize,dashes,units) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_SetDashesWithUnits(This,startIndex,__dashValuesSize,dashValues,__unitValuesSize,unitValues) \
    ( (This)->lpVtbl->SetDashesWithUnits(This,startIndex,__dashValuesSize,dashValues,__unitValuesSize,unitValues) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgStrokeDashArrayAttribute_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Svg.ICanvasSvgTextElement
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Svg.CanvasSvgTextElement
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Svg_ICanvasSvgTextElement[] = L"Microsoft.Graphics.Canvas.Svg.ICanvasSvgTextElement";
/* [object, version, uuid("652786A8-F3AB-4083-991D-9748AA86BD6D"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElementVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Text )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement * This,
        /* [in] */HSTRING value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Text )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement * This,
        /* [retval, out] */HSTRING * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElementVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElementVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_put_Text(This,value) \
    ( (This)->lpVtbl->put_Text(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_get_Text(This,value) \
    ( (This)->lpVtbl->get_Text(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgTextElement_INTERFACE_DEFINED__) */


/*
 *
 * Class Microsoft.Graphics.Canvas.Svg.CanvasSvgDocument
 *
 * RuntimeClass can be activated.
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgDocument ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgDocument_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgDocument_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Svg_CanvasSvgDocument[] = L"Microsoft.Graphics.Canvas.Svg.CanvasSvgDocument";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Svg.CanvasSvgNamedElement
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgNamedElement ** Default Interface **
 *    Windows.Foundation.IClosable
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgElement
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgNamedElement_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgNamedElement_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Svg_CanvasSvgNamedElement[] = L"Microsoft.Graphics.Canvas.Svg.CanvasSvgNamedElement";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Svg.CanvasSvgPaintAttribute
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgPaintAttribute ** Default Interface **
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgPaintAttribute_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgPaintAttribute_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Svg_CanvasSvgPaintAttribute[] = L"Microsoft.Graphics.Canvas.Svg.CanvasSvgPaintAttribute";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Svg.CanvasSvgPathAttribute
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgPathAttribute ** Default Interface **
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgPathAttribute_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgPathAttribute_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Svg_CanvasSvgPathAttribute[] = L"Microsoft.Graphics.Canvas.Svg.CanvasSvgPathAttribute";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Svg.CanvasSvgPointsAttribute
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgPointsAttribute ** Default Interface **
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgPointsAttribute_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgPointsAttribute_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Svg_CanvasSvgPointsAttribute[] = L"Microsoft.Graphics.Canvas.Svg.CanvasSvgPointsAttribute";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Svg.CanvasSvgStrokeDashArrayAttribute
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgStrokeDashArrayAttribute ** Default Interface **
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgAttribute
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgStrokeDashArrayAttribute_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgStrokeDashArrayAttribute_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Svg_CanvasSvgStrokeDashArrayAttribute[] = L"Microsoft.Graphics.Canvas.Svg.CanvasSvgStrokeDashArrayAttribute";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Svg.CanvasSvgTextElement
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Svg.ICanvasSvgTextElement ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgTextElement_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Svg_CanvasSvgTextElement_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Svg_CanvasSvgTextElement[] = L"Microsoft.Graphics.Canvas.Svg.CanvasSvgTextElement";
#endif





#endif // defined(__cplusplus)
#pragma pop_macro("MIDL_CONST_ID")
// Restore the original value of the 'DEPRECATED' macro
#pragma pop_macro("DEPRECATED")

#ifdef __clang__
#pragma clang diagnostic pop // deprecated-declarations
#else
#pragma warning(pop)
#endif
#endif // __microsoft2Egraphics2Ecanvas2Esvg_p_h__

#endif // __microsoft2Egraphics2Ecanvas2Esvg_h__
