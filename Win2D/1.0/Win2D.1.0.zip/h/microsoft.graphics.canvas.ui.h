
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

/* verify that the <rpcsal.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCSAL_H_VERSION__
#define __REQUIRED_RPCSAL_H_VERSION__ 100
#endif

#include <rpc.h>
#include <rpcndr.h>

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include <windows.h>
#include <ole2.h>
#endif /*COM_NO_WINDOWS_H*/
#ifndef __microsoft2Egraphics2Ecanvas2Eui_h__
#define __microsoft2Egraphics2Ecanvas2Eui_h__
#ifndef __microsoft2Egraphics2Ecanvas2Eui_p_h__
#define __microsoft2Egraphics2Ecanvas2Eui_p_h__


#pragma once

//
// Deprecated attribute support
//

#pragma push_macro("DEPRECATED")
#undef DEPRECATED

#if !defined(DISABLE_WINRT_DEPRECATION)
#if defined(__cplusplus)
#if __cplusplus >= 201402
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#elif defined(_MSC_VER)
#if _MSC_VER >= 1900
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#else
#define DEPRECATED(x) __declspec(deprecated(x))
#define DEPRECATEDENUMERATOR(x)
#endif // _MSC_VER >= 1900
#else // Not Standard C++ or MSVC, ignore the construct.
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  // C++ deprecation
#else // C - disable deprecation
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif
#else // Deprecation is disabled
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  /* DEPRECATED */

// Disable Deprecation for this header, MIDL verifies that cross-type access is acceptable
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#else
#pragma warning(push)
#pragma warning(disable: 4996)
#endif

// Ensure that the setting of the /ns_prefix command line switch is consistent for all headers.
// If you get an error from the compiler indicating "warning C4005: 'CHECK_NS_PREFIX_STATE': macro redefinition", this
// indicates that you have included two different headers with different settings for the /ns_prefix MIDL command line switch
#if !defined(DISABLE_NS_PREFIX_CHECKS)
#define CHECK_NS_PREFIX_STATE "always"
#endif // !defined(DISABLE_NS_PREFIX_CHECKS)


#pragma push_macro("MIDL_CONST_ID")
#undef MIDL_CONST_ID
#define MIDL_CONST_ID const __declspec(selectany)


//  API Contract Inclusion Definitions
#if !defined(SPECIFIC_API_CONTRACT_DEFINITIONS)
#if !defined(MICROSOFT_FOUNDATION_WINDOWSAPPSDKCONTRACT_VERSION)
#define MICROSOFT_FOUNDATION_WINDOWSAPPSDKCONTRACT_VERSION 0x10000
#endif // defined(MICROSOFT_FOUNDATION_WINDOWSAPPSDKCONTRACT_VERSION)

#if !defined(MICROSOFT_UI_XAML_WINUICONTRACT_VERSION)
#define MICROSOFT_UI_XAML_WINUICONTRACT_VERSION 0x10000
#endif // defined(MICROSOFT_UI_XAML_WINUICONTRACT_VERSION)

#if !defined(MICROSOFT_UI_XAML_XAMLCONTRACT_VERSION)
#define MICROSOFT_UI_XAML_XAMLCONTRACT_VERSION 0x20000
#endif // defined(MICROSOFT_UI_XAML_XAMLCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION 0x50000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION)
#define WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION)
#define WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION)
#define WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION 0x60000
#endif // defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION)
#define WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)
#define WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)
#define WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION 0xa0000
#endif // defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)

#if !defined(WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION)
#define WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION)

#if !defined(WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION)
#define WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION)
#define WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION)
#define WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION)
#define WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION)
#define WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)
#define WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)
#define WINDOWS_PHONE_PHONECONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)
#define WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)

#if !defined(WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION)
#define WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION 0x50000
#endif // defined(WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION)

#if !defined(WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION)
#define WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION)

#if !defined(WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION)
#define WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION)

#if !defined(WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION)
#define WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION)

#if !defined(WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION)
#define WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION)

#if !defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)
#define WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)

#endif // defined(SPECIFIC_API_CONTRACT_DEFINITIONS)


// Header files for imported files
#include "inspectable.h"
#include "AsyncInfo.h"
#include "EventToken.h"
#include "Windows.Foundation.h"
#include "Microsoft.Graphics.Canvas.UI.Xaml.h"
// Importing Collections header
#include <windows.foundation.collections.h>

#if defined(__cplusplus) && !defined(CINTERFACE)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace UI {
                    interface ICanvasCreateResourcesEventArgs;
                } /* UI */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs ABI::Microsoft::Graphics::Canvas::UI::ICanvasCreateResourcesEventArgs

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace UI {
                    interface ICanvasCreateResourcesEventArgsFactory;
                } /* UI */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory ABI::Microsoft::Graphics::Canvas::UI::ICanvasCreateResourcesEventArgsFactory

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_FWD_DEFINED__

// Parameterized interface forward declarations (C++)

// Collection interface definitions
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace UI {
                    namespace Xaml {
                        class CanvasControl;
                    } /* Xaml */
                } /* UI */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasControl_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasControl_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace UI {
                    namespace Xaml {
                        interface ICanvasControl;
                    } /* Xaml */
                } /* UI */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasControl ABI::Microsoft::Graphics::Canvas::UI::Xaml::ICanvasControl

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasControl_FWD_DEFINED__


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace UI {
                    class CanvasCreateResourcesEventArgs;
                } /* UI */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */



#ifndef DEF___FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_USE
#define DEF___FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("ffcd91a9-b0f6-5e59-b815-0581129240e6"))
ITypedEventHandler<ABI::Microsoft::Graphics::Canvas::UI::Xaml::CanvasControl*,ABI::Microsoft::Graphics::Canvas::UI::CanvasCreateResourcesEventArgs*> : ITypedEventHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::UI::Xaml::CanvasControl*, ABI::Microsoft::Graphics::Canvas::UI::Xaml::ICanvasControl*>,ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::UI::CanvasCreateResourcesEventArgs*, ABI::Microsoft::Graphics::Canvas::UI::ICanvasCreateResourcesEventArgs*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.TypedEventHandler`2<Microsoft.Graphics.Canvas.UI.Xaml.CanvasControl, Microsoft.Graphics.Canvas.UI.CanvasCreateResourcesEventArgs>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef ITypedEventHandler<ABI::Microsoft::Graphics::Canvas::UI::Xaml::CanvasControl*,ABI::Microsoft::Graphics::Canvas::UI::CanvasCreateResourcesEventArgs*> __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_t;
#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs ABI::Windows::Foundation::__FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs ABI::Windows::Foundation::ITypedEventHandler<ABI::Microsoft::Graphics::Canvas::UI::Xaml::ICanvasControl*,ABI::Microsoft::Graphics::Canvas::UI::ICanvasCreateResourcesEventArgs*>
//#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_t ABI::Windows::Foundation::ITypedEventHandler<ABI::Microsoft::Graphics::Canvas::UI::Xaml::ICanvasControl*,ABI::Microsoft::Graphics::Canvas::UI::ICanvasCreateResourcesEventArgs*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_USE */



namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace UI {
                    namespace Xaml {
                        class CanvasVirtualControl;
                    } /* Xaml */
                } /* UI */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasVirtualControl_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasVirtualControl_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace UI {
                    namespace Xaml {
                        interface ICanvasVirtualControl;
                    } /* Xaml */
                } /* UI */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasVirtualControl ABI::Microsoft::Graphics::Canvas::UI::Xaml::ICanvasVirtualControl

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasVirtualControl_FWD_DEFINED__




#ifndef DEF___FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_USE
#define DEF___FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("82c7431b-0f55-5f54-8dd8-f9a8327df123"))
ITypedEventHandler<ABI::Microsoft::Graphics::Canvas::UI::Xaml::CanvasVirtualControl*,ABI::Microsoft::Graphics::Canvas::UI::CanvasCreateResourcesEventArgs*> : ITypedEventHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::UI::Xaml::CanvasVirtualControl*, ABI::Microsoft::Graphics::Canvas::UI::Xaml::ICanvasVirtualControl*>,ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::UI::CanvasCreateResourcesEventArgs*, ABI::Microsoft::Graphics::Canvas::UI::ICanvasCreateResourcesEventArgs*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.TypedEventHandler`2<Microsoft.Graphics.Canvas.UI.Xaml.CanvasVirtualControl, Microsoft.Graphics.Canvas.UI.CanvasCreateResourcesEventArgs>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef ITypedEventHandler<ABI::Microsoft::Graphics::Canvas::UI::Xaml::CanvasVirtualControl*,ABI::Microsoft::Graphics::Canvas::UI::CanvasCreateResourcesEventArgs*> __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_t;
#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs ABI::Windows::Foundation::__FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs ABI::Windows::Foundation::ITypedEventHandler<ABI::Microsoft::Graphics::Canvas::UI::Xaml::ICanvasVirtualControl*,ABI::Microsoft::Graphics::Canvas::UI::ICanvasCreateResourcesEventArgs*>
//#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_t ABI::Windows::Foundation::ITypedEventHandler<ABI::Microsoft::Graphics::Canvas::UI::Xaml::ICanvasVirtualControl*,ABI::Microsoft::Graphics::Canvas::UI::ICanvasCreateResourcesEventArgs*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_USE */












#ifndef ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Foundation {
            interface IAsyncAction;
        } /* Foundation */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CFoundation_CIAsyncAction ABI::Windows::Foundation::IAsyncAction

#endif // ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__




namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace UI {
                    
                    typedef enum CanvasCreateResourcesReason : int CanvasCreateResourcesReason;
                    
                } /* UI */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */














/*
 *
 * Struct Microsoft.Graphics.Canvas.UI.CanvasCreateResourcesReason
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace UI {
                    /* [v1_enum, version] */
                    enum CanvasCreateResourcesReason : int
                    {
                        CanvasCreateResourcesReason_FirstTime = 0,
                        CanvasCreateResourcesReason_NewDevice = 1,
                        CanvasCreateResourcesReason_DpiChanged = 2,
                    };
                    
                } /* UI */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Interface Microsoft.Graphics.Canvas.UI.ICanvasCreateResourcesEventArgs
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.UI.CanvasCreateResourcesEventArgs
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_UI_ICanvasCreateResourcesEventArgs[] = L"Microsoft.Graphics.Canvas.UI.ICanvasCreateResourcesEventArgs";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace UI {
                    /* [object, version, uuid("EDC52108-F6BA-4A09-9FA3-10C97A24E49A"), exclusiveto] */
                    MIDL_INTERFACE("EDC52108-F6BA-4A09-9FA3-10C97A24E49A")
                    ICanvasCreateResourcesEventArgs : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Reason(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::UI::CanvasCreateResourcesReason * value
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE TrackAsyncAction(
                            /* [in] */ABI::Windows::Foundation::IAsyncAction * action
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE GetTrackedAction(
                            /* [retval, out] */ABI::Windows::Foundation::IAsyncAction * * action
                            ) = 0;
                        
                    };

                    extern MIDL_CONST_ID IID & IID_ICanvasCreateResourcesEventArgs=_uuidof(ICanvasCreateResourcesEventArgs);
                    
                } /* UI */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.UI.ICanvasCreateResourcesEventArgsFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.UI.CanvasCreateResourcesEventArgs
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_UI_ICanvasCreateResourcesEventArgsFactory[] = L"Microsoft.Graphics.Canvas.UI.ICanvasCreateResourcesEventArgsFactory";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace UI {
                    /* [object, version, uuid("3A21C766-0781-4389-BBC3-86B1F5022AF1"), exclusiveto] */
                    MIDL_INTERFACE("3A21C766-0781-4389-BBC3-86B1F5022AF1")
                    ICanvasCreateResourcesEventArgsFactory : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE Create(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::UI::CanvasCreateResourcesReason createResourcesReason,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::UI::ICanvasCreateResourcesEventArgs * * CreateResourcesEventArgs
                            ) = 0;
                        
                    };

                    extern MIDL_CONST_ID IID & IID_ICanvasCreateResourcesEventArgsFactory=_uuidof(ICanvasCreateResourcesEventArgsFactory);
                    
                } /* UI */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_INTERFACE_DEFINED__) */


/*
 *
 * Class Microsoft.Graphics.Canvas.UI.CanvasCreateResourcesEventArgs
 *
 * RuntimeClass can be activated.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.UI.ICanvasCreateResourcesEventArgs ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_UI_CanvasCreateResourcesEventArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_UI_CanvasCreateResourcesEventArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_UI_CanvasCreateResourcesEventArgs[] = L"Microsoft.Graphics.Canvas.UI.CanvasCreateResourcesEventArgs";
#endif





#else // !defined(__cplusplus)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_FWD_DEFINED__

// Parameterized interface forward declarations (C)

// Collection interface definitions
#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasControl_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasControl_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasControl __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasControl;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasControl_FWD_DEFINED__



#if !defined(____FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_INTERFACE_DEFINED__)
#define ____FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_INTERFACE_DEFINED__

typedef interface __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs;

typedef struct __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs * This,/* [in] */ __RPC__in_opt __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasControl * sender,/* [in] */ __RPC__in_opt __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs * e);
    END_INTERFACE
} __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgsVtbl;

interface __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs
{
    CONST_VTBL struct __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_Invoke(This,sender,e)	\
    ( (This)->lpVtbl -> Invoke(This,sender,e) ) 
#endif /* COBJMACROS */



#endif // ____FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_INTERFACE_DEFINED__


#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasVirtualControl_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasVirtualControl_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasVirtualControl __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasVirtualControl;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasVirtualControl_FWD_DEFINED__



#if !defined(____FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_INTERFACE_DEFINED__)
#define ____FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_INTERFACE_DEFINED__

typedef interface __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs;

typedef struct __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs * This,/* [in] */ __RPC__in_opt __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CXaml_CICanvasVirtualControl * sender,/* [in] */ __RPC__in_opt __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs * e);
    END_INTERFACE
} __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgsVtbl;

interface __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs
{
    CONST_VTBL struct __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_Invoke(This,sender,e)	\
    ( (This)->lpVtbl -> Invoke(This,sender,e) ) 
#endif /* COBJMACROS */



#endif // ____FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CUI__CXaml__CCanvasVirtualControl_Microsoft__CGraphics__CCanvas__CUI__CCanvasCreateResourcesEventArgs_INTERFACE_DEFINED__










#ifndef ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CFoundation_CIAsyncAction __x_ABI_CWindows_CFoundation_CIAsyncAction;

#endif // ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__





typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CCanvasCreateResourcesReason __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CCanvasCreateResourcesReason;














/*
 *
 * Struct Microsoft.Graphics.Canvas.UI.CanvasCreateResourcesReason
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CCanvasCreateResourcesReason
{
    CanvasCreateResourcesReason_FirstTime = 0,
    CanvasCreateResourcesReason_NewDevice = 1,
    CanvasCreateResourcesReason_DpiChanged = 2,
};


/*
 *
 * Interface Microsoft.Graphics.Canvas.UI.ICanvasCreateResourcesEventArgs
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.UI.CanvasCreateResourcesEventArgs
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_UI_ICanvasCreateResourcesEventArgs[] = L"Microsoft.Graphics.Canvas.UI.ICanvasCreateResourcesEventArgs";
/* [object, version, uuid("EDC52108-F6BA-4A09-9FA3-10C97A24E49A"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Reason )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CCanvasCreateResourcesReason * value
        );
    HRESULT ( STDMETHODCALLTYPE *TrackAsyncAction )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CIAsyncAction * action
        );
    HRESULT ( STDMETHODCALLTYPE *GetTrackedAction )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CIAsyncAction * * action
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_get_Reason(This,value) \
    ( (This)->lpVtbl->get_Reason(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_TrackAsyncAction(This,action) \
    ( (This)->lpVtbl->TrackAsyncAction(This,action) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_GetTrackedAction(This,action) \
    ( (This)->lpVtbl->GetTrackedAction(This,action) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.UI.ICanvasCreateResourcesEventArgsFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.UI.CanvasCreateResourcesEventArgs
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_UI_ICanvasCreateResourcesEventArgsFactory[] = L"Microsoft.Graphics.Canvas.UI.ICanvasCreateResourcesEventArgsFactory";
/* [object, version, uuid("3A21C766-0781-4389-BBC3-86B1F5022AF1"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *Create )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CCanvasCreateResourcesReason createResourcesReason,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgs * * CreateResourcesEventArgs
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactoryVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_Create(This,createResourcesReason,CreateResourcesEventArgs) \
    ( (This)->lpVtbl->Create(This,createResourcesReason,CreateResourcesEventArgs) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CICanvasCreateResourcesEventArgsFactory_INTERFACE_DEFINED__) */


/*
 *
 * Class Microsoft.Graphics.Canvas.UI.CanvasCreateResourcesEventArgs
 *
 * RuntimeClass can be activated.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.UI.ICanvasCreateResourcesEventArgs ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_UI_CanvasCreateResourcesEventArgs_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_UI_CanvasCreateResourcesEventArgs_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_UI_CanvasCreateResourcesEventArgs[] = L"Microsoft.Graphics.Canvas.UI.CanvasCreateResourcesEventArgs";
#endif





#endif // defined(__cplusplus)
#pragma pop_macro("MIDL_CONST_ID")
// Restore the original value of the 'DEPRECATED' macro
#pragma pop_macro("DEPRECATED")

#ifdef __clang__
#pragma clang diagnostic pop // deprecated-declarations
#else
#pragma warning(pop)
#endif
#endif // __microsoft2Egraphics2Ecanvas2Eui_p_h__

#endif // __microsoft2Egraphics2Ecanvas2Eui_h__
