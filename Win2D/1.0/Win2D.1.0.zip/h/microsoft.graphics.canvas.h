
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

/* verify that the <rpcsal.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCSAL_H_VERSION__
#define __REQUIRED_RPCSAL_H_VERSION__ 100
#endif

#include <rpc.h>
#include <rpcndr.h>

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include <windows.h>
#include <ole2.h>
#endif /*COM_NO_WINDOWS_H*/
#ifndef __microsoft2Egraphics2Ecanvas_h__
#define __microsoft2Egraphics2Ecanvas_h__
#ifndef __microsoft2Egraphics2Ecanvas_p_h__
#define __microsoft2Egraphics2Ecanvas_p_h__


#pragma once

//
// Deprecated attribute support
//

#pragma push_macro("DEPRECATED")
#undef DEPRECATED

#if !defined(DISABLE_WINRT_DEPRECATION)
#if defined(__cplusplus)
#if __cplusplus >= 201402
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#elif defined(_MSC_VER)
#if _MSC_VER >= 1900
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#else
#define DEPRECATED(x) __declspec(deprecated(x))
#define DEPRECATEDENUMERATOR(x)
#endif // _MSC_VER >= 1900
#else // Not Standard C++ or MSVC, ignore the construct.
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  // C++ deprecation
#else // C - disable deprecation
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif
#else // Deprecation is disabled
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  /* DEPRECATED */

// Disable Deprecation for this header, MIDL verifies that cross-type access is acceptable
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#else
#pragma warning(push)
#pragma warning(disable: 4996)
#endif

// Ensure that the setting of the /ns_prefix command line switch is consistent for all headers.
// If you get an error from the compiler indicating "warning C4005: 'CHECK_NS_PREFIX_STATE': macro redefinition", this
// indicates that you have included two different headers with different settings for the /ns_prefix MIDL command line switch
#if !defined(DISABLE_NS_PREFIX_CHECKS)
#define CHECK_NS_PREFIX_STATE "always"
#endif // !defined(DISABLE_NS_PREFIX_CHECKS)


#pragma push_macro("MIDL_CONST_ID")
#undef MIDL_CONST_ID
#define MIDL_CONST_ID const __declspec(selectany)


//  API Contract Inclusion Definitions
#if !defined(SPECIFIC_API_CONTRACT_DEFINITIONS)
#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION 0x50000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION)
#define WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION)
#define WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION)
#define WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION 0x60000
#endif // defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION)
#define WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)
#define WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)
#define WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION 0xa0000
#endif // defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)

#if !defined(WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION)
#define WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION)

#if !defined(WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION)
#define WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION)
#define WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION)
#define WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION)
#define WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION)
#define WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)
#define WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)
#define WINDOWS_PHONE_PHONECONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)
#define WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)

#if !defined(WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION)
#define WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION 0x50000
#endif // defined(WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION)

#if !defined(WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION)
#define WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION)

#if !defined(WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION)
#define WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION)

#if !defined(WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION)
#define WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION)

#if !defined(WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION)
#define WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION)

#if !defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)
#define WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)

#endif // defined(SPECIFIC_API_CONTRACT_DEFINITIONS)


// Header files for imported files
#include "inspectable.h"
#include "AsyncInfo.h"
#include "EventToken.h"
#include "Windows.Foundation.h"
#include "Microsoft.Graphics.Canvas.Brushes.h"
#include "Microsoft.Graphics.Canvas.Effects.h"
#include "Microsoft.Graphics.Canvas.Geometry.h"
#include "Microsoft.Graphics.Canvas.Svg.h"
#include "Microsoft.Graphics.Canvas.Text.h"
#include "Windows.Foundation.Numerics.h"
#include "Windows.Graphics.DirectX.h"
#include "Windows.Graphics.DirectX.Direct3D11.h"
#include "Windows.Graphics.Effects.h"
#include "Windows.Graphics.Imaging.h"
#include "Windows.Storage.Streams.h"
#include "Windows.UI.h"
#include "Windows.UI.Core.h"
// Importing Collections header
#include <windows.foundation.collections.h>

#if defined(__cplusplus) && !defined(CINTERFACE)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasActiveLayer;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer ABI::Microsoft::Graphics::Canvas::ICanvasActiveLayer

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasBitmap;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap ABI::Microsoft::Graphics::Canvas::ICanvasBitmap

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasBitmapFactory;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory ABI::Microsoft::Graphics::Canvas::ICanvasBitmapFactory

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasBitmapStatics;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics ABI::Microsoft::Graphics::Canvas::ICanvasBitmapStatics

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasCommandList;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList ABI::Microsoft::Graphics::Canvas::ICanvasCommandList

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasCommandListFactory;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory ABI::Microsoft::Graphics::Canvas::ICanvasCommandListFactory

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasDevice;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice ABI::Microsoft::Graphics::Canvas::ICanvasDevice

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasDeviceFactory;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory ABI::Microsoft::Graphics::Canvas::ICanvasDeviceFactory

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasDeviceStatics;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics ABI::Microsoft::Graphics::Canvas::ICanvasDeviceStatics

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasDrawingSession;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession ABI::Microsoft::Graphics::Canvas::ICanvasDrawingSession

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasImage;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage ABI::Microsoft::Graphics::Canvas::ICanvasImage

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasImageStatics;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics ABI::Microsoft::Graphics::Canvas::ICanvasImageStatics

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasLock;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock ABI::Microsoft::Graphics::Canvas::ICanvasLock

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasRenderTarget;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget ABI::Microsoft::Graphics::Canvas::ICanvasRenderTarget

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasRenderTargetFactory;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory ABI::Microsoft::Graphics::Canvas::ICanvasRenderTargetFactory

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasRenderTargetStatics;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics ABI::Microsoft::Graphics::Canvas::ICanvasRenderTargetStatics

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasResourceCreator;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasResourceCreatorWithDpi;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreatorWithDpi

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasSpriteBatch;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch ABI::Microsoft::Graphics::Canvas::ICanvasSpriteBatch

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasSpriteBatchStatics;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics ABI::Microsoft::Graphics::Canvas::ICanvasSpriteBatchStatics

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasSwapChain;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain ABI::Microsoft::Graphics::Canvas::ICanvasSwapChain

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasSwapChainFactory;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory ABI::Microsoft::Graphics::Canvas::ICanvasSwapChainFactory

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasSwapChainStatics;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics ABI::Microsoft::Graphics::Canvas::ICanvasSwapChainStatics

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasVirtualBitmap;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap ABI::Microsoft::Graphics::Canvas::ICanvasVirtualBitmap

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasVirtualBitmapStatics;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics ABI::Microsoft::Graphics::Canvas::ICanvasVirtualBitmapStatics

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_FWD_DEFINED__

// Parameterized interface forward declarations (C++)

// Collection interface definitions
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                class CanvasBitmap;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */



#ifndef DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_USE
#define DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("01f4b012-b7d5-5e02-8caa-2c460f35c947"))
IAsyncOperationCompletedHandler<ABI::Microsoft::Graphics::Canvas::CanvasBitmap*> : IAsyncOperationCompletedHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::CanvasBitmap*, ABI::Microsoft::Graphics::Canvas::ICanvasBitmap*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationCompletedHandler`1<Microsoft.Graphics.Canvas.CanvasBitmap>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationCompletedHandler<ABI::Microsoft::Graphics::Canvas::CanvasBitmap*> __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_t;
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap ABI::Windows::Foundation::__FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Graphics::Canvas::ICanvasBitmap*>
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_t ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Graphics::Canvas::ICanvasBitmap*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_USE */





#ifndef DEF___FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_USE
#define DEF___FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("0391e8ef-719a-5c80-b87a-7d902b154e3e"))
IAsyncOperation<ABI::Microsoft::Graphics::Canvas::CanvasBitmap*> : IAsyncOperation_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::CanvasBitmap*, ABI::Microsoft::Graphics::Canvas::ICanvasBitmap*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IAsyncOperation`1<Microsoft.Graphics.Canvas.CanvasBitmap>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperation<ABI::Microsoft::Graphics::Canvas::CanvasBitmap*> __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_t;
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap ABI::Windows::Foundation::__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Graphics::Canvas::ICanvasBitmap*>
//#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_t ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Graphics::Canvas::ICanvasBitmap*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_USE */



namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                class CanvasVirtualBitmap;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */



#ifndef DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_USE
#define DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("6fec4e18-7336-5236-8748-9a4b669b98f6"))
IAsyncOperationCompletedHandler<ABI::Microsoft::Graphics::Canvas::CanvasVirtualBitmap*> : IAsyncOperationCompletedHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::CanvasVirtualBitmap*, ABI::Microsoft::Graphics::Canvas::ICanvasVirtualBitmap*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.AsyncOperationCompletedHandler`1<Microsoft.Graphics.Canvas.CanvasVirtualBitmap>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperationCompletedHandler<ABI::Microsoft::Graphics::Canvas::CanvasVirtualBitmap*> __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_t;
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap ABI::Windows::Foundation::__FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Graphics::Canvas::ICanvasVirtualBitmap*>
//#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_t ABI::Windows::Foundation::IAsyncOperationCompletedHandler<ABI::Microsoft::Graphics::Canvas::ICanvasVirtualBitmap*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_USE */





#ifndef DEF___FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_USE
#define DEF___FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("d47cfc52-5abc-550b-ad7c-63b5aec8ca3a"))
IAsyncOperation<ABI::Microsoft::Graphics::Canvas::CanvasVirtualBitmap*> : IAsyncOperation_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::CanvasVirtualBitmap*, ABI::Microsoft::Graphics::Canvas::ICanvasVirtualBitmap*>> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IAsyncOperation`1<Microsoft.Graphics.Canvas.CanvasVirtualBitmap>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IAsyncOperation<ABI::Microsoft::Graphics::Canvas::CanvasVirtualBitmap*> __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_t;
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap ABI::Windows::Foundation::__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Graphics::Canvas::ICanvasVirtualBitmap*>
//#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_t ABI::Windows::Foundation::IAsyncOperation<ABI::Microsoft::Graphics::Canvas::ICanvasVirtualBitmap*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_USE */



namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                enum CanvasBufferPrecision : int;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


#ifndef DEF___FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision_USE
#define DEF___FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("8bff1f50-aef3-558e-a02b-589b6c0cfea8"))
IReference<enum ABI::Microsoft::Graphics::Canvas::CanvasBufferPrecision> : IReference_impl<enum ABI::Microsoft::Graphics::Canvas::CanvasBufferPrecision> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.IReference`1<Microsoft.Graphics.Canvas.CanvasBufferPrecision>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef IReference<enum ABI::Microsoft::Graphics::Canvas::CanvasBufferPrecision> __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision_t;
#define __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision ABI::Windows::Foundation::__FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision ABI::Windows::Foundation::IReference<ABI::Microsoft::Graphics::Canvas::CanvasBufferPrecision>
//#define __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision_t ABI::Windows::Foundation::IReference<ABI::Microsoft::Graphics::Canvas::CanvasBufferPrecision>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision_USE */



namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                class CanvasDevice;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */




#ifndef DEF___FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable_USE
#define DEF___FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable_USE
#if !defined(RO_NO_TEMPLATE_NAME)
namespace ABI { namespace Windows { namespace Foundation {
template <>
struct __declspec(uuid("ef539eb5-aa23-573f-ba41-ccd7f3150c5b"))
ITypedEventHandler<ABI::Microsoft::Graphics::Canvas::CanvasDevice*,IInspectable*> : ITypedEventHandler_impl<ABI::Windows::Foundation::Internal::AggregateType<ABI::Microsoft::Graphics::Canvas::CanvasDevice*, ABI::Microsoft::Graphics::Canvas::ICanvasDevice*>,IInspectable*> 
{
    static const wchar_t* z_get_rc_name_impl() 
    {
        return L"Windows.Foundation.TypedEventHandler`2<Microsoft.Graphics.Canvas.CanvasDevice, Object>"; 
    }
};
// Define a typedef for the parameterized interface specialization's mangled name.
// This allows code which uses the mangled name for the parameterized interface to access the
// correct parameterized interface specialization.
typedef ITypedEventHandler<ABI::Microsoft::Graphics::Canvas::CanvasDevice*,IInspectable*> __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable_t;
#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable ABI::Windows::Foundation::__FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable_t
/* Foundation */ } /* Windows */ } /* ABI */ } 

////  Define an alias for the C version of the interface for compatibility purposes.
//#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable ABI::Windows::Foundation::ITypedEventHandler<ABI::Microsoft::Graphics::Canvas::ICanvasDevice*,IInspectable*>
//#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable_t ABI::Windows::Foundation::ITypedEventHandler<ABI::Microsoft::Graphics::Canvas::ICanvasDevice*,IInspectable*>
#endif // !defined(RO_NO_TEMPLATE_NAME)
#endif /* DEF___FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable_USE */





#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Brushes {
                    interface ICanvasBrush;
                } /* Brushes */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush_FWD_DEFINED__






namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Effects {
                    
                    typedef enum EffectChannelSelect : int EffectChannelSelect;
                    
                } /* Effects */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */





namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    class CanvasCachedGeometry;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    interface ICanvasCachedGeometry;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasCachedGeometry

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_FWD_DEFINED__


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    class CanvasGeometry;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    interface ICanvasGeometry;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    class CanvasGradientMesh;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    interface ICanvasGradientMesh;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGradientMesh

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_FWD_DEFINED__


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    class CanvasStrokeStyle;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    interface ICanvasStrokeStyle;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_FWD_DEFINED__






namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    class CanvasSvgDocument;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Svg {
                    interface ICanvasSvgDocument;
                } /* Svg */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgDocument

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_FWD_DEFINED__






namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    class CanvasFontFace;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasFontFace;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasGlyph CanvasGlyph;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasTextAntialiasing : int CanvasTextAntialiasing;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    class CanvasTextFormat;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasTextFormat;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextFormat

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_FWD_DEFINED__


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    class CanvasTextLayout;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasTextLayout;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextLayout

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasTextMeasuringMode : int CanvasTextMeasuringMode;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    class CanvasTextRenderingParameters;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasTextRenderingParameters;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextRenderingParameters

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_FWD_DEFINED__






#ifndef ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Foundation {
            interface IAsyncAction;
        } /* Foundation */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CFoundation_CIAsyncAction ABI::Windows::Foundation::IAsyncAction

#endif // ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__


#ifndef ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Foundation {
            interface IClosable;
        } /* Foundation */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CFoundation_CIClosable ABI::Windows::Foundation::IClosable

#endif // ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__




namespace ABI {
    namespace Windows {
        namespace Foundation {
            namespace Numerics {
                
                typedef struct Matrix3x2 Matrix3x2;
                
            } /* Numerics */
        } /* Foundation */
    } /* Windows */
} /* ABI */

namespace ABI {
    namespace Windows {
        namespace Foundation {
            namespace Numerics {
                
                typedef struct Matrix4x4 Matrix4x4;
                
            } /* Numerics */
        } /* Foundation */
    } /* Windows */
} /* ABI */

namespace ABI {
    namespace Windows {
        namespace Foundation {
            namespace Numerics {
                
                typedef struct Vector2 Vector2;
                
            } /* Numerics */
        } /* Foundation */
    } /* Windows */
} /* ABI */

namespace ABI {
    namespace Windows {
        namespace Foundation {
            namespace Numerics {
                
                typedef struct Vector4 Vector4;
                
            } /* Numerics */
        } /* Foundation */
    } /* Windows */
} /* ABI */




namespace ABI {
    namespace Windows {
        namespace Foundation {
            
            typedef struct Rect Rect;
            
        } /* Foundation */
    } /* Windows */
} /* ABI */

namespace ABI {
    namespace Windows {
        namespace Foundation {
            
            typedef struct Size Size;
            
        } /* Foundation */
    } /* Windows */
} /* ABI */

namespace ABI {
    namespace Windows {
        namespace Foundation {
            class Uri;
        } /* Foundation */
    } /* Windows */
} /* ABI */

#ifndef ____x_ABI_CWindows_CFoundation_CIUriRuntimeClass_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIUriRuntimeClass_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Foundation {
            interface IUriRuntimeClass;
        } /* Foundation */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CFoundation_CIUriRuntimeClass ABI::Windows::Foundation::IUriRuntimeClass

#endif // ____x_ABI_CWindows_CFoundation_CIUriRuntimeClass_FWD_DEFINED__




#ifndef ____x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DDevice_FWD_DEFINED__
#define ____x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DDevice_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Graphics {
            namespace DirectX {
                namespace Direct3D11 {
                    interface IDirect3DDevice;
                } /* Direct3D11 */
            } /* DirectX */
        } /* Graphics */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DDevice ABI::Windows::Graphics::DirectX::Direct3D11::IDirect3DDevice

#endif // ____x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DDevice_FWD_DEFINED__


#ifndef ____x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DSurface_FWD_DEFINED__
#define ____x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DSurface_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Graphics {
            namespace DirectX {
                namespace Direct3D11 {
                    interface IDirect3DSurface;
                } /* Direct3D11 */
            } /* DirectX */
        } /* Graphics */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DSurface ABI::Windows::Graphics::DirectX::Direct3D11::IDirect3DSurface

#endif // ____x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DSurface_FWD_DEFINED__






namespace ABI {
    namespace Windows {
        namespace Graphics {
            namespace DirectX {
                
                typedef enum DirectXPixelFormat : int DirectXPixelFormat;
                
            } /* DirectX */
        } /* Graphics */
    } /* Windows */
} /* ABI */




#ifndef ____x_ABI_CWindows_CGraphics_CEffects_CIGraphicsEffectSource_FWD_DEFINED__
#define ____x_ABI_CWindows_CGraphics_CEffects_CIGraphicsEffectSource_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Graphics {
            namespace Effects {
                interface IGraphicsEffectSource;
            } /* Effects */
        } /* Graphics */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CGraphics_CEffects_CIGraphicsEffectSource ABI::Windows::Graphics::Effects::IGraphicsEffectSource

#endif // ____x_ABI_CWindows_CGraphics_CEffects_CIGraphicsEffectSource_FWD_DEFINED__





namespace ABI {
    namespace Windows {
        namespace Graphics {
            namespace Imaging {
                
                typedef struct BitmapSize BitmapSize;
                
            } /* Imaging */
        } /* Graphics */
    } /* Windows */
} /* ABI */

namespace ABI {
    namespace Windows {
        namespace Graphics {
            namespace Imaging {
                class SoftwareBitmap;
            } /* Imaging */
        } /* Graphics */
    } /* Windows */
} /* ABI */

#ifndef ____x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap_FWD_DEFINED__
#define ____x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Graphics {
            namespace Imaging {
                interface ISoftwareBitmap;
            } /* Imaging */
        } /* Graphics */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap ABI::Windows::Graphics::Imaging::ISoftwareBitmap

#endif // ____x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap_FWD_DEFINED__





#ifndef ____x_ABI_CWindows_CStorage_CStreams_CIBuffer_FWD_DEFINED__
#define ____x_ABI_CWindows_CStorage_CStreams_CIBuffer_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Storage {
            namespace Streams {
                interface IBuffer;
            } /* Streams */
        } /* Storage */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CStorage_CStreams_CIBuffer ABI::Windows::Storage::Streams::IBuffer

#endif // ____x_ABI_CWindows_CStorage_CStreams_CIBuffer_FWD_DEFINED__


#ifndef ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream_FWD_DEFINED__
#define ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Storage {
            namespace Streams {
                interface IRandomAccessStream;
            } /* Streams */
        } /* Storage */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream ABI::Windows::Storage::Streams::IRandomAccessStream

#endif // ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream_FWD_DEFINED__





namespace ABI {
    namespace Windows {
        namespace UI {
            
            typedef struct Color Color;
            
        } /* UI */
    } /* Windows */
} /* ABI */



namespace ABI {
    namespace Windows {
        namespace UI {
            namespace Core {
                class CoreWindow;
            } /* Core */
        } /* UI */
    } /* Windows */
} /* ABI */

#ifndef ____x_ABI_CWindows_CUI_CCore_CICoreWindow_FWD_DEFINED__
#define ____x_ABI_CWindows_CUI_CCore_CICoreWindow_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace UI {
            namespace Core {
                interface ICoreWindow;
            } /* Core */
        } /* UI */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CUI_CCore_CICoreWindow ABI::Windows::UI::Core::ICoreWindow

#endif // ____x_ABI_CWindows_CUI_CCore_CICoreWindow_FWD_DEFINED__





namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasAlphaMode : int CanvasAlphaMode;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasAntialiasing : int CanvasAntialiasing;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasBitmapFileFormat : int CanvasBitmapFileFormat;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasBlend : int CanvasBlend;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasBufferPrecision : int CanvasBufferPrecision;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasColorSpace : int CanvasColorSpace;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasComposite : int CanvasComposite;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasDebugLevel : int CanvasDebugLevel;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasDpiRounding : int CanvasDpiRounding;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasEdgeBehavior : int CanvasEdgeBehavior;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasImageInterpolation : int CanvasImageInterpolation;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasLayerOptions : unsigned int CanvasLayerOptions;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasSpriteFlip : unsigned int CanvasSpriteFlip;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasSpriteOptions : unsigned int CanvasSpriteOptions;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasSpriteSortMode : int CanvasSpriteSortMode;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasSwapChainRotation : int CanvasSwapChainRotation;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasUnits : int CanvasUnits;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                
                typedef enum CanvasVirtualBitmapOptions : int CanvasVirtualBitmapOptions;
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


























namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                class CanvasActiveLayer;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */



namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                class CanvasCommandList;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */



namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                class CanvasDrawingSession;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */



namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                class CanvasLock;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                class CanvasRenderTarget;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                class CanvasSpriteBatch;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                class CanvasSwapChain;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */











/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasAlphaMode
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version] */
                enum CanvasAlphaMode : int
                {
                    CanvasAlphaMode_Premultiplied = 0,
                    CanvasAlphaMode_Straight = 1,
                    CanvasAlphaMode_Ignore = 2,
                };
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasAntialiasing
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version] */
                enum CanvasAntialiasing : int
                {
                    CanvasAntialiasing_Antialiased = 0,
                    CanvasAntialiasing_Aliased = 1,
                };
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasBitmapFileFormat
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version] */
                enum CanvasBitmapFileFormat : int
                {
                    CanvasBitmapFileFormat_Auto = 0,
                    CanvasBitmapFileFormat_Bmp = 1,
                    CanvasBitmapFileFormat_Png = 2,
                    CanvasBitmapFileFormat_Jpeg = 3,
                    CanvasBitmapFileFormat_Tiff = 4,
                    CanvasBitmapFileFormat_Gif = 5,
                    CanvasBitmapFileFormat_JpegXR = 6,
                };
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasBlend
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version] */
                enum CanvasBlend : int
                {
                    CanvasBlend_SourceOver = 0,
                    CanvasBlend_Copy = 1,
                    CanvasBlend_Min = 2,
                    CanvasBlend_Add = 3,
                };
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasBufferPrecision
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version] */
                enum CanvasBufferPrecision : int
                {
                    CanvasBufferPrecision_Precision8UIntNormalized = 0,
                    CanvasBufferPrecision_Precision8UIntNormalizedSrgb = 1,
                    CanvasBufferPrecision_Precision16UIntNormalized = 2,
                    CanvasBufferPrecision_Precision16Float = 3,
                    CanvasBufferPrecision_Precision32Float = 4,
                };
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasColorSpace
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version] */
                enum CanvasColorSpace : int
                {
                    CanvasColorSpace_Custom = 0,
                    CanvasColorSpace_Srgb = 1,
                    CanvasColorSpace_ScRgb = 2,
                };
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasComposite
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version] */
                enum CanvasComposite : int
                {
                    CanvasComposite_SourceOver = 0,
                    CanvasComposite_DestinationOver = 1,
                    CanvasComposite_SourceIn = 2,
                    CanvasComposite_DestinationIn = 3,
                    CanvasComposite_SourceOut = 4,
                    CanvasComposite_DestinationOut = 5,
                    CanvasComposite_SourceAtop = 6,
                    CanvasComposite_DestinationAtop = 7,
                    CanvasComposite_Xor = 8,
                    CanvasComposite_Add = 9,
                    CanvasComposite_Copy = 10,
                    CanvasComposite_BoundedCopy = 11,
                    CanvasComposite_MaskInvert = 12,
                };
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasDebugLevel
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version] */
                enum CanvasDebugLevel : int
                {
                    CanvasDebugLevel_None = 0,
                    CanvasDebugLevel_Error = 1,
                    CanvasDebugLevel_Warning = 2,
                    CanvasDebugLevel_Information = 3,
                };
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasDpiRounding
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version] */
                enum CanvasDpiRounding : int
                {
                    CanvasDpiRounding_Floor = 0,
                    CanvasDpiRounding_Round = 1,
                    CanvasDpiRounding_Ceiling = 2,
                };
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasEdgeBehavior
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version] */
                enum CanvasEdgeBehavior : int
                {
                    CanvasEdgeBehavior_Clamp = 0,
                    CanvasEdgeBehavior_Wrap = 1,
                    CanvasEdgeBehavior_Mirror = 2,
                };
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasImageInterpolation
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version] */
                enum CanvasImageInterpolation : int
                {
                    CanvasImageInterpolation_NearestNeighbor = 0,
                    CanvasImageInterpolation_Linear = 1,
                    CanvasImageInterpolation_Cubic = 2,
                    CanvasImageInterpolation_MultiSampleLinear = 3,
                    CanvasImageInterpolation_Anisotropic = 4,
                    CanvasImageInterpolation_HighQualityCubic = 5,
                };
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasLayerOptions
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version, flags] */
                enum CanvasLayerOptions : unsigned int
                {
                    CanvasLayerOptions_None = 0,
                    CanvasLayerOptions_InitializeFromBackground = 0x1,
                    CanvasLayerOptions_IgnoreAlpha = 0x2,
                };
                
                DEFINE_ENUM_FLAG_OPERATORS(CanvasLayerOptions)
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasSpriteFlip
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version, flags] */
                enum CanvasSpriteFlip : unsigned int
                {
                    CanvasSpriteFlip_None = 0,
                    CanvasSpriteFlip_Horizontal = 0x1,
                    CanvasSpriteFlip_Vertical = 0x2,
                    CanvasSpriteFlip_Both = 0x3,
                };
                
                DEFINE_ENUM_FLAG_OPERATORS(CanvasSpriteFlip)
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasSpriteOptions
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version, flags] */
                enum CanvasSpriteOptions : unsigned int
                {
                    CanvasSpriteOptions_None = 0,
                    CanvasSpriteOptions_ClampToSourceRect = 0x1,
                };
                
                DEFINE_ENUM_FLAG_OPERATORS(CanvasSpriteOptions)
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasSpriteSortMode
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version] */
                enum CanvasSpriteSortMode : int
                {
                    CanvasSpriteSortMode_None = 0,
                    CanvasSpriteSortMode_Bitmap = 1,
                };
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasSwapChainRotation
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version] */
                enum CanvasSwapChainRotation : int
                {
                    CanvasSwapChainRotation_None = 0,
                    CanvasSwapChainRotation_Rotate90 = 1,
                    CanvasSwapChainRotation_Rotate180 = 2,
                    CanvasSwapChainRotation_Rotate270 = 3,
                };
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasUnits
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version] */
                enum CanvasUnits : int
                {
                    CanvasUnits_Dips = 0,
                    CanvasUnits_Pixels = 1,
                };
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasVirtualBitmapOptions
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [v1_enum, version] */
                enum CanvasVirtualBitmapOptions : int
                {
                    CanvasVirtualBitmapOptions_None = 0,
                    CanvasVirtualBitmapOptions_ReleaseSource = 1,
                    CanvasVirtualBitmapOptions_CacheOnDemand = 2,
                };
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasActiveLayer
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasActiveLayer
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasActiveLayer[] = L"Microsoft.Graphics.Canvas.ICanvasActiveLayer";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("49ECFC58-5E1C-4EE3-8088-542F94E93C60"), exclusiveto] */
                MIDL_INTERFACE("49ECFC58-5E1C-4EE3-8088-542F94E93C60")
                ICanvasActiveLayer : public IInspectable
                {
                public:
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasActiveLayer=_uuidof(ICanvasActiveLayer);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasBitmap
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasBitmap
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Microsoft.Graphics.Canvas.ICanvasImage
 *     Windows.Graphics.Effects.IGraphicsEffectSource
 *     Windows.Foundation.IClosable
 *     Windows.Graphics.DirectX.Direct3D11.IDirect3DSurface
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasBitmap[] = L"Microsoft.Graphics.Canvas.ICanvasBitmap";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("C57532ED-709E-4AC2-86BE-A1EC3A7FA8FE"), exclusiveto] */
                MIDL_INTERFACE("C57532ED-709E-4AC2-86BE-A1EC3A7FA8FE")
                ICanvasBitmap : public IInspectable
                {
                public:
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_SizeInPixels(
                        /* [retval, out] */ABI::Windows::Graphics::Imaging::BitmapSize * size
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Size(
                        /* [retval, out] */ABI::Windows::Foundation::Size * size
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Bounds(
                        /* [retval, out] */ABI::Windows::Foundation::Rect * bounds
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Format(
                        /* [retval, out] */ABI::Windows::Graphics::DirectX::DirectXPixelFormat * value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_AlphaMode(
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::CanvasAlphaMode * value
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE SaveToFileAsync(
                        /* [in] */HSTRING fileName,
                        /* [retval, out] */ABI::Windows::Foundation::IAsyncAction * * asyncAction
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE SaveToFileWithBitmapFileFormatAsync(
                        /* [in] */HSTRING fileName,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasBitmapFileFormat fileFormat,
                        /* [retval, out] */ABI::Windows::Foundation::IAsyncAction * * asyncAction
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE SaveToFileWithBitmapFileFormatAndQualityAsync(
                        /* [in] */HSTRING fileName,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasBitmapFileFormat fileFormat,
                        /* [in] */FLOAT quality,
                        /* [retval, out] */ABI::Windows::Foundation::IAsyncAction * * asyncAction
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE SaveToStreamAsync(
                        /* [in] */ABI::Windows::Storage::Streams::IRandomAccessStream * stream,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasBitmapFileFormat fileFormat,
                        /* [retval, out] */ABI::Windows::Foundation::IAsyncAction * * asyncAction
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE SaveToStreamWithQualityAsync(
                        /* [in] */ABI::Windows::Storage::Streams::IRandomAccessStream * stream,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasBitmapFileFormat fileFormat,
                        /* [in] */FLOAT quality,
                        /* [retval, out] */ABI::Windows::Foundation::IAsyncAction * * asyncAction
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetPixelBytes(
                        /* [out] */UINT32 * __valueElementsSize,
                        /* [size_is(, *(__valueElementsSize)), retval, out] */BYTE * * valueElements
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetPixelBytesWithSubrectangle(
                        /* [in] */INT32 left,
                        /* [in] */INT32 top,
                        /* [in] */INT32 width,
                        /* [in] */INT32 height,
                        /* [out] */UINT32 * __valueElementsSize,
                        /* [size_is(, *(__valueElementsSize)), retval, out] */BYTE * * valueElements
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetPixelBytesWithBuffer(
                        /* [in] */ABI::Windows::Storage::Streams::IBuffer * buffer
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetPixelBytesWithBufferAndSubrectangle(
                        /* [in] */ABI::Windows::Storage::Streams::IBuffer * buffer,
                        /* [in] */INT32 left,
                        /* [in] */INT32 top,
                        /* [in] */INT32 width,
                        /* [in] */INT32 height
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetPixelColors(
                        /* [out] */UINT32 * __valueElementsSize,
                        /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Windows::UI::Color * * valueElements
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetPixelColorsWithSubrectangle(
                        /* [in] */INT32 left,
                        /* [in] */INT32 top,
                        /* [in] */INT32 width,
                        /* [in] */INT32 height,
                        /* [out] */UINT32 * __valueElementsSize,
                        /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Windows::UI::Color * * valueElements
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE SetPixelBytes(
                        /* [in] */UINT32 __valueElementsSize,
                        /* [size_is(__valueElementsSize), in] */BYTE * valueElements
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE SetPixelBytesWithSubrectangle(
                        /* [in] */UINT32 __valueElementsSize,
                        /* [size_is(__valueElementsSize), in] */BYTE * valueElements,
                        /* [in] */INT32 left,
                        /* [in] */INT32 top,
                        /* [in] */INT32 width,
                        /* [in] */INT32 height
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE SetPixelBytesWithBuffer(
                        /* [in] */ABI::Windows::Storage::Streams::IBuffer * buffer
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE SetPixelBytesWithBufferAndSubrectangle(
                        /* [in] */ABI::Windows::Storage::Streams::IBuffer * buffer,
                        /* [in] */INT32 left,
                        /* [in] */INT32 top,
                        /* [in] */INT32 width,
                        /* [in] */INT32 height
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE SetPixelColors(
                        /* [in] */UINT32 __valueElementsSize,
                        /* [size_is(__valueElementsSize), in] */ABI::Windows::UI::Color * valueElements
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE SetPixelColorsWithSubrectangle(
                        /* [in] */UINT32 __valueElementsSize,
                        /* [size_is(__valueElementsSize), in] */ABI::Windows::UI::Color * valueElements,
                        /* [in] */INT32 left,
                        /* [in] */INT32 top,
                        /* [in] */INT32 width,
                        /* [in] */INT32 height
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CopyPixelsFromBitmap(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * otherBitmap
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CopyPixelsFromBitmapWithDestPoint(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * otherBitmap,
                        /* [in] */INT32 destX,
                        /* [in] */INT32 destY
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CopyPixelsFromBitmapWithDestPointAndSourceRect(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * otherBitmap,
                        /* [in] */INT32 destX,
                        /* [in] */INT32 destY,
                        /* [in] */INT32 sourceRectLeft,
                        /* [in] */INT32 sourceRectTop,
                        /* [in] */INT32 sourceRectWidth,
                        /* [in] */INT32 sourceRectHeight
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasBitmap=_uuidof(ICanvasBitmap);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasBitmapFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasBitmap
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasBitmapFactory[] = L"Microsoft.Graphics.Canvas.ICanvasBitmapFactory";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("F2D0EB0E-16F3-4BCF-B1D1-04834AB97DE4"), exclusiveto] */
                MIDL_INTERFACE("F2D0EB0E-16F3-4BCF-B1D1-04834AB97DE4")
                ICanvasBitmapFactory : public IInspectable
                {
                public:
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasBitmapFactory=_uuidof(ICanvasBitmapFactory);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasBitmapStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasBitmap
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasBitmapStatics[] = L"Microsoft.Graphics.Canvas.ICanvasBitmapStatics";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("C8948DEA-A41D-4CC2-AF9A-FDDE01B606DC"), exclusiveto] */
                MIDL_INTERFACE("C8948DEA-A41D-4CC2-AF9A-FDDE01B606DC")
                ICanvasBitmapStatics : public IInspectable
                {
                public:
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateFromDirect3D11Surface(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Graphics::DirectX::Direct3D11::IDirect3DSurface * surface,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * * bitmap
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateFromDirect3D11SurfaceWithDpi(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Graphics::DirectX::Direct3D11::IDirect3DSurface * surface,
                        /* [in] */FLOAT dpi,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * * bitmap
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateFromDirect3D11SurfaceWithDpiAndAlpha(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Graphics::DirectX::Direct3D11::IDirect3DSurface * surface,
                        /* [in] */FLOAT dpi,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasAlphaMode alpha,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * * bitmap
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreateFromBytes(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */UINT32 __bytesSize,
                        /* [size_is(__bytesSize), in] */BYTE * bytes,
                        /* [in] */INT32 widthInPixels,
                        /* [in] */INT32 heightInPixels,
                        /* [in] */ABI::Windows::Graphics::DirectX::DirectXPixelFormat format,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * * bitmap
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreateFromBytesWithDpi(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */UINT32 __bytesSize,
                        /* [size_is(__bytesSize), in] */BYTE * bytes,
                        /* [in] */INT32 widthInPixels,
                        /* [in] */INT32 heightInPixels,
                        /* [in] */ABI::Windows::Graphics::DirectX::DirectXPixelFormat format,
                        /* [in] */FLOAT dpi,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * * bitmap
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreateFromBytesWithDpiAndAlpha(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */UINT32 __bytesSize,
                        /* [size_is(__bytesSize), in] */BYTE * bytes,
                        /* [in] */INT32 widthInPixels,
                        /* [in] */INT32 heightInPixels,
                        /* [in] */ABI::Windows::Graphics::DirectX::DirectXPixelFormat format,
                        /* [in] */FLOAT dpi,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasAlphaMode alpha,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * * bitmap
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateFromBytesWithBuffer(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Storage::Streams::IBuffer * buffer,
                        /* [in] */INT32 widthInPixels,
                        /* [in] */INT32 heightInPixels,
                        /* [in] */ABI::Windows::Graphics::DirectX::DirectXPixelFormat format,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * * bitmap
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateFromBytesWithBufferAndDpi(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Storage::Streams::IBuffer * buffer,
                        /* [in] */INT32 widthInPixels,
                        /* [in] */INT32 heightInPixels,
                        /* [in] */ABI::Windows::Graphics::DirectX::DirectXPixelFormat format,
                        /* [in] */FLOAT dpi,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * * bitmap
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateFromBytesWithBufferAndDpiAndAlpha(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Storage::Streams::IBuffer * buffer,
                        /* [in] */INT32 widthInPixels,
                        /* [in] */INT32 heightInPixels,
                        /* [in] */ABI::Windows::Graphics::DirectX::DirectXPixelFormat format,
                        /* [in] */FLOAT dpi,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasAlphaMode alpha,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * * bitmap
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateFromColors(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */UINT32 __colorsSize,
                        /* [size_is(__colorsSize), in] */ABI::Windows::UI::Color * colors,
                        /* [in] */INT32 widthInPixels,
                        /* [in] */INT32 heightInPixels,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * * bitmap
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateFromColorsWithDpi(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */UINT32 __colorsSize,
                        /* [size_is(__colorsSize), in] */ABI::Windows::UI::Color * colors,
                        /* [in] */INT32 widthInPixels,
                        /* [in] */INT32 heightInPixels,
                        /* [in] */FLOAT dpi,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * * bitmap
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateFromColorsWithDpiAndAlpha(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */UINT32 __colorsSize,
                        /* [size_is(__colorsSize), in] */ABI::Windows::UI::Color * colors,
                        /* [in] */INT32 widthInPixels,
                        /* [in] */INT32 heightInPixels,
                        /* [in] */FLOAT dpi,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasAlphaMode alpha,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * * bitmap
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE CreateFromSoftwareBitmap(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Graphics::Imaging::ISoftwareBitmap * sourceBitmap,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * * bitmap
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromHstring(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */HSTRING fileName,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromHstringWithDpi(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */HSTRING fileName,
                        /* [in] */FLOAT dpi,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromHstringWithDpiAndAlpha(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */HSTRING fileName,
                        /* [in] */FLOAT dpi,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasAlphaMode alpha,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromUri(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Foundation::IUriRuntimeClass * uri,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromUriWithDpi(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Foundation::IUriRuntimeClass * uri,
                        /* [in] */FLOAT dpi,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromUriWithDpiAndAlpha(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Foundation::IUriRuntimeClass * uri,
                        /* [in] */FLOAT dpi,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasAlphaMode alpha,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromStream(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Storage::Streams::IRandomAccessStream * stream,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromStreamWithDpi(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Storage::Streams::IRandomAccessStream * stream,
                        /* [in] */FLOAT dpi,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromStreamWithDpiAndAlpha(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Storage::Streams::IRandomAccessStream * stream,
                        /* [in] */FLOAT dpi,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasAlphaMode alpha,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasBitmapStatics=_uuidof(ICanvasBitmapStatics);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasCommandList
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasCommandList
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Microsoft.Graphics.Canvas.ICanvasImage
 *     Windows.Graphics.Effects.IGraphicsEffectSource
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasCommandList[] = L"Microsoft.Graphics.Canvas.ICanvasCommandList";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("B71E73CF-2FE7-4D3A-BBB8-19F016F5BE1B"), exclusiveto] */
                MIDL_INTERFACE("B71E73CF-2FE7-4D3A-BBB8-19F016F5BE1B")
                ICanvasCommandList : public IInspectable
                {
                public:
                    virtual HRESULT STDMETHODCALLTYPE CreateDrawingSession(
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDrawingSession * * drawingSession
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Device(
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * * value
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasCommandList=_uuidof(ICanvasCommandList);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasCommandListFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasCommandList
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasCommandListFactory[] = L"Microsoft.Graphics.Canvas.ICanvasCommandListFactory";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("B3D44E68-D931-4B5B-B957-0888980A7D50"), exclusiveto] */
                MIDL_INTERFACE("B3D44E68-D931-4B5B-B957-0888980A7D50")
                ICanvasCommandListFactory : public IInspectable
                {
                public:
                    virtual HRESULT STDMETHODCALLTYPE Create(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasCommandList * * commandList
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasCommandListFactory=_uuidof(ICanvasCommandListFactory);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasDevice
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasDevice
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *     Windows.Graphics.DirectX.Direct3D11.IDirect3DDevice
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasDevice[] = L"Microsoft.Graphics.Canvas.ICanvasDevice";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("A27F0B5D-EC2C-4D4F-948F-0AA1E95E33E6"), exclusiveto] */
                MIDL_INTERFACE("A27F0B5D-EC2C-4D4F-948F-0AA1E95E33E6")
                ICanvasDevice : public IInspectable
                {
                public:
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_ForceSoftwareRenderer(
                        /* [retval, out] */::boolean * value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_MaximumBitmapSizeInPixels(
                        /* [retval, out] */INT32 * value
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE IsPixelFormatSupported(
                        /* [in] */ABI::Windows::Graphics::DirectX::DirectXPixelFormat pixelFormat,
                        /* [retval, out] */::boolean * value
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE IsBufferPrecisionSupported(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasBufferPrecision bufferPrecision,
                        /* [retval, out] */::boolean * value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_MaximumCacheSize(
                        /* [retval, out] */UINT64 * value
                        ) = 0;
                    /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_MaximumCacheSize(
                        /* [in] */UINT64 value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LowPriority(
                        /* [retval, out] */::boolean * value
                        ) = 0;
                    /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_LowPriority(
                        /* [in] */::boolean value
                        ) = 0;
                    /* [eventadd] */virtual HRESULT STDMETHODCALLTYPE add_DeviceLost(
                        /* [in] */__FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable * value,
                        /* [retval, out] */EventRegistrationToken * token
                        ) = 0;
                    /* [eventremove] */virtual HRESULT STDMETHODCALLTYPE remove_DeviceLost(
                        /* [in] */EventRegistrationToken token
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE IsDeviceLost(
                        /* [in] */INT32 hresult,
                        /* [retval, out] */::boolean * value
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE RaiseDeviceLost(void) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Lock(
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasLock * * lock
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasDevice=_uuidof(ICanvasDevice);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasDeviceFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasDevice
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasDeviceFactory[] = L"Microsoft.Graphics.Canvas.ICanvasDeviceFactory";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("E2C2BF21-5418-43B9-A2DA-539E287C790F"), exclusiveto] */
                MIDL_INTERFACE("E2C2BF21-5418-43B9-A2DA-539E287C790F")
                ICanvasDeviceFactory : public IInspectable
                {
                public:
                    virtual HRESULT STDMETHODCALLTYPE CreateWithForceSoftwareRendererOption(
                        /* [in] */::boolean forceSoftwareRenderer,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * * canvasDevice
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasDeviceFactory=_uuidof(ICanvasDeviceFactory);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasDeviceStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasDevice
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasDeviceStatics[] = L"Microsoft.Graphics.Canvas.ICanvasDeviceStatics";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("9B6E2B27-CD07-421A-8F69-0AE8A787FE8C"), exclusiveto] */
                MIDL_INTERFACE("9B6E2B27-CD07-421A-8F69-0AE8A787FE8C")
                ICanvasDeviceStatics : public IInspectable
                {
                public:
                    virtual HRESULT STDMETHODCALLTYPE CreateFromDirect3D11Device(
                        /* [in] */ABI::Windows::Graphics::DirectX::Direct3D11::IDirect3DDevice * direct3DDevice,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * * canvasDevice
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetSharedDevice(
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * * canvasDevice
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetSharedDeviceWithForceSoftwareRenderer(
                        /* [in] */::boolean forceSoftwareRenderer,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * * canvasDevice
                        ) = 0;
                    /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_DebugLevel(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasDebugLevel value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_DebugLevel(
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::CanvasDebugLevel * value
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasDeviceStatics=_uuidof(ICanvasDeviceStatics);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasDrawingSession
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasDrawingSession
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasDrawingSession[] = L"Microsoft.Graphics.Canvas.ICanvasDrawingSession";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("F60AFD09-E623-4BE0-B750-578AA920B1DB"), exclusiveto] */
                MIDL_INTERFACE("F60AFD09-E623-4BE0-B750-578AA920B1DB")
                ICanvasDrawingSession : public IInspectable
                {
                public:
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE Clear(
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE ClearHdr(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector4 color
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Flush(void) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageAtOrigin(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageAtOffset(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageAtCoords(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageToRect(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Rect destinationRectangle
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageAtOffsetWithSourceRect(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageAtCoordsWithSourceRect(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageToRectWithSourceRect(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */ABI::Windows::Foundation::Rect destinationRectangle,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageAtOffsetWithSourceRectAndOpacity(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle,
                        /* [in] */FLOAT opacity
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageAtCoordsWithSourceRectAndOpacity(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle,
                        /* [in] */FLOAT opacity
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageToRectWithSourceRectAndOpacity(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */ABI::Windows::Foundation::Rect destinationRectangle,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle,
                        /* [in] */FLOAT opacity
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageAtOffsetWithSourceRectAndOpacityAndInterpolation(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle,
                        /* [in] */FLOAT opacity,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasImageInterpolation interpolation
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageAtCoordsWithSourceRectAndOpacityAndInterpolation(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle,
                        /* [in] */FLOAT opacity,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasImageInterpolation interpolation
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageToRectWithSourceRectAndOpacityAndInterpolation(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */ABI::Windows::Foundation::Rect destinationRectangle,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle,
                        /* [in] */FLOAT opacity,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasImageInterpolation interpolation
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageAtOffsetWithSourceRectAndOpacityAndInterpolationAndComposite(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle,
                        /* [in] */FLOAT opacity,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasImageInterpolation interpolation,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasComposite composite
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageAtCoordsWithSourceRectAndOpacityAndInterpolationAndComposite(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle,
                        /* [in] */FLOAT opacity,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasImageInterpolation interpolation,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasComposite composite
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageToRectWithSourceRectAndOpacityAndInterpolationAndComposite(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */ABI::Windows::Foundation::Rect destinationRectangle,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle,
                        /* [in] */FLOAT opacity,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasImageInterpolation interpolation,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasComposite composite
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageAtOffsetWithSourceRectAndOpacityAndInterpolationAndPerspective(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle,
                        /* [in] */FLOAT opacity,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasImageInterpolation interpolation,
                        /* [in] */ABI::Windows::Foundation::Numerics::Matrix4x4 perspective
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageAtCoordsWithSourceRectAndOpacityAndInterpolationAndPerspective(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle,
                        /* [in] */FLOAT opacity,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasImageInterpolation interpolation,
                        /* [in] */ABI::Windows::Foundation::Numerics::Matrix4x4 perspective
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawImageToRectWithSourceRectAndOpacityAndInterpolationAndPerspective(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Rect destinationRectangle,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle,
                        /* [in] */FLOAT opacity,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasImageInterpolation interpolation,
                        /* [in] */ABI::Windows::Foundation::Numerics::Matrix4x4 perspective
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawLineWithBrush(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point0,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point1,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawLineAtCoordsWithBrush(
                        /* [in] */FLOAT x0,
                        /* [in] */FLOAT y0,
                        /* [in] */FLOAT x1,
                        /* [in] */FLOAT y1,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawLineWithColor(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point0,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point1,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawLineAtCoordsWithColor(
                        /* [in] */FLOAT x0,
                        /* [in] */FLOAT y0,
                        /* [in] */FLOAT x1,
                        /* [in] */FLOAT y1,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawLineWithBrushAndStrokeWidth(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point0,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point1,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawLineAtCoordsWithBrushAndStrokeWidth(
                        /* [in] */FLOAT x0,
                        /* [in] */FLOAT y0,
                        /* [in] */FLOAT x1,
                        /* [in] */FLOAT y1,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawLineWithColorAndStrokeWidth(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point0,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point1,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawLineAtCoordsWithColorAndStrokeWidth(
                        /* [in] */FLOAT x0,
                        /* [in] */FLOAT y0,
                        /* [in] */FLOAT x1,
                        /* [in] */FLOAT y1,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawLineWithBrushAndStrokeWidthAndStrokeStyle(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point0,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point1,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawLineAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(
                        /* [in] */FLOAT x0,
                        /* [in] */FLOAT y0,
                        /* [in] */FLOAT x1,
                        /* [in] */FLOAT y1,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawLineWithColorAndStrokeWidthAndStrokeStyle(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point0,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point1,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawLineAtCoordsWithColorAndStrokeWidthAndStrokeStyle(
                        /* [in] */FLOAT x0,
                        /* [in] */FLOAT y0,
                        /* [in] */FLOAT x1,
                        /* [in] */FLOAT y1,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawRectangleWithBrush(
                        /* [in] */ABI::Windows::Foundation::Rect rect,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawRectangleAtCoordsWithBrush(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawRectangleWithColor(
                        /* [in] */ABI::Windows::Foundation::Rect rect,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawRectangleAtCoordsWithColor(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawRectangleWithBrushAndStrokeWidth(
                        /* [in] */ABI::Windows::Foundation::Rect rect,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawRectangleAtCoordsWithBrushAndStrokeWidth(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawRectangleWithColorAndStrokeWidth(
                        /* [in] */ABI::Windows::Foundation::Rect rect,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawRectangleAtCoordsWithColorAndStrokeWidth(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawRectangleWithBrushAndStrokeWidthAndStrokeStyle(
                        /* [in] */ABI::Windows::Foundation::Rect rect,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawRectangleAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawRectangleWithColorAndStrokeWidthAndStrokeStyle(
                        /* [in] */ABI::Windows::Foundation::Rect rect,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawRectangleAtCoordsWithColorAndStrokeWidthAndStrokeStyle(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE FillRectangleWithBrush(
                        /* [in] */ABI::Windows::Foundation::Rect rect,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE FillRectangleAtCoordsWithBrush(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FillRectangleWithColor(
                        /* [in] */ABI::Windows::Foundation::Rect rect,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FillRectangleAtCoordsWithColor(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FillRectangleWithBrushAndOpacityBrush(
                        /* [in] */ABI::Windows::Foundation::Rect rect,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * opacityBrush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FillRectangleAtCoordsWithBrushAndOpacityBrush(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * opacityBrush
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawRoundedRectangleWithBrush(
                        /* [in] */ABI::Windows::Foundation::Rect rect,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawRoundedRectangleAtCoordsWithBrush(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawRoundedRectangleWithColor(
                        /* [in] */ABI::Windows::Foundation::Rect rect,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawRoundedRectangleAtCoordsWithColor(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawRoundedRectangleWithBrushAndStrokeWidth(
                        /* [in] */ABI::Windows::Foundation::Rect rect,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawRoundedRectangleAtCoordsWithBrushAndStrokeWidth(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawRoundedRectangleWithColorAndStrokeWidth(
                        /* [in] */ABI::Windows::Foundation::Rect rect,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawRoundedRectangleAtCoordsWithColorAndStrokeWidth(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawRoundedRectangleWithBrushAndStrokeWidthAndStrokeStyle(
                        /* [in] */ABI::Windows::Foundation::Rect rect,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawRoundedRectangleAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawRoundedRectangleWithColorAndStrokeWidthAndStrokeStyle(
                        /* [in] */ABI::Windows::Foundation::Rect rect,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawRoundedRectangleAtCoordsWithColorAndStrokeWidthAndStrokeStyle(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE FillRoundedRectangleWithBrush(
                        /* [in] */ABI::Windows::Foundation::Rect rect,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE FillRoundedRectangleAtCoordsWithBrush(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FillRoundedRectangleWithColor(
                        /* [in] */ABI::Windows::Foundation::Rect rect,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FillRoundedRectangleAtCoordsWithColor(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawEllipseWithBrush(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawEllipseAtCoordsWithBrush(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawEllipseWithColor(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawEllipseAtCoordsWithColor(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawEllipseWithBrushAndStrokeWidth(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawEllipseAtCoordsWithBrushAndStrokeWidth(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawEllipseWithColorAndStrokeWidth(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawEllipseAtCoordsWithColorAndStrokeWidth(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawEllipseWithBrushAndStrokeWidthAndStrokeStyle(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawEllipseAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawEllipseWithColorAndStrokeWidthAndStrokeStyle(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawEllipseAtCoordsWithColorAndStrokeWidthAndStrokeStyle(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE FillEllipseWithBrush(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE FillEllipseAtCoordsWithBrush(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FillEllipseWithColor(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FillEllipseAtCoordsWithColor(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT radiusX,
                        /* [in] */FLOAT radiusY,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawCircleWithBrush(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                        /* [in] */FLOAT radius,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawCircleAtCoordsWithBrush(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT radius,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawCircleWithColor(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                        /* [in] */FLOAT radius,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawCircleAtCoordsWithColor(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT radius,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawCircleWithBrushAndStrokeWidth(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                        /* [in] */FLOAT radius,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawCircleAtCoordsWithBrushAndStrokeWidth(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT radius,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawCircleWithColorAndStrokeWidth(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                        /* [in] */FLOAT radius,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawCircleAtCoordsWithColorAndStrokeWidth(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT radius,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawCircleWithBrushAndStrokeWidthAndStrokeStyle(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                        /* [in] */FLOAT radius,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawCircleAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT radius,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawCircleWithColorAndStrokeWidthAndStrokeStyle(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                        /* [in] */FLOAT radius,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawCircleAtCoordsWithColorAndStrokeWidthAndStrokeStyle(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT radius,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE FillCircleWithBrush(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                        /* [in] */FLOAT radius,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE FillCircleAtCoordsWithBrush(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT radius,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FillCircleWithColor(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                        /* [in] */FLOAT radius,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FillCircleAtCoordsWithColor(
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT radius,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawTextAtPointWithColor(
                        /* [in] */HSTRING text,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawTextAtPointCoordsWithColor(
                        /* [in] */HSTRING text,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawTextAtPointWithBrushAndFormat(
                        /* [in] */HSTRING text,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextFormat * format
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawTextAtRectWithBrushAndFormat(
                        /* [in] */HSTRING text,
                        /* [in] */ABI::Windows::Foundation::Rect rectangle,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextFormat * format
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawTextAtPointCoordsWithBrushAndFormat(
                        /* [in] */HSTRING text,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextFormat * format
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawTextAtRectCoordsWithBrushAndFormat(
                        /* [in] */HSTRING text,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextFormat * format
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawTextAtPointWithColorAndFormat(
                        /* [in] */HSTRING text,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextFormat * format
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawTextAtRectWithColorAndFormat(
                        /* [in] */HSTRING text,
                        /* [in] */ABI::Windows::Foundation::Rect rectangle,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextFormat * format
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawTextAtPointCoordsWithColorAndFormat(
                        /* [in] */HSTRING text,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextFormat * format
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawTextAtRectCoordsWithColorAndFormat(
                        /* [in] */HSTRING text,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */FLOAT w,
                        /* [in] */FLOAT h,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextFormat * format
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryWithBrush(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryWithColor(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryAtCoordsWithBrush(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryAtCoordsWithColor(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryAtOriginWithBrush(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryAtOriginWithColor(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryWithBrushAndStrokeWidth(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryWithColorAndStrokeWidth(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryAtCoordsWithBrushAndStrokeWidth(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryAtCoordsWithColorAndStrokeWidth(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryAtOriginWithBrushAndStrokeWidth(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryAtOriginWithColorAndStrokeWidth(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryWithBrushAndStrokeWidthAndStrokeStyle(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryWithColorAndStrokeWidthAndStrokeStyle(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryAtCoordsWithColorAndStrokeWidthAndStrokeStyle(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryAtOriginWithBrushAndStrokeWidthAndStrokeStyle(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGeometryAtOriginWithColorAndStrokeWidthAndStrokeStyle(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Windows::UI::Color color,
                        /* [in] */FLOAT strokeWidth,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE FillGeometryWithBrush(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FillGeometryWithBrushAndOpacityBrush(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * opacityBrush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FillGeometryWithColor(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE FillGeometryAtCoordsWithBrush(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FillGeometryAtCoordsWithBrushAndOpacityBrush(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * opacityBrush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FillGeometryAtCoordsWithColor(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE FillGeometryAtOriginWithBrush(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FillGeometryAtOriginWithBrushAndOpacityBrush(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * opacityBrush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FillGeometryAtOriginWithColor(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawCachedGeometryWithBrush(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasCachedGeometry * geometry,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawCachedGeometryWithColor(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasCachedGeometry * geometry,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawCachedGeometryAtCoordsWithBrush(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasCachedGeometry * geometry,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawCachedGeometryAtCoordsWithColor(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasCachedGeometry * geometry,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawCachedGeometryAtOriginWithBrush(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasCachedGeometry * geometry,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawCachedGeometryAtOriginWithColor(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasCachedGeometry * geometry,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawTextLayoutWithBrush(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextLayout * textLayout,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawTextLayoutAtCoordsWithBrush(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextLayout * textLayout,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawTextLayoutWithColor(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextLayout * textLayout,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawTextLayoutAtCoordsWithColor(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextLayout * textLayout,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y,
                        /* [in] */ABI::Windows::UI::Color color
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGradientMeshAtOrigin(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGradientMesh * gradientMesh
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGradientMesh(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGradientMesh * gradientMesh,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGradientMeshAtCoords(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGradientMesh * gradientMesh,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawSvgAtOrigin(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgDocument * svgDocument,
                        /* [in] */ABI::Windows::Foundation::Size viewportSize
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawSvgAtPoint(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgDocument * svgDocument,
                        /* [in] */ABI::Windows::Foundation::Size viewportSize,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawSvgAtCoords(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Svg::ICanvasSvgDocument * svgDocument,
                        /* [in] */ABI::Windows::Foundation::Size viewportSize,
                        /* [in] */FLOAT x,
                        /* [in] */FLOAT y
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Antialiasing(
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::CanvasAntialiasing * value
                        ) = 0;
                    /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Antialiasing(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasAntialiasing value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Blend(
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::CanvasBlend * value
                        ) = 0;
                    /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Blend(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasBlend value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_TextAntialiasing(
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextAntialiasing * value
                        ) = 0;
                    /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_TextAntialiasing(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextAntialiasing value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_TextRenderingParameters(
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextRenderingParameters * * value
                        ) = 0;
                    /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_TextRenderingParameters(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextRenderingParameters * value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Transform(
                        /* [retval, out] */ABI::Windows::Foundation::Numerics::Matrix3x2 * value
                        ) = 0;
                    /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Transform(
                        /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Units(
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::CanvasUnits * value
                        ) = 0;
                    /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Units(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasUnits value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_EffectBufferPrecision(
                        /* [retval, out] */__FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision * * value
                        ) = 0;
                    /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_EffectBufferPrecision(
                        /* [in] */__FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision * value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_EffectTileSize(
                        /* [retval, out] */ABI::Windows::Graphics::Imaging::BitmapSize * value
                        ) = 0;
                    /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_EffectTileSize(
                        /* [in] */ABI::Windows::Graphics::Imaging::BitmapSize value
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateLayerWithOpacity(
                        /* [in] */FLOAT opacity,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasActiveLayer * * layer
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreateLayerWithOpacityBrush(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * opacityBrush,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasActiveLayer * * layer
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateLayerWithOpacityAndClipRectangle(
                        /* [in] */FLOAT opacity,
                        /* [in] */ABI::Windows::Foundation::Rect clipRectangle,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasActiveLayer * * layer
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateLayerWithOpacityBrushAndClipRectangle(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * opacityBrush,
                        /* [in] */ABI::Windows::Foundation::Rect clipRectangle,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasActiveLayer * * layer
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateLayerWithOpacityAndClipGeometry(
                        /* [in] */FLOAT opacity,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * clipGeometry,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasActiveLayer * * layer
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreateLayerWithOpacityBrushAndClipGeometry(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * opacityBrush,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * clipGeometry,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasActiveLayer * * layer
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateLayerWithOpacityAndClipGeometryAndTransform(
                        /* [in] */FLOAT opacity,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * clipGeometry,
                        /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 geometryTransform,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasActiveLayer * * layer
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreateLayerWithOpacityBrushAndClipGeometryAndTransform(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * opacityBrush,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * clipGeometry,
                        /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 geometryTransform,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasActiveLayer * * layer
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateLayerWithAllOptions(
                        /* [in] */FLOAT opacity,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * opacityBrush,
                        /* [in] */ABI::Windows::Foundation::Rect clipRectangle,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * clipGeometry,
                        /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 geometryTransform,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasLayerOptions options,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasActiveLayer * * layer
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGlyphRun(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace * fontFace,
                        /* [in] */FLOAT fontSize,
                        /* [in] */UINT32 __glyphsSize,
                        /* [size_is(__glyphsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * glyphs,
                        /* [in] */::boolean isSideways,
                        /* [in] */UINT32 bidiLevel,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGlyphRunWithMeasuringMode(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace * fontFace,
                        /* [in] */FLOAT fontSize,
                        /* [in] */UINT32 __glyphsSize,
                        /* [size_is(__glyphsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * glyphs,
                        /* [in] */::boolean isSideways,
                        /* [in] */UINT32 bidiLevel,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextMeasuringMode measuringMode
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawGlyphRunWithMeasuringModeAndDescription(
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace * fontFace,
                        /* [in] */FLOAT fontSize,
                        /* [in] */UINT32 __glyphsSize,
                        /* [size_is(__glyphsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * glyphs,
                        /* [in] */::boolean isSideways,
                        /* [in] */UINT32 bidiLevel,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Brushes::ICanvasBrush * brush,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextMeasuringMode measuringMode,
                        /* [in] */HSTRING localeName,
                        /* [in] */HSTRING textString,
                        /* [in] */UINT32 __clusterMapIndicesSize,
                        /* [size_is(__clusterMapIndicesSize), in] */INT32 * clusterMapIndices,
                        /* [in] */UINT32 textPosition
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateSpriteBatch(
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasSpriteBatch * * spriteBatch
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateSpriteBatchWithSortMode(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasSpriteSortMode sortMode,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasSpriteBatch * * spriteBatch
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateSpriteBatchWithSortModeAndInterpolation(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasSpriteSortMode sortMode,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasImageInterpolation interpolation,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasSpriteBatch * * spriteBatch
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateSpriteBatchWithSortModeAndInterpolationAndOptions(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasSpriteSortMode sortMode,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasImageInterpolation interpolation,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasSpriteOptions options,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasSpriteBatch * * spriteBatch
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasDrawingSession=_uuidof(ICanvasDrawingSession);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasImage
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Graphics.Effects.IGraphicsEffectSource
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasImage[] = L"Microsoft.Graphics.Canvas.ICanvasImage";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("794966D3-6A64-47E9-8DA8-B46AAA24D53B")] */
                MIDL_INTERFACE("794966D3-6A64-47E9-8DA8-B46AAA24D53B")
                ICanvasImage : public IInspectable
                {
                public:
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetBounds(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [retval, out] */ABI::Windows::Foundation::Rect * bounds
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetBoundsWithTransform(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                        /* [retval, out] */ABI::Windows::Foundation::Rect * bounds
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasImage=_uuidof(ICanvasImage);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasImageStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasImage
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasImageStatics[] = L"Microsoft.Graphics.Canvas.ICanvasImageStatics";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("C54EEA15-5A14-489A-8FA0-6E84541F922D"), exclusiveto] */
                MIDL_INTERFACE("C54EEA15-5A14-489A-8FA0-6E84541F922D")
                ICanvasImageStatics : public IInspectable
                {
                public:
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE SaveAsync(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle,
                        /* [in] */FLOAT dpi,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Storage::Streams::IRandomAccessStream * stream,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasBitmapFileFormat fileFormat,
                        /* [retval, out] */ABI::Windows::Foundation::IAsyncAction * * action
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE SaveWithQualityAsync(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle,
                        /* [in] */FLOAT dpi,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Storage::Streams::IRandomAccessStream * stream,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasBitmapFileFormat fileFormat,
                        /* [in] */FLOAT quality,
                        /* [retval, out] */ABI::Windows::Foundation::IAsyncAction * * action
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE SaveWithQualityAndBufferPrecisionAsync(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle,
                        /* [in] */FLOAT dpi,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Storage::Streams::IRandomAccessStream * stream,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasBitmapFileFormat fileFormat,
                        /* [in] */FLOAT quality,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasBufferPrecision bufferPrecision,
                        /* [retval, out] */ABI::Windows::Foundation::IAsyncAction * * action
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE ComputeHistogram(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasImage * image,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRectangle,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::Effects::EffectChannelSelect channelSelect,
                        /* [in] */INT32 numberOfBins,
                        /* [out] */UINT32 * __valueElementsSize,
                        /* [size_is(, *(__valueElementsSize)), retval, out] */FLOAT * * valueElements
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE IsHistogramSupported(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * device,
                        /* [retval, out] */::boolean * result
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasImageStatics=_uuidof(ICanvasImageStatics);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasLock
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasLock
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasLock[] = L"Microsoft.Graphics.Canvas.ICanvasLock";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("7A0E8498-FBA9-4FB0-AA8C-6A48B5EE3E4F"), exclusiveto] */
                MIDL_INTERFACE("7A0E8498-FBA9-4FB0-AA8C-6A48B5EE3E4F")
                ICanvasLock : public IInspectable
                {
                public:
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasLock=_uuidof(ICanvasLock);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasRenderTarget
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasRenderTarget
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasRenderTarget[] = L"Microsoft.Graphics.Canvas.ICanvasRenderTarget";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("2D4C7349-9A32-41B9-B3CC-CAF1B7E1099B"), exclusiveto] */
                MIDL_INTERFACE("2D4C7349-9A32-41B9-B3CC-CAF1B7E1099B")
                ICanvasRenderTarget : public IInspectable
                {
                public:
                    virtual HRESULT STDMETHODCALLTYPE CreateDrawingSession(
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDrawingSession * * drawingSession
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasRenderTarget=_uuidof(ICanvasRenderTarget);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasRenderTargetFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasRenderTarget
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasRenderTargetFactory[] = L"Microsoft.Graphics.Canvas.ICanvasRenderTargetFactory";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("620DFDBB-9D08-406C-BFE6-D9B81E6DF8E7"), exclusiveto] */
                MIDL_INTERFACE("620DFDBB-9D08-406C-BFE6-D9B81E6DF8E7")
                ICanvasRenderTargetFactory : public IInspectable
                {
                public:
                    virtual HRESULT STDMETHODCALLTYPE CreateWithSize(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreatorWithDpi * resourceCreator,
                        /* [in] */ABI::Windows::Foundation::Size size,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasRenderTarget * * renderTarget
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE CreateWithWidthAndHeight(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreatorWithDpi * resourceCreator,
                        /* [in] */FLOAT width,
                        /* [in] */FLOAT height,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasRenderTarget * * renderTarget
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE CreateWithWidthAndHeightAndDpi(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */FLOAT width,
                        /* [in] */FLOAT height,
                        /* [in] */FLOAT dpi,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasRenderTarget * * renderTarget
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE CreateWithWidthAndHeightAndDpiAndFormatAndAlpha(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */FLOAT width,
                        /* [in] */FLOAT height,
                        /* [in] */FLOAT dpi,
                        /* [in] */ABI::Windows::Graphics::DirectX::DirectXPixelFormat format,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasAlphaMode alpha,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasRenderTarget * * renderTarget
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasRenderTargetFactory=_uuidof(ICanvasRenderTargetFactory);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasRenderTargetStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasRenderTarget
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasRenderTargetStatics[] = L"Microsoft.Graphics.Canvas.ICanvasRenderTargetStatics";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("C7D1FE37-DD57-45D7-BCC1-15625A21E8D5"), exclusiveto] */
                MIDL_INTERFACE("C7D1FE37-DD57-45D7-BCC1-15625A21E8D5")
                ICanvasRenderTargetStatics : public IInspectable
                {
                public:
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateFromDirect3D11Surface(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Graphics::DirectX::Direct3D11::IDirect3DSurface * surface,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasRenderTarget * * bitmap
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateFromDirect3D11SurfaceWithDpi(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Graphics::DirectX::Direct3D11::IDirect3DSurface * surface,
                        /* [in] */FLOAT dpi,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasRenderTarget * * bitmap
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateFromDirect3D11SurfaceWithDpiAndAlpha(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Graphics::DirectX::Direct3D11::IDirect3DSurface * surface,
                        /* [in] */FLOAT dpi,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasAlphaMode alpha,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasRenderTarget * * bitmap
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasRenderTargetStatics=_uuidof(ICanvasRenderTargetStatics);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasResourceCreator[] = L"Microsoft.Graphics.Canvas.ICanvasResourceCreator";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("8F6D8AA8-492F-4BC6-B3D0-E7F5EAE84B11")] */
                MIDL_INTERFACE("8F6D8AA8-492F-4BC6-B3D0-E7F5EAE84B11")
                ICanvasResourceCreator : public IInspectable
                {
                public:
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Device(
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * * value
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasResourceCreator=_uuidof(ICanvasResourceCreator);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasResourceCreatorWithDpi[] = L"Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("1A75B512-E9FA-49E6-A876-38CAE194013E")] */
                MIDL_INTERFACE("1A75B512-E9FA-49E6-A876-38CAE194013E")
                ICanvasResourceCreatorWithDpi : public IInspectable
                {
                public:
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Dpi(
                        /* [retval, out] */FLOAT * dpi
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE ConvertPixelsToDips(
                        /* [in] */INT32 pixels,
                        /* [retval, out] */FLOAT * dips
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE ConvertDipsToPixels(
                        /* [in] */FLOAT dips,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasDpiRounding dpiRounding,
                        /* [retval, out] */INT32 * pixels
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasResourceCreatorWithDpi=_uuidof(ICanvasResourceCreatorWithDpi);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasSpriteBatch
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasSpriteBatch
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasSpriteBatch[] = L"Microsoft.Graphics.Canvas.ICanvasSpriteBatch";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("A065DCE4-A7F2-4DF4-8405-EA9E3A215BF8"), exclusiveto] */
                MIDL_INTERFACE("A065DCE4-A7F2-4DF4-8405-EA9E3A215BF8")
                ICanvasSpriteBatch : public IInspectable
                {
                public:
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawToRect(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Rect destRect
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawAtOffset(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawWithTransform(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawToRectWithTint(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Rect destRect,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector4 tint
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawAtOffsetWithTint(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector4 tint
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawWithTransformAndTint(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector4 tint
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawToRectWithTintAndFlip(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Rect destRect,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector4 tint,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasSpriteFlip flip
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawWithTransformAndTintAndFlip(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector4 tint,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasSpriteFlip flip
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawAtOffsetWithTintAndTransform(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector4 tint,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 origin,
                        /* [in] */FLOAT rotation,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 scale,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasSpriteFlip flip
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawFromSpriteSheetToRect(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Rect destRect,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRect
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawFromSpriteSheetAtOffset(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRect
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawFromSpriteSheetWithTransform(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRect
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawFromSpriteSheetToRectWithTint(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Rect destRect,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRect,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector4 tint
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawFromSpriteSheetAtOffsetWithTint(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRect,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector4 tint
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawFromSpriteSheetWithTransformAndTint(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRect,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector4 tint
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE DrawFromSpriteSheetToRectWithTintAndFlip(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Rect destRect,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRect,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector4 tint,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasSpriteFlip flip
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawFromSpriteSheetWithTransformAndTintAndFlip(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRect,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector4 tint,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasSpriteFlip flip
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE DrawFromSpriteSheetAtOffsetWithTintAndTransform(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasBitmap * bitmap,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 offset,
                        /* [in] */ABI::Windows::Foundation::Rect sourceRect,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector4 tint,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 origin,
                        /* [in] */FLOAT rotation,
                        /* [in] */ABI::Windows::Foundation::Numerics::Vector2 scale,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasSpriteFlip flip
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasSpriteBatch=_uuidof(ICanvasSpriteBatch);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasSpriteBatchStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasSpriteBatch
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasSpriteBatchStatics[] = L"Microsoft.Graphics.Canvas.ICanvasSpriteBatchStatics";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("851EB08D-9D01-4B57-9E94-24113151B74B"), exclusiveto] */
                MIDL_INTERFACE("851EB08D-9D01-4B57-9E94-24113151B74B")
                ICanvasSpriteBatchStatics : public IInspectable
                {
                public:
                    virtual HRESULT STDMETHODCALLTYPE IsSupported(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * device,
                        /* [retval, out] */::boolean * value
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasSpriteBatchStatics=_uuidof(ICanvasSpriteBatchStatics);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasSwapChain
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasSwapChain
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasSwapChain[] = L"Microsoft.Graphics.Canvas.ICanvasSwapChain";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("882E3C3A-5725-409C-9E76-F80B3BACF1B4"), exclusiveto] */
                MIDL_INTERFACE("882E3C3A-5725-409C-9E76-F80B3BACF1B4")
                ICanvasSwapChain : public IInspectable
                {
                public:
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE Present(void) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE PresentWithSyncInterval(
                        /* [in] */INT32 syncInterval
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE ResizeBuffersWithSize(
                        /* [in] */ABI::Windows::Foundation::Size newSize
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE ResizeBuffersWithWidthAndHeight(
                        /* [in] */FLOAT newWidth,
                        /* [in] */FLOAT newHeight
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE ResizeBuffersWithWidthAndHeightAndDpi(
                        /* [in] */FLOAT newWidth,
                        /* [in] */FLOAT newHeight,
                        /* [in] */FLOAT newDpi
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE ResizeBuffersWithAllOptions(
                        /* [in] */FLOAT newWidth,
                        /* [in] */FLOAT newHeight,
                        /* [in] */FLOAT newDpi,
                        /* [in] */ABI::Windows::Graphics::DirectX::DirectXPixelFormat newFormat,
                        /* [in] */INT32 bufferCount
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Size(
                        /* [retval, out] */ABI::Windows::Foundation::Size * size
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_SizeInPixels(
                        /* [retval, out] */ABI::Windows::Graphics::Imaging::BitmapSize * size
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Format(
                        /* [retval, out] */ABI::Windows::Graphics::DirectX::DirectXPixelFormat * value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_BufferCount(
                        /* [retval, out] */INT32 * value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_AlphaMode(
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::CanvasAlphaMode * value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Rotation(
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::CanvasSwapChainRotation * value
                        ) = 0;
                    /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_Rotation(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasSwapChainRotation value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_SourceSize(
                        /* [retval, out] */ABI::Windows::Foundation::Size * value
                        ) = 0;
                    /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_SourceSize(
                        /* [in] */ABI::Windows::Foundation::Size value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_TransformMatrix(
                        /* [retval, out] */ABI::Windows::Foundation::Numerics::Matrix3x2 * value
                        ) = 0;
                    /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_TransformMatrix(
                        /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 value
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE CreateDrawingSession(
                        /* [in] */ABI::Windows::UI::Color clearColor,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDrawingSession * * drawingSession
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE WaitForVerticalBlank(void) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasSwapChain=_uuidof(ICanvasSwapChain);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasSwapChainFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasSwapChain
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasSwapChainFactory[] = L"Microsoft.Graphics.Canvas.ICanvasSwapChainFactory";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("133C25CB-ED3C-492B-BFFE-7509B521842B"), exclusiveto] */
                MIDL_INTERFACE("133C25CB-ED3C-492B-BFFE-7509B521842B")
                ICanvasSwapChainFactory : public IInspectable
                {
                public:
                    virtual HRESULT STDMETHODCALLTYPE CreateWithSize(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreatorWithDpi * resourceCreator,
                        /* [in] */ABI::Windows::Foundation::Size size,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasSwapChain * * swapChain
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE CreateWithWidthAndHeight(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreatorWithDpi * resourceCreator,
                        /* [in] */FLOAT width,
                        /* [in] */FLOAT height,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasSwapChain * * swapChain
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE CreateWithWidthAndHeightAndDpi(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */FLOAT width,
                        /* [in] */FLOAT height,
                        /* [in] */FLOAT dpi,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasSwapChain * * swapChain
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE CreateWithAllOptions(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */FLOAT width,
                        /* [in] */FLOAT height,
                        /* [in] */FLOAT dpi,
                        /* [in] */ABI::Windows::Graphics::DirectX::DirectXPixelFormat format,
                        /* [in] */INT32 bufferCount,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasAlphaMode alphaMode,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasSwapChain * * swapChain
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasSwapChainFactory=_uuidof(ICanvasSwapChainFactory);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasSwapChainStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasSwapChain
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasSwapChainStatics[] = L"Microsoft.Graphics.Canvas.ICanvasSwapChainStatics";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("05376D8F-3E8D-4A82-9838-691680D32A52"), exclusiveto] */
                MIDL_INTERFACE("05376D8F-3E8D-4A82-9838-691680D32A52")
                ICanvasSwapChainStatics : public IInspectable
                {
                public:
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateForCoreWindowWithDpi(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::UI::Core::ICoreWindow * coreWindow,
                        /* [in] */FLOAT dpi,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasSwapChain * * swapChain
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateForCoreWindowWithAllOptions(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::UI::Core::ICoreWindow * coreWindow,
                        /* [in] */FLOAT width,
                        /* [in] */FLOAT height,
                        /* [in] */FLOAT dpi,
                        /* [in] */ABI::Windows::Graphics::DirectX::DirectXPixelFormat format,
                        /* [in] */INT32 bufferCount,
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasSwapChain * * swapChain
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasSwapChainStatics=_uuidof(ICanvasSwapChainStatics);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasVirtualBitmap
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasVirtualBitmap
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.ICanvasImage
 *     Windows.Graphics.Effects.IGraphicsEffectSource
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasVirtualBitmap[] = L"Microsoft.Graphics.Canvas.ICanvasVirtualBitmap";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("707D8BB0-05F9-484C-9EE2-179E0681C8A7"), exclusiveto] */
                MIDL_INTERFACE("707D8BB0-05F9-484C-9EE2-179E0681C8A7")
                ICanvasVirtualBitmap : public IInspectable
                {
                public:
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Device(
                        /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * * value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_IsCachedOnDemand(
                        /* [retval, out] */::boolean * value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_SizeInPixels(
                        /* [retval, out] */ABI::Windows::Graphics::Imaging::BitmapSize * value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Size(
                        /* [retval, out] */ABI::Windows::Foundation::Size * value
                        ) = 0;
                    /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Bounds(
                        /* [retval, out] */ABI::Windows::Foundation::Rect * value
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasVirtualBitmap=_uuidof(ICanvasVirtualBitmap);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasVirtualBitmapStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasVirtualBitmap
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasVirtualBitmapStatics[] = L"Microsoft.Graphics.Canvas.ICanvasVirtualBitmapStatics";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                /* [object, version, uuid("B2F1F8E9-0770-4DD4-956D-78D911390957"), exclusiveto] */
                MIDL_INTERFACE("B2F1F8E9-0770-4DD4-956D-78D911390957")
                ICanvasVirtualBitmapStatics : public IInspectable
                {
                public:
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromFileName(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */HSTRING fileName,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromFileNameWithOptions(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */HSTRING fileName,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasVirtualBitmapOptions options,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromFileNameWithOptionsAndAlpha(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */HSTRING fileName,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasVirtualBitmapOptions options,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasAlphaMode alpha,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromUri(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Foundation::IUriRuntimeClass * uri,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromUriWithOptions(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Foundation::IUriRuntimeClass * uri,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasVirtualBitmapOptions options,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromUriWithOptionsAndAlpha(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Foundation::IUriRuntimeClass * uri,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasVirtualBitmapOptions options,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasAlphaMode alpha,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromStream(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Storage::Streams::IRandomAccessStream * stream,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromStreamWithOptions(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Storage::Streams::IRandomAccessStream * stream,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasVirtualBitmapOptions options,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
                        ) = 0;
                    /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE LoadAsyncFromStreamWithOptionsAndAlpha(
                        /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                        /* [in] */ABI::Windows::Storage::Streams::IRandomAccessStream * stream,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasVirtualBitmapOptions options,
                        /* [in] */ABI::Microsoft::Graphics::Canvas::CanvasAlphaMode alpha,
                        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
                        ) = 0;
                    
                };

                extern MIDL_CONST_ID IID & IID_ICanvasVirtualBitmapStatics=_uuidof(ICanvasVirtualBitmapStatics);
                
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_INTERFACE_DEFINED__) */


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasActiveLayer
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasActiveLayer ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasActiveLayer_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasActiveLayer_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasActiveLayer[] = L"Microsoft.Graphics.Canvas.CanvasActiveLayer";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasBitmap
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasBitmap ** Default Interface **
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *    Windows.Graphics.DirectX.Direct3D11.IDirect3DSurface
 *    Windows.Foundation.IClosable
 *    Microsoft.Graphics.Canvas.ICanvasImage
 *    Windows.Graphics.Effects.IGraphicsEffectSource
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasBitmap_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasBitmap_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasBitmap[] = L"Microsoft.Graphics.Canvas.CanvasBitmap";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasCommandList
 *
 * RuntimeClass can be activated.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasCommandList ** Default Interface **
 *    Microsoft.Graphics.Canvas.ICanvasImage
 *    Windows.Foundation.IClosable
 *    Windows.Graphics.Effects.IGraphicsEffectSource
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasCommandList_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasCommandList_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasCommandList[] = L"Microsoft.Graphics.Canvas.CanvasCommandList";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasDevice
 *
 * RuntimeClass can be activated.
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasDevice ** Default Interface **
 *    Windows.Graphics.DirectX.Direct3D11.IDirect3DDevice
 *    Windows.Foundation.IClosable
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasDevice_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasDevice_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasDevice[] = L"Microsoft.Graphics.Canvas.CanvasDevice";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasDrawingSession
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasDrawingSession ** Default Interface **
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasDrawingSession_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasDrawingSession_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasDrawingSession[] = L"Microsoft.Graphics.Canvas.CanvasDrawingSession";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasImage
 *
 * RuntimeClass contains static methods.
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasImage_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasImage_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasImage[] = L"Microsoft.Graphics.Canvas.CanvasImage";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasLock
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasLock ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasLock_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasLock_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasLock[] = L"Microsoft.Graphics.Canvas.CanvasLock";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasRenderTarget
 *
 * RuntimeClass can be activated.
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasRenderTarget ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasRenderTarget_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasRenderTarget_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasRenderTarget[] = L"Microsoft.Graphics.Canvas.CanvasRenderTarget";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasSpriteBatch
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasSpriteBatch ** Default Interface **
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasSpriteBatch_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasSpriteBatch_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasSpriteBatch[] = L"Microsoft.Graphics.Canvas.CanvasSpriteBatch";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasSwapChain
 *
 * RuntimeClass can be activated.
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasSwapChain ** Default Interface **
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasSwapChain_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasSwapChain_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasSwapChain[] = L"Microsoft.Graphics.Canvas.CanvasSwapChain";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasVirtualBitmap
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasVirtualBitmap ** Default Interface **
 *    Microsoft.Graphics.Canvas.ICanvasImage
 *    Windows.Foundation.IClosable
 *    Windows.Graphics.Effects.IGraphicsEffectSource
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasVirtualBitmap_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasVirtualBitmap_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasVirtualBitmap[] = L"Microsoft.Graphics.Canvas.CanvasVirtualBitmap";
#endif




#else // !defined(__cplusplus)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_FWD_DEFINED__

// Parameterized interface forward declarations (C)

// Collection interface definitions

#if !defined(____FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_INTERFACE_DEFINED__)
#define ____FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap;

// Forward declare the async operation.
typedef interface __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap;

typedef struct __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmapVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * This,/* [in] */ __RPC__in_opt __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap *asyncInfo, /* [in] */ AsyncStatus status);
    END_INTERFACE
} __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmapVtbl;

interface __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap
{
    CONST_VTBL struct __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmapVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_Invoke(This,asyncInfo,status)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,status) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_INTERFACE_DEFINED__



#if !defined(____FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_INTERFACE_DEFINED__)
#define ____FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_INTERFACE_DEFINED__

typedef interface __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap;

typedef struct __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmapVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * This, /* [in] */ __RPC__in_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap **handler);
    HRESULT ( STDMETHODCALLTYPE *GetResults )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * This, /* [retval][out] */ __RPC__out __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * *results);
    END_INTERFACE
} __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmapVtbl;

interface __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap
{
    CONST_VTBL struct __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmapVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_put_Completed(This,handler)	\
    ( (This)->lpVtbl -> put_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_get_Completed(This,handler)	\
    ( (This)->lpVtbl -> get_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_GetResults(This,results)	\
    ( (This)->lpVtbl -> GetResults(This,results) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap_INTERFACE_DEFINED__



#if !defined(____FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_INTERFACE_DEFINED__)
#define ____FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_INTERFACE_DEFINED__

typedef interface __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap;

// Forward declare the async operation.
typedef interface __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap;

typedef struct __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmapVtbl
{
    BEGIN_INTERFACE

    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * This,/* [in] */ __RPC__in_opt __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap *asyncInfo, /* [in] */ AsyncStatus status);
    END_INTERFACE
} __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmapVtbl;

interface __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap
{
    CONST_VTBL struct __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmapVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_Invoke(This,asyncInfo,status)	\
    ( (This)->lpVtbl -> Invoke(This,asyncInfo,status) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_INTERFACE_DEFINED__



#if !defined(____FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_INTERFACE_DEFINED__)
#define ____FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_INTERFACE_DEFINED__

typedef interface __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap;

typedef struct __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmapVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * This);

    HRESULT ( STDMETHODCALLTYPE *GetIids )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * This,
        /* [out] */ __RPC__out ULONG *iidCount,
        /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * This, /* [in] */ __RPC__in_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap *handler);
    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Completed )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * This, /* [retval][out] */ __RPC__deref_out_opt __FIAsyncOperationCompletedHandler_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap **handler);
    HRESULT ( STDMETHODCALLTYPE *GetResults )(__RPC__in __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * This, /* [retval][out] */ __RPC__out __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap * *results);
    END_INTERFACE
} __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmapVtbl;

interface __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap
{
    CONST_VTBL struct __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmapVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_put_Completed(This,handler)	\
    ( (This)->lpVtbl -> put_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_get_Completed(This,handler)	\
    ( (This)->lpVtbl -> get_Completed(This,handler) ) 
#define __FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_GetResults(This,results)	\
    ( (This)->lpVtbl -> GetResults(This,results) ) 
#endif /* COBJMACROS */


#endif // ____FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap_INTERFACE_DEFINED__


enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBufferPrecision;
#if !defined(____FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision_INTERFACE_DEFINED__)
#define ____FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision_INTERFACE_DEFINED__

typedef interface __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision;

typedef struct __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecisionVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )( __RPC__in __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision * This );
    ULONG ( STDMETHODCALLTYPE *Release )( __RPC__in __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision * This );

    HRESULT ( STDMETHODCALLTYPE *GetIids )( __RPC__in __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision * This, 
                                            /* [out] */ __RPC__out ULONG *iidCount,
                                            /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids);
    HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( __RPC__in __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision * This, /* [out] */ __RPC__deref_out_opt HSTRING *className);
    HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( __RPC__in __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision * This, /* [out] */ __RPC__out TrustLevel *trustLevel);

    /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Value )(__RPC__in __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision * This, /* [retval][out] */ __RPC__out enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBufferPrecision *value);
    END_INTERFACE
} __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecisionVtbl;

interface __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision
{
    CONST_VTBL struct __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecisionVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 
#define __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 
#define __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 

#define __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 
#define __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 
#define __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 

#define __FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision_get_Value(This,value)	\
    ( (This)->lpVtbl -> get_Value(This,value) ) 
#endif /* COBJMACROS */


#endif // ____FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision_INTERFACE_DEFINED__




#if !defined(____FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable_INTERFACE_DEFINED__)
#define ____FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable_INTERFACE_DEFINED__

typedef interface __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable;

//  Declare the parameterized interface IID.
EXTERN_C const IID IID___FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable;

typedef struct __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectableVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface )(__RPC__in __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable * This,
        /* [in] */ __RPC__in REFIID riid,
        /* [annotation][iid_is][out] */ 
        _COM_Outptr_  void **ppvObject);
    ULONG ( STDMETHODCALLTYPE *AddRef )(__RPC__in __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable * This);
    ULONG ( STDMETHODCALLTYPE *Release )(__RPC__in __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable * This);

    HRESULT ( STDMETHODCALLTYPE *Invoke )(__RPC__in __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable * This,/* [in] */ __RPC__in_opt __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * sender,/* [in] */ __RPC__in_opt IInspectable * e);
    END_INTERFACE
} __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectableVtbl;

interface __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable
{
    CONST_VTBL struct __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectableVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define __FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable_Invoke(This,sender,e)	\
    ( (This)->lpVtbl -> Invoke(This,sender,e) ) 
#endif /* COBJMACROS */



#endif // ____FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable_INTERFACE_DEFINED__



#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush __x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush_FWD_DEFINED__







typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CEffects_CEffectChannelSelect __x_ABI_CMicrosoft_CGraphics_CCanvas_CEffects_CEffectChannelSelect;





#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_FWD_DEFINED__


#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__


#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_FWD_DEFINED__


#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_FWD_DEFINED__






#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument __x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument_FWD_DEFINED__






#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__



typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextAntialiasing __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextAntialiasing;

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat_FWD_DEFINED__


#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__



typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextMeasuringMode __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextMeasuringMode;

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters_FWD_DEFINED__






#ifndef ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CFoundation_CIAsyncAction __x_ABI_CWindows_CFoundation_CIAsyncAction;

#endif // ____x_ABI_CWindows_CFoundation_CIAsyncAction_FWD_DEFINED__


#ifndef ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CFoundation_CIClosable __x_ABI_CWindows_CFoundation_CIClosable;

#endif // ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__





typedef struct __x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 __x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2;


typedef struct __x_ABI_CWindows_CFoundation_CNumerics_CMatrix4x4 __x_ABI_CWindows_CFoundation_CNumerics_CMatrix4x4;


typedef struct __x_ABI_CWindows_CFoundation_CNumerics_CVector2 __x_ABI_CWindows_CFoundation_CNumerics_CVector2;


typedef struct __x_ABI_CWindows_CFoundation_CNumerics_CVector4 __x_ABI_CWindows_CFoundation_CNumerics_CVector4;





typedef struct __x_ABI_CWindows_CFoundation_CRect __x_ABI_CWindows_CFoundation_CRect;


typedef struct __x_ABI_CWindows_CFoundation_CSize __x_ABI_CWindows_CFoundation_CSize;

#ifndef ____x_ABI_CWindows_CFoundation_CIUriRuntimeClass_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIUriRuntimeClass_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CFoundation_CIUriRuntimeClass __x_ABI_CWindows_CFoundation_CIUriRuntimeClass;

#endif // ____x_ABI_CWindows_CFoundation_CIUriRuntimeClass_FWD_DEFINED__




#ifndef ____x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DDevice_FWD_DEFINED__
#define ____x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DDevice_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DDevice __x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DDevice;

#endif // ____x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DDevice_FWD_DEFINED__


#ifndef ____x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DSurface_FWD_DEFINED__
#define ____x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DSurface_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DSurface __x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DSurface;

#endif // ____x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DSurface_FWD_DEFINED__







typedef enum __x_ABI_CWindows_CGraphics_CDirectX_CDirectXPixelFormat __x_ABI_CWindows_CGraphics_CDirectX_CDirectXPixelFormat;




#ifndef ____x_ABI_CWindows_CGraphics_CEffects_CIGraphicsEffectSource_FWD_DEFINED__
#define ____x_ABI_CWindows_CGraphics_CEffects_CIGraphicsEffectSource_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CGraphics_CEffects_CIGraphicsEffectSource __x_ABI_CWindows_CGraphics_CEffects_CIGraphicsEffectSource;

#endif // ____x_ABI_CWindows_CGraphics_CEffects_CIGraphicsEffectSource_FWD_DEFINED__






typedef struct __x_ABI_CWindows_CGraphics_CImaging_CBitmapSize __x_ABI_CWindows_CGraphics_CImaging_CBitmapSize;

#ifndef ____x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap_FWD_DEFINED__
#define ____x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap __x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap;

#endif // ____x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap_FWD_DEFINED__





#ifndef ____x_ABI_CWindows_CStorage_CStreams_CIBuffer_FWD_DEFINED__
#define ____x_ABI_CWindows_CStorage_CStreams_CIBuffer_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CStorage_CStreams_CIBuffer __x_ABI_CWindows_CStorage_CStreams_CIBuffer;

#endif // ____x_ABI_CWindows_CStorage_CStreams_CIBuffer_FWD_DEFINED__


#ifndef ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream_FWD_DEFINED__
#define ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream __x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream;

#endif // ____x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream_FWD_DEFINED__






typedef struct __x_ABI_CWindows_CUI_CColor __x_ABI_CWindows_CUI_CColor;



#ifndef ____x_ABI_CWindows_CUI_CCore_CICoreWindow_FWD_DEFINED__
#define ____x_ABI_CWindows_CUI_CCore_CICoreWindow_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CUI_CCore_CICoreWindow __x_ABI_CWindows_CUI_CCore_CICoreWindow;

#endif // ____x_ABI_CWindows_CUI_CCore_CICoreWindow_FWD_DEFINED__






typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAntialiasing __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAntialiasing;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBitmapFileFormat __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBitmapFileFormat;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBlend __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBlend;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBufferPrecision __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBufferPrecision;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasColorSpace __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasColorSpace;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasComposite __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasComposite;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasDebugLevel __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasDebugLevel;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasDpiRounding __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasDpiRounding;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasEdgeBehavior __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasEdgeBehavior;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasImageInterpolation __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasImageInterpolation;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasLayerOptions __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasLayerOptions;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteFlip __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteFlip;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteOptions __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteOptions;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteSortMode __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteSortMode;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSwapChainRotation __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSwapChainRotation;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasUnits __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasUnits;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasVirtualBitmapOptions __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasVirtualBitmapOptions;













































/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasAlphaMode
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode
{
    CanvasAlphaMode_Premultiplied = 0,
    CanvasAlphaMode_Straight = 1,
    CanvasAlphaMode_Ignore = 2,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasAntialiasing
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAntialiasing
{
    CanvasAntialiasing_Antialiased = 0,
    CanvasAntialiasing_Aliased = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasBitmapFileFormat
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBitmapFileFormat
{
    CanvasBitmapFileFormat_Auto = 0,
    CanvasBitmapFileFormat_Bmp = 1,
    CanvasBitmapFileFormat_Png = 2,
    CanvasBitmapFileFormat_Jpeg = 3,
    CanvasBitmapFileFormat_Tiff = 4,
    CanvasBitmapFileFormat_Gif = 5,
    CanvasBitmapFileFormat_JpegXR = 6,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasBlend
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBlend
{
    CanvasBlend_SourceOver = 0,
    CanvasBlend_Copy = 1,
    CanvasBlend_Min = 2,
    CanvasBlend_Add = 3,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasBufferPrecision
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBufferPrecision
{
    CanvasBufferPrecision_Precision8UIntNormalized = 0,
    CanvasBufferPrecision_Precision8UIntNormalizedSrgb = 1,
    CanvasBufferPrecision_Precision16UIntNormalized = 2,
    CanvasBufferPrecision_Precision16Float = 3,
    CanvasBufferPrecision_Precision32Float = 4,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasColorSpace
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasColorSpace
{
    CanvasColorSpace_Custom = 0,
    CanvasColorSpace_Srgb = 1,
    CanvasColorSpace_ScRgb = 2,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasComposite
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasComposite
{
    CanvasComposite_SourceOver = 0,
    CanvasComposite_DestinationOver = 1,
    CanvasComposite_SourceIn = 2,
    CanvasComposite_DestinationIn = 3,
    CanvasComposite_SourceOut = 4,
    CanvasComposite_DestinationOut = 5,
    CanvasComposite_SourceAtop = 6,
    CanvasComposite_DestinationAtop = 7,
    CanvasComposite_Xor = 8,
    CanvasComposite_Add = 9,
    CanvasComposite_Copy = 10,
    CanvasComposite_BoundedCopy = 11,
    CanvasComposite_MaskInvert = 12,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasDebugLevel
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasDebugLevel
{
    CanvasDebugLevel_None = 0,
    CanvasDebugLevel_Error = 1,
    CanvasDebugLevel_Warning = 2,
    CanvasDebugLevel_Information = 3,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasDpiRounding
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasDpiRounding
{
    CanvasDpiRounding_Floor = 0,
    CanvasDpiRounding_Round = 1,
    CanvasDpiRounding_Ceiling = 2,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasEdgeBehavior
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasEdgeBehavior
{
    CanvasEdgeBehavior_Clamp = 0,
    CanvasEdgeBehavior_Wrap = 1,
    CanvasEdgeBehavior_Mirror = 2,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasImageInterpolation
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasImageInterpolation
{
    CanvasImageInterpolation_NearestNeighbor = 0,
    CanvasImageInterpolation_Linear = 1,
    CanvasImageInterpolation_Cubic = 2,
    CanvasImageInterpolation_MultiSampleLinear = 3,
    CanvasImageInterpolation_Anisotropic = 4,
    CanvasImageInterpolation_HighQualityCubic = 5,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasLayerOptions
 *
 */

/* [v1_enum, version, flags] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasLayerOptions
{
    CanvasLayerOptions_None = 0,
    CanvasLayerOptions_InitializeFromBackground = 0x1,
    CanvasLayerOptions_IgnoreAlpha = 0x2,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasSpriteFlip
 *
 */

/* [v1_enum, version, flags] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteFlip
{
    CanvasSpriteFlip_None = 0,
    CanvasSpriteFlip_Horizontal = 0x1,
    CanvasSpriteFlip_Vertical = 0x2,
    CanvasSpriteFlip_Both = 0x3,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasSpriteOptions
 *
 */

/* [v1_enum, version, flags] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteOptions
{
    CanvasSpriteOptions_None = 0,
    CanvasSpriteOptions_ClampToSourceRect = 0x1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasSpriteSortMode
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteSortMode
{
    CanvasSpriteSortMode_None = 0,
    CanvasSpriteSortMode_Bitmap = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasSwapChainRotation
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSwapChainRotation
{
    CanvasSwapChainRotation_None = 0,
    CanvasSwapChainRotation_Rotate90 = 1,
    CanvasSwapChainRotation_Rotate180 = 2,
    CanvasSwapChainRotation_Rotate270 = 3,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasUnits
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasUnits
{
    CanvasUnits_Dips = 0,
    CanvasUnits_Pixels = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.CanvasVirtualBitmapOptions
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasVirtualBitmapOptions
{
    CanvasVirtualBitmapOptions_None = 0,
    CanvasVirtualBitmapOptions_ReleaseSource = 1,
    CanvasVirtualBitmapOptions_CacheOnDemand = 2,
};


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasActiveLayer
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasActiveLayer
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasActiveLayer[] = L"Microsoft.Graphics.Canvas.ICanvasActiveLayer";
/* [object, version, uuid("49ECFC58-5E1C-4EE3-8088-542F94E93C60"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayerVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayerVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayerVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasBitmap
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasBitmap
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Microsoft.Graphics.Canvas.ICanvasImage
 *     Windows.Graphics.Effects.IGraphicsEffectSource
 *     Windows.Foundation.IClosable
 *     Windows.Graphics.DirectX.Direct3D11.IDirect3DSurface
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasBitmap[] = L"Microsoft.Graphics.Canvas.ICanvasBitmap";
/* [object, version, uuid("C57532ED-709E-4AC2-86BE-A1EC3A7FA8FE"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_SizeInPixels )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [retval, out] */__x_ABI_CWindows_CGraphics_CImaging_CBitmapSize * size
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Size )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CSize * size
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Bounds )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * bounds
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Format )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [retval, out] */__x_ABI_CWindows_CGraphics_CDirectX_CDirectXPixelFormat * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_AlphaMode )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode * value
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *SaveToFileAsync )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */HSTRING fileName,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CIAsyncAction * * asyncAction
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *SaveToFileWithBitmapFileFormatAsync )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */HSTRING fileName,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBitmapFileFormat fileFormat,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CIAsyncAction * * asyncAction
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *SaveToFileWithBitmapFileFormatAndQualityAsync )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */HSTRING fileName,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBitmapFileFormat fileFormat,
        /* [in] */FLOAT quality,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CIAsyncAction * * asyncAction
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *SaveToStreamAsync )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream * stream,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBitmapFileFormat fileFormat,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CIAsyncAction * * asyncAction
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *SaveToStreamWithQualityAsync )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream * stream,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBitmapFileFormat fileFormat,
        /* [in] */FLOAT quality,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CIAsyncAction * * asyncAction
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetPixelBytes )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */BYTE * * valueElements
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetPixelBytesWithSubrectangle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */INT32 left,
        /* [in] */INT32 top,
        /* [in] */INT32 width,
        /* [in] */INT32 height,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */BYTE * * valueElements
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetPixelBytesWithBuffer )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIBuffer * buffer
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetPixelBytesWithBufferAndSubrectangle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIBuffer * buffer,
        /* [in] */INT32 left,
        /* [in] */INT32 top,
        /* [in] */INT32 width,
        /* [in] */INT32 height
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetPixelColors )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CWindows_CUI_CColor * * valueElements
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetPixelColorsWithSubrectangle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */INT32 left,
        /* [in] */INT32 top,
        /* [in] */INT32 width,
        /* [in] */INT32 height,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CWindows_CUI_CColor * * valueElements
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *SetPixelBytes )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */UINT32 __valueElementsSize,
        /* [size_is(__valueElementsSize), in] */BYTE * valueElements
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *SetPixelBytesWithSubrectangle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */UINT32 __valueElementsSize,
        /* [size_is(__valueElementsSize), in] */BYTE * valueElements,
        /* [in] */INT32 left,
        /* [in] */INT32 top,
        /* [in] */INT32 width,
        /* [in] */INT32 height
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *SetPixelBytesWithBuffer )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIBuffer * buffer
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *SetPixelBytesWithBufferAndSubrectangle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIBuffer * buffer,
        /* [in] */INT32 left,
        /* [in] */INT32 top,
        /* [in] */INT32 width,
        /* [in] */INT32 height
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *SetPixelColors )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */UINT32 __valueElementsSize,
        /* [size_is(__valueElementsSize), in] */__x_ABI_CWindows_CUI_CColor * valueElements
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *SetPixelColorsWithSubrectangle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */UINT32 __valueElementsSize,
        /* [size_is(__valueElementsSize), in] */__x_ABI_CWindows_CUI_CColor * valueElements,
        /* [in] */INT32 left,
        /* [in] */INT32 top,
        /* [in] */INT32 width,
        /* [in] */INT32 height
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CopyPixelsFromBitmap )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * otherBitmap
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CopyPixelsFromBitmapWithDestPoint )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * otherBitmap,
        /* [in] */INT32 destX,
        /* [in] */INT32 destY
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CopyPixelsFromBitmapWithDestPointAndSourceRect )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * otherBitmap,
        /* [in] */INT32 destX,
        /* [in] */INT32 destY,
        /* [in] */INT32 sourceRectLeft,
        /* [in] */INT32 sourceRectTop,
        /* [in] */INT32 sourceRectWidth,
        /* [in] */INT32 sourceRectHeight
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_get_SizeInPixels(This,size) \
    ( (This)->lpVtbl->get_SizeInPixels(This,size) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_get_Size(This,size) \
    ( (This)->lpVtbl->get_Size(This,size) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_get_Bounds(This,bounds) \
    ( (This)->lpVtbl->get_Bounds(This,bounds) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_get_Format(This,value) \
    ( (This)->lpVtbl->get_Format(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_get_AlphaMode(This,value) \
    ( (This)->lpVtbl->get_AlphaMode(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_SaveToFileAsync(This,fileName,asyncAction) \
    ( (This)->lpVtbl->SaveToFileAsync(This,fileName,asyncAction) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_SaveToFileWithBitmapFileFormatAsync(This,fileName,fileFormat,asyncAction) \
    ( (This)->lpVtbl->SaveToFileWithBitmapFileFormatAsync(This,fileName,fileFormat,asyncAction) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_SaveToFileWithBitmapFileFormatAndQualityAsync(This,fileName,fileFormat,quality,asyncAction) \
    ( (This)->lpVtbl->SaveToFileWithBitmapFileFormatAndQualityAsync(This,fileName,fileFormat,quality,asyncAction) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_SaveToStreamAsync(This,stream,fileFormat,asyncAction) \
    ( (This)->lpVtbl->SaveToStreamAsync(This,stream,fileFormat,asyncAction) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_SaveToStreamWithQualityAsync(This,stream,fileFormat,quality,asyncAction) \
    ( (This)->lpVtbl->SaveToStreamWithQualityAsync(This,stream,fileFormat,quality,asyncAction) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_GetPixelBytes(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetPixelBytes(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_GetPixelBytesWithSubrectangle(This,left,top,width,height,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetPixelBytesWithSubrectangle(This,left,top,width,height,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_GetPixelBytesWithBuffer(This,buffer) \
    ( (This)->lpVtbl->GetPixelBytesWithBuffer(This,buffer) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_GetPixelBytesWithBufferAndSubrectangle(This,buffer,left,top,width,height) \
    ( (This)->lpVtbl->GetPixelBytesWithBufferAndSubrectangle(This,buffer,left,top,width,height) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_GetPixelColors(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetPixelColors(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_GetPixelColorsWithSubrectangle(This,left,top,width,height,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->GetPixelColorsWithSubrectangle(This,left,top,width,height,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_SetPixelBytes(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->SetPixelBytes(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_SetPixelBytesWithSubrectangle(This,__valueElementsSize,valueElements,left,top,width,height) \
    ( (This)->lpVtbl->SetPixelBytesWithSubrectangle(This,__valueElementsSize,valueElements,left,top,width,height) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_SetPixelBytesWithBuffer(This,buffer) \
    ( (This)->lpVtbl->SetPixelBytesWithBuffer(This,buffer) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_SetPixelBytesWithBufferAndSubrectangle(This,buffer,left,top,width,height) \
    ( (This)->lpVtbl->SetPixelBytesWithBufferAndSubrectangle(This,buffer,left,top,width,height) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_SetPixelColors(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->SetPixelColors(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_SetPixelColorsWithSubrectangle(This,__valueElementsSize,valueElements,left,top,width,height) \
    ( (This)->lpVtbl->SetPixelColorsWithSubrectangle(This,__valueElementsSize,valueElements,left,top,width,height) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_CopyPixelsFromBitmap(This,otherBitmap) \
    ( (This)->lpVtbl->CopyPixelsFromBitmap(This,otherBitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_CopyPixelsFromBitmapWithDestPoint(This,otherBitmap,destX,destY) \
    ( (This)->lpVtbl->CopyPixelsFromBitmapWithDestPoint(This,otherBitmap,destX,destY) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_CopyPixelsFromBitmapWithDestPointAndSourceRect(This,otherBitmap,destX,destY,sourceRectLeft,sourceRectTop,sourceRectWidth,sourceRectHeight) \
    ( (This)->lpVtbl->CopyPixelsFromBitmapWithDestPointAndSourceRect(This,otherBitmap,destX,destY,sourceRectLeft,sourceRectTop,sourceRectWidth,sourceRectHeight) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasBitmapFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasBitmap
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasBitmapFactory[] = L"Microsoft.Graphics.Canvas.ICanvasBitmapFactory";
/* [object, version, uuid("F2D0EB0E-16F3-4BCF-B1D1-04834AB97DE4"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactoryVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasBitmapStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasBitmap
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasBitmapStatics[] = L"Microsoft.Graphics.Canvas.ICanvasBitmapStatics";
/* [object, version, uuid("C8948DEA-A41D-4CC2-AF9A-FDDE01B606DC"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateFromDirect3D11Surface )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DSurface * surface,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * * bitmap
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateFromDirect3D11SurfaceWithDpi )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DSurface * surface,
        /* [in] */FLOAT dpi,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * * bitmap
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateFromDirect3D11SurfaceWithDpiAndAlpha )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DSurface * surface,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode alpha,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * * bitmap
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreateFromBytes )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */UINT32 __bytesSize,
        /* [size_is(__bytesSize), in] */BYTE * bytes,
        /* [in] */INT32 widthInPixels,
        /* [in] */INT32 heightInPixels,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirectXPixelFormat format,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * * bitmap
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreateFromBytesWithDpi )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */UINT32 __bytesSize,
        /* [size_is(__bytesSize), in] */BYTE * bytes,
        /* [in] */INT32 widthInPixels,
        /* [in] */INT32 heightInPixels,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirectXPixelFormat format,
        /* [in] */FLOAT dpi,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * * bitmap
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreateFromBytesWithDpiAndAlpha )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */UINT32 __bytesSize,
        /* [size_is(__bytesSize), in] */BYTE * bytes,
        /* [in] */INT32 widthInPixels,
        /* [in] */INT32 heightInPixels,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirectXPixelFormat format,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode alpha,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * * bitmap
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateFromBytesWithBuffer )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIBuffer * buffer,
        /* [in] */INT32 widthInPixels,
        /* [in] */INT32 heightInPixels,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirectXPixelFormat format,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * * bitmap
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateFromBytesWithBufferAndDpi )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIBuffer * buffer,
        /* [in] */INT32 widthInPixels,
        /* [in] */INT32 heightInPixels,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirectXPixelFormat format,
        /* [in] */FLOAT dpi,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * * bitmap
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateFromBytesWithBufferAndDpiAndAlpha )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIBuffer * buffer,
        /* [in] */INT32 widthInPixels,
        /* [in] */INT32 heightInPixels,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirectXPixelFormat format,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode alpha,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * * bitmap
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateFromColors )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */UINT32 __colorsSize,
        /* [size_is(__colorsSize), in] */__x_ABI_CWindows_CUI_CColor * colors,
        /* [in] */INT32 widthInPixels,
        /* [in] */INT32 heightInPixels,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * * bitmap
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateFromColorsWithDpi )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */UINT32 __colorsSize,
        /* [size_is(__colorsSize), in] */__x_ABI_CWindows_CUI_CColor * colors,
        /* [in] */INT32 widthInPixels,
        /* [in] */INT32 heightInPixels,
        /* [in] */FLOAT dpi,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * * bitmap
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateFromColorsWithDpiAndAlpha )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */UINT32 __colorsSize,
        /* [size_is(__colorsSize), in] */__x_ABI_CWindows_CUI_CColor * colors,
        /* [in] */INT32 widthInPixels,
        /* [in] */INT32 heightInPixels,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode alpha,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * * bitmap
        );
    HRESULT ( STDMETHODCALLTYPE *CreateFromSoftwareBitmap )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CGraphics_CImaging_CISoftwareBitmap * sourceBitmap,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * * bitmap
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromHstring )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */HSTRING fileName,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromHstringWithDpi )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */HSTRING fileName,
        /* [in] */FLOAT dpi,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromHstringWithDpiAndAlpha )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */HSTRING fileName,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode alpha,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromUri )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CFoundation_CIUriRuntimeClass * uri,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromUriWithDpi )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CFoundation_CIUriRuntimeClass * uri,
        /* [in] */FLOAT dpi,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromUriWithDpiAndAlpha )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CFoundation_CIUriRuntimeClass * uri,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode alpha,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromStream )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream * stream,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromStreamWithDpi )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream * stream,
        /* [in] */FLOAT dpi,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromStreamWithDpiAndAlpha )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream * stream,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode alpha,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasBitmap * * canvasBitmap
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStaticsVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_CreateFromDirect3D11Surface(This,resourceCreator,surface,bitmap) \
    ( (This)->lpVtbl->CreateFromDirect3D11Surface(This,resourceCreator,surface,bitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_CreateFromDirect3D11SurfaceWithDpi(This,resourceCreator,surface,dpi,bitmap) \
    ( (This)->lpVtbl->CreateFromDirect3D11SurfaceWithDpi(This,resourceCreator,surface,dpi,bitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_CreateFromDirect3D11SurfaceWithDpiAndAlpha(This,resourceCreator,surface,dpi,alpha,bitmap) \
    ( (This)->lpVtbl->CreateFromDirect3D11SurfaceWithDpiAndAlpha(This,resourceCreator,surface,dpi,alpha,bitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_CreateFromBytes(This,resourceCreator,__bytesSize,bytes,widthInPixels,heightInPixels,format,bitmap) \
    ( (This)->lpVtbl->CreateFromBytes(This,resourceCreator,__bytesSize,bytes,widthInPixels,heightInPixels,format,bitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_CreateFromBytesWithDpi(This,resourceCreator,__bytesSize,bytes,widthInPixels,heightInPixels,format,dpi,bitmap) \
    ( (This)->lpVtbl->CreateFromBytesWithDpi(This,resourceCreator,__bytesSize,bytes,widthInPixels,heightInPixels,format,dpi,bitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_CreateFromBytesWithDpiAndAlpha(This,resourceCreator,__bytesSize,bytes,widthInPixels,heightInPixels,format,dpi,alpha,bitmap) \
    ( (This)->lpVtbl->CreateFromBytesWithDpiAndAlpha(This,resourceCreator,__bytesSize,bytes,widthInPixels,heightInPixels,format,dpi,alpha,bitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_CreateFromBytesWithBuffer(This,resourceCreator,buffer,widthInPixels,heightInPixels,format,bitmap) \
    ( (This)->lpVtbl->CreateFromBytesWithBuffer(This,resourceCreator,buffer,widthInPixels,heightInPixels,format,bitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_CreateFromBytesWithBufferAndDpi(This,resourceCreator,buffer,widthInPixels,heightInPixels,format,dpi,bitmap) \
    ( (This)->lpVtbl->CreateFromBytesWithBufferAndDpi(This,resourceCreator,buffer,widthInPixels,heightInPixels,format,dpi,bitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_CreateFromBytesWithBufferAndDpiAndAlpha(This,resourceCreator,buffer,widthInPixels,heightInPixels,format,dpi,alpha,bitmap) \
    ( (This)->lpVtbl->CreateFromBytesWithBufferAndDpiAndAlpha(This,resourceCreator,buffer,widthInPixels,heightInPixels,format,dpi,alpha,bitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_CreateFromColors(This,resourceCreator,__colorsSize,colors,widthInPixels,heightInPixels,bitmap) \
    ( (This)->lpVtbl->CreateFromColors(This,resourceCreator,__colorsSize,colors,widthInPixels,heightInPixels,bitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_CreateFromColorsWithDpi(This,resourceCreator,__colorsSize,colors,widthInPixels,heightInPixels,dpi,bitmap) \
    ( (This)->lpVtbl->CreateFromColorsWithDpi(This,resourceCreator,__colorsSize,colors,widthInPixels,heightInPixels,dpi,bitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_CreateFromColorsWithDpiAndAlpha(This,resourceCreator,__colorsSize,colors,widthInPixels,heightInPixels,dpi,alpha,bitmap) \
    ( (This)->lpVtbl->CreateFromColorsWithDpiAndAlpha(This,resourceCreator,__colorsSize,colors,widthInPixels,heightInPixels,dpi,alpha,bitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_CreateFromSoftwareBitmap(This,resourceCreator,sourceBitmap,bitmap) \
    ( (This)->lpVtbl->CreateFromSoftwareBitmap(This,resourceCreator,sourceBitmap,bitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_LoadAsyncFromHstring(This,resourceCreator,fileName,canvasBitmap) \
    ( (This)->lpVtbl->LoadAsyncFromHstring(This,resourceCreator,fileName,canvasBitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_LoadAsyncFromHstringWithDpi(This,resourceCreator,fileName,dpi,canvasBitmap) \
    ( (This)->lpVtbl->LoadAsyncFromHstringWithDpi(This,resourceCreator,fileName,dpi,canvasBitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_LoadAsyncFromHstringWithDpiAndAlpha(This,resourceCreator,fileName,dpi,alpha,canvasBitmap) \
    ( (This)->lpVtbl->LoadAsyncFromHstringWithDpiAndAlpha(This,resourceCreator,fileName,dpi,alpha,canvasBitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_LoadAsyncFromUri(This,resourceCreator,uri,canvasBitmap) \
    ( (This)->lpVtbl->LoadAsyncFromUri(This,resourceCreator,uri,canvasBitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_LoadAsyncFromUriWithDpi(This,resourceCreator,uri,dpi,canvasBitmap) \
    ( (This)->lpVtbl->LoadAsyncFromUriWithDpi(This,resourceCreator,uri,dpi,canvasBitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_LoadAsyncFromUriWithDpiAndAlpha(This,resourceCreator,uri,dpi,alpha,canvasBitmap) \
    ( (This)->lpVtbl->LoadAsyncFromUriWithDpiAndAlpha(This,resourceCreator,uri,dpi,alpha,canvasBitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_LoadAsyncFromStream(This,resourceCreator,stream,canvasBitmap) \
    ( (This)->lpVtbl->LoadAsyncFromStream(This,resourceCreator,stream,canvasBitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_LoadAsyncFromStreamWithDpi(This,resourceCreator,stream,dpi,canvasBitmap) \
    ( (This)->lpVtbl->LoadAsyncFromStreamWithDpi(This,resourceCreator,stream,dpi,canvasBitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_LoadAsyncFromStreamWithDpiAndAlpha(This,resourceCreator,stream,dpi,alpha,canvasBitmap) \
    ( (This)->lpVtbl->LoadAsyncFromStreamWithDpiAndAlpha(This,resourceCreator,stream,dpi,alpha,canvasBitmap) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmapStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasCommandList
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasCommandList
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Microsoft.Graphics.Canvas.ICanvasImage
 *     Windows.Graphics.Effects.IGraphicsEffectSource
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasCommandList[] = L"Microsoft.Graphics.Canvas.ICanvasCommandList";
/* [object, version, uuid("B71E73CF-2FE7-4D3A-BBB8-19F016F5BE1B"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateDrawingSession )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * * drawingSession
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Device )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_CreateDrawingSession(This,drawingSession) \
    ( (This)->lpVtbl->CreateDrawingSession(This,drawingSession) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_get_Device(This,value) \
    ( (This)->lpVtbl->get_Device(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasCommandListFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasCommandList
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasCommandListFactory[] = L"Microsoft.Graphics.Canvas.ICanvasCommandListFactory";
/* [object, version, uuid("B3D44E68-D931-4B5B-B957-0888980A7D50"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *Create )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandList * * commandList
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactoryVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_Create(This,resourceCreator,commandList) \
    ( (This)->lpVtbl->Create(This,resourceCreator,commandList) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasCommandListFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasDevice
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasDevice
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *     Windows.Graphics.DirectX.Direct3D11.IDirect3DDevice
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasDevice[] = L"Microsoft.Graphics.Canvas.ICanvasDevice";
/* [object, version, uuid("A27F0B5D-EC2C-4D4F-948F-0AA1E95E33E6"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_ForceSoftwareRenderer )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This,
        /* [retval, out] */boolean * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_MaximumBitmapSizeInPixels )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This,
        /* [retval, out] */INT32 * value
        );
    HRESULT ( STDMETHODCALLTYPE *IsPixelFormatSupported )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirectXPixelFormat pixelFormat,
        /* [retval, out] */boolean * value
        );
    HRESULT ( STDMETHODCALLTYPE *IsBufferPrecisionSupported )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBufferPrecision bufferPrecision,
        /* [retval, out] */boolean * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_MaximumCacheSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This,
        /* [retval, out] */UINT64 * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_MaximumCacheSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This,
        /* [in] */UINT64 value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LowPriority )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This,
        /* [retval, out] */boolean * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_LowPriority )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This,
        /* [in] */boolean value
        );
    /* [eventadd] */HRESULT ( STDMETHODCALLTYPE *add_DeviceLost )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This,
        /* [in] */__FITypedEventHandler_2_Microsoft__CGraphics__CCanvas__CCanvasDevice_IInspectable * value,
        /* [retval, out] */EventRegistrationToken * token
        );
    /* [eventremove] */HRESULT ( STDMETHODCALLTYPE *remove_DeviceLost )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This,
        /* [in] */EventRegistrationToken token
        );
    HRESULT ( STDMETHODCALLTYPE *IsDeviceLost )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This,
        /* [in] */INT32 hresult,
        /* [retval, out] */boolean * value
        );
    HRESULT ( STDMETHODCALLTYPE *RaiseDeviceLost )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This
        );
    HRESULT ( STDMETHODCALLTYPE *Lock )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock * * lock
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_get_ForceSoftwareRenderer(This,value) \
    ( (This)->lpVtbl->get_ForceSoftwareRenderer(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_get_MaximumBitmapSizeInPixels(This,value) \
    ( (This)->lpVtbl->get_MaximumBitmapSizeInPixels(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_IsPixelFormatSupported(This,pixelFormat,value) \
    ( (This)->lpVtbl->IsPixelFormatSupported(This,pixelFormat,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_IsBufferPrecisionSupported(This,bufferPrecision,value) \
    ( (This)->lpVtbl->IsBufferPrecisionSupported(This,bufferPrecision,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_get_MaximumCacheSize(This,value) \
    ( (This)->lpVtbl->get_MaximumCacheSize(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_put_MaximumCacheSize(This,value) \
    ( (This)->lpVtbl->put_MaximumCacheSize(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_get_LowPriority(This,value) \
    ( (This)->lpVtbl->get_LowPriority(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_put_LowPriority(This,value) \
    ( (This)->lpVtbl->put_LowPriority(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_add_DeviceLost(This,value,token) \
    ( (This)->lpVtbl->add_DeviceLost(This,value,token) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_remove_DeviceLost(This,token) \
    ( (This)->lpVtbl->remove_DeviceLost(This,token) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_IsDeviceLost(This,hresult,value) \
    ( (This)->lpVtbl->IsDeviceLost(This,hresult,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_RaiseDeviceLost(This) \
    ( (This)->lpVtbl->RaiseDeviceLost(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_Lock(This,lock) \
    ( (This)->lpVtbl->Lock(This,lock) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasDeviceFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasDevice
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasDeviceFactory[] = L"Microsoft.Graphics.Canvas.ICanvasDeviceFactory";
/* [object, version, uuid("E2C2BF21-5418-43B9-A2DA-539E287C790F"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateWithForceSoftwareRendererOption )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory * This,
        /* [in] */boolean forceSoftwareRenderer,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * * canvasDevice
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactoryVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_CreateWithForceSoftwareRendererOption(This,forceSoftwareRenderer,canvasDevice) \
    ( (This)->lpVtbl->CreateWithForceSoftwareRendererOption(This,forceSoftwareRenderer,canvasDevice) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasDeviceStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasDevice
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasDeviceStatics[] = L"Microsoft.Graphics.Canvas.ICanvasDeviceStatics";
/* [object, version, uuid("9B6E2B27-CD07-421A-8F69-0AE8A787FE8C"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateFromDirect3D11Device )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics * This,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DDevice * direct3DDevice,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * * canvasDevice
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetSharedDevice )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * * canvasDevice
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetSharedDeviceWithForceSoftwareRenderer )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics * This,
        /* [in] */boolean forceSoftwareRenderer,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * * canvasDevice
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_DebugLevel )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasDebugLevel value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_DebugLevel )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasDebugLevel * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStaticsVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_CreateFromDirect3D11Device(This,direct3DDevice,canvasDevice) \
    ( (This)->lpVtbl->CreateFromDirect3D11Device(This,direct3DDevice,canvasDevice) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_GetSharedDevice(This,canvasDevice) \
    ( (This)->lpVtbl->GetSharedDevice(This,canvasDevice) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_GetSharedDeviceWithForceSoftwareRenderer(This,forceSoftwareRenderer,canvasDevice) \
    ( (This)->lpVtbl->GetSharedDeviceWithForceSoftwareRenderer(This,forceSoftwareRenderer,canvasDevice) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_put_DebugLevel(This,value) \
    ( (This)->lpVtbl->put_DebugLevel(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_get_DebugLevel(This,value) \
    ( (This)->lpVtbl->get_DebugLevel(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDeviceStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasDrawingSession
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasDrawingSession
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasDrawingSession[] = L"Microsoft.Graphics.Canvas.ICanvasDrawingSession";
/* [object, version, uuid("F60AFD09-E623-4BE0-B750-578AA920B1DB"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSessionVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload] */HRESULT ( STDMETHODCALLTYPE *Clear )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *ClearHdr )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector4 color
        );
    HRESULT ( STDMETHODCALLTYPE *Flush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageAtOrigin )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageAtOffset )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageAtCoords )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageToRect )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect destinationRectangle
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageAtOffsetWithSourceRect )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageAtCoordsWithSourceRect )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageToRectWithSourceRect )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect destinationRectangle,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageAtOffsetWithSourceRectAndOpacity )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle,
        /* [in] */FLOAT opacity
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageAtCoordsWithSourceRectAndOpacity )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle,
        /* [in] */FLOAT opacity
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageToRectWithSourceRectAndOpacity )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect destinationRectangle,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle,
        /* [in] */FLOAT opacity
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageAtOffsetWithSourceRectAndOpacityAndInterpolation )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle,
        /* [in] */FLOAT opacity,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasImageInterpolation interpolation
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageAtCoordsWithSourceRectAndOpacityAndInterpolation )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle,
        /* [in] */FLOAT opacity,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasImageInterpolation interpolation
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageToRectWithSourceRectAndOpacityAndInterpolation )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect destinationRectangle,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle,
        /* [in] */FLOAT opacity,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasImageInterpolation interpolation
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageAtOffsetWithSourceRectAndOpacityAndInterpolationAndComposite )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle,
        /* [in] */FLOAT opacity,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasImageInterpolation interpolation,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasComposite composite
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageAtCoordsWithSourceRectAndOpacityAndInterpolationAndComposite )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle,
        /* [in] */FLOAT opacity,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasImageInterpolation interpolation,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasComposite composite
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageToRectWithSourceRectAndOpacityAndInterpolationAndComposite )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect destinationRectangle,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle,
        /* [in] */FLOAT opacity,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasImageInterpolation interpolation,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasComposite composite
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageAtOffsetWithSourceRectAndOpacityAndInterpolationAndPerspective )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle,
        /* [in] */FLOAT opacity,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasImageInterpolation interpolation,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix4x4 perspective
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageAtCoordsWithSourceRectAndOpacityAndInterpolationAndPerspective )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle,
        /* [in] */FLOAT opacity,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasImageInterpolation interpolation,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix4x4 perspective
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawImageToRectWithSourceRectAndOpacityAndInterpolationAndPerspective )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect destinationRectangle,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle,
        /* [in] */FLOAT opacity,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasImageInterpolation interpolation,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix4x4 perspective
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawLineWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point0,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point1,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawLineAtCoordsWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x0,
        /* [in] */FLOAT y0,
        /* [in] */FLOAT x1,
        /* [in] */FLOAT y1,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawLineWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point0,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point1,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawLineAtCoordsWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x0,
        /* [in] */FLOAT y0,
        /* [in] */FLOAT x1,
        /* [in] */FLOAT y1,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawLineWithBrushAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point0,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point1,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawLineAtCoordsWithBrushAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x0,
        /* [in] */FLOAT y0,
        /* [in] */FLOAT x1,
        /* [in] */FLOAT y1,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawLineWithColorAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point0,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point1,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawLineAtCoordsWithColorAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x0,
        /* [in] */FLOAT y0,
        /* [in] */FLOAT x1,
        /* [in] */FLOAT y1,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawLineWithBrushAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point0,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point1,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawLineAtCoordsWithBrushAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x0,
        /* [in] */FLOAT y0,
        /* [in] */FLOAT x1,
        /* [in] */FLOAT y1,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawLineWithColorAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point0,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point1,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawLineAtCoordsWithColorAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x0,
        /* [in] */FLOAT y0,
        /* [in] */FLOAT x1,
        /* [in] */FLOAT y1,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawRectangleWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawRectangleAtCoordsWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawRectangleWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawRectangleAtCoordsWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawRectangleWithBrushAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawRectangleAtCoordsWithBrushAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawRectangleWithColorAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawRectangleAtCoordsWithColorAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawRectangleWithBrushAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawRectangleAtCoordsWithBrushAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawRectangleWithColorAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawRectangleAtCoordsWithColorAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *FillRectangleWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *FillRectangleAtCoordsWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FillRectangleWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FillRectangleAtCoordsWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FillRectangleWithBrushAndOpacityBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * opacityBrush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FillRectangleAtCoordsWithBrushAndOpacityBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * opacityBrush
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawRoundedRectangleWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawRoundedRectangleAtCoordsWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawRoundedRectangleWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawRoundedRectangleAtCoordsWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawRoundedRectangleWithBrushAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawRoundedRectangleAtCoordsWithBrushAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawRoundedRectangleWithColorAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawRoundedRectangleAtCoordsWithColorAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawRoundedRectangleWithBrushAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawRoundedRectangleAtCoordsWithBrushAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawRoundedRectangleWithColorAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawRoundedRectangleAtCoordsWithColorAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *FillRoundedRectangleWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *FillRoundedRectangleAtCoordsWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FillRoundedRectangleWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FillRoundedRectangleAtCoordsWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawEllipseWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawEllipseAtCoordsWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawEllipseWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawEllipseAtCoordsWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawEllipseWithBrushAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawEllipseAtCoordsWithBrushAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawEllipseWithColorAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawEllipseAtCoordsWithColorAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawEllipseWithBrushAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawEllipseAtCoordsWithBrushAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawEllipseWithColorAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawEllipseAtCoordsWithColorAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *FillEllipseWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *FillEllipseAtCoordsWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FillEllipseWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FillEllipseAtCoordsWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawCircleWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radius,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawCircleAtCoordsWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radius,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawCircleWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radius,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawCircleAtCoordsWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radius,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawCircleWithBrushAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radius,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawCircleAtCoordsWithBrushAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radius,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawCircleWithColorAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radius,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawCircleAtCoordsWithColorAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radius,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawCircleWithBrushAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radius,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawCircleAtCoordsWithBrushAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radius,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawCircleWithColorAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radius,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawCircleAtCoordsWithColorAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radius,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *FillCircleWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radius,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *FillCircleAtCoordsWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radius,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FillCircleWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radius,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FillCircleAtCoordsWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radius,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawTextAtPointWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */HSTRING text,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawTextAtPointCoordsWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */HSTRING text,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawTextAtPointWithBrushAndFormat )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */HSTRING text,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * format
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawTextAtRectWithBrushAndFormat )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */HSTRING text,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rectangle,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * format
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawTextAtPointCoordsWithBrushAndFormat )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */HSTRING text,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * format
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawTextAtRectCoordsWithBrushAndFormat )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */HSTRING text,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * format
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawTextAtPointWithColorAndFormat )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */HSTRING text,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * format
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawTextAtRectWithColorAndFormat )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */HSTRING text,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rectangle,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * format
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawTextAtPointCoordsWithColorAndFormat )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */HSTRING text,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * format
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawTextAtRectCoordsWithColorAndFormat )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */HSTRING text,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextFormat * format
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryAtCoordsWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryAtCoordsWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryAtOriginWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryAtOriginWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryWithBrushAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryWithColorAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryAtCoordsWithBrushAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryAtCoordsWithColorAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryAtOriginWithBrushAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryAtOriginWithColorAndStrokeWidth )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryWithBrushAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryWithColorAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryAtCoordsWithBrushAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryAtCoordsWithColorAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryAtOriginWithBrushAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGeometryAtOriginWithColorAndStrokeWidthAndStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CWindows_CUI_CColor color,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *FillGeometryWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FillGeometryWithBrushAndOpacityBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * opacityBrush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FillGeometryWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *FillGeometryAtCoordsWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FillGeometryAtCoordsWithBrushAndOpacityBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * opacityBrush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FillGeometryAtCoordsWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *FillGeometryAtOriginWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FillGeometryAtOriginWithBrushAndOpacityBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * opacityBrush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FillGeometryAtOriginWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawCachedGeometryWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * geometry,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawCachedGeometryWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * geometry,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawCachedGeometryAtCoordsWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * geometry,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawCachedGeometryAtCoordsWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * geometry,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawCachedGeometryAtOriginWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * geometry,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawCachedGeometryAtOriginWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * geometry,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawTextLayoutWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * textLayout,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawTextLayoutAtCoordsWithBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * textLayout,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawTextLayoutWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * textLayout,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawTextLayoutAtCoordsWithColor )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * textLayout,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */__x_ABI_CWindows_CUI_CColor color
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGradientMeshAtOrigin )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh * gradientMesh
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGradientMesh )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh * gradientMesh,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGradientMeshAtCoords )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh * gradientMesh,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawSvgAtOrigin )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * svgDocument,
        /* [in] */__x_ABI_CWindows_CFoundation_CSize viewportSize
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawSvgAtPoint )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * svgDocument,
        /* [in] */__x_ABI_CWindows_CFoundation_CSize viewportSize,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawSvgAtCoords )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CSvg_CICanvasSvgDocument * svgDocument,
        /* [in] */__x_ABI_CWindows_CFoundation_CSize viewportSize,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Antialiasing )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAntialiasing * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Antialiasing )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAntialiasing value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Blend )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBlend * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Blend )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBlend value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_TextAntialiasing )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextAntialiasing * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_TextAntialiasing )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextAntialiasing value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_TextRenderingParameters )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters * * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_TextRenderingParameters )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextRenderingParameters * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Transform )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Transform )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Units )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasUnits * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Units )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasUnits value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_EffectBufferPrecision )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [retval, out] */__FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision * * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_EffectBufferPrecision )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__FIReference_1_Microsoft__CGraphics__CCanvas__CCanvasBufferPrecision * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_EffectTileSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [retval, out] */__x_ABI_CWindows_CGraphics_CImaging_CBitmapSize * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_EffectTileSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CGraphics_CImaging_CBitmapSize value
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateLayerWithOpacity )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT opacity,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer * * layer
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreateLayerWithOpacityBrush )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * opacityBrush,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer * * layer
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateLayerWithOpacityAndClipRectangle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT opacity,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect clipRectangle,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer * * layer
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateLayerWithOpacityBrushAndClipRectangle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * opacityBrush,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect clipRectangle,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer * * layer
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateLayerWithOpacityAndClipGeometry )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT opacity,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * clipGeometry,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer * * layer
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreateLayerWithOpacityBrushAndClipGeometry )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * opacityBrush,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * clipGeometry,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer * * layer
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateLayerWithOpacityAndClipGeometryAndTransform )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT opacity,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * clipGeometry,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 geometryTransform,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer * * layer
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreateLayerWithOpacityBrushAndClipGeometryAndTransform )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * opacityBrush,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * clipGeometry,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 geometryTransform,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer * * layer
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateLayerWithAllOptions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */FLOAT opacity,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * opacityBrush,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect clipRectangle,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * clipGeometry,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 geometryTransform,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasLayerOptions options,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasActiveLayer * * layer
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGlyphRun )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * fontFace,
        /* [in] */FLOAT fontSize,
        /* [in] */UINT32 __glyphsSize,
        /* [size_is(__glyphsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * glyphs,
        /* [in] */boolean isSideways,
        /* [in] */UINT32 bidiLevel,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGlyphRunWithMeasuringMode )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * fontFace,
        /* [in] */FLOAT fontSize,
        /* [in] */UINT32 __glyphsSize,
        /* [size_is(__glyphsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * glyphs,
        /* [in] */boolean isSideways,
        /* [in] */UINT32 bidiLevel,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextMeasuringMode measuringMode
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawGlyphRunWithMeasuringModeAndDescription )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * fontFace,
        /* [in] */FLOAT fontSize,
        /* [in] */UINT32 __glyphsSize,
        /* [size_is(__glyphsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * glyphs,
        /* [in] */boolean isSideways,
        /* [in] */UINT32 bidiLevel,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CBrushes_CICanvasBrush * brush,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextMeasuringMode measuringMode,
        /* [in] */HSTRING localeName,
        /* [in] */HSTRING textString,
        /* [in] */UINT32 __clusterMapIndicesSize,
        /* [size_is(__clusterMapIndicesSize), in] */INT32 * clusterMapIndices,
        /* [in] */UINT32 textPosition
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateSpriteBatch )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * * spriteBatch
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateSpriteBatchWithSortMode )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteSortMode sortMode,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * * spriteBatch
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateSpriteBatchWithSortModeAndInterpolation )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteSortMode sortMode,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasImageInterpolation interpolation,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * * spriteBatch
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateSpriteBatchWithSortModeAndInterpolationAndOptions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteSortMode sortMode,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasImageInterpolation interpolation,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteOptions options,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * * spriteBatch
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSessionVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSessionVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_Clear(This,color) \
    ( (This)->lpVtbl->Clear(This,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_ClearHdr(This,color) \
    ( (This)->lpVtbl->ClearHdr(This,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_Flush(This) \
    ( (This)->lpVtbl->Flush(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageAtOrigin(This,image) \
    ( (This)->lpVtbl->DrawImageAtOrigin(This,image) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageAtOffset(This,image,offset) \
    ( (This)->lpVtbl->DrawImageAtOffset(This,image,offset) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageAtCoords(This,image,x,y) \
    ( (This)->lpVtbl->DrawImageAtCoords(This,image,x,y) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageToRect(This,bitmap,destinationRectangle) \
    ( (This)->lpVtbl->DrawImageToRect(This,bitmap,destinationRectangle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageAtOffsetWithSourceRect(This,image,offset,sourceRectangle) \
    ( (This)->lpVtbl->DrawImageAtOffsetWithSourceRect(This,image,offset,sourceRectangle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageAtCoordsWithSourceRect(This,image,x,y,sourceRectangle) \
    ( (This)->lpVtbl->DrawImageAtCoordsWithSourceRect(This,image,x,y,sourceRectangle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageToRectWithSourceRect(This,image,destinationRectangle,sourceRectangle) \
    ( (This)->lpVtbl->DrawImageToRectWithSourceRect(This,image,destinationRectangle,sourceRectangle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageAtOffsetWithSourceRectAndOpacity(This,image,offset,sourceRectangle,opacity) \
    ( (This)->lpVtbl->DrawImageAtOffsetWithSourceRectAndOpacity(This,image,offset,sourceRectangle,opacity) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageAtCoordsWithSourceRectAndOpacity(This,image,x,y,sourceRectangle,opacity) \
    ( (This)->lpVtbl->DrawImageAtCoordsWithSourceRectAndOpacity(This,image,x,y,sourceRectangle,opacity) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageToRectWithSourceRectAndOpacity(This,image,destinationRectangle,sourceRectangle,opacity) \
    ( (This)->lpVtbl->DrawImageToRectWithSourceRectAndOpacity(This,image,destinationRectangle,sourceRectangle,opacity) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageAtOffsetWithSourceRectAndOpacityAndInterpolation(This,image,offset,sourceRectangle,opacity,interpolation) \
    ( (This)->lpVtbl->DrawImageAtOffsetWithSourceRectAndOpacityAndInterpolation(This,image,offset,sourceRectangle,opacity,interpolation) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageAtCoordsWithSourceRectAndOpacityAndInterpolation(This,image,x,y,sourceRectangle,opacity,interpolation) \
    ( (This)->lpVtbl->DrawImageAtCoordsWithSourceRectAndOpacityAndInterpolation(This,image,x,y,sourceRectangle,opacity,interpolation) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageToRectWithSourceRectAndOpacityAndInterpolation(This,image,destinationRectangle,sourceRectangle,opacity,interpolation) \
    ( (This)->lpVtbl->DrawImageToRectWithSourceRectAndOpacityAndInterpolation(This,image,destinationRectangle,sourceRectangle,opacity,interpolation) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageAtOffsetWithSourceRectAndOpacityAndInterpolationAndComposite(This,image,offset,sourceRectangle,opacity,interpolation,composite) \
    ( (This)->lpVtbl->DrawImageAtOffsetWithSourceRectAndOpacityAndInterpolationAndComposite(This,image,offset,sourceRectangle,opacity,interpolation,composite) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageAtCoordsWithSourceRectAndOpacityAndInterpolationAndComposite(This,image,x,y,sourceRectangle,opacity,interpolation,composite) \
    ( (This)->lpVtbl->DrawImageAtCoordsWithSourceRectAndOpacityAndInterpolationAndComposite(This,image,x,y,sourceRectangle,opacity,interpolation,composite) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageToRectWithSourceRectAndOpacityAndInterpolationAndComposite(This,image,destinationRectangle,sourceRectangle,opacity,interpolation,composite) \
    ( (This)->lpVtbl->DrawImageToRectWithSourceRectAndOpacityAndInterpolationAndComposite(This,image,destinationRectangle,sourceRectangle,opacity,interpolation,composite) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageAtOffsetWithSourceRectAndOpacityAndInterpolationAndPerspective(This,bitmap,offset,sourceRectangle,opacity,interpolation,perspective) \
    ( (This)->lpVtbl->DrawImageAtOffsetWithSourceRectAndOpacityAndInterpolationAndPerspective(This,bitmap,offset,sourceRectangle,opacity,interpolation,perspective) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageAtCoordsWithSourceRectAndOpacityAndInterpolationAndPerspective(This,bitmap,x,y,sourceRectangle,opacity,interpolation,perspective) \
    ( (This)->lpVtbl->DrawImageAtCoordsWithSourceRectAndOpacityAndInterpolationAndPerspective(This,bitmap,x,y,sourceRectangle,opacity,interpolation,perspective) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawImageToRectWithSourceRectAndOpacityAndInterpolationAndPerspective(This,bitmap,destinationRectangle,sourceRectangle,opacity,interpolation,perspective) \
    ( (This)->lpVtbl->DrawImageToRectWithSourceRectAndOpacityAndInterpolationAndPerspective(This,bitmap,destinationRectangle,sourceRectangle,opacity,interpolation,perspective) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawLineWithBrush(This,point0,point1,brush) \
    ( (This)->lpVtbl->DrawLineWithBrush(This,point0,point1,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawLineAtCoordsWithBrush(This,x0,y0,x1,y1,brush) \
    ( (This)->lpVtbl->DrawLineAtCoordsWithBrush(This,x0,y0,x1,y1,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawLineWithColor(This,point0,point1,color) \
    ( (This)->lpVtbl->DrawLineWithColor(This,point0,point1,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawLineAtCoordsWithColor(This,x0,y0,x1,y1,color) \
    ( (This)->lpVtbl->DrawLineAtCoordsWithColor(This,x0,y0,x1,y1,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawLineWithBrushAndStrokeWidth(This,point0,point1,brush,strokeWidth) \
    ( (This)->lpVtbl->DrawLineWithBrushAndStrokeWidth(This,point0,point1,brush,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawLineAtCoordsWithBrushAndStrokeWidth(This,x0,y0,x1,y1,brush,strokeWidth) \
    ( (This)->lpVtbl->DrawLineAtCoordsWithBrushAndStrokeWidth(This,x0,y0,x1,y1,brush,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawLineWithColorAndStrokeWidth(This,point0,point1,color,strokeWidth) \
    ( (This)->lpVtbl->DrawLineWithColorAndStrokeWidth(This,point0,point1,color,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawLineAtCoordsWithColorAndStrokeWidth(This,x0,y0,x1,y1,color,strokeWidth) \
    ( (This)->lpVtbl->DrawLineAtCoordsWithColorAndStrokeWidth(This,x0,y0,x1,y1,color,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawLineWithBrushAndStrokeWidthAndStrokeStyle(This,point0,point1,brush,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawLineWithBrushAndStrokeWidthAndStrokeStyle(This,point0,point1,brush,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawLineAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(This,x0,y0,x1,y1,brush,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawLineAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(This,x0,y0,x1,y1,brush,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawLineWithColorAndStrokeWidthAndStrokeStyle(This,point0,point1,color,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawLineWithColorAndStrokeWidthAndStrokeStyle(This,point0,point1,color,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawLineAtCoordsWithColorAndStrokeWidthAndStrokeStyle(This,x0,y0,x1,y1,color,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawLineAtCoordsWithColorAndStrokeWidthAndStrokeStyle(This,x0,y0,x1,y1,color,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRectangleWithBrush(This,rect,brush) \
    ( (This)->lpVtbl->DrawRectangleWithBrush(This,rect,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRectangleAtCoordsWithBrush(This,x,y,w,h,brush) \
    ( (This)->lpVtbl->DrawRectangleAtCoordsWithBrush(This,x,y,w,h,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRectangleWithColor(This,rect,color) \
    ( (This)->lpVtbl->DrawRectangleWithColor(This,rect,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRectangleAtCoordsWithColor(This,x,y,w,h,color) \
    ( (This)->lpVtbl->DrawRectangleAtCoordsWithColor(This,x,y,w,h,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRectangleWithBrushAndStrokeWidth(This,rect,brush,strokeWidth) \
    ( (This)->lpVtbl->DrawRectangleWithBrushAndStrokeWidth(This,rect,brush,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRectangleAtCoordsWithBrushAndStrokeWidth(This,x,y,w,h,brush,strokeWidth) \
    ( (This)->lpVtbl->DrawRectangleAtCoordsWithBrushAndStrokeWidth(This,x,y,w,h,brush,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRectangleWithColorAndStrokeWidth(This,rect,color,strokeWidth) \
    ( (This)->lpVtbl->DrawRectangleWithColorAndStrokeWidth(This,rect,color,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRectangleAtCoordsWithColorAndStrokeWidth(This,x,y,w,h,color,strokeWidth) \
    ( (This)->lpVtbl->DrawRectangleAtCoordsWithColorAndStrokeWidth(This,x,y,w,h,color,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRectangleWithBrushAndStrokeWidthAndStrokeStyle(This,rect,brush,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawRectangleWithBrushAndStrokeWidthAndStrokeStyle(This,rect,brush,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRectangleAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(This,x,y,w,h,brush,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawRectangleAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(This,x,y,w,h,brush,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRectangleWithColorAndStrokeWidthAndStrokeStyle(This,rect,color,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawRectangleWithColorAndStrokeWidthAndStrokeStyle(This,rect,color,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRectangleAtCoordsWithColorAndStrokeWidthAndStrokeStyle(This,x,y,w,h,color,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawRectangleAtCoordsWithColorAndStrokeWidthAndStrokeStyle(This,x,y,w,h,color,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillRectangleWithBrush(This,rect,brush) \
    ( (This)->lpVtbl->FillRectangleWithBrush(This,rect,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillRectangleAtCoordsWithBrush(This,x,y,w,h,brush) \
    ( (This)->lpVtbl->FillRectangleAtCoordsWithBrush(This,x,y,w,h,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillRectangleWithColor(This,rect,color) \
    ( (This)->lpVtbl->FillRectangleWithColor(This,rect,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillRectangleAtCoordsWithColor(This,x,y,w,h,color) \
    ( (This)->lpVtbl->FillRectangleAtCoordsWithColor(This,x,y,w,h,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillRectangleWithBrushAndOpacityBrush(This,rect,brush,opacityBrush) \
    ( (This)->lpVtbl->FillRectangleWithBrushAndOpacityBrush(This,rect,brush,opacityBrush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillRectangleAtCoordsWithBrushAndOpacityBrush(This,x,y,w,h,brush,opacityBrush) \
    ( (This)->lpVtbl->FillRectangleAtCoordsWithBrushAndOpacityBrush(This,x,y,w,h,brush,opacityBrush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRoundedRectangleWithBrush(This,rect,radiusX,radiusY,brush) \
    ( (This)->lpVtbl->DrawRoundedRectangleWithBrush(This,rect,radiusX,radiusY,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRoundedRectangleAtCoordsWithBrush(This,x,y,w,h,radiusX,radiusY,brush) \
    ( (This)->lpVtbl->DrawRoundedRectangleAtCoordsWithBrush(This,x,y,w,h,radiusX,radiusY,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRoundedRectangleWithColor(This,rect,radiusX,radiusY,color) \
    ( (This)->lpVtbl->DrawRoundedRectangleWithColor(This,rect,radiusX,radiusY,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRoundedRectangleAtCoordsWithColor(This,x,y,w,h,radiusX,radiusY,color) \
    ( (This)->lpVtbl->DrawRoundedRectangleAtCoordsWithColor(This,x,y,w,h,radiusX,radiusY,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRoundedRectangleWithBrushAndStrokeWidth(This,rect,radiusX,radiusY,brush,strokeWidth) \
    ( (This)->lpVtbl->DrawRoundedRectangleWithBrushAndStrokeWidth(This,rect,radiusX,radiusY,brush,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRoundedRectangleAtCoordsWithBrushAndStrokeWidth(This,x,y,w,h,radiusX,radiusY,brush,strokeWidth) \
    ( (This)->lpVtbl->DrawRoundedRectangleAtCoordsWithBrushAndStrokeWidth(This,x,y,w,h,radiusX,radiusY,brush,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRoundedRectangleWithColorAndStrokeWidth(This,rect,radiusX,radiusY,color,strokeWidth) \
    ( (This)->lpVtbl->DrawRoundedRectangleWithColorAndStrokeWidth(This,rect,radiusX,radiusY,color,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRoundedRectangleAtCoordsWithColorAndStrokeWidth(This,x,y,w,h,radiusX,radiusY,color,strokeWidth) \
    ( (This)->lpVtbl->DrawRoundedRectangleAtCoordsWithColorAndStrokeWidth(This,x,y,w,h,radiusX,radiusY,color,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRoundedRectangleWithBrushAndStrokeWidthAndStrokeStyle(This,rect,radiusX,radiusY,brush,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawRoundedRectangleWithBrushAndStrokeWidthAndStrokeStyle(This,rect,radiusX,radiusY,brush,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRoundedRectangleAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(This,x,y,w,h,radiusX,radiusY,brush,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawRoundedRectangleAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(This,x,y,w,h,radiusX,radiusY,brush,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRoundedRectangleWithColorAndStrokeWidthAndStrokeStyle(This,rect,radiusX,radiusY,color,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawRoundedRectangleWithColorAndStrokeWidthAndStrokeStyle(This,rect,radiusX,radiusY,color,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawRoundedRectangleAtCoordsWithColorAndStrokeWidthAndStrokeStyle(This,x,y,w,h,radiusX,radiusY,color,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawRoundedRectangleAtCoordsWithColorAndStrokeWidthAndStrokeStyle(This,x,y,w,h,radiusX,radiusY,color,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillRoundedRectangleWithBrush(This,rect,radiusX,radiusY,brush) \
    ( (This)->lpVtbl->FillRoundedRectangleWithBrush(This,rect,radiusX,radiusY,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillRoundedRectangleAtCoordsWithBrush(This,x,y,w,h,radiusX,radiusY,brush) \
    ( (This)->lpVtbl->FillRoundedRectangleAtCoordsWithBrush(This,x,y,w,h,radiusX,radiusY,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillRoundedRectangleWithColor(This,rect,radiusX,radiusY,color) \
    ( (This)->lpVtbl->FillRoundedRectangleWithColor(This,rect,radiusX,radiusY,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillRoundedRectangleAtCoordsWithColor(This,x,y,w,h,radiusX,radiusY,color) \
    ( (This)->lpVtbl->FillRoundedRectangleAtCoordsWithColor(This,x,y,w,h,radiusX,radiusY,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawEllipseWithBrush(This,centerPoint,radiusX,radiusY,brush) \
    ( (This)->lpVtbl->DrawEllipseWithBrush(This,centerPoint,radiusX,radiusY,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawEllipseAtCoordsWithBrush(This,x,y,radiusX,radiusY,brush) \
    ( (This)->lpVtbl->DrawEllipseAtCoordsWithBrush(This,x,y,radiusX,radiusY,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawEllipseWithColor(This,centerPoint,radiusX,radiusY,color) \
    ( (This)->lpVtbl->DrawEllipseWithColor(This,centerPoint,radiusX,radiusY,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawEllipseAtCoordsWithColor(This,x,y,radiusX,radiusY,color) \
    ( (This)->lpVtbl->DrawEllipseAtCoordsWithColor(This,x,y,radiusX,radiusY,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawEllipseWithBrushAndStrokeWidth(This,centerPoint,radiusX,radiusY,brush,strokeWidth) \
    ( (This)->lpVtbl->DrawEllipseWithBrushAndStrokeWidth(This,centerPoint,radiusX,radiusY,brush,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawEllipseAtCoordsWithBrushAndStrokeWidth(This,x,y,radiusX,radiusY,brush,strokeWidth) \
    ( (This)->lpVtbl->DrawEllipseAtCoordsWithBrushAndStrokeWidth(This,x,y,radiusX,radiusY,brush,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawEllipseWithColorAndStrokeWidth(This,centerPoint,radiusX,radiusY,color,strokeWidth) \
    ( (This)->lpVtbl->DrawEllipseWithColorAndStrokeWidth(This,centerPoint,radiusX,radiusY,color,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawEllipseAtCoordsWithColorAndStrokeWidth(This,x,y,radiusX,radiusY,color,strokeWidth) \
    ( (This)->lpVtbl->DrawEllipseAtCoordsWithColorAndStrokeWidth(This,x,y,radiusX,radiusY,color,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawEllipseWithBrushAndStrokeWidthAndStrokeStyle(This,centerPoint,radiusX,radiusY,brush,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawEllipseWithBrushAndStrokeWidthAndStrokeStyle(This,centerPoint,radiusX,radiusY,brush,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawEllipseAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(This,x,y,radiusX,radiusY,brush,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawEllipseAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(This,x,y,radiusX,radiusY,brush,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawEllipseWithColorAndStrokeWidthAndStrokeStyle(This,centerPoint,radiusX,radiusY,color,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawEllipseWithColorAndStrokeWidthAndStrokeStyle(This,centerPoint,radiusX,radiusY,color,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawEllipseAtCoordsWithColorAndStrokeWidthAndStrokeStyle(This,x,y,radiusX,radiusY,color,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawEllipseAtCoordsWithColorAndStrokeWidthAndStrokeStyle(This,x,y,radiusX,radiusY,color,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillEllipseWithBrush(This,centerPoint,radiusX,radiusY,brush) \
    ( (This)->lpVtbl->FillEllipseWithBrush(This,centerPoint,radiusX,radiusY,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillEllipseAtCoordsWithBrush(This,x,y,radiusX,radiusY,brush) \
    ( (This)->lpVtbl->FillEllipseAtCoordsWithBrush(This,x,y,radiusX,radiusY,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillEllipseWithColor(This,centerPoint,radiusX,radiusY,color) \
    ( (This)->lpVtbl->FillEllipseWithColor(This,centerPoint,radiusX,radiusY,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillEllipseAtCoordsWithColor(This,x,y,radiusX,radiusY,color) \
    ( (This)->lpVtbl->FillEllipseAtCoordsWithColor(This,x,y,radiusX,radiusY,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCircleWithBrush(This,centerPoint,radius,brush) \
    ( (This)->lpVtbl->DrawCircleWithBrush(This,centerPoint,radius,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCircleAtCoordsWithBrush(This,x,y,radius,brush) \
    ( (This)->lpVtbl->DrawCircleAtCoordsWithBrush(This,x,y,radius,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCircleWithColor(This,centerPoint,radius,color) \
    ( (This)->lpVtbl->DrawCircleWithColor(This,centerPoint,radius,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCircleAtCoordsWithColor(This,x,y,radius,color) \
    ( (This)->lpVtbl->DrawCircleAtCoordsWithColor(This,x,y,radius,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCircleWithBrushAndStrokeWidth(This,centerPoint,radius,brush,strokeWidth) \
    ( (This)->lpVtbl->DrawCircleWithBrushAndStrokeWidth(This,centerPoint,radius,brush,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCircleAtCoordsWithBrushAndStrokeWidth(This,x,y,radius,brush,strokeWidth) \
    ( (This)->lpVtbl->DrawCircleAtCoordsWithBrushAndStrokeWidth(This,x,y,radius,brush,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCircleWithColorAndStrokeWidth(This,centerPoint,radius,color,strokeWidth) \
    ( (This)->lpVtbl->DrawCircleWithColorAndStrokeWidth(This,centerPoint,radius,color,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCircleAtCoordsWithColorAndStrokeWidth(This,x,y,radius,color,strokeWidth) \
    ( (This)->lpVtbl->DrawCircleAtCoordsWithColorAndStrokeWidth(This,x,y,radius,color,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCircleWithBrushAndStrokeWidthAndStrokeStyle(This,centerPoint,radius,brush,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawCircleWithBrushAndStrokeWidthAndStrokeStyle(This,centerPoint,radius,brush,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCircleAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(This,x,y,radius,brush,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawCircleAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(This,x,y,radius,brush,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCircleWithColorAndStrokeWidthAndStrokeStyle(This,centerPoint,radius,color,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawCircleWithColorAndStrokeWidthAndStrokeStyle(This,centerPoint,radius,color,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCircleAtCoordsWithColorAndStrokeWidthAndStrokeStyle(This,x,y,radius,color,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawCircleAtCoordsWithColorAndStrokeWidthAndStrokeStyle(This,x,y,radius,color,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillCircleWithBrush(This,centerPoint,radius,brush) \
    ( (This)->lpVtbl->FillCircleWithBrush(This,centerPoint,radius,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillCircleAtCoordsWithBrush(This,x,y,radius,brush) \
    ( (This)->lpVtbl->FillCircleAtCoordsWithBrush(This,x,y,radius,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillCircleWithColor(This,centerPoint,radius,color) \
    ( (This)->lpVtbl->FillCircleWithColor(This,centerPoint,radius,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillCircleAtCoordsWithColor(This,x,y,radius,color) \
    ( (This)->lpVtbl->FillCircleAtCoordsWithColor(This,x,y,radius,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawTextAtPointWithColor(This,text,point,color) \
    ( (This)->lpVtbl->DrawTextAtPointWithColor(This,text,point,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawTextAtPointCoordsWithColor(This,text,x,y,color) \
    ( (This)->lpVtbl->DrawTextAtPointCoordsWithColor(This,text,x,y,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawTextAtPointWithBrushAndFormat(This,text,point,brush,format) \
    ( (This)->lpVtbl->DrawTextAtPointWithBrushAndFormat(This,text,point,brush,format) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawTextAtRectWithBrushAndFormat(This,text,rectangle,brush,format) \
    ( (This)->lpVtbl->DrawTextAtRectWithBrushAndFormat(This,text,rectangle,brush,format) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawTextAtPointCoordsWithBrushAndFormat(This,text,x,y,brush,format) \
    ( (This)->lpVtbl->DrawTextAtPointCoordsWithBrushAndFormat(This,text,x,y,brush,format) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawTextAtRectCoordsWithBrushAndFormat(This,text,x,y,w,h,brush,format) \
    ( (This)->lpVtbl->DrawTextAtRectCoordsWithBrushAndFormat(This,text,x,y,w,h,brush,format) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawTextAtPointWithColorAndFormat(This,text,point,color,format) \
    ( (This)->lpVtbl->DrawTextAtPointWithColorAndFormat(This,text,point,color,format) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawTextAtRectWithColorAndFormat(This,text,rectangle,color,format) \
    ( (This)->lpVtbl->DrawTextAtRectWithColorAndFormat(This,text,rectangle,color,format) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawTextAtPointCoordsWithColorAndFormat(This,text,x,y,color,format) \
    ( (This)->lpVtbl->DrawTextAtPointCoordsWithColorAndFormat(This,text,x,y,color,format) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawTextAtRectCoordsWithColorAndFormat(This,text,x,y,w,h,color,format) \
    ( (This)->lpVtbl->DrawTextAtRectCoordsWithColorAndFormat(This,text,x,y,w,h,color,format) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryWithBrush(This,geometry,offset,brush) \
    ( (This)->lpVtbl->DrawGeometryWithBrush(This,geometry,offset,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryWithColor(This,geometry,offset,color) \
    ( (This)->lpVtbl->DrawGeometryWithColor(This,geometry,offset,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryAtCoordsWithBrush(This,geometry,x,y,brush) \
    ( (This)->lpVtbl->DrawGeometryAtCoordsWithBrush(This,geometry,x,y,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryAtCoordsWithColor(This,geometry,x,y,color) \
    ( (This)->lpVtbl->DrawGeometryAtCoordsWithColor(This,geometry,x,y,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryAtOriginWithBrush(This,geometry,brush) \
    ( (This)->lpVtbl->DrawGeometryAtOriginWithBrush(This,geometry,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryAtOriginWithColor(This,geometry,color) \
    ( (This)->lpVtbl->DrawGeometryAtOriginWithColor(This,geometry,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryWithBrushAndStrokeWidth(This,geometry,offset,brush,strokeWidth) \
    ( (This)->lpVtbl->DrawGeometryWithBrushAndStrokeWidth(This,geometry,offset,brush,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryWithColorAndStrokeWidth(This,geometry,offset,color,strokeWidth) \
    ( (This)->lpVtbl->DrawGeometryWithColorAndStrokeWidth(This,geometry,offset,color,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryAtCoordsWithBrushAndStrokeWidth(This,geometry,x,y,brush,strokeWidth) \
    ( (This)->lpVtbl->DrawGeometryAtCoordsWithBrushAndStrokeWidth(This,geometry,x,y,brush,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryAtCoordsWithColorAndStrokeWidth(This,geometry,x,y,color,strokeWidth) \
    ( (This)->lpVtbl->DrawGeometryAtCoordsWithColorAndStrokeWidth(This,geometry,x,y,color,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryAtOriginWithBrushAndStrokeWidth(This,geometry,brush,strokeWidth) \
    ( (This)->lpVtbl->DrawGeometryAtOriginWithBrushAndStrokeWidth(This,geometry,brush,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryAtOriginWithColorAndStrokeWidth(This,geometry,color,strokeWidth) \
    ( (This)->lpVtbl->DrawGeometryAtOriginWithColorAndStrokeWidth(This,geometry,color,strokeWidth) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryWithBrushAndStrokeWidthAndStrokeStyle(This,geometry,offset,brush,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawGeometryWithBrushAndStrokeWidthAndStrokeStyle(This,geometry,offset,brush,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryWithColorAndStrokeWidthAndStrokeStyle(This,geometry,offset,color,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawGeometryWithColorAndStrokeWidthAndStrokeStyle(This,geometry,offset,color,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(This,geometry,x,y,brush,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawGeometryAtCoordsWithBrushAndStrokeWidthAndStrokeStyle(This,geometry,x,y,brush,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryAtCoordsWithColorAndStrokeWidthAndStrokeStyle(This,geometry,x,y,color,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawGeometryAtCoordsWithColorAndStrokeWidthAndStrokeStyle(This,geometry,x,y,color,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryAtOriginWithBrushAndStrokeWidthAndStrokeStyle(This,geometry,brush,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawGeometryAtOriginWithBrushAndStrokeWidthAndStrokeStyle(This,geometry,brush,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGeometryAtOriginWithColorAndStrokeWidthAndStrokeStyle(This,geometry,color,strokeWidth,strokeStyle) \
    ( (This)->lpVtbl->DrawGeometryAtOriginWithColorAndStrokeWidthAndStrokeStyle(This,geometry,color,strokeWidth,strokeStyle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillGeometryWithBrush(This,geometry,offset,brush) \
    ( (This)->lpVtbl->FillGeometryWithBrush(This,geometry,offset,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillGeometryWithBrushAndOpacityBrush(This,geometry,offset,brush,opacityBrush) \
    ( (This)->lpVtbl->FillGeometryWithBrushAndOpacityBrush(This,geometry,offset,brush,opacityBrush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillGeometryWithColor(This,geometry,offset,color) \
    ( (This)->lpVtbl->FillGeometryWithColor(This,geometry,offset,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillGeometryAtCoordsWithBrush(This,geometry,x,y,brush) \
    ( (This)->lpVtbl->FillGeometryAtCoordsWithBrush(This,geometry,x,y,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillGeometryAtCoordsWithBrushAndOpacityBrush(This,geometry,x,y,brush,opacityBrush) \
    ( (This)->lpVtbl->FillGeometryAtCoordsWithBrushAndOpacityBrush(This,geometry,x,y,brush,opacityBrush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillGeometryAtCoordsWithColor(This,geometry,x,y,color) \
    ( (This)->lpVtbl->FillGeometryAtCoordsWithColor(This,geometry,x,y,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillGeometryAtOriginWithBrush(This,geometry,brush) \
    ( (This)->lpVtbl->FillGeometryAtOriginWithBrush(This,geometry,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillGeometryAtOriginWithBrushAndOpacityBrush(This,geometry,brush,opacityBrush) \
    ( (This)->lpVtbl->FillGeometryAtOriginWithBrushAndOpacityBrush(This,geometry,brush,opacityBrush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FillGeometryAtOriginWithColor(This,geometry,color) \
    ( (This)->lpVtbl->FillGeometryAtOriginWithColor(This,geometry,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCachedGeometryWithBrush(This,geometry,offset,brush) \
    ( (This)->lpVtbl->DrawCachedGeometryWithBrush(This,geometry,offset,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCachedGeometryWithColor(This,geometry,offset,color) \
    ( (This)->lpVtbl->DrawCachedGeometryWithColor(This,geometry,offset,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCachedGeometryAtCoordsWithBrush(This,geometry,x,y,brush) \
    ( (This)->lpVtbl->DrawCachedGeometryAtCoordsWithBrush(This,geometry,x,y,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCachedGeometryAtCoordsWithColor(This,geometry,x,y,color) \
    ( (This)->lpVtbl->DrawCachedGeometryAtCoordsWithColor(This,geometry,x,y,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCachedGeometryAtOriginWithBrush(This,geometry,brush) \
    ( (This)->lpVtbl->DrawCachedGeometryAtOriginWithBrush(This,geometry,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawCachedGeometryAtOriginWithColor(This,geometry,color) \
    ( (This)->lpVtbl->DrawCachedGeometryAtOriginWithColor(This,geometry,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawTextLayoutWithBrush(This,textLayout,point,brush) \
    ( (This)->lpVtbl->DrawTextLayoutWithBrush(This,textLayout,point,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawTextLayoutAtCoordsWithBrush(This,textLayout,x,y,brush) \
    ( (This)->lpVtbl->DrawTextLayoutAtCoordsWithBrush(This,textLayout,x,y,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawTextLayoutWithColor(This,textLayout,point,color) \
    ( (This)->lpVtbl->DrawTextLayoutWithColor(This,textLayout,point,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawTextLayoutAtCoordsWithColor(This,textLayout,x,y,color) \
    ( (This)->lpVtbl->DrawTextLayoutAtCoordsWithColor(This,textLayout,x,y,color) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGradientMeshAtOrigin(This,gradientMesh) \
    ( (This)->lpVtbl->DrawGradientMeshAtOrigin(This,gradientMesh) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGradientMesh(This,gradientMesh,point) \
    ( (This)->lpVtbl->DrawGradientMesh(This,gradientMesh,point) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGradientMeshAtCoords(This,gradientMesh,x,y) \
    ( (This)->lpVtbl->DrawGradientMeshAtCoords(This,gradientMesh,x,y) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawSvgAtOrigin(This,svgDocument,viewportSize) \
    ( (This)->lpVtbl->DrawSvgAtOrigin(This,svgDocument,viewportSize) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawSvgAtPoint(This,svgDocument,viewportSize,point) \
    ( (This)->lpVtbl->DrawSvgAtPoint(This,svgDocument,viewportSize,point) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawSvgAtCoords(This,svgDocument,viewportSize,x,y) \
    ( (This)->lpVtbl->DrawSvgAtCoords(This,svgDocument,viewportSize,x,y) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_get_Antialiasing(This,value) \
    ( (This)->lpVtbl->get_Antialiasing(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_put_Antialiasing(This,value) \
    ( (This)->lpVtbl->put_Antialiasing(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_get_Blend(This,value) \
    ( (This)->lpVtbl->get_Blend(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_put_Blend(This,value) \
    ( (This)->lpVtbl->put_Blend(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_get_TextAntialiasing(This,value) \
    ( (This)->lpVtbl->get_TextAntialiasing(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_put_TextAntialiasing(This,value) \
    ( (This)->lpVtbl->put_TextAntialiasing(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_get_TextRenderingParameters(This,value) \
    ( (This)->lpVtbl->get_TextRenderingParameters(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_put_TextRenderingParameters(This,value) \
    ( (This)->lpVtbl->put_TextRenderingParameters(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_get_Transform(This,value) \
    ( (This)->lpVtbl->get_Transform(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_put_Transform(This,value) \
    ( (This)->lpVtbl->put_Transform(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_get_Units(This,value) \
    ( (This)->lpVtbl->get_Units(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_put_Units(This,value) \
    ( (This)->lpVtbl->put_Units(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_get_EffectBufferPrecision(This,value) \
    ( (This)->lpVtbl->get_EffectBufferPrecision(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_put_EffectBufferPrecision(This,value) \
    ( (This)->lpVtbl->put_EffectBufferPrecision(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_get_EffectTileSize(This,value) \
    ( (This)->lpVtbl->get_EffectTileSize(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_put_EffectTileSize(This,value) \
    ( (This)->lpVtbl->put_EffectTileSize(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_CreateLayerWithOpacity(This,opacity,layer) \
    ( (This)->lpVtbl->CreateLayerWithOpacity(This,opacity,layer) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_CreateLayerWithOpacityBrush(This,opacityBrush,layer) \
    ( (This)->lpVtbl->CreateLayerWithOpacityBrush(This,opacityBrush,layer) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_CreateLayerWithOpacityAndClipRectangle(This,opacity,clipRectangle,layer) \
    ( (This)->lpVtbl->CreateLayerWithOpacityAndClipRectangle(This,opacity,clipRectangle,layer) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_CreateLayerWithOpacityBrushAndClipRectangle(This,opacityBrush,clipRectangle,layer) \
    ( (This)->lpVtbl->CreateLayerWithOpacityBrushAndClipRectangle(This,opacityBrush,clipRectangle,layer) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_CreateLayerWithOpacityAndClipGeometry(This,opacity,clipGeometry,layer) \
    ( (This)->lpVtbl->CreateLayerWithOpacityAndClipGeometry(This,opacity,clipGeometry,layer) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_CreateLayerWithOpacityBrushAndClipGeometry(This,opacityBrush,clipGeometry,layer) \
    ( (This)->lpVtbl->CreateLayerWithOpacityBrushAndClipGeometry(This,opacityBrush,clipGeometry,layer) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_CreateLayerWithOpacityAndClipGeometryAndTransform(This,opacity,clipGeometry,geometryTransform,layer) \
    ( (This)->lpVtbl->CreateLayerWithOpacityAndClipGeometryAndTransform(This,opacity,clipGeometry,geometryTransform,layer) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_CreateLayerWithOpacityBrushAndClipGeometryAndTransform(This,opacityBrush,clipGeometry,geometryTransform,layer) \
    ( (This)->lpVtbl->CreateLayerWithOpacityBrushAndClipGeometryAndTransform(This,opacityBrush,clipGeometry,geometryTransform,layer) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_CreateLayerWithAllOptions(This,opacity,opacityBrush,clipRectangle,clipGeometry,geometryTransform,options,layer) \
    ( (This)->lpVtbl->CreateLayerWithAllOptions(This,opacity,opacityBrush,clipRectangle,clipGeometry,geometryTransform,options,layer) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGlyphRun(This,point,fontFace,fontSize,__glyphsSize,glyphs,isSideways,bidiLevel,brush) \
    ( (This)->lpVtbl->DrawGlyphRun(This,point,fontFace,fontSize,__glyphsSize,glyphs,isSideways,bidiLevel,brush) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGlyphRunWithMeasuringMode(This,point,fontFace,fontSize,__glyphsSize,glyphs,isSideways,bidiLevel,brush,measuringMode) \
    ( (This)->lpVtbl->DrawGlyphRunWithMeasuringMode(This,point,fontFace,fontSize,__glyphsSize,glyphs,isSideways,bidiLevel,brush,measuringMode) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_DrawGlyphRunWithMeasuringModeAndDescription(This,point,fontFace,fontSize,__glyphsSize,glyphs,isSideways,bidiLevel,brush,measuringMode,localeName,textString,__clusterMapIndicesSize,clusterMapIndices,textPosition) \
    ( (This)->lpVtbl->DrawGlyphRunWithMeasuringModeAndDescription(This,point,fontFace,fontSize,__glyphsSize,glyphs,isSideways,bidiLevel,brush,measuringMode,localeName,textString,__clusterMapIndicesSize,clusterMapIndices,textPosition) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_CreateSpriteBatch(This,spriteBatch) \
    ( (This)->lpVtbl->CreateSpriteBatch(This,spriteBatch) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_CreateSpriteBatchWithSortMode(This,sortMode,spriteBatch) \
    ( (This)->lpVtbl->CreateSpriteBatchWithSortMode(This,sortMode,spriteBatch) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_CreateSpriteBatchWithSortModeAndInterpolation(This,sortMode,interpolation,spriteBatch) \
    ( (This)->lpVtbl->CreateSpriteBatchWithSortModeAndInterpolation(This,sortMode,interpolation,spriteBatch) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_CreateSpriteBatchWithSortModeAndInterpolationAndOptions(This,sortMode,interpolation,options,spriteBatch) \
    ( (This)->lpVtbl->CreateSpriteBatchWithSortModeAndInterpolationAndOptions(This,sortMode,interpolation,options,spriteBatch) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasImage
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Graphics.Effects.IGraphicsEffectSource
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasImage[] = L"Microsoft.Graphics.Canvas.ICanvasImage";
/* [object, version, uuid("794966D3-6A64-47E9-8DA8-B46AAA24D53B")] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload] */HRESULT ( STDMETHODCALLTYPE *GetBounds )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * bounds
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetBoundsWithTransform )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * bounds
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_GetBounds(This,resourceCreator,bounds) \
    ( (This)->lpVtbl->GetBounds(This,resourceCreator,bounds) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_GetBoundsWithTransform(This,resourceCreator,transform,bounds) \
    ( (This)->lpVtbl->GetBoundsWithTransform(This,resourceCreator,transform,bounds) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasImageStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasImage
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasImageStatics[] = L"Microsoft.Graphics.Canvas.ICanvasImageStatics";
/* [object, version, uuid("C54EEA15-5A14-489A-8FA0-6E84541F922D"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *SaveAsync )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream * stream,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBitmapFileFormat fileFormat,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CIAsyncAction * * action
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *SaveWithQualityAsync )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream * stream,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBitmapFileFormat fileFormat,
        /* [in] */FLOAT quality,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CIAsyncAction * * action
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *SaveWithQualityAndBufferPrecisionAsync )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream * stream,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBitmapFileFormat fileFormat,
        /* [in] */FLOAT quality,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasBufferPrecision bufferPrecision,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CIAsyncAction * * action
        );
    HRESULT ( STDMETHODCALLTYPE *ComputeHistogram )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImage * image,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRectangle,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CEffects_CEffectChannelSelect channelSelect,
        /* [in] */INT32 numberOfBins,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */FLOAT * * valueElements
        );
    HRESULT ( STDMETHODCALLTYPE *IsHistogramSupported )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * device,
        /* [retval, out] */boolean * result
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStaticsVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_SaveAsync(This,image,sourceRectangle,dpi,resourceCreator,stream,fileFormat,action) \
    ( (This)->lpVtbl->SaveAsync(This,image,sourceRectangle,dpi,resourceCreator,stream,fileFormat,action) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_SaveWithQualityAsync(This,image,sourceRectangle,dpi,resourceCreator,stream,fileFormat,quality,action) \
    ( (This)->lpVtbl->SaveWithQualityAsync(This,image,sourceRectangle,dpi,resourceCreator,stream,fileFormat,quality,action) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_SaveWithQualityAndBufferPrecisionAsync(This,image,sourceRectangle,dpi,resourceCreator,stream,fileFormat,quality,bufferPrecision,action) \
    ( (This)->lpVtbl->SaveWithQualityAndBufferPrecisionAsync(This,image,sourceRectangle,dpi,resourceCreator,stream,fileFormat,quality,bufferPrecision,action) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_ComputeHistogram(This,image,sourceRectangle,resourceCreator,channelSelect,numberOfBins,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->ComputeHistogram(This,image,sourceRectangle,resourceCreator,channelSelect,numberOfBins,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_IsHistogramSupported(This,device,result) \
    ( (This)->lpVtbl->IsHistogramSupported(This,device,result) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasImageStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasLock
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasLock
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasLock[] = L"Microsoft.Graphics.Canvas.ICanvasLock";
/* [object, version, uuid("7A0E8498-FBA9-4FB0-AA8C-6A48B5EE3E4F"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLockVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLockVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLockVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasLock_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasRenderTarget
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasRenderTarget
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasRenderTarget[] = L"Microsoft.Graphics.Canvas.ICanvasRenderTarget";
/* [object, version, uuid("2D4C7349-9A32-41B9-B3CC-CAF1B7E1099B"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateDrawingSession )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * * drawingSession
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_CreateDrawingSession(This,drawingSession) \
    ( (This)->lpVtbl->CreateDrawingSession(This,drawingSession) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasRenderTargetFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasRenderTarget
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasRenderTargetFactory[] = L"Microsoft.Graphics.Canvas.ICanvasRenderTargetFactory";
/* [object, version, uuid("620DFDBB-9D08-406C-BFE6-D9B81E6DF8E7"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateWithSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi * resourceCreator,
        /* [in] */__x_ABI_CWindows_CFoundation_CSize size,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget * * renderTarget
        );
    HRESULT ( STDMETHODCALLTYPE *CreateWithWidthAndHeight )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi * resourceCreator,
        /* [in] */FLOAT width,
        /* [in] */FLOAT height,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget * * renderTarget
        );
    HRESULT ( STDMETHODCALLTYPE *CreateWithWidthAndHeightAndDpi )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */FLOAT width,
        /* [in] */FLOAT height,
        /* [in] */FLOAT dpi,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget * * renderTarget
        );
    HRESULT ( STDMETHODCALLTYPE *CreateWithWidthAndHeightAndDpiAndFormatAndAlpha )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */FLOAT width,
        /* [in] */FLOAT height,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirectXPixelFormat format,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode alpha,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget * * renderTarget
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactoryVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_CreateWithSize(This,resourceCreator,size,renderTarget) \
    ( (This)->lpVtbl->CreateWithSize(This,resourceCreator,size,renderTarget) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_CreateWithWidthAndHeight(This,resourceCreator,width,height,renderTarget) \
    ( (This)->lpVtbl->CreateWithWidthAndHeight(This,resourceCreator,width,height,renderTarget) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_CreateWithWidthAndHeightAndDpi(This,resourceCreator,width,height,dpi,renderTarget) \
    ( (This)->lpVtbl->CreateWithWidthAndHeightAndDpi(This,resourceCreator,width,height,dpi,renderTarget) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_CreateWithWidthAndHeightAndDpiAndFormatAndAlpha(This,resourceCreator,width,height,dpi,format,alpha,renderTarget) \
    ( (This)->lpVtbl->CreateWithWidthAndHeightAndDpiAndFormatAndAlpha(This,resourceCreator,width,height,dpi,format,alpha,renderTarget) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasRenderTargetStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasRenderTarget
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasRenderTargetStatics[] = L"Microsoft.Graphics.Canvas.ICanvasRenderTargetStatics";
/* [object, version, uuid("C7D1FE37-DD57-45D7-BCC1-15625A21E8D5"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateFromDirect3D11Surface )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DSurface * surface,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget * * bitmap
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateFromDirect3D11SurfaceWithDpi )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DSurface * surface,
        /* [in] */FLOAT dpi,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget * * bitmap
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateFromDirect3D11SurfaceWithDpiAndAlpha )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirect3D11_CIDirect3DSurface * surface,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode alpha,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTarget * * bitmap
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStaticsVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_CreateFromDirect3D11Surface(This,resourceCreator,surface,bitmap) \
    ( (This)->lpVtbl->CreateFromDirect3D11Surface(This,resourceCreator,surface,bitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_CreateFromDirect3D11SurfaceWithDpi(This,resourceCreator,surface,dpi,bitmap) \
    ( (This)->lpVtbl->CreateFromDirect3D11SurfaceWithDpi(This,resourceCreator,surface,dpi,bitmap) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_CreateFromDirect3D11SurfaceWithDpiAndAlpha(This,resourceCreator,surface,dpi,alpha,bitmap) \
    ( (This)->lpVtbl->CreateFromDirect3D11SurfaceWithDpiAndAlpha(This,resourceCreator,surface,dpi,alpha,bitmap) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasRenderTargetStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasResourceCreator[] = L"Microsoft.Graphics.Canvas.ICanvasResourceCreator";
/* [object, version, uuid("8F6D8AA8-492F-4BC6-B3D0-E7F5EAE84B11")] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Device )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_get_Device(This,value) \
    ( (This)->lpVtbl->get_Device(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasResourceCreatorWithDpi[] = L"Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi";
/* [object, version, uuid("1A75B512-E9FA-49E6-A876-38CAE194013E")] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpiVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Dpi )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi * This,
        /* [retval, out] */FLOAT * dpi
        );
    HRESULT ( STDMETHODCALLTYPE *ConvertPixelsToDips )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi * This,
        /* [in] */INT32 pixels,
        /* [retval, out] */FLOAT * dips
        );
    HRESULT ( STDMETHODCALLTYPE *ConvertDipsToPixels )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi * This,
        /* [in] */FLOAT dips,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasDpiRounding dpiRounding,
        /* [retval, out] */INT32 * pixels
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpiVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpiVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_get_Dpi(This,dpi) \
    ( (This)->lpVtbl->get_Dpi(This,dpi) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_ConvertPixelsToDips(This,pixels,dips) \
    ( (This)->lpVtbl->ConvertPixelsToDips(This,pixels,dips) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_ConvertDipsToPixels(This,dips,dpiRounding,pixels) \
    ( (This)->lpVtbl->ConvertDipsToPixels(This,dips,dpiRounding,pixels) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasSpriteBatch
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasSpriteBatch
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasSpriteBatch[] = L"Microsoft.Graphics.Canvas.ICanvasSpriteBatch";
/* [object, version, uuid("A065DCE4-A7F2-4DF4-8405-EA9E3A215BF8"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawToRect )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect destRect
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawAtOffset )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawWithTransform )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawToRectWithTint )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect destRect,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector4 tint
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawAtOffsetWithTint )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector4 tint
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawWithTransformAndTint )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector4 tint
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawToRectWithTintAndFlip )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect destRect,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector4 tint,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteFlip flip
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawWithTransformAndTintAndFlip )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector4 tint,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteFlip flip
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawAtOffsetWithTintAndTransform )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector4 tint,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 origin,
        /* [in] */FLOAT rotation,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 scale,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteFlip flip
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawFromSpriteSheetToRect )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect destRect,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRect
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawFromSpriteSheetAtOffset )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRect
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawFromSpriteSheetWithTransform )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRect
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawFromSpriteSheetToRectWithTint )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect destRect,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRect,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector4 tint
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawFromSpriteSheetAtOffsetWithTint )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRect,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector4 tint
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawFromSpriteSheetWithTransformAndTint )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRect,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector4 tint
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *DrawFromSpriteSheetToRectWithTintAndFlip )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect destRect,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRect,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector4 tint,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteFlip flip
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawFromSpriteSheetWithTransformAndTintAndFlip )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRect,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector4 tint,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteFlip flip
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *DrawFromSpriteSheetAtOffsetWithTintAndTransform )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasBitmap * bitmap,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 offset,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect sourceRect,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector4 tint,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 origin,
        /* [in] */FLOAT rotation,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 scale,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSpriteFlip flip
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawToRect(This,bitmap,destRect) \
    ( (This)->lpVtbl->DrawToRect(This,bitmap,destRect) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawAtOffset(This,bitmap,offset) \
    ( (This)->lpVtbl->DrawAtOffset(This,bitmap,offset) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawWithTransform(This,bitmap,transform) \
    ( (This)->lpVtbl->DrawWithTransform(This,bitmap,transform) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawToRectWithTint(This,bitmap,destRect,tint) \
    ( (This)->lpVtbl->DrawToRectWithTint(This,bitmap,destRect,tint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawAtOffsetWithTint(This,bitmap,offset,tint) \
    ( (This)->lpVtbl->DrawAtOffsetWithTint(This,bitmap,offset,tint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawWithTransformAndTint(This,bitmap,transform,tint) \
    ( (This)->lpVtbl->DrawWithTransformAndTint(This,bitmap,transform,tint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawToRectWithTintAndFlip(This,bitmap,destRect,tint,flip) \
    ( (This)->lpVtbl->DrawToRectWithTintAndFlip(This,bitmap,destRect,tint,flip) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawWithTransformAndTintAndFlip(This,bitmap,transform,tint,flip) \
    ( (This)->lpVtbl->DrawWithTransformAndTintAndFlip(This,bitmap,transform,tint,flip) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawAtOffsetWithTintAndTransform(This,bitmap,offset,tint,origin,rotation,scale,flip) \
    ( (This)->lpVtbl->DrawAtOffsetWithTintAndTransform(This,bitmap,offset,tint,origin,rotation,scale,flip) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawFromSpriteSheetToRect(This,bitmap,destRect,sourceRect) \
    ( (This)->lpVtbl->DrawFromSpriteSheetToRect(This,bitmap,destRect,sourceRect) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawFromSpriteSheetAtOffset(This,bitmap,offset,sourceRect) \
    ( (This)->lpVtbl->DrawFromSpriteSheetAtOffset(This,bitmap,offset,sourceRect) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawFromSpriteSheetWithTransform(This,bitmap,transform,sourceRect) \
    ( (This)->lpVtbl->DrawFromSpriteSheetWithTransform(This,bitmap,transform,sourceRect) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawFromSpriteSheetToRectWithTint(This,bitmap,destRect,sourceRect,tint) \
    ( (This)->lpVtbl->DrawFromSpriteSheetToRectWithTint(This,bitmap,destRect,sourceRect,tint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawFromSpriteSheetAtOffsetWithTint(This,bitmap,offset,sourceRect,tint) \
    ( (This)->lpVtbl->DrawFromSpriteSheetAtOffsetWithTint(This,bitmap,offset,sourceRect,tint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawFromSpriteSheetWithTransformAndTint(This,bitmap,transform,sourceRect,tint) \
    ( (This)->lpVtbl->DrawFromSpriteSheetWithTransformAndTint(This,bitmap,transform,sourceRect,tint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawFromSpriteSheetToRectWithTintAndFlip(This,bitmap,destRect,sourceRect,tint,flip) \
    ( (This)->lpVtbl->DrawFromSpriteSheetToRectWithTintAndFlip(This,bitmap,destRect,sourceRect,tint,flip) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawFromSpriteSheetWithTransformAndTintAndFlip(This,bitmap,transform,sourceRect,tint,flip) \
    ( (This)->lpVtbl->DrawFromSpriteSheetWithTransformAndTintAndFlip(This,bitmap,transform,sourceRect,tint,flip) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_DrawFromSpriteSheetAtOffsetWithTintAndTransform(This,bitmap,offset,sourceRect,tint,origin,rotation,scale,flip) \
    ( (This)->lpVtbl->DrawFromSpriteSheetAtOffsetWithTintAndTransform(This,bitmap,offset,sourceRect,tint,origin,rotation,scale,flip) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatch_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasSpriteBatchStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasSpriteBatch
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasSpriteBatchStatics[] = L"Microsoft.Graphics.Canvas.ICanvasSpriteBatchStatics";
/* [object, version, uuid("851EB08D-9D01-4B57-9E94-24113151B74B"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *IsSupported )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * device,
        /* [retval, out] */boolean * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStaticsVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_IsSupported(This,device,value) \
    ( (This)->lpVtbl->IsSupported(This,device,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSpriteBatchStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasSwapChain
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasSwapChain
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *     Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasSwapChain[] = L"Microsoft.Graphics.Canvas.ICanvasSwapChain";
/* [object, version, uuid("882E3C3A-5725-409C-9E76-F80B3BACF1B4"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload] */HRESULT ( STDMETHODCALLTYPE *Present )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *PresentWithSyncInterval )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
        /* [in] */INT32 syncInterval
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *ResizeBuffersWithSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CSize newSize
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *ResizeBuffersWithWidthAndHeight )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
        /* [in] */FLOAT newWidth,
        /* [in] */FLOAT newHeight
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *ResizeBuffersWithWidthAndHeightAndDpi )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
        /* [in] */FLOAT newWidth,
        /* [in] */FLOAT newHeight,
        /* [in] */FLOAT newDpi
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *ResizeBuffersWithAllOptions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
        /* [in] */FLOAT newWidth,
        /* [in] */FLOAT newHeight,
        /* [in] */FLOAT newDpi,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirectXPixelFormat newFormat,
        /* [in] */INT32 bufferCount
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Size )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CSize * size
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_SizeInPixels )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
        /* [retval, out] */__x_ABI_CWindows_CGraphics_CImaging_CBitmapSize * size
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Format )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
        /* [retval, out] */__x_ABI_CWindows_CGraphics_CDirectX_CDirectXPixelFormat * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_BufferCount )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
        /* [retval, out] */INT32 * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_AlphaMode )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Rotation )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSwapChainRotation * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_Rotation )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasSwapChainRotation value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_SourceSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CSize * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_SourceSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CSize value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_TransformMatrix )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_TransformMatrix )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 value
        );
    HRESULT ( STDMETHODCALLTYPE *CreateDrawingSession )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This,
        /* [in] */__x_ABI_CWindows_CUI_CColor clearColor,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * * drawingSession
        );
    HRESULT ( STDMETHODCALLTYPE *WaitForVerticalBlank )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * This
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_Present(This) \
    ( (This)->lpVtbl->Present(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_PresentWithSyncInterval(This,syncInterval) \
    ( (This)->lpVtbl->PresentWithSyncInterval(This,syncInterval) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_ResizeBuffersWithSize(This,newSize) \
    ( (This)->lpVtbl->ResizeBuffersWithSize(This,newSize) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_ResizeBuffersWithWidthAndHeight(This,newWidth,newHeight) \
    ( (This)->lpVtbl->ResizeBuffersWithWidthAndHeight(This,newWidth,newHeight) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_ResizeBuffersWithWidthAndHeightAndDpi(This,newWidth,newHeight,newDpi) \
    ( (This)->lpVtbl->ResizeBuffersWithWidthAndHeightAndDpi(This,newWidth,newHeight,newDpi) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_ResizeBuffersWithAllOptions(This,newWidth,newHeight,newDpi,newFormat,bufferCount) \
    ( (This)->lpVtbl->ResizeBuffersWithAllOptions(This,newWidth,newHeight,newDpi,newFormat,bufferCount) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_get_Size(This,size) \
    ( (This)->lpVtbl->get_Size(This,size) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_get_SizeInPixels(This,size) \
    ( (This)->lpVtbl->get_SizeInPixels(This,size) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_get_Format(This,value) \
    ( (This)->lpVtbl->get_Format(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_get_BufferCount(This,value) \
    ( (This)->lpVtbl->get_BufferCount(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_get_AlphaMode(This,value) \
    ( (This)->lpVtbl->get_AlphaMode(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_get_Rotation(This,value) \
    ( (This)->lpVtbl->get_Rotation(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_put_Rotation(This,value) \
    ( (This)->lpVtbl->put_Rotation(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_get_SourceSize(This,value) \
    ( (This)->lpVtbl->get_SourceSize(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_put_SourceSize(This,value) \
    ( (This)->lpVtbl->put_SourceSize(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_get_TransformMatrix(This,value) \
    ( (This)->lpVtbl->get_TransformMatrix(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_put_TransformMatrix(This,value) \
    ( (This)->lpVtbl->put_TransformMatrix(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_CreateDrawingSession(This,clearColor,drawingSession) \
    ( (This)->lpVtbl->CreateDrawingSession(This,clearColor,drawingSession) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_WaitForVerticalBlank(This) \
    ( (This)->lpVtbl->WaitForVerticalBlank(This) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasSwapChainFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasSwapChain
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasSwapChainFactory[] = L"Microsoft.Graphics.Canvas.ICanvasSwapChainFactory";
/* [object, version, uuid("133C25CB-ED3C-492B-BFFE-7509B521842B"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateWithSize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi * resourceCreator,
        /* [in] */__x_ABI_CWindows_CFoundation_CSize size,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * * swapChain
        );
    HRESULT ( STDMETHODCALLTYPE *CreateWithWidthAndHeight )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreatorWithDpi * resourceCreator,
        /* [in] */FLOAT width,
        /* [in] */FLOAT height,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * * swapChain
        );
    HRESULT ( STDMETHODCALLTYPE *CreateWithWidthAndHeightAndDpi )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */FLOAT width,
        /* [in] */FLOAT height,
        /* [in] */FLOAT dpi,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * * swapChain
        );
    HRESULT ( STDMETHODCALLTYPE *CreateWithAllOptions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */FLOAT width,
        /* [in] */FLOAT height,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirectXPixelFormat format,
        /* [in] */INT32 bufferCount,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode alphaMode,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * * swapChain
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactoryVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_CreateWithSize(This,resourceCreator,size,swapChain) \
    ( (This)->lpVtbl->CreateWithSize(This,resourceCreator,size,swapChain) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_CreateWithWidthAndHeight(This,resourceCreator,width,height,swapChain) \
    ( (This)->lpVtbl->CreateWithWidthAndHeight(This,resourceCreator,width,height,swapChain) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_CreateWithWidthAndHeightAndDpi(This,resourceCreator,width,height,dpi,swapChain) \
    ( (This)->lpVtbl->CreateWithWidthAndHeightAndDpi(This,resourceCreator,width,height,dpi,swapChain) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_CreateWithAllOptions(This,resourceCreator,width,height,dpi,format,bufferCount,alphaMode,swapChain) \
    ( (This)->lpVtbl->CreateWithAllOptions(This,resourceCreator,width,height,dpi,format,bufferCount,alphaMode,swapChain) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasSwapChainStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasSwapChain
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasSwapChainStatics[] = L"Microsoft.Graphics.Canvas.ICanvasSwapChainStatics";
/* [object, version, uuid("05376D8F-3E8D-4A82-9838-691680D32A52"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateForCoreWindowWithDpi )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CUI_CCore_CICoreWindow * coreWindow,
        /* [in] */FLOAT dpi,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * * swapChain
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateForCoreWindowWithAllOptions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CUI_CCore_CICoreWindow * coreWindow,
        /* [in] */FLOAT width,
        /* [in] */FLOAT height,
        /* [in] */FLOAT dpi,
        /* [in] */__x_ABI_CWindows_CGraphics_CDirectX_CDirectXPixelFormat format,
        /* [in] */INT32 bufferCount,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChain * * swapChain
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStaticsVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_CreateForCoreWindowWithDpi(This,resourceCreator,coreWindow,dpi,swapChain) \
    ( (This)->lpVtbl->CreateForCoreWindowWithDpi(This,resourceCreator,coreWindow,dpi,swapChain) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_CreateForCoreWindowWithAllOptions(This,resourceCreator,coreWindow,width,height,dpi,format,bufferCount,swapChain) \
    ( (This)->lpVtbl->CreateForCoreWindowWithAllOptions(This,resourceCreator,coreWindow,width,height,dpi,format,bufferCount,swapChain) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasSwapChainStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasVirtualBitmap
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasVirtualBitmap
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *     Microsoft.Graphics.Canvas.ICanvasImage
 *     Windows.Graphics.Effects.IGraphicsEffectSource
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasVirtualBitmap[] = L"Microsoft.Graphics.Canvas.ICanvasVirtualBitmap";
/* [object, version, uuid("707D8BB0-05F9-484C-9EE2-179E0681C8A7"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Device )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_IsCachedOnDemand )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap * This,
        /* [retval, out] */boolean * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_SizeInPixels )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap * This,
        /* [retval, out] */__x_ABI_CWindows_CGraphics_CImaging_CBitmapSize * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Size )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CSize * value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Bounds )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_get_Device(This,value) \
    ( (This)->lpVtbl->get_Device(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_get_IsCachedOnDemand(This,value) \
    ( (This)->lpVtbl->get_IsCachedOnDemand(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_get_SizeInPixels(This,value) \
    ( (This)->lpVtbl->get_SizeInPixels(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_get_Size(This,value) \
    ( (This)->lpVtbl->get_Size(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_get_Bounds(This,value) \
    ( (This)->lpVtbl->get_Bounds(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmap_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.ICanvasVirtualBitmapStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.CanvasVirtualBitmap
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_ICanvasVirtualBitmapStatics[] = L"Microsoft.Graphics.Canvas.ICanvasVirtualBitmapStatics";
/* [object, version, uuid("B2F1F8E9-0770-4DD4-956D-78D911390957"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromFileName )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */HSTRING fileName,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromFileNameWithOptions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */HSTRING fileName,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasVirtualBitmapOptions options,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromFileNameWithOptionsAndAlpha )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */HSTRING fileName,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasVirtualBitmapOptions options,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode alpha,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromUri )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CFoundation_CIUriRuntimeClass * uri,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromUriWithOptions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CFoundation_CIUriRuntimeClass * uri,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasVirtualBitmapOptions options,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromUriWithOptionsAndAlpha )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CFoundation_CIUriRuntimeClass * uri,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasVirtualBitmapOptions options,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode alpha,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromStream )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream * stream,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromStreamWithOptions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream * stream,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasVirtualBitmapOptions options,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *LoadAsyncFromStreamWithOptionsAndAlpha )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CStorage_CStreams_CIRandomAccessStream * stream,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasVirtualBitmapOptions options,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CCanvasAlphaMode alpha,
        /* [retval, out] */__FIAsyncOperation_1_Microsoft__CGraphics__CCanvas__CCanvasVirtualBitmap * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStaticsVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_LoadAsyncFromFileName(This,resourceCreator,fileName,value) \
    ( (This)->lpVtbl->LoadAsyncFromFileName(This,resourceCreator,fileName,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_LoadAsyncFromFileNameWithOptions(This,resourceCreator,fileName,options,value) \
    ( (This)->lpVtbl->LoadAsyncFromFileNameWithOptions(This,resourceCreator,fileName,options,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_LoadAsyncFromFileNameWithOptionsAndAlpha(This,resourceCreator,fileName,options,alpha,value) \
    ( (This)->lpVtbl->LoadAsyncFromFileNameWithOptionsAndAlpha(This,resourceCreator,fileName,options,alpha,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_LoadAsyncFromUri(This,resourceCreator,uri,value) \
    ( (This)->lpVtbl->LoadAsyncFromUri(This,resourceCreator,uri,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_LoadAsyncFromUriWithOptions(This,resourceCreator,uri,options,value) \
    ( (This)->lpVtbl->LoadAsyncFromUriWithOptions(This,resourceCreator,uri,options,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_LoadAsyncFromUriWithOptionsAndAlpha(This,resourceCreator,uri,options,alpha,value) \
    ( (This)->lpVtbl->LoadAsyncFromUriWithOptionsAndAlpha(This,resourceCreator,uri,options,alpha,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_LoadAsyncFromStream(This,resourceCreator,stream,value) \
    ( (This)->lpVtbl->LoadAsyncFromStream(This,resourceCreator,stream,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_LoadAsyncFromStreamWithOptions(This,resourceCreator,stream,options,value) \
    ( (This)->lpVtbl->LoadAsyncFromStreamWithOptions(This,resourceCreator,stream,options,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_LoadAsyncFromStreamWithOptionsAndAlpha(This,resourceCreator,stream,options,alpha,value) \
    ( (This)->lpVtbl->LoadAsyncFromStreamWithOptionsAndAlpha(This,resourceCreator,stream,options,alpha,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasVirtualBitmapStatics_INTERFACE_DEFINED__) */


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasActiveLayer
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasActiveLayer ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasActiveLayer_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasActiveLayer_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasActiveLayer[] = L"Microsoft.Graphics.Canvas.CanvasActiveLayer";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasBitmap
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasBitmap ** Default Interface **
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *    Windows.Graphics.DirectX.Direct3D11.IDirect3DSurface
 *    Windows.Foundation.IClosable
 *    Microsoft.Graphics.Canvas.ICanvasImage
 *    Windows.Graphics.Effects.IGraphicsEffectSource
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasBitmap_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasBitmap_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasBitmap[] = L"Microsoft.Graphics.Canvas.CanvasBitmap";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasCommandList
 *
 * RuntimeClass can be activated.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasCommandList ** Default Interface **
 *    Microsoft.Graphics.Canvas.ICanvasImage
 *    Windows.Foundation.IClosable
 *    Windows.Graphics.Effects.IGraphicsEffectSource
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasCommandList_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasCommandList_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasCommandList[] = L"Microsoft.Graphics.Canvas.CanvasCommandList";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasDevice
 *
 * RuntimeClass can be activated.
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasDevice ** Default Interface **
 *    Windows.Graphics.DirectX.Direct3D11.IDirect3DDevice
 *    Windows.Foundation.IClosable
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasDevice_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasDevice_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasDevice[] = L"Microsoft.Graphics.Canvas.CanvasDevice";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasDrawingSession
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasDrawingSession ** Default Interface **
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasDrawingSession_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasDrawingSession_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasDrawingSession[] = L"Microsoft.Graphics.Canvas.CanvasDrawingSession";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasImage
 *
 * RuntimeClass contains static methods.
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasImage_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasImage_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasImage[] = L"Microsoft.Graphics.Canvas.CanvasImage";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasLock
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasLock ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasLock_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasLock_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasLock[] = L"Microsoft.Graphics.Canvas.CanvasLock";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasRenderTarget
 *
 * RuntimeClass can be activated.
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasRenderTarget ** Default Interface **
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasRenderTarget_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasRenderTarget_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasRenderTarget[] = L"Microsoft.Graphics.Canvas.CanvasRenderTarget";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasSpriteBatch
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasSpriteBatch ** Default Interface **
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasSpriteBatch_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasSpriteBatch_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasSpriteBatch[] = L"Microsoft.Graphics.Canvas.CanvasSpriteBatch";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasSwapChain
 *
 * RuntimeClass can be activated.
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasSwapChain ** Default Interface **
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreatorWithDpi
 *    Microsoft.Graphics.Canvas.ICanvasResourceCreator
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasSwapChain_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasSwapChain_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasSwapChain[] = L"Microsoft.Graphics.Canvas.CanvasSwapChain";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.CanvasVirtualBitmap
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.ICanvasVirtualBitmap ** Default Interface **
 *    Microsoft.Graphics.Canvas.ICanvasImage
 *    Windows.Foundation.IClosable
 *    Windows.Graphics.Effects.IGraphicsEffectSource
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasVirtualBitmap_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_CanvasVirtualBitmap_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_CanvasVirtualBitmap[] = L"Microsoft.Graphics.Canvas.CanvasVirtualBitmap";
#endif




#endif // defined(__cplusplus)
#pragma pop_macro("MIDL_CONST_ID")
// Restore the original value of the 'DEPRECATED' macro
#pragma pop_macro("DEPRECATED")

#ifdef __clang__
#pragma clang diagnostic pop // deprecated-declarations
#else
#pragma warning(pop)
#endif
#endif // __microsoft2Egraphics2Ecanvas_p_h__

#endif // __microsoft2Egraphics2Ecanvas_h__
