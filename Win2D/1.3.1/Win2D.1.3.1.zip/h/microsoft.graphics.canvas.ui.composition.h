
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

/* verify that the <rpcsal.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCSAL_H_VERSION__
#define __REQUIRED_RPCSAL_H_VERSION__ 100
#endif

#include <rpc.h>
#include <rpcndr.h>

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include <windows.h>
#include <ole2.h>
#endif /*COM_NO_WINDOWS_H*/
#ifndef __microsoft2Egraphics2Ecanvas2Eui2Ecomposition_h__
#define __microsoft2Egraphics2Ecanvas2Eui2Ecomposition_h__
#ifndef __microsoft2Egraphics2Ecanvas2Eui2Ecomposition_p_h__
#define __microsoft2Egraphics2Ecanvas2Eui2Ecomposition_p_h__


#pragma once

//
// Deprecated attribute support
//

#pragma push_macro("DEPRECATED")
#undef DEPRECATED

#if !defined(DISABLE_WINRT_DEPRECATION)
#if defined(__cplusplus)
#if __cplusplus >= 201402
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#elif defined(_MSC_VER)
#if _MSC_VER >= 1900
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#else
#define DEPRECATED(x) __declspec(deprecated(x))
#define DEPRECATEDENUMERATOR(x)
#endif // _MSC_VER >= 1900
#else // Not Standard C++ or MSVC, ignore the construct.
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  // C++ deprecation
#else // C - disable deprecation
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif
#else // Deprecation is disabled
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  /* DEPRECATED */

// Disable Deprecation for this header, MIDL verifies that cross-type access is acceptable
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#else
#pragma warning(push)
#pragma warning(disable: 4996)
#endif

// Ensure that the setting of the /ns_prefix command line switch is consistent for all headers.
// If you get an error from the compiler indicating "warning C4005: 'CHECK_NS_PREFIX_STATE': macro redefinition", this
// indicates that you have included two different headers with different settings for the /ns_prefix MIDL command line switch
#if !defined(DISABLE_NS_PREFIX_CHECKS)
#define CHECK_NS_PREFIX_STATE "always"
#endif // !defined(DISABLE_NS_PREFIX_CHECKS)


#pragma push_macro("MIDL_CONST_ID")
#undef MIDL_CONST_ID
#define MIDL_CONST_ID const __declspec(selectany)


//  API Contract Inclusion Definitions
#if !defined(SPECIFIC_API_CONTRACT_DEFINITIONS)
#if !defined(MICROSOFT_FOUNDATION_WINDOWSAPPSDKCONTRACT_VERSION)
#define MICROSOFT_FOUNDATION_WINDOWSAPPSDKCONTRACT_VERSION 0x10006
#endif // defined(MICROSOFT_FOUNDATION_WINDOWSAPPSDKCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION 0x50000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION)
#define WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION)
#define WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION)
#define WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION)
#define WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION 0x60000
#endif // defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION)
#define WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)
#define WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)
#define WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION 0x130000
#endif // defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)

#if !defined(WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION)
#define WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION)

#if !defined(WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION)
#define WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION)
#define WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION)
#define WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION)
#define WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION)
#define WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)
#define WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)
#define WINDOWS_PHONE_PHONECONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)
#define WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)

#if !defined(WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION)
#define WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION 0x50000
#endif // defined(WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION)

#if !defined(WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION)
#define WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION)

#if !defined(WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION)
#define WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION)

#if !defined(WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION)
#define WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION)

#if !defined(WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION)
#define WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION)

#if !defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)
#define WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)

#endif // defined(SPECIFIC_API_CONTRACT_DEFINITIONS)


// Header files for imported files
#include "inspectable.h"
#include "AsyncInfo.h"
#include "EventToken.h"
#include "Windows.Foundation.h"
#include "Microsoft.Graphics.Canvas.h"
#include "Microsoft.UI.Composition.h"

#if defined(__cplusplus) && !defined(CINTERFACE)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace UI {
                    namespace Composition {
                        interface ICanvasCompositionStatics;
                    } /* Composition */
                } /* UI */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics ABI::Microsoft::Graphics::Canvas::UI::Composition::ICanvasCompositionStatics

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_FWD_DEFINED__


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                class CanvasDevice;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasDevice;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice ABI::Microsoft::Graphics::Canvas::ICanvasDevice

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                class CanvasDrawingSession;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasDrawingSession;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession ABI::Microsoft::Graphics::Canvas::ICanvasDrawingSession

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__





namespace ABI {
    namespace Microsoft {
        namespace UI {
            namespace Composition {
                class CompositionDrawingSurface;
            } /* Composition */
        } /* UI */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CUI_CComposition_CICompositionDrawingSurface_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CUI_CComposition_CICompositionDrawingSurface_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace UI {
            namespace Composition {
                interface ICompositionDrawingSurface;
            } /* Composition */
        } /* UI */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CUI_CComposition_CICompositionDrawingSurface ABI::Microsoft::UI::Composition::ICompositionDrawingSurface

#endif // ____x_ABI_CMicrosoft_CUI_CComposition_CICompositionDrawingSurface_FWD_DEFINED__


namespace ABI {
    namespace Microsoft {
        namespace UI {
            namespace Composition {
                class CompositionGraphicsDevice;
            } /* Composition */
        } /* UI */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CUI_CComposition_CICompositionGraphicsDevice_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CUI_CComposition_CICompositionGraphicsDevice_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace UI {
            namespace Composition {
                interface ICompositionGraphicsDevice;
            } /* Composition */
        } /* UI */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CUI_CComposition_CICompositionGraphicsDevice ABI::Microsoft::UI::Composition::ICompositionGraphicsDevice

#endif // ____x_ABI_CMicrosoft_CUI_CComposition_CICompositionGraphicsDevice_FWD_DEFINED__


namespace ABI {
    namespace Microsoft {
        namespace UI {
            namespace Composition {
                class Compositor;
            } /* Composition */
        } /* UI */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CUI_CComposition_CICompositor_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CUI_CComposition_CICompositor_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace UI {
            namespace Composition {
                interface ICompositor;
            } /* Composition */
        } /* UI */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CUI_CComposition_CICompositor ABI::Microsoft::UI::Composition::ICompositor

#endif // ____x_ABI_CMicrosoft_CUI_CComposition_CICompositor_FWD_DEFINED__





namespace ABI {
    namespace Windows {
        namespace Foundation {
            
            typedef struct Rect Rect;
            
        } /* Foundation */
    } /* Windows */
} /* ABI */

namespace ABI {
    namespace Windows {
        namespace Foundation {
            
            typedef struct Size Size;
            
        } /* Foundation */
    } /* Windows */
} /* ABI */











/*
 *
 * Interface Microsoft.Graphics.Canvas.UI.Composition.ICanvasCompositionStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.UI.Composition.CanvasComposition
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_UI_Composition_ICanvasCompositionStatics[] = L"Microsoft.Graphics.Canvas.UI.Composition.ICanvasCompositionStatics";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace UI {
                    namespace Composition {
                        /* [object, version, uuid("162DEB43-1CF5-46F8-A0AF-356B23158F92"), exclusiveto] */
                        MIDL_INTERFACE("162DEB43-1CF5-46F8-A0AF-356B23158F92")
                        ICanvasCompositionStatics : public IInspectable
                        {
                        public:
                            virtual HRESULT STDMETHODCALLTYPE CreateCompositionGraphicsDevice(
                                /* [in] */ABI::Microsoft::UI::Composition::ICompositor * compositor,
                                /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * canvasDevice,
                                /* [retval, out] */ABI::Microsoft::UI::Composition::ICompositionGraphicsDevice * * graphicsDevice
                                ) = 0;
                            virtual HRESULT STDMETHODCALLTYPE GetCanvasDevice(
                                /* [in] */ABI::Microsoft::UI::Composition::ICompositionGraphicsDevice * graphicsDevice,
                                /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * * canvasDevice
                                ) = 0;
                            virtual HRESULT STDMETHODCALLTYPE SetCanvasDevice(
                                /* [in] */ABI::Microsoft::UI::Composition::ICompositionGraphicsDevice * graphicsDevice,
                                /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * canvasDevice
                                ) = 0;
                            /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateDrawingSession(
                                /* [in] */ABI::Microsoft::UI::Composition::ICompositionDrawingSurface * drawingSurface,
                                /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDrawingSession * * drawingSession
                                ) = 0;
                            /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateDrawingSessionWithUpdateRect(
                                /* [in] */ABI::Microsoft::UI::Composition::ICompositionDrawingSurface * drawingSurface,
                                /* [in] */ABI::Windows::Foundation::Rect updateRect,
                                /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDrawingSession * * drawingSession
                                ) = 0;
                            /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateDrawingSessionWithUpdateRectAndDpi(
                                /* [in] */ABI::Microsoft::UI::Composition::ICompositionDrawingSurface * drawingSurface,
                                /* [in] */ABI::Windows::Foundation::Rect updateRectInPixels,
                                /* [in] */FLOAT dpi,
                                /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDrawingSession * * drawingSession
                                ) = 0;
                            virtual HRESULT STDMETHODCALLTYPE Resize(
                                /* [in] */ABI::Microsoft::UI::Composition::ICompositionDrawingSurface * drawingSurface,
                                /* [in] */ABI::Windows::Foundation::Size sizeInPixels
                                ) = 0;
                            
                        };

                        MIDL_CONST_ID IID & IID_ICanvasCompositionStatics=__uuidof(ICanvasCompositionStatics);
                        
                    } /* Composition */
                } /* UI */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_INTERFACE_DEFINED__) */


/*
 *
 * Class Microsoft.Graphics.Canvas.UI.Composition.CanvasComposition
 *
 * RuntimeClass contains static methods.
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_UI_Composition_CanvasComposition_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_UI_Composition_CanvasComposition_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_UI_Composition_CanvasComposition[] = L"Microsoft.Graphics.Canvas.UI.Composition.CanvasComposition";
#endif






#else // !defined(__cplusplus)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__


#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession_FWD_DEFINED__





#ifndef ____x_ABI_CMicrosoft_CUI_CComposition_CICompositionDrawingSurface_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CUI_CComposition_CICompositionDrawingSurface_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CUI_CComposition_CICompositionDrawingSurface __x_ABI_CMicrosoft_CUI_CComposition_CICompositionDrawingSurface;

#endif // ____x_ABI_CMicrosoft_CUI_CComposition_CICompositionDrawingSurface_FWD_DEFINED__


#ifndef ____x_ABI_CMicrosoft_CUI_CComposition_CICompositionGraphicsDevice_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CUI_CComposition_CICompositionGraphicsDevice_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CUI_CComposition_CICompositionGraphicsDevice __x_ABI_CMicrosoft_CUI_CComposition_CICompositionGraphicsDevice;

#endif // ____x_ABI_CMicrosoft_CUI_CComposition_CICompositionGraphicsDevice_FWD_DEFINED__


#ifndef ____x_ABI_CMicrosoft_CUI_CComposition_CICompositor_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CUI_CComposition_CICompositor_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CUI_CComposition_CICompositor __x_ABI_CMicrosoft_CUI_CComposition_CICompositor;

#endif // ____x_ABI_CMicrosoft_CUI_CComposition_CICompositor_FWD_DEFINED__






typedef struct __x_ABI_CWindows_CFoundation_CRect __x_ABI_CWindows_CFoundation_CRect;


typedef struct __x_ABI_CWindows_CFoundation_CSize __x_ABI_CWindows_CFoundation_CSize;











/*
 *
 * Interface Microsoft.Graphics.Canvas.UI.Composition.ICanvasCompositionStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.UI.Composition.CanvasComposition
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_UI_Composition_ICanvasCompositionStatics[] = L"Microsoft.Graphics.Canvas.UI.Composition.ICanvasCompositionStatics";
/* [object, version, uuid("162DEB43-1CF5-46F8-A0AF-356B23158F92"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateCompositionGraphicsDevice )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CUI_CComposition_CICompositor * compositor,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * canvasDevice,
        /* [retval, out] */__x_ABI_CMicrosoft_CUI_CComposition_CICompositionGraphicsDevice * * graphicsDevice
        );
    HRESULT ( STDMETHODCALLTYPE *GetCanvasDevice )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CUI_CComposition_CICompositionGraphicsDevice * graphicsDevice,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * * canvasDevice
        );
    HRESULT ( STDMETHODCALLTYPE *SetCanvasDevice )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CUI_CComposition_CICompositionGraphicsDevice * graphicsDevice,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * canvasDevice
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateDrawingSession )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CUI_CComposition_CICompositionDrawingSurface * drawingSurface,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * * drawingSession
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateDrawingSessionWithUpdateRect )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CUI_CComposition_CICompositionDrawingSurface * drawingSurface,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect updateRect,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * * drawingSession
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateDrawingSessionWithUpdateRectAndDpi )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CUI_CComposition_CICompositionDrawingSurface * drawingSurface,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect updateRectInPixels,
        /* [in] */FLOAT dpi,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDrawingSession * * drawingSession
        );
    HRESULT ( STDMETHODCALLTYPE *Resize )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CUI_CComposition_CICompositionDrawingSurface * drawingSurface,
        /* [in] */__x_ABI_CWindows_CFoundation_CSize sizeInPixels
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStaticsVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_CreateCompositionGraphicsDevice(This,compositor,canvasDevice,graphicsDevice) \
    ( (This)->lpVtbl->CreateCompositionGraphicsDevice(This,compositor,canvasDevice,graphicsDevice) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_GetCanvasDevice(This,graphicsDevice,canvasDevice) \
    ( (This)->lpVtbl->GetCanvasDevice(This,graphicsDevice,canvasDevice) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_SetCanvasDevice(This,graphicsDevice,canvasDevice) \
    ( (This)->lpVtbl->SetCanvasDevice(This,graphicsDevice,canvasDevice) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_CreateDrawingSession(This,drawingSurface,drawingSession) \
    ( (This)->lpVtbl->CreateDrawingSession(This,drawingSurface,drawingSession) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_CreateDrawingSessionWithUpdateRect(This,drawingSurface,updateRect,drawingSession) \
    ( (This)->lpVtbl->CreateDrawingSessionWithUpdateRect(This,drawingSurface,updateRect,drawingSession) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_CreateDrawingSessionWithUpdateRectAndDpi(This,drawingSurface,updateRectInPixels,dpi,drawingSession) \
    ( (This)->lpVtbl->CreateDrawingSessionWithUpdateRectAndDpi(This,drawingSurface,updateRectInPixels,dpi,drawingSession) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_Resize(This,drawingSurface,sizeInPixels) \
    ( (This)->lpVtbl->Resize(This,drawingSurface,sizeInPixels) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CUI_CComposition_CICanvasCompositionStatics_INTERFACE_DEFINED__) */


/*
 *
 * Class Microsoft.Graphics.Canvas.UI.Composition.CanvasComposition
 *
 * RuntimeClass contains static methods.
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_UI_Composition_CanvasComposition_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_UI_Composition_CanvasComposition_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_UI_Composition_CanvasComposition[] = L"Microsoft.Graphics.Canvas.UI.Composition.CanvasComposition";
#endif






#endif // defined(__cplusplus)
#pragma pop_macro("MIDL_CONST_ID")
// Restore the original value of the 'DEPRECATED' macro
#pragma pop_macro("DEPRECATED")

#ifdef __clang__
#pragma clang diagnostic pop // deprecated-declarations
#else
#pragma warning(pop)
#endif
#endif // __microsoft2Egraphics2Ecanvas2Eui2Ecomposition_p_h__

#endif // __microsoft2Egraphics2Ecanvas2Eui2Ecomposition_h__
