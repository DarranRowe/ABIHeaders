
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

/* verify that the <rpcsal.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCSAL_H_VERSION__
#define __REQUIRED_RPCSAL_H_VERSION__ 100
#endif

#include <rpc.h>
#include <rpcndr.h>

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include <windows.h>
#include <ole2.h>
#endif /*COM_NO_WINDOWS_H*/
#ifndef __microsoft2Egraphics2Ecanvas2Egeometry_h__
#define __microsoft2Egraphics2Ecanvas2Egeometry_h__
#ifndef __microsoft2Egraphics2Ecanvas2Egeometry_p_h__
#define __microsoft2Egraphics2Ecanvas2Egeometry_p_h__


#pragma once

//
// Deprecated attribute support
//

#pragma push_macro("DEPRECATED")
#undef DEPRECATED

#if !defined(DISABLE_WINRT_DEPRECATION)
#if defined(__cplusplus)
#if __cplusplus >= 201402
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#elif defined(_MSC_VER)
#if _MSC_VER >= 1900
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#else
#define DEPRECATED(x) __declspec(deprecated(x))
#define DEPRECATEDENUMERATOR(x)
#endif // _MSC_VER >= 1900
#else // Not Standard C++ or MSVC, ignore the construct.
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  // C++ deprecation
#else // C - disable deprecation
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif
#else // Deprecation is disabled
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  /* DEPRECATED */

// Disable Deprecation for this header, MIDL verifies that cross-type access is acceptable
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#else
#pragma warning(push)
#pragma warning(disable: 4996)
#endif

// Ensure that the setting of the /ns_prefix command line switch is consistent for all headers.
// If you get an error from the compiler indicating "warning C4005: 'CHECK_NS_PREFIX_STATE': macro redefinition", this
// indicates that you have included two different headers with different settings for the /ns_prefix MIDL command line switch
#if !defined(DISABLE_NS_PREFIX_CHECKS)
#define CHECK_NS_PREFIX_STATE "always"
#endif // !defined(DISABLE_NS_PREFIX_CHECKS)


#pragma push_macro("MIDL_CONST_ID")
#undef MIDL_CONST_ID
#define MIDL_CONST_ID const __declspec(selectany)


//  API Contract Inclusion Definitions
#if !defined(SPECIFIC_API_CONTRACT_DEFINITIONS)
#if !defined(MICROSOFT_FOUNDATION_WINDOWSAPPSDKCONTRACT_VERSION)
#define MICROSOFT_FOUNDATION_WINDOWSAPPSDKCONTRACT_VERSION 0x10006
#endif // defined(MICROSOFT_FOUNDATION_WINDOWSAPPSDKCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_ACTIVATIONCAMERASETTINGSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_CONTACTACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_ACTIVATION_WEBUISEARCHACTIVATEDEVENTSCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_BACKGROUND_BACKGROUNDALARMAPPLICATIONCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_BACKGROUND_CALLSBACKGROUNDCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION 0x50000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSVOIPCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_LOCKSCREENCALLCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_COMMUNICATIONBLOCKING_COMMUNICATIONBLOCKINGCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_FULLTRUSTAPPCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_APPLICATIONMODEL_SEARCH_SEARCHCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_APPLICATIONMODEL_STARTUPTASKCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_APPLICATIONMODEL_WALLET_WALLETCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION)
#define WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_DEVICES_POWER_POWERGRIDAPICONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION)
#define WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_DEVICES_PRINTERS_EXTENSIONS_EXTENSIONSCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION)
#define WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDBACKGROUNDTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION)
#define WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION 0x60000
#endif // defined(WINDOWS_DEVICES_SMARTCARDS_SMARTCARDEMULATORCONTRACT_VERSION)

#if !defined(WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION)
#define WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_DEVICES_SMS_LEGACYSMSAPICONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)
#define WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)
#define WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION 0x130000
#endif // defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)

#if !defined(WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION)
#define WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_GAMING_INPUT_GAMINGINPUTPREVIEWCONTRACT_VERSION)

#if !defined(WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION)
#define WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_GLOBALIZATION_GLOBALIZATIONJAPANESEPHONETICANALYZERCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION 0x20000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPBROADCASTCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPCAPTURECONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_APPCAPTUREMETADATACONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_CAMERACAPTUREUICONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION)
#define WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_CAPTURE_GAMEBARCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION)
#define WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_DEVICES_CALLCONTROLCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION)
#define WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_MEDIACONTROLCONTRACT_VERSION)

#if !defined(WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION)
#define WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_MEDIA_PROTECTION_PROTECTIONRENEWALCONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION)
#define WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_NETWORKING_CONNECTIVITY_WWANCONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)
#define WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)
#define WINDOWS_PHONE_PHONECONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)
#define WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)

#if !defined(WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION)
#define WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION 0x50000
#endif // defined(WINDOWS_SECURITY_ENTERPRISEDATA_ENTERPRISEDATACONTRACT_VERSION)

#if !defined(WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION)
#define WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_STORAGE_PROVIDER_CLOUDFILESCONTRACT_VERSION)

#if !defined(WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION)
#define WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_SYSTEM_SYSTEMMANAGEMENTCONTRACT_VERSION)

#if !defined(WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION)
#define WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_CORE_COREWINDOWDIALOGSCONTRACT_VERSION)

#if !defined(WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION)
#define WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_VIEWMANAGEMENT_VIEWMANAGEMENTVIEWSCALINGCONTRACT_VERSION)

#if !defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)
#define WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)

#endif // defined(SPECIFIC_API_CONTRACT_DEFINITIONS)


// Header files for imported files
#include "inspectable.h"
#include "AsyncInfo.h"
#include "EventToken.h"
#include "Windows.Foundation.h"
#include "Microsoft.Graphics.Canvas.h"
#include "Microsoft.Graphics.Canvas.Text.h"
#include "Windows.Foundation.Numerics.h"
#include "Windows.Graphics.h"

#if defined(__cplusplus) && !defined(CINTERFACE)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    interface ICanvasCachedGeometry;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasCachedGeometry

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    interface ICanvasCachedGeometryStatics;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasCachedGeometryStatics

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    interface ICanvasGeometry;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    interface ICanvasGeometryStatics;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometryStatics

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    interface ICanvasGradientMesh;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGradientMesh

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    interface ICanvasGradientMeshFactory;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGradientMeshFactory

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    interface ICanvasGradientMeshStatics;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGradientMeshStatics

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    interface ICanvasPathBuilder;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasPathBuilder

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    interface ICanvasPathBuilderFactory;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasPathBuilderFactory

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    interface ICanvasPathReceiver;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasPathReceiver

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    interface ICanvasStrokeStyle;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_FWD_DEFINED__


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                class CanvasDevice;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasDevice;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice ABI::Microsoft::Graphics::Canvas::ICanvasDevice

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__


#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                interface ICanvasResourceCreator;
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__





namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    class CanvasFontFace;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasFontFace;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef struct CanvasGlyph CanvasGlyph;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasGlyphOrientation : int CanvasGlyphOrientation;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    class CanvasTextLayout;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    interface ICanvasTextLayout;
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextLayout

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Text {
                    
                    typedef enum CanvasTextMeasuringMode : int CanvasTextMeasuringMode;
                    
                } /* Text */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */





#ifndef ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Foundation {
            interface IClosable;
        } /* Foundation */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CFoundation_CIClosable ABI::Windows::Foundation::IClosable

#endif // ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__




namespace ABI {
    namespace Windows {
        namespace Foundation {
            namespace Numerics {
                
                typedef struct Matrix3x2 Matrix3x2;
                
            } /* Numerics */
        } /* Foundation */
    } /* Windows */
} /* ABI */

namespace ABI {
    namespace Windows {
        namespace Foundation {
            namespace Numerics {
                
                typedef struct Vector2 Vector2;
                
            } /* Numerics */
        } /* Foundation */
    } /* Windows */
} /* ABI */

namespace ABI {
    namespace Windows {
        namespace Foundation {
            namespace Numerics {
                
                typedef struct Vector4 Vector4;
                
            } /* Numerics */
        } /* Foundation */
    } /* Windows */
} /* ABI */




namespace ABI {
    namespace Windows {
        namespace Foundation {
            
            typedef struct Rect Rect;
            
        } /* Foundation */
    } /* Windows */
} /* ABI */



#ifndef ____x_ABI_CWindows_CGraphics_CIGeometrySource2D_FWD_DEFINED__
#define ____x_ABI_CWindows_CGraphics_CIGeometrySource2D_FWD_DEFINED__
namespace ABI {
    namespace Windows {
        namespace Graphics {
            interface IGeometrySource2D;
        } /* Graphics */
    } /* Windows */
} /* ABI */
#define __x_ABI_CWindows_CGraphics_CIGeometrySource2D ABI::Windows::Graphics::IGeometrySource2D

#endif // ____x_ABI_CWindows_CGraphics_CIGeometrySource2D_FWD_DEFINED__




namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef enum CanvasArcSize : int CanvasArcSize;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef enum CanvasCapStyle : int CanvasCapStyle;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef enum CanvasDashStyle : int CanvasDashStyle;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef enum CanvasFigureFill : int CanvasFigureFill;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef enum CanvasFigureLoop : int CanvasFigureLoop;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef enum CanvasFigureSegmentOptions : unsigned int CanvasFigureSegmentOptions;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef enum CanvasFilledRegionDetermination : int CanvasFilledRegionDetermination;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef enum CanvasGeometryCombine : int CanvasGeometryCombine;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef enum CanvasGeometryRelation : int CanvasGeometryRelation;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef enum CanvasGeometrySimplification : int CanvasGeometrySimplification;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef enum CanvasGradientMeshPatchEdge : int CanvasGradientMeshPatchEdge;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef enum CanvasLineJoin : int CanvasLineJoin;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef enum CanvasStrokeTransformBehavior : int CanvasStrokeTransformBehavior;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef enum CanvasSweepDirection : int CanvasSweepDirection;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef struct CanvasGradientMeshPatch CanvasGradientMeshPatch;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    
                    typedef struct CanvasTriangleVertices CanvasTriangleVertices;
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */












namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    class CanvasCachedGeometry;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    class CanvasGeometry;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    class CanvasGradientMesh;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    class CanvasPathBuilder;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    class CanvasStrokeStyle;
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */







/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasArcSize
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [v1_enum, version] */
                    enum CanvasArcSize : int
                    {
                        CanvasArcSize_Small = 0,
                        CanvasArcSize_Large = 1,
                    };
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasCapStyle
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [v1_enum, version] */
                    enum CanvasCapStyle : int
                    {
                        CanvasCapStyle_Flat = 0,
                        CanvasCapStyle_Square = 1,
                        CanvasCapStyle_Round = 2,
                        CanvasCapStyle_Triangle = 3,
                    };
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasDashStyle
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [v1_enum, version] */
                    enum CanvasDashStyle : int
                    {
                        CanvasDashStyle_Solid = 0,
                        CanvasDashStyle_Dash = 1,
                        CanvasDashStyle_Dot = 2,
                        CanvasDashStyle_DashDot = 3,
                        CanvasDashStyle_DashDotDot = 4,
                    };
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasFigureFill
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [v1_enum, version] */
                    enum CanvasFigureFill : int
                    {
                        CanvasFigureFill_Default = 0,
                        CanvasFigureFill_DoesNotAffectFills = 1,
                    };
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasFigureLoop
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [v1_enum, version] */
                    enum CanvasFigureLoop : int
                    {
                        CanvasFigureLoop_Open = 0,
                        CanvasFigureLoop_Closed = 1,
                    };
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasFigureSegmentOptions
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [v1_enum, version, flags] */
                    enum CanvasFigureSegmentOptions : unsigned int
                    {
                        CanvasFigureSegmentOptions_None = 0,
                        CanvasFigureSegmentOptions_ForceUnstroked = 0x1,
                        CanvasFigureSegmentOptions_ForceRoundLineJoin = 0x2,
                    };
                    
                    DEFINE_ENUM_FLAG_OPERATORS(CanvasFigureSegmentOptions)
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasFilledRegionDetermination
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [v1_enum, version] */
                    enum CanvasFilledRegionDetermination : int
                    {
                        CanvasFilledRegionDetermination_Alternate = 0,
                        CanvasFilledRegionDetermination_Winding = 1,
                    };
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasGeometryCombine
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [v1_enum, version] */
                    enum CanvasGeometryCombine : int
                    {
                        CanvasGeometryCombine_Union = 0,
                        CanvasGeometryCombine_Intersect = 1,
                        CanvasGeometryCombine_Xor = 2,
                        CanvasGeometryCombine_Exclude = 3,
                    };
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasGeometryRelation
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [v1_enum, version] */
                    enum CanvasGeometryRelation : int
                    {
                        CanvasGeometryRelation_Disjoint = 0,
                        CanvasGeometryRelation_Contained = 1,
                        CanvasGeometryRelation_Contains = 2,
                        CanvasGeometryRelation_Overlap = 3,
                    };
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasGeometrySimplification
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [v1_enum, version] */
                    enum CanvasGeometrySimplification : int
                    {
                        CanvasGeometrySimplification_CubicsAndLines = 0,
                        CanvasGeometrySimplification_Lines = 1,
                    };
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasGradientMeshPatchEdge
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [v1_enum, version] */
                    enum CanvasGradientMeshPatchEdge : int
                    {
                        CanvasGradientMeshPatchEdge_Aliased = 0,
                        CanvasGradientMeshPatchEdge_Antialiased = 1,
                        CanvasGradientMeshPatchEdge_AliasedAndInflated = 2,
                    };
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasLineJoin
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [v1_enum, version] */
                    enum CanvasLineJoin : int
                    {
                        CanvasLineJoin_Miter = 0,
                        CanvasLineJoin_Bevel = 1,
                        CanvasLineJoin_Round = 2,
                        CanvasLineJoin_MiterOrBevel = 3,
                    };
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasStrokeTransformBehavior
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [v1_enum, version] */
                    enum CanvasStrokeTransformBehavior : int
                    {
                        CanvasStrokeTransformBehavior_Normal = 0,
                        CanvasStrokeTransformBehavior_Fixed = 1,
                        CanvasStrokeTransformBehavior_Hairline = 2,
                    };
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasSweepDirection
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [v1_enum, version] */
                    enum CanvasSweepDirection : int
                    {
                        CanvasSweepDirection_CounterClockwise = 0,
                        CanvasSweepDirection_Clockwise = 1,
                    };
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasGradientMeshPatch
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [version] */
                    struct CanvasGradientMeshPatch
                    {
                        ABI::Windows::Foundation::Numerics::Vector2 Point00;
                        ABI::Windows::Foundation::Numerics::Vector2 Point01;
                        ABI::Windows::Foundation::Numerics::Vector2 Point02;
                        ABI::Windows::Foundation::Numerics::Vector2 Point03;
                        ABI::Windows::Foundation::Numerics::Vector2 Point10;
                        ABI::Windows::Foundation::Numerics::Vector2 Point11;
                        ABI::Windows::Foundation::Numerics::Vector2 Point12;
                        ABI::Windows::Foundation::Numerics::Vector2 Point13;
                        ABI::Windows::Foundation::Numerics::Vector2 Point20;
                        ABI::Windows::Foundation::Numerics::Vector2 Point21;
                        ABI::Windows::Foundation::Numerics::Vector2 Point22;
                        ABI::Windows::Foundation::Numerics::Vector2 Point23;
                        ABI::Windows::Foundation::Numerics::Vector2 Point30;
                        ABI::Windows::Foundation::Numerics::Vector2 Point31;
                        ABI::Windows::Foundation::Numerics::Vector2 Point32;
                        ABI::Windows::Foundation::Numerics::Vector2 Point33;
                        ABI::Windows::Foundation::Numerics::Vector4 Color00;
                        ABI::Windows::Foundation::Numerics::Vector4 Color03;
                        ABI::Windows::Foundation::Numerics::Vector4 Color30;
                        ABI::Windows::Foundation::Numerics::Vector4 Color33;
                        ABI::Microsoft::Graphics::Canvas::Geometry::CanvasGradientMeshPatchEdge Edge00To03;
                        ABI::Microsoft::Graphics::Canvas::Geometry::CanvasGradientMeshPatchEdge Edge03To33;
                        ABI::Microsoft::Graphics::Canvas::Geometry::CanvasGradientMeshPatchEdge Edge33To30;
                        ABI::Microsoft::Graphics::Canvas::Geometry::CanvasGradientMeshPatchEdge Edge30To00;
                    };
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasTriangleVertices
 *
 */

namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [version] */
                    struct CanvasTriangleVertices
                    {
                        ABI::Windows::Foundation::Numerics::Vector2 Vertex1;
                        ABI::Windows::Foundation::Numerics::Vector2 Vertex2;
                        ABI::Windows::Foundation::Numerics::Vector2 Vertex3;
                    };
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasCachedGeometry
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasCachedGeometry
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasCachedGeometry[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasCachedGeometry";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [object, version, uuid("BA6CB114-E1A1-448D-AB7C-8D2B92674119"), exclusiveto] */
                    MIDL_INTERFACE("BA6CB114-E1A1-448D-AB7C-8D2B92674119")
                    ICanvasCachedGeometry : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Device(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasCachedGeometry=__uuidof(ICanvasCachedGeometry);
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasCachedGeometryStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasCachedGeometry
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasCachedGeometryStatics[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasCachedGeometryStatics";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [object, version, uuid("80BA1060-A9D7-41BA-9372-EC3FC1744E5D"), exclusiveto] */
                    MIDL_INTERFACE("80BA1060-A9D7-41BA-9372-EC3FC1744E5D")
                    ICanvasCachedGeometryStatics : public IInspectable
                    {
                    public:
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateFill(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasCachedGeometry * * cachedGeometry
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreateFillWithFlatteningTolerance(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                            /* [in] */FLOAT flatteningTolerance,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasCachedGeometry * * cachedGeometry
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateStroke(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                            /* [in] */FLOAT strokeWidth,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasCachedGeometry * * cachedGeometry
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateStrokeWithStrokeStyle(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                            /* [in] */FLOAT strokeWidth,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasCachedGeometry * * cachedGeometry
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreateStrokeWithStrokeStyleAndFlatteningTolerance(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry,
                            /* [in] */FLOAT strokeWidth,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle,
                            /* [in] */FLOAT flatteningTolerance,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasCachedGeometry * * cachedGeometry
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasCachedGeometryStatics=__uuidof(ICanvasCachedGeometryStatics);
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasGeometry
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasGeometry
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasGeometry[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasGeometry";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [object, version, uuid("74EA89FA-C87C-4D0D-9057-2743B8DB67EE"), exclusiveto] */
                    MIDL_INTERFACE("74EA89FA-C87C-4D0D-9057-2743B8DB67EE")
                    ICanvasGeometry : public IInspectable
                    {
                    public:
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE CombineWith(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * otherGeometry,
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 otherGeometryTransform,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasGeometryCombine combine,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CombineWithUsingFlatteningTolerance(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * otherGeometry,
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 otherGeometryTransform,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasGeometryCombine combine,
                            /* [in] */FLOAT flatteningTolerance,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE Stroke(
                            /* [in] */FLOAT strokeWidth,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE StrokeWithStrokeStyle(
                            /* [in] */FLOAT strokeWidth,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE StrokeWithAllOptions(
                            /* [in] */FLOAT strokeWidth,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle,
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                            /* [in] */FLOAT flatteningTolerance,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE Outline(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE OutlineWithTransformAndFlatteningTolerance(
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                            /* [in] */FLOAT flatteningTolerance,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE Simplify(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasGeometrySimplification simplification,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE SimplifyWithTransformAndFlatteningTolerance(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasGeometrySimplification simplification,
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                            /* [in] */FLOAT flatteningTolerance,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE Transform(
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE CompareWith(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * otherGeometry,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasGeometryRelation * relation
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CompareWithUsingTransformAndFlatteningTolerance(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * otherGeometry,
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 otherGeometryTransform,
                            /* [in] */FLOAT flatteningTolerance,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasGeometryRelation * relation
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE ComputeArea(
                            /* [retval, out] */FLOAT * area
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE ComputeAreaWithTransformAndFlatteningTolerance(
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                            /* [in] */FLOAT flatteningTolerance,
                            /* [retval, out] */FLOAT * area
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE ComputePathLength(
                            /* [retval, out] */FLOAT * length
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE ComputePathLengthWithTransformAndFlatteningTolerance(
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                            /* [in] */FLOAT flatteningTolerance,
                            /* [retval, out] */FLOAT * length
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE ComputePointOnPath(
                            /* [in] */FLOAT distance,
                            /* [retval, out] */ABI::Windows::Foundation::Numerics::Vector2 * point
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE ComputePointOnPathWithTangent(
                            /* [in] */FLOAT distance,
                            /* [out] */ABI::Windows::Foundation::Numerics::Vector2 * tangent,
                            /* [retval, out] */ABI::Windows::Foundation::Numerics::Vector2 * point
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE ComputePointOnPathWithTransformAndFlatteningToleranceAndTangent(
                            /* [in] */FLOAT length,
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                            /* [in] */FLOAT flatteningTolerance,
                            /* [out] */ABI::Windows::Foundation::Numerics::Vector2 * tangent,
                            /* [retval, out] */ABI::Windows::Foundation::Numerics::Vector2 * point
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE FillContainsPoint(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                            /* [retval, out] */::boolean * containsPoint
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE FillContainsPointWithTransformAndFlatteningTolerance(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                            /* [in] */FLOAT flatteningTolerance,
                            /* [retval, out] */::boolean * containsPoint
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE ComputeBounds(
                            /* [retval, out] */ABI::Windows::Foundation::Rect * bounds
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE ComputeBoundsWithTransform(
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                            /* [retval, out] */ABI::Windows::Foundation::Rect * bounds
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE ComputeStrokeBounds(
                            /* [in] */FLOAT strokeWidth,
                            /* [retval, out] */ABI::Windows::Foundation::Rect * bounds
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE ComputeStrokeBoundsWithStrokeStyle(
                            /* [in] */FLOAT strokeWidth,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle,
                            /* [retval, out] */ABI::Windows::Foundation::Rect * bounds
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE ComputeStrokeBoundsWithAllOptions(
                            /* [in] */FLOAT strokeWidth,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle,
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                            /* [in] */FLOAT flatteningTolerance,
                            /* [retval, out] */ABI::Windows::Foundation::Rect * bounds
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE StrokeContainsPoint(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                            /* [in] */FLOAT strokeWidth,
                            /* [retval, out] */::boolean * containsPoint
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE StrokeContainsPointWithStrokeStyle(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                            /* [in] */FLOAT strokeWidth,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle,
                            /* [retval, out] */::boolean * containsPoint
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE StrokeContainsPointWithAllOptions(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                            /* [in] */FLOAT strokeWidth,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasStrokeStyle * strokeStyle,
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                            /* [in] */FLOAT flatteningTolerance,
                            /* [retval, out] */::boolean * containsPoint
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE Tessellate(
                            /* [out] */UINT32 * __trianglesSize,
                            /* [size_is(, *(__trianglesSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasTriangleVertices * * triangles
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE TessellateWithTransformAndFlatteningTolerance(
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                            /* [in] */FLOAT flatteningTolerance,
                            /* [out] */UINT32 * __trianglesSize,
                            /* [size_is(, *(__trianglesSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasTriangleVertices * * triangles
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SendPathTo(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasPathReceiver * streamReader
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Device(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasGeometry=__uuidof(ICanvasGeometry);
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasGeometryStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasGeometry
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasGeometryStatics[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasGeometryStatics";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [object, version, uuid("D94E33CF-CD59-46F2-8DF4-55066AABFD56"), exclusiveto] */
                    MIDL_INTERFACE("D94E33CF-CD59-46F2-8DF4-55066AABFD56")
                    ICanvasGeometryStatics : public IInspectable
                    {
                    public:
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreateRectangle(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [in] */ABI::Windows::Foundation::Rect rect,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateRectangleAtCoords(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [in] */FLOAT x,
                            /* [in] */FLOAT y,
                            /* [in] */FLOAT w,
                            /* [in] */FLOAT h,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreateRoundedRectangle(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [in] */ABI::Windows::Foundation::Rect rect,
                            /* [in] */FLOAT radiusX,
                            /* [in] */FLOAT radiusY,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateRoundedRectangleAtCoords(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [in] */FLOAT x,
                            /* [in] */FLOAT y,
                            /* [in] */FLOAT w,
                            /* [in] */FLOAT h,
                            /* [in] */FLOAT radiusX,
                            /* [in] */FLOAT radiusY,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreateEllipse(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                            /* [in] */FLOAT radiusX,
                            /* [in] */FLOAT radiusY,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateEllipseAtCoords(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [in] */FLOAT x,
                            /* [in] */FLOAT y,
                            /* [in] */FLOAT radiusX,
                            /* [in] */FLOAT radiusY,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreateCircle(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                            /* [in] */FLOAT radius,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateCircleAtCoords(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [in] */FLOAT x,
                            /* [in] */FLOAT y,
                            /* [in] */FLOAT radius,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE CreatePath(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasPathBuilder * pathBuilder,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE CreatePolygon(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [in] */UINT32 __pointsSize,
                            /* [size_is(__pointsSize), in] */ABI::Windows::Foundation::Numerics::Vector2 * points,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE CreateGroup(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [in] */UINT32 __geometriesSize,
                            /* [size_is(__geometriesSize), in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometries,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE CreateGroupWithFilledRegionDetermination(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [in] */UINT32 __geometriesSize,
                            /* [size_is(__geometriesSize), in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometries,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasFilledRegionDetermination filledRegionDetermination,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE CreateText(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasTextLayout * textLayout,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE CreateGlyphRun(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 point,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::ICanvasFontFace * fontFace,
                            /* [in] */FLOAT fontSize,
                            /* [in] */UINT32 __glyphsSize,
                            /* [size_is(__glyphsSize), in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyph * glyphs,
                            /* [in] */::boolean isSideways,
                            /* [in] */UINT32 bidiLevel,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasTextMeasuringMode measuringMode,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Text::CanvasGlyphOrientation glyphOrientation,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * * geometry
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE ComputeFlatteningTolerance(
                            /* [in] */FLOAT dpi,
                            /* [in] */FLOAT maximumZoomFactor,
                            /* [retval, out] */FLOAT * flatteningTolerance
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE ComputeFlatteningToleranceWithTransform(
                            /* [in] */FLOAT dpi,
                            /* [in] */FLOAT maximumZoomFactor,
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 expectedGeometryTransform,
                            /* [retval, out] */FLOAT * flatteningTolerance
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_DefaultFlatteningTolerance(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasGeometryStatics=__uuidof(ICanvasGeometryStatics);
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasGradientMesh
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasGradientMesh
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasGradientMesh[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasGradientMesh";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [object, version, uuid("6BFC2BF1-0A7A-449C-A7EF-6706321B0C1A"), exclusiveto] */
                    MIDL_INTERFACE("6BFC2BF1-0A7A-449C-A7EF-6706321B0C1A")
                    ICanvasGradientMesh : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Patches(
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasGradientMeshPatch * * valueElements
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetBounds(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [retval, out] */ABI::Windows::Foundation::Rect * bounds
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE GetBoundsWithTransform(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [in] */ABI::Windows::Foundation::Numerics::Matrix3x2 transform,
                            /* [retval, out] */ABI::Windows::Foundation::Rect * bounds
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_Device(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::ICanvasDevice * * value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasGradientMesh=__uuidof(ICanvasGradientMesh);
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasGradientMeshFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasGradientMesh
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasGradientMeshFactory[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasGradientMeshFactory";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [object, version, uuid("4756492D-251E-421D-834D-87EC260D5E4D"), exclusiveto] */
                    MIDL_INTERFACE("4756492D-251E-421D-834D-87EC260D5E4D")
                    ICanvasGradientMeshFactory : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE Create(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [in] */UINT32 __patchElementsSize,
                            /* [size_is(__patchElementsSize), in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasGradientMeshPatch * patchElements,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGradientMesh * * canvasGradientMesh
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasGradientMeshFactory=__uuidof(ICanvasGradientMeshFactory);
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasGradientMeshStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasGradientMesh
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasGradientMeshStatics[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasGradientMeshStatics";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [object, version, uuid("44027640-3EAB-4199-AA3B-644890D0123D"), exclusiveto] */
                    MIDL_INTERFACE("44027640-3EAB-4199-AA3B-644890D0123D")
                    ICanvasGradientMeshStatics : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE CreateCoonsPatch(
                            /* [in] */UINT32 __pointsSize,
                            /* [size_is(__pointsSize), in] */ABI::Windows::Foundation::Numerics::Vector2 * points,
                            /* [in] */UINT32 __colorsSize,
                            /* [size_is(__colorsSize), in] */ABI::Windows::Foundation::Numerics::Vector4 * colors,
                            /* [in] */UINT32 __edgesSize,
                            /* [size_is(__edgesSize), in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasGradientMeshPatchEdge * edges,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasGradientMeshPatch * gradientMeshPatch
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE CreateTensorPatch(
                            /* [in] */UINT32 __pointsSize,
                            /* [size_is(__pointsSize), in] */ABI::Windows::Foundation::Numerics::Vector2 * points,
                            /* [in] */UINT32 __colorsSize,
                            /* [size_is(__colorsSize), in] */ABI::Windows::Foundation::Numerics::Vector4 * colors,
                            /* [in] */UINT32 __edgesSize,
                            /* [size_is(__edgesSize), in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasGradientMeshPatchEdge * edges,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasGradientMeshPatch * gradientMeshPatch
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasGradientMeshStatics=__uuidof(ICanvasGradientMeshStatics);
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasPathBuilder
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasPathBuilder
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasPathBuilder[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasPathBuilder";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [object, version, uuid("BCF5822F-8127-4E5C-96B8-29983B915541"), exclusiveto] */
                    MIDL_INTERFACE("BCF5822F-8127-4E5C-96B8-29983B915541")
                    ICanvasPathBuilder : public IInspectable
                    {
                    public:
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE BeginFigureWithFigureFill(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 startPoint,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasFigureFill figureFill
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE BeginFigure(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 startPoint
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE BeginFigureAtCoordsWithFigureFill(
                            /* [in] */FLOAT startX,
                            /* [in] */FLOAT startY,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasFigureFill figureFill
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE BeginFigureAtCoords(
                            /* [in] */FLOAT startX,
                            /* [in] */FLOAT startY
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE AddArcToPoint(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 endPoint,
                            /* [in] */FLOAT radiusX,
                            /* [in] */FLOAT radiusY,
                            /* [in] */FLOAT rotationAngle,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasSweepDirection sweepDirection,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasArcSize arcSize
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE AddArcAroundEllipse(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 centerPoint,
                            /* [in] */FLOAT radiusX,
                            /* [in] */FLOAT radiusY,
                            /* [in] */FLOAT startAngle,
                            /* [in] */FLOAT sweepAngle
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE AddCubicBezier(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 controlPoint1,
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 controlPoint2,
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 endPoint
                            ) = 0;
                        /* [overload, default_overload] */virtual HRESULT STDMETHODCALLTYPE AddLine(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 endPoint
                            ) = 0;
                        /* [overload] */virtual HRESULT STDMETHODCALLTYPE AddLineWithCoords(
                            /* [in] */FLOAT x,
                            /* [in] */FLOAT y
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE AddQuadraticBezier(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 controlPoint,
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 endPoint
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetFilledRegionDetermination(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasFilledRegionDetermination filledRegionDetermination
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetSegmentOptions(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasFigureSegmentOptions figureSegmentOptions
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE EndFigure(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasFigureLoop figureLoop
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE AddGeometry(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasGeometry * geometry
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasPathBuilder=__uuidof(ICanvasPathBuilder);
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasPathBuilderFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasPathBuilder
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasPathBuilderFactory[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasPathBuilderFactory";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [object, version, uuid("AC2BEE14-EFD1-4343-8E53-BA62153D8966"), exclusiveto] */
                    MIDL_INTERFACE("AC2BEE14-EFD1-4343-8E53-BA62153D8966")
                    ICanvasPathBuilderFactory : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE Create(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::ICanvasResourceCreator * resourceCreator,
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::ICanvasPathBuilder * * canvasPathBuilder
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasPathBuilderFactory=__uuidof(ICanvasPathBuilderFactory);
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasPathReceiver
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasPathReceiver[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasPathReceiver";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [object, version, uuid("70E65373-7FB3-4645-8B6D-F616D1B9A9D7")] */
                    MIDL_INTERFACE("70E65373-7FB3-4645-8B6D-F616D1B9A9D7")
                    ICanvasPathReceiver : public IInspectable
                    {
                    public:
                        virtual HRESULT STDMETHODCALLTYPE BeginFigure(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 startPoint,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasFigureFill figureFill
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE AddArc(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 endPoint,
                            /* [in] */FLOAT radiusX,
                            /* [in] */FLOAT radiusY,
                            /* [in] */FLOAT rotationAngle,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasSweepDirection sweepDirection,
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasArcSize arcSize
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE AddCubicBezier(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 controlPoint1,
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 controlPoint2,
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 endPoint
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE AddLine(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 endPoint
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE AddQuadraticBezier(
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 controlPoint,
                            /* [in] */ABI::Windows::Foundation::Numerics::Vector2 endPoint
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetFilledRegionDetermination(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasFilledRegionDetermination filledRegionDetermination
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE SetSegmentOptions(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasFigureSegmentOptions figureSegmentOptions
                            ) = 0;
                        virtual HRESULT STDMETHODCALLTYPE EndFigure(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasFigureLoop figureLoop
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasPathReceiver=__uuidof(ICanvasPathReceiver);
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasStrokeStyle
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasStrokeStyle
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasStrokeStyle[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasStrokeStyle";
namespace ABI {
    namespace Microsoft {
        namespace Graphics {
            namespace Canvas {
                namespace Geometry {
                    /* [object, version, uuid("FD3E1CD2-6019-40A1-B315-267EEF6C2AEB"), exclusiveto] */
                    MIDL_INTERFACE("FD3E1CD2-6019-40A1-B315-267EEF6C2AEB")
                    ICanvasStrokeStyle : public IInspectable
                    {
                    public:
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_StartCap(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasCapStyle * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_StartCap(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasCapStyle value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_EndCap(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasCapStyle * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_EndCap(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasCapStyle value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_DashCap(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasCapStyle * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_DashCap(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasCapStyle value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_LineJoin(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasLineJoin * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_LineJoin(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasLineJoin value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_MiterLimit(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_MiterLimit(
                            /* [in] */FLOAT value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_DashStyle(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasDashStyle * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_DashStyle(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasDashStyle value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_DashOffset(
                            /* [retval, out] */FLOAT * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_DashOffset(
                            /* [in] */FLOAT value
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_CustomDashStyle(
                            /* [out] */UINT32 * __valueElementsSize,
                            /* [size_is(, *(__valueElementsSize)), retval, out] */FLOAT * * valueElements
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_CustomDashStyle(
                            /* [in] */UINT32 __valueElementsSize,
                            /* [size_is(__valueElementsSize), in] */FLOAT * valueElements
                            ) = 0;
                        /* [propget] */virtual HRESULT STDMETHODCALLTYPE get_TransformBehavior(
                            /* [retval, out] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasStrokeTransformBehavior * value
                            ) = 0;
                        /* [propput] */virtual HRESULT STDMETHODCALLTYPE put_TransformBehavior(
                            /* [in] */ABI::Microsoft::Graphics::Canvas::Geometry::CanvasStrokeTransformBehavior value
                            ) = 0;
                        
                    };

                    MIDL_CONST_ID IID & IID_ICanvasStrokeStyle=__uuidof(ICanvasStrokeStyle);
                    
                } /* Geometry */
            } /* Canvas */
        } /* Graphics */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_INTERFACE_DEFINED__) */


/*
 *
 * Class Microsoft.Graphics.Canvas.Geometry.CanvasCachedGeometry
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Geometry.ICanvasCachedGeometry ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasCachedGeometry_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasCachedGeometry_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Geometry_CanvasCachedGeometry[] = L"Microsoft.Graphics.Canvas.Geometry.CanvasCachedGeometry";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Geometry.CanvasGeometry
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Geometry.ICanvasGeometry ** Default Interface **
 *    Windows.Foundation.IClosable
 *    Windows.Graphics.IGeometrySource2D
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasGeometry_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasGeometry_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Geometry_CanvasGeometry[] = L"Microsoft.Graphics.Canvas.Geometry.CanvasGeometry";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Geometry.CanvasGradientMesh
 *
 * RuntimeClass can be activated.
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Geometry.ICanvasGradientMesh ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasGradientMesh_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasGradientMesh_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Geometry_CanvasGradientMesh[] = L"Microsoft.Graphics.Canvas.Geometry.CanvasGradientMesh";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Geometry.CanvasPathBuilder
 *
 * RuntimeClass can be activated.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Geometry.ICanvasPathBuilder ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasPathBuilder_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasPathBuilder_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Geometry_CanvasPathBuilder[] = L"Microsoft.Graphics.Canvas.Geometry.CanvasPathBuilder";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Geometry.CanvasStrokeStyle
 *
 * RuntimeClass can be activated.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Geometry.ICanvasStrokeStyle ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasStrokeStyle_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasStrokeStyle_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Geometry_CanvasStrokeStyle[] = L"Microsoft.Graphics.Canvas.Geometry.CanvasStrokeStyle";
#endif





#else // !defined(__cplusplus)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_FWD_DEFINED__

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice_FWD_DEFINED__


#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator __x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator_FWD_DEFINED__





#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace_FWD_DEFINED__



typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphOrientation __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphOrientation;

#ifndef ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout;

#endif // ____x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout_FWD_DEFINED__



typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextMeasuringMode __x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextMeasuringMode;





#ifndef ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
#define ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CFoundation_CIClosable __x_ABI_CWindows_CFoundation_CIClosable;

#endif // ____x_ABI_CWindows_CFoundation_CIClosable_FWD_DEFINED__





typedef struct __x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 __x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2;


typedef struct __x_ABI_CWindows_CFoundation_CNumerics_CVector2 __x_ABI_CWindows_CFoundation_CNumerics_CVector2;


typedef struct __x_ABI_CWindows_CFoundation_CNumerics_CVector4 __x_ABI_CWindows_CFoundation_CNumerics_CVector4;





typedef struct __x_ABI_CWindows_CFoundation_CRect __x_ABI_CWindows_CFoundation_CRect;



#ifndef ____x_ABI_CWindows_CGraphics_CIGeometrySource2D_FWD_DEFINED__
#define ____x_ABI_CWindows_CGraphics_CIGeometrySource2D_FWD_DEFINED__
typedef interface __x_ABI_CWindows_CGraphics_CIGeometrySource2D __x_ABI_CWindows_CGraphics_CIGeometrySource2D;

#endif // ____x_ABI_CWindows_CGraphics_CIGeometrySource2D_FWD_DEFINED__





typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasArcSize __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasArcSize;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasCapStyle __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasCapStyle;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasDashStyle __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasDashStyle;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFigureFill __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFigureFill;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFigureLoop __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFigureLoop;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFigureSegmentOptions __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFigureSegmentOptions;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFilledRegionDetermination __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFilledRegionDetermination;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGeometryCombine __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGeometryCombine;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGeometryRelation __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGeometryRelation;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGeometrySimplification __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGeometrySimplification;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGradientMeshPatchEdge __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGradientMeshPatchEdge;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasLineJoin __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasLineJoin;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasStrokeTransformBehavior __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasStrokeTransformBehavior;


typedef enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasSweepDirection __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasSweepDirection;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGradientMeshPatch __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGradientMeshPatch;


typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasTriangleVertices __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasTriangleVertices;






















/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasArcSize
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasArcSize
{
    CanvasArcSize_Small = 0,
    CanvasArcSize_Large = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasCapStyle
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasCapStyle
{
    CanvasCapStyle_Flat = 0,
    CanvasCapStyle_Square = 1,
    CanvasCapStyle_Round = 2,
    CanvasCapStyle_Triangle = 3,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasDashStyle
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasDashStyle
{
    CanvasDashStyle_Solid = 0,
    CanvasDashStyle_Dash = 1,
    CanvasDashStyle_Dot = 2,
    CanvasDashStyle_DashDot = 3,
    CanvasDashStyle_DashDotDot = 4,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasFigureFill
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFigureFill
{
    CanvasFigureFill_Default = 0,
    CanvasFigureFill_DoesNotAffectFills = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasFigureLoop
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFigureLoop
{
    CanvasFigureLoop_Open = 0,
    CanvasFigureLoop_Closed = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasFigureSegmentOptions
 *
 */

/* [v1_enum, version, flags] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFigureSegmentOptions
{
    CanvasFigureSegmentOptions_None = 0,
    CanvasFigureSegmentOptions_ForceUnstroked = 0x1,
    CanvasFigureSegmentOptions_ForceRoundLineJoin = 0x2,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasFilledRegionDetermination
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFilledRegionDetermination
{
    CanvasFilledRegionDetermination_Alternate = 0,
    CanvasFilledRegionDetermination_Winding = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasGeometryCombine
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGeometryCombine
{
    CanvasGeometryCombine_Union = 0,
    CanvasGeometryCombine_Intersect = 1,
    CanvasGeometryCombine_Xor = 2,
    CanvasGeometryCombine_Exclude = 3,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasGeometryRelation
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGeometryRelation
{
    CanvasGeometryRelation_Disjoint = 0,
    CanvasGeometryRelation_Contained = 1,
    CanvasGeometryRelation_Contains = 2,
    CanvasGeometryRelation_Overlap = 3,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasGeometrySimplification
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGeometrySimplification
{
    CanvasGeometrySimplification_CubicsAndLines = 0,
    CanvasGeometrySimplification_Lines = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasGradientMeshPatchEdge
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGradientMeshPatchEdge
{
    CanvasGradientMeshPatchEdge_Aliased = 0,
    CanvasGradientMeshPatchEdge_Antialiased = 1,
    CanvasGradientMeshPatchEdge_AliasedAndInflated = 2,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasLineJoin
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasLineJoin
{
    CanvasLineJoin_Miter = 0,
    CanvasLineJoin_Bevel = 1,
    CanvasLineJoin_Round = 2,
    CanvasLineJoin_MiterOrBevel = 3,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasStrokeTransformBehavior
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasStrokeTransformBehavior
{
    CanvasStrokeTransformBehavior_Normal = 0,
    CanvasStrokeTransformBehavior_Fixed = 1,
    CanvasStrokeTransformBehavior_Hairline = 2,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasSweepDirection
 *
 */

/* [v1_enum, version] */
enum __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasSweepDirection
{
    CanvasSweepDirection_CounterClockwise = 0,
    CanvasSweepDirection_Clockwise = 1,
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasGradientMeshPatch
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGradientMeshPatch
{
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Point00;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Point01;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Point02;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Point03;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Point10;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Point11;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Point12;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Point13;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Point20;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Point21;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Point22;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Point23;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Point30;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Point31;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Point32;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Point33;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector4 Color00;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector4 Color03;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector4 Color30;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector4 Color33;
    __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGradientMeshPatchEdge Edge00To03;
    __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGradientMeshPatchEdge Edge03To33;
    __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGradientMeshPatchEdge Edge33To30;
    __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGradientMeshPatchEdge Edge30To00;
};


/*
 *
 * Struct Microsoft.Graphics.Canvas.Geometry.CanvasTriangleVertices
 *
 */

/* [version] */
struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasTriangleVertices
{
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Vertex1;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Vertex2;
    __x_ABI_CWindows_CFoundation_CNumerics_CVector2 Vertex3;
};


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasCachedGeometry
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasCachedGeometry
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasCachedGeometry[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasCachedGeometry";
/* [object, version, uuid("BA6CB114-E1A1-448D-AB7C-8D2B92674119"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Device )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_get_Device(This,value) \
    ( (This)->lpVtbl->get_Device(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasCachedGeometryStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasCachedGeometry
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasCachedGeometryStatics[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasCachedGeometryStatics";
/* [object, version, uuid("80BA1060-A9D7-41BA-9372-EC3FC1744E5D"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateFill )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * * cachedGeometry
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreateFillWithFlatteningTolerance )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */FLOAT flatteningTolerance,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * * cachedGeometry
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateStroke )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */FLOAT strokeWidth,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * * cachedGeometry
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateStrokeWithStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * * cachedGeometry
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreateStrokeWithStrokeStyleAndFlatteningTolerance )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle,
        /* [in] */FLOAT flatteningTolerance,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometry * * cachedGeometry
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStaticsVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_CreateFill(This,geometry,cachedGeometry) \
    ( (This)->lpVtbl->CreateFill(This,geometry,cachedGeometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_CreateFillWithFlatteningTolerance(This,geometry,flatteningTolerance,cachedGeometry) \
    ( (This)->lpVtbl->CreateFillWithFlatteningTolerance(This,geometry,flatteningTolerance,cachedGeometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_CreateStroke(This,geometry,strokeWidth,cachedGeometry) \
    ( (This)->lpVtbl->CreateStroke(This,geometry,strokeWidth,cachedGeometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_CreateStrokeWithStrokeStyle(This,geometry,strokeWidth,strokeStyle,cachedGeometry) \
    ( (This)->lpVtbl->CreateStrokeWithStrokeStyle(This,geometry,strokeWidth,strokeStyle,cachedGeometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_CreateStrokeWithStrokeStyleAndFlatteningTolerance(This,geometry,strokeWidth,strokeStyle,flatteningTolerance,cachedGeometry) \
    ( (This)->lpVtbl->CreateStrokeWithStrokeStyleAndFlatteningTolerance(This,geometry,strokeWidth,strokeStyle,flatteningTolerance,cachedGeometry) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasCachedGeometryStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasGeometry
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasGeometry
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasGeometry[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasGeometry";
/* [object, version, uuid("74EA89FA-C87C-4D0D-9057-2743B8DB67EE"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload] */HRESULT ( STDMETHODCALLTYPE *CombineWith )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * otherGeometry,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 otherGeometryTransform,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGeometryCombine combine,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CombineWithUsingFlatteningTolerance )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * otherGeometry,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 otherGeometryTransform,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGeometryCombine combine,
        /* [in] */FLOAT flatteningTolerance,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *Stroke )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */FLOAT strokeWidth,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *StrokeWithStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *StrokeWithAllOptions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */FLOAT flatteningTolerance,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *Outline )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *OutlineWithTransformAndFlatteningTolerance )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */FLOAT flatteningTolerance,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *Simplify )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGeometrySimplification simplification,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *SimplifyWithTransformAndFlatteningTolerance )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGeometrySimplification simplification,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */FLOAT flatteningTolerance,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    HRESULT ( STDMETHODCALLTYPE *Transform )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CompareWith )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * otherGeometry,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGeometryRelation * relation
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CompareWithUsingTransformAndFlatteningTolerance )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * otherGeometry,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 otherGeometryTransform,
        /* [in] */FLOAT flatteningTolerance,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGeometryRelation * relation
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *ComputeArea )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [retval, out] */FLOAT * area
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *ComputeAreaWithTransformAndFlatteningTolerance )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */FLOAT flatteningTolerance,
        /* [retval, out] */FLOAT * area
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *ComputePathLength )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [retval, out] */FLOAT * length
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *ComputePathLengthWithTransformAndFlatteningTolerance )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */FLOAT flatteningTolerance,
        /* [retval, out] */FLOAT * length
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *ComputePointOnPath )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */FLOAT distance,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 * point
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *ComputePointOnPathWithTangent )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */FLOAT distance,
        /* [out] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 * tangent,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 * point
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *ComputePointOnPathWithTransformAndFlatteningToleranceAndTangent )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */FLOAT length,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */FLOAT flatteningTolerance,
        /* [out] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 * tangent,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 * point
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FillContainsPoint )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [retval, out] */boolean * containsPoint
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *FillContainsPointWithTransformAndFlatteningTolerance )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */FLOAT flatteningTolerance,
        /* [retval, out] */boolean * containsPoint
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *ComputeBounds )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * bounds
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *ComputeBoundsWithTransform )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * bounds
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *ComputeStrokeBounds )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */FLOAT strokeWidth,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * bounds
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *ComputeStrokeBoundsWithStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * bounds
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *ComputeStrokeBoundsWithAllOptions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */FLOAT flatteningTolerance,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * bounds
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *StrokeContainsPoint )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */FLOAT strokeWidth,
        /* [retval, out] */boolean * containsPoint
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *StrokeContainsPointWithStrokeStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle,
        /* [retval, out] */boolean * containsPoint
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *StrokeContainsPointWithAllOptions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */FLOAT strokeWidth,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * strokeStyle,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */FLOAT flatteningTolerance,
        /* [retval, out] */boolean * containsPoint
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *Tessellate )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [out] */UINT32 * __trianglesSize,
        /* [size_is(, *(__trianglesSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasTriangleVertices * * triangles
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *TessellateWithTransformAndFlatteningTolerance )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [in] */FLOAT flatteningTolerance,
        /* [out] */UINT32 * __trianglesSize,
        /* [size_is(, *(__trianglesSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasTriangleVertices * * triangles
        );
    HRESULT ( STDMETHODCALLTYPE *SendPathTo )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver * streamReader
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Device )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_CombineWith(This,otherGeometry,otherGeometryTransform,combine,geometry) \
    ( (This)->lpVtbl->CombineWith(This,otherGeometry,otherGeometryTransform,combine,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_CombineWithUsingFlatteningTolerance(This,otherGeometry,otherGeometryTransform,combine,flatteningTolerance,geometry) \
    ( (This)->lpVtbl->CombineWithUsingFlatteningTolerance(This,otherGeometry,otherGeometryTransform,combine,flatteningTolerance,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_Stroke(This,strokeWidth,geometry) \
    ( (This)->lpVtbl->Stroke(This,strokeWidth,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_StrokeWithStrokeStyle(This,strokeWidth,strokeStyle,geometry) \
    ( (This)->lpVtbl->StrokeWithStrokeStyle(This,strokeWidth,strokeStyle,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_StrokeWithAllOptions(This,strokeWidth,strokeStyle,transform,flatteningTolerance,geometry) \
    ( (This)->lpVtbl->StrokeWithAllOptions(This,strokeWidth,strokeStyle,transform,flatteningTolerance,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_Outline(This,geometry) \
    ( (This)->lpVtbl->Outline(This,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_OutlineWithTransformAndFlatteningTolerance(This,transform,flatteningTolerance,geometry) \
    ( (This)->lpVtbl->OutlineWithTransformAndFlatteningTolerance(This,transform,flatteningTolerance,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_Simplify(This,simplification,geometry) \
    ( (This)->lpVtbl->Simplify(This,simplification,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_SimplifyWithTransformAndFlatteningTolerance(This,simplification,transform,flatteningTolerance,geometry) \
    ( (This)->lpVtbl->SimplifyWithTransformAndFlatteningTolerance(This,simplification,transform,flatteningTolerance,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_Transform(This,transform,geometry) \
    ( (This)->lpVtbl->Transform(This,transform,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_CompareWith(This,otherGeometry,relation) \
    ( (This)->lpVtbl->CompareWith(This,otherGeometry,relation) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_CompareWithUsingTransformAndFlatteningTolerance(This,otherGeometry,otherGeometryTransform,flatteningTolerance,relation) \
    ( (This)->lpVtbl->CompareWithUsingTransformAndFlatteningTolerance(This,otherGeometry,otherGeometryTransform,flatteningTolerance,relation) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_ComputeArea(This,area) \
    ( (This)->lpVtbl->ComputeArea(This,area) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_ComputeAreaWithTransformAndFlatteningTolerance(This,transform,flatteningTolerance,area) \
    ( (This)->lpVtbl->ComputeAreaWithTransformAndFlatteningTolerance(This,transform,flatteningTolerance,area) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_ComputePathLength(This,length) \
    ( (This)->lpVtbl->ComputePathLength(This,length) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_ComputePathLengthWithTransformAndFlatteningTolerance(This,transform,flatteningTolerance,length) \
    ( (This)->lpVtbl->ComputePathLengthWithTransformAndFlatteningTolerance(This,transform,flatteningTolerance,length) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_ComputePointOnPath(This,distance,point) \
    ( (This)->lpVtbl->ComputePointOnPath(This,distance,point) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_ComputePointOnPathWithTangent(This,distance,tangent,point) \
    ( (This)->lpVtbl->ComputePointOnPathWithTangent(This,distance,tangent,point) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_ComputePointOnPathWithTransformAndFlatteningToleranceAndTangent(This,length,transform,flatteningTolerance,tangent,point) \
    ( (This)->lpVtbl->ComputePointOnPathWithTransformAndFlatteningToleranceAndTangent(This,length,transform,flatteningTolerance,tangent,point) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FillContainsPoint(This,point,containsPoint) \
    ( (This)->lpVtbl->FillContainsPoint(This,point,containsPoint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_FillContainsPointWithTransformAndFlatteningTolerance(This,point,transform,flatteningTolerance,containsPoint) \
    ( (This)->lpVtbl->FillContainsPointWithTransformAndFlatteningTolerance(This,point,transform,flatteningTolerance,containsPoint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_ComputeBounds(This,bounds) \
    ( (This)->lpVtbl->ComputeBounds(This,bounds) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_ComputeBoundsWithTransform(This,transform,bounds) \
    ( (This)->lpVtbl->ComputeBoundsWithTransform(This,transform,bounds) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_ComputeStrokeBounds(This,strokeWidth,bounds) \
    ( (This)->lpVtbl->ComputeStrokeBounds(This,strokeWidth,bounds) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_ComputeStrokeBoundsWithStrokeStyle(This,strokeWidth,strokeStyle,bounds) \
    ( (This)->lpVtbl->ComputeStrokeBoundsWithStrokeStyle(This,strokeWidth,strokeStyle,bounds) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_ComputeStrokeBoundsWithAllOptions(This,strokeWidth,strokeStyle,transform,flatteningTolerance,bounds) \
    ( (This)->lpVtbl->ComputeStrokeBoundsWithAllOptions(This,strokeWidth,strokeStyle,transform,flatteningTolerance,bounds) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_StrokeContainsPoint(This,point,strokeWidth,containsPoint) \
    ( (This)->lpVtbl->StrokeContainsPoint(This,point,strokeWidth,containsPoint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_StrokeContainsPointWithStrokeStyle(This,point,strokeWidth,strokeStyle,containsPoint) \
    ( (This)->lpVtbl->StrokeContainsPointWithStrokeStyle(This,point,strokeWidth,strokeStyle,containsPoint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_StrokeContainsPointWithAllOptions(This,point,strokeWidth,strokeStyle,transform,flatteningTolerance,containsPoint) \
    ( (This)->lpVtbl->StrokeContainsPointWithAllOptions(This,point,strokeWidth,strokeStyle,transform,flatteningTolerance,containsPoint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_Tessellate(This,__trianglesSize,triangles) \
    ( (This)->lpVtbl->Tessellate(This,__trianglesSize,triangles) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_TessellateWithTransformAndFlatteningTolerance(This,transform,flatteningTolerance,__trianglesSize,triangles) \
    ( (This)->lpVtbl->TessellateWithTransformAndFlatteningTolerance(This,transform,flatteningTolerance,__trianglesSize,triangles) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_SendPathTo(This,streamReader) \
    ( (This)->lpVtbl->SendPathTo(This,streamReader) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_get_Device(This,value) \
    ( (This)->lpVtbl->get_Device(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasGeometryStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasGeometry
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasGeometryStatics[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasGeometryStatics";
/* [object, version, uuid("D94E33CF-CD59-46F2-8DF4-55066AABFD56"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreateRectangle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateRectangleAtCoords )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreateRoundedRectangle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CFoundation_CRect rect,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateRoundedRectangleAtCoords )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT w,
        /* [in] */FLOAT h,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreateEllipse )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateEllipseAtCoords )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreateCircle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radius,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateCircleAtCoords )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y,
        /* [in] */FLOAT radius,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    HRESULT ( STDMETHODCALLTYPE *CreatePath )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * pathBuilder,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    HRESULT ( STDMETHODCALLTYPE *CreatePolygon )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */UINT32 __pointsSize,
        /* [size_is(__pointsSize), in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 * points,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *CreateGroup )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */UINT32 __geometriesSize,
        /* [size_is(__geometriesSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometries,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *CreateGroupWithFilledRegionDetermination )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */UINT32 __geometriesSize,
        /* [size_is(__geometriesSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometries,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFilledRegionDetermination filledRegionDetermination,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    HRESULT ( STDMETHODCALLTYPE *CreateText )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasTextLayout * textLayout,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    HRESULT ( STDMETHODCALLTYPE *CreateGlyphRun )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 point,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CICanvasFontFace * fontFace,
        /* [in] */FLOAT fontSize,
        /* [in] */UINT32 __glyphsSize,
        /* [size_is(__glyphsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyph * glyphs,
        /* [in] */boolean isSideways,
        /* [in] */UINT32 bidiLevel,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasTextMeasuringMode measuringMode,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CText_CCanvasGlyphOrientation glyphOrientation,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * * geometry
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *ComputeFlatteningTolerance )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
        /* [in] */FLOAT dpi,
        /* [in] */FLOAT maximumZoomFactor,
        /* [retval, out] */FLOAT * flatteningTolerance
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *ComputeFlatteningToleranceWithTransform )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
        /* [in] */FLOAT dpi,
        /* [in] */FLOAT maximumZoomFactor,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 expectedGeometryTransform,
        /* [retval, out] */FLOAT * flatteningTolerance
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_DefaultFlatteningTolerance )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics * This,
        /* [retval, out] */FLOAT * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStaticsVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_CreateRectangle(This,resourceCreator,rect,geometry) \
    ( (This)->lpVtbl->CreateRectangle(This,resourceCreator,rect,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_CreateRectangleAtCoords(This,resourceCreator,x,y,w,h,geometry) \
    ( (This)->lpVtbl->CreateRectangleAtCoords(This,resourceCreator,x,y,w,h,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_CreateRoundedRectangle(This,resourceCreator,rect,radiusX,radiusY,geometry) \
    ( (This)->lpVtbl->CreateRoundedRectangle(This,resourceCreator,rect,radiusX,radiusY,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_CreateRoundedRectangleAtCoords(This,resourceCreator,x,y,w,h,radiusX,radiusY,geometry) \
    ( (This)->lpVtbl->CreateRoundedRectangleAtCoords(This,resourceCreator,x,y,w,h,radiusX,radiusY,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_CreateEllipse(This,resourceCreator,centerPoint,radiusX,radiusY,geometry) \
    ( (This)->lpVtbl->CreateEllipse(This,resourceCreator,centerPoint,radiusX,radiusY,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_CreateEllipseAtCoords(This,resourceCreator,x,y,radiusX,radiusY,geometry) \
    ( (This)->lpVtbl->CreateEllipseAtCoords(This,resourceCreator,x,y,radiusX,radiusY,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_CreateCircle(This,resourceCreator,centerPoint,radius,geometry) \
    ( (This)->lpVtbl->CreateCircle(This,resourceCreator,centerPoint,radius,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_CreateCircleAtCoords(This,resourceCreator,x,y,radius,geometry) \
    ( (This)->lpVtbl->CreateCircleAtCoords(This,resourceCreator,x,y,radius,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_CreatePath(This,pathBuilder,geometry) \
    ( (This)->lpVtbl->CreatePath(This,pathBuilder,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_CreatePolygon(This,resourceCreator,__pointsSize,points,geometry) \
    ( (This)->lpVtbl->CreatePolygon(This,resourceCreator,__pointsSize,points,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_CreateGroup(This,resourceCreator,__geometriesSize,geometries,geometry) \
    ( (This)->lpVtbl->CreateGroup(This,resourceCreator,__geometriesSize,geometries,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_CreateGroupWithFilledRegionDetermination(This,resourceCreator,__geometriesSize,geometries,filledRegionDetermination,geometry) \
    ( (This)->lpVtbl->CreateGroupWithFilledRegionDetermination(This,resourceCreator,__geometriesSize,geometries,filledRegionDetermination,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_CreateText(This,textLayout,geometry) \
    ( (This)->lpVtbl->CreateText(This,textLayout,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_CreateGlyphRun(This,resourceCreator,point,fontFace,fontSize,__glyphsSize,glyphs,isSideways,bidiLevel,measuringMode,glyphOrientation,geometry) \
    ( (This)->lpVtbl->CreateGlyphRun(This,resourceCreator,point,fontFace,fontSize,__glyphsSize,glyphs,isSideways,bidiLevel,measuringMode,glyphOrientation,geometry) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_ComputeFlatteningTolerance(This,dpi,maximumZoomFactor,flatteningTolerance) \
    ( (This)->lpVtbl->ComputeFlatteningTolerance(This,dpi,maximumZoomFactor,flatteningTolerance) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_ComputeFlatteningToleranceWithTransform(This,dpi,maximumZoomFactor,expectedGeometryTransform,flatteningTolerance) \
    ( (This)->lpVtbl->ComputeFlatteningToleranceWithTransform(This,dpi,maximumZoomFactor,expectedGeometryTransform,flatteningTolerance) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_get_DefaultFlatteningTolerance(This,value) \
    ( (This)->lpVtbl->get_DefaultFlatteningTolerance(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometryStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasGradientMesh
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasGradientMesh
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasGradientMesh[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasGradientMesh";
/* [object, version, uuid("6BFC2BF1-0A7A-449C-A7EF-6706321B0C1A"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Patches )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh * This,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGradientMeshPatch * * valueElements
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetBounds )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * bounds
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *GetBoundsWithTransform )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CMatrix3x2 transform,
        /* [retval, out] */__x_ABI_CWindows_CFoundation_CRect * bounds
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_Device )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasDevice * * value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_get_Patches(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->get_Patches(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_GetBounds(This,resourceCreator,bounds) \
    ( (This)->lpVtbl->GetBounds(This,resourceCreator,bounds) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_GetBoundsWithTransform(This,resourceCreator,transform,bounds) \
    ( (This)->lpVtbl->GetBoundsWithTransform(This,resourceCreator,transform,bounds) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_get_Device(This,value) \
    ( (This)->lpVtbl->get_Device(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasGradientMeshFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasGradientMesh
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasGradientMeshFactory[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasGradientMeshFactory";
/* [object, version, uuid("4756492D-251E-421D-834D-87EC260D5E4D"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *Create )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [in] */UINT32 __patchElementsSize,
        /* [size_is(__patchElementsSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGradientMeshPatch * patchElements,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMesh * * canvasGradientMesh
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactoryVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_Create(This,resourceCreator,__patchElementsSize,patchElements,canvasGradientMesh) \
    ( (This)->lpVtbl->Create(This,resourceCreator,__patchElementsSize,patchElements,canvasGradientMesh) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasGradientMeshStatics
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasGradientMesh
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasGradientMeshStatics[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasGradientMeshStatics";
/* [object, version, uuid("44027640-3EAB-4199-AA3B-644890D0123D"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *CreateCoonsPatch )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics * This,
        /* [in] */UINT32 __pointsSize,
        /* [size_is(__pointsSize), in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 * points,
        /* [in] */UINT32 __colorsSize,
        /* [size_is(__colorsSize), in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector4 * colors,
        /* [in] */UINT32 __edgesSize,
        /* [size_is(__edgesSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGradientMeshPatchEdge * edges,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGradientMeshPatch * gradientMeshPatch
        );
    HRESULT ( STDMETHODCALLTYPE *CreateTensorPatch )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics * This,
        /* [in] */UINT32 __pointsSize,
        /* [size_is(__pointsSize), in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 * points,
        /* [in] */UINT32 __colorsSize,
        /* [size_is(__colorsSize), in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector4 * colors,
        /* [in] */UINT32 __edgesSize,
        /* [size_is(__edgesSize), in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGradientMeshPatchEdge * edges,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasGradientMeshPatch * gradientMeshPatch
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStaticsVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_CreateCoonsPatch(This,__pointsSize,points,__colorsSize,colors,__edgesSize,edges,gradientMeshPatch) \
    ( (This)->lpVtbl->CreateCoonsPatch(This,__pointsSize,points,__colorsSize,colors,__edgesSize,edges,gradientMeshPatch) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_CreateTensorPatch(This,__pointsSize,points,__colorsSize,colors,__edgesSize,edges,gradientMeshPatch) \
    ( (This)->lpVtbl->CreateTensorPatch(This,__pointsSize,points,__colorsSize,colors,__edgesSize,edges,gradientMeshPatch) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGradientMeshStatics_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasPathBuilder
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasPathBuilder
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasPathBuilder[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasPathBuilder";
/* [object, version, uuid("BCF5822F-8127-4E5C-96B8-29983B915541"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *BeginFigureWithFigureFill )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 startPoint,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFigureFill figureFill
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *BeginFigure )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 startPoint
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *BeginFigureAtCoordsWithFigureFill )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
        /* [in] */FLOAT startX,
        /* [in] */FLOAT startY,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFigureFill figureFill
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *BeginFigureAtCoords )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
        /* [in] */FLOAT startX,
        /* [in] */FLOAT startY
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *AddArcToPoint )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 endPoint,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */FLOAT rotationAngle,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasSweepDirection sweepDirection,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasArcSize arcSize
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *AddArcAroundEllipse )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 centerPoint,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */FLOAT startAngle,
        /* [in] */FLOAT sweepAngle
        );
    HRESULT ( STDMETHODCALLTYPE *AddCubicBezier )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 controlPoint1,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 controlPoint2,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 endPoint
        );
    /* [overload, default_overload] */HRESULT ( STDMETHODCALLTYPE *AddLine )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 endPoint
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *AddLineWithCoords )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
        /* [in] */FLOAT x,
        /* [in] */FLOAT y
        );
    HRESULT ( STDMETHODCALLTYPE *AddQuadraticBezier )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 controlPoint,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 endPoint
        );
    HRESULT ( STDMETHODCALLTYPE *SetFilledRegionDetermination )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFilledRegionDetermination filledRegionDetermination
        );
    HRESULT ( STDMETHODCALLTYPE *SetSegmentOptions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFigureSegmentOptions figureSegmentOptions
        );
    HRESULT ( STDMETHODCALLTYPE *EndFigure )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFigureLoop figureLoop
        );
    HRESULT ( STDMETHODCALLTYPE *AddGeometry )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasGeometry * geometry
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_BeginFigureWithFigureFill(This,startPoint,figureFill) \
    ( (This)->lpVtbl->BeginFigureWithFigureFill(This,startPoint,figureFill) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_BeginFigure(This,startPoint) \
    ( (This)->lpVtbl->BeginFigure(This,startPoint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_BeginFigureAtCoordsWithFigureFill(This,startX,startY,figureFill) \
    ( (This)->lpVtbl->BeginFigureAtCoordsWithFigureFill(This,startX,startY,figureFill) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_BeginFigureAtCoords(This,startX,startY) \
    ( (This)->lpVtbl->BeginFigureAtCoords(This,startX,startY) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_AddArcToPoint(This,endPoint,radiusX,radiusY,rotationAngle,sweepDirection,arcSize) \
    ( (This)->lpVtbl->AddArcToPoint(This,endPoint,radiusX,radiusY,rotationAngle,sweepDirection,arcSize) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_AddArcAroundEllipse(This,centerPoint,radiusX,radiusY,startAngle,sweepAngle) \
    ( (This)->lpVtbl->AddArcAroundEllipse(This,centerPoint,radiusX,radiusY,startAngle,sweepAngle) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_AddCubicBezier(This,controlPoint1,controlPoint2,endPoint) \
    ( (This)->lpVtbl->AddCubicBezier(This,controlPoint1,controlPoint2,endPoint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_AddLine(This,endPoint) \
    ( (This)->lpVtbl->AddLine(This,endPoint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_AddLineWithCoords(This,x,y) \
    ( (This)->lpVtbl->AddLineWithCoords(This,x,y) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_AddQuadraticBezier(This,controlPoint,endPoint) \
    ( (This)->lpVtbl->AddQuadraticBezier(This,controlPoint,endPoint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_SetFilledRegionDetermination(This,filledRegionDetermination) \
    ( (This)->lpVtbl->SetFilledRegionDetermination(This,filledRegionDetermination) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_SetSegmentOptions(This,figureSegmentOptions) \
    ( (This)->lpVtbl->SetSegmentOptions(This,figureSegmentOptions) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_EndFigure(This,figureLoop) \
    ( (This)->lpVtbl->EndFigure(This,figureLoop) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_AddGeometry(This,geometry) \
    ( (This)->lpVtbl->AddGeometry(This,geometry) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasPathBuilderFactory
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasPathBuilder
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasPathBuilderFactory[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasPathBuilderFactory";
/* [object, version, uuid("AC2BEE14-EFD1-4343-8E53-BA62153D8966"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactoryVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *Create )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CICanvasResourceCreator * resourceCreator,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilder * * canvasPathBuilder
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactoryVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactoryVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_Create(This,resourceCreator,canvasPathBuilder) \
    ( (This)->lpVtbl->Create(This,resourceCreator,canvasPathBuilder) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathBuilderFactory_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasPathReceiver
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasPathReceiver[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasPathReceiver";
/* [object, version, uuid("70E65373-7FB3-4645-8B6D-F616D1B9A9D7")] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiverVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *BeginFigure )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 startPoint,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFigureFill figureFill
        );
    HRESULT ( STDMETHODCALLTYPE *AddArc )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 endPoint,
        /* [in] */FLOAT radiusX,
        /* [in] */FLOAT radiusY,
        /* [in] */FLOAT rotationAngle,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasSweepDirection sweepDirection,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasArcSize arcSize
        );
    HRESULT ( STDMETHODCALLTYPE *AddCubicBezier )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 controlPoint1,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 controlPoint2,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 endPoint
        );
    HRESULT ( STDMETHODCALLTYPE *AddLine )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 endPoint
        );
    HRESULT ( STDMETHODCALLTYPE *AddQuadraticBezier )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver * This,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 controlPoint,
        /* [in] */__x_ABI_CWindows_CFoundation_CNumerics_CVector2 endPoint
        );
    HRESULT ( STDMETHODCALLTYPE *SetFilledRegionDetermination )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFilledRegionDetermination filledRegionDetermination
        );
    HRESULT ( STDMETHODCALLTYPE *SetSegmentOptions )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFigureSegmentOptions figureSegmentOptions
        );
    HRESULT ( STDMETHODCALLTYPE *EndFigure )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasFigureLoop figureLoop
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiverVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiverVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_BeginFigure(This,startPoint,figureFill) \
    ( (This)->lpVtbl->BeginFigure(This,startPoint,figureFill) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_AddArc(This,endPoint,radiusX,radiusY,rotationAngle,sweepDirection,arcSize) \
    ( (This)->lpVtbl->AddArc(This,endPoint,radiusX,radiusY,rotationAngle,sweepDirection,arcSize) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_AddCubicBezier(This,controlPoint1,controlPoint2,endPoint) \
    ( (This)->lpVtbl->AddCubicBezier(This,controlPoint1,controlPoint2,endPoint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_AddLine(This,endPoint) \
    ( (This)->lpVtbl->AddLine(This,endPoint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_AddQuadraticBezier(This,controlPoint,endPoint) \
    ( (This)->lpVtbl->AddQuadraticBezier(This,controlPoint,endPoint) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_SetFilledRegionDetermination(This,filledRegionDetermination) \
    ( (This)->lpVtbl->SetFilledRegionDetermination(This,filledRegionDetermination) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_SetSegmentOptions(This,figureSegmentOptions) \
    ( (This)->lpVtbl->SetSegmentOptions(This,figureSegmentOptions) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_EndFigure(This,figureLoop) \
    ( (This)->lpVtbl->EndFigure(This,figureLoop) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasPathReceiver_INTERFACE_DEFINED__) */


/*
 *
 * Interface Microsoft.Graphics.Canvas.Geometry.ICanvasStrokeStyle
 *
 * Interface is a part of the implementation of type Microsoft.Graphics.Canvas.Geometry.CanvasStrokeStyle
 *
 *
 * Any object which implements this interface must also implement the following interfaces:
 *     Windows.Foundation.IClosable
 *
 *
 */
#if !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Graphics_Canvas_Geometry_ICanvasStrokeStyle[] = L"Microsoft.Graphics.Canvas.Geometry.ICanvasStrokeStyle";
/* [object, version, uuid("FD3E1CD2-6019-40A1-B315-267EEF6C2AEB"), exclusiveto] */
typedef struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyleVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
/* [propget] */HRESULT ( STDMETHODCALLTYPE *get_StartCap )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasCapStyle * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_StartCap )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasCapStyle value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_EndCap )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasCapStyle * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_EndCap )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasCapStyle value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_DashCap )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasCapStyle * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_DashCap )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasCapStyle value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_LineJoin )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasLineJoin * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_LineJoin )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasLineJoin value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_MiterLimit )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_MiterLimit )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [in] */FLOAT value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_DashStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasDashStyle * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_DashStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasDashStyle value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_DashOffset )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [retval, out] */FLOAT * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_DashOffset )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [in] */FLOAT value
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_CustomDashStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [out] */UINT32 * __valueElementsSize,
        /* [size_is(, *(__valueElementsSize)), retval, out] */FLOAT * * valueElements
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_CustomDashStyle )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [in] */UINT32 __valueElementsSize,
        /* [size_is(__valueElementsSize), in] */FLOAT * valueElements
        );
    /* [propget] */HRESULT ( STDMETHODCALLTYPE *get_TransformBehavior )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasStrokeTransformBehavior * value
        );
    /* [propput] */HRESULT ( STDMETHODCALLTYPE *put_TransformBehavior )(
        __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle * This,
        /* [in] */__x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CCanvasStrokeTransformBehavior value
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyleVtbl;

interface __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyleVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_get_StartCap(This,value) \
    ( (This)->lpVtbl->get_StartCap(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_put_StartCap(This,value) \
    ( (This)->lpVtbl->put_StartCap(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_get_EndCap(This,value) \
    ( (This)->lpVtbl->get_EndCap(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_put_EndCap(This,value) \
    ( (This)->lpVtbl->put_EndCap(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_get_DashCap(This,value) \
    ( (This)->lpVtbl->get_DashCap(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_put_DashCap(This,value) \
    ( (This)->lpVtbl->put_DashCap(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_get_LineJoin(This,value) \
    ( (This)->lpVtbl->get_LineJoin(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_put_LineJoin(This,value) \
    ( (This)->lpVtbl->put_LineJoin(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_get_MiterLimit(This,value) \
    ( (This)->lpVtbl->get_MiterLimit(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_put_MiterLimit(This,value) \
    ( (This)->lpVtbl->put_MiterLimit(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_get_DashStyle(This,value) \
    ( (This)->lpVtbl->get_DashStyle(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_put_DashStyle(This,value) \
    ( (This)->lpVtbl->put_DashStyle(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_get_DashOffset(This,value) \
    ( (This)->lpVtbl->get_DashOffset(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_put_DashOffset(This,value) \
    ( (This)->lpVtbl->put_DashOffset(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_get_CustomDashStyle(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->get_CustomDashStyle(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_put_CustomDashStyle(This,__valueElementsSize,valueElements) \
    ( (This)->lpVtbl->put_CustomDashStyle(This,__valueElementsSize,valueElements) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_get_TransformBehavior(This,value) \
    ( (This)->lpVtbl->get_TransformBehavior(This,value) )

#define __x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_put_TransformBehavior(This,value) \
    ( (This)->lpVtbl->put_TransformBehavior(This,value) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle;
#endif /* !defined(____x_ABI_CMicrosoft_CGraphics_CCanvas_CGeometry_CICanvasStrokeStyle_INTERFACE_DEFINED__) */


/*
 *
 * Class Microsoft.Graphics.Canvas.Geometry.CanvasCachedGeometry
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Geometry.ICanvasCachedGeometry ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasCachedGeometry_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasCachedGeometry_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Geometry_CanvasCachedGeometry[] = L"Microsoft.Graphics.Canvas.Geometry.CanvasCachedGeometry";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Geometry.CanvasGeometry
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Geometry.ICanvasGeometry ** Default Interface **
 *    Windows.Foundation.IClosable
 *    Windows.Graphics.IGeometrySource2D
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasGeometry_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasGeometry_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Geometry_CanvasGeometry[] = L"Microsoft.Graphics.Canvas.Geometry.CanvasGeometry";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Geometry.CanvasGradientMesh
 *
 * RuntimeClass can be activated.
 *
 * RuntimeClass contains static methods.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Geometry.ICanvasGradientMesh ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasGradientMesh_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasGradientMesh_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Geometry_CanvasGradientMesh[] = L"Microsoft.Graphics.Canvas.Geometry.CanvasGradientMesh";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Geometry.CanvasPathBuilder
 *
 * RuntimeClass can be activated.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Geometry.ICanvasPathBuilder ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasPathBuilder_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasPathBuilder_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Geometry_CanvasPathBuilder[] = L"Microsoft.Graphics.Canvas.Geometry.CanvasPathBuilder";
#endif


/*
 *
 * Class Microsoft.Graphics.Canvas.Geometry.CanvasStrokeStyle
 *
 * RuntimeClass can be activated.
 *
 * Class implements the following interfaces:
 *    Microsoft.Graphics.Canvas.Geometry.ICanvasStrokeStyle ** Default Interface **
 *    Windows.Foundation.IClosable
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */

#ifndef RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasStrokeStyle_DEFINED
#define RUNTIMECLASS_Microsoft_Graphics_Canvas_Geometry_CanvasStrokeStyle_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Graphics_Canvas_Geometry_CanvasStrokeStyle[] = L"Microsoft.Graphics.Canvas.Geometry.CanvasStrokeStyle";
#endif





#endif // defined(__cplusplus)
#pragma pop_macro("MIDL_CONST_ID")
// Restore the original value of the 'DEPRECATED' macro
#pragma pop_macro("DEPRECATED")

#ifdef __clang__
#pragma clang diagnostic pop // deprecated-declarations
#else
#pragma warning(pop)
#endif
#endif // __microsoft2Egraphics2Ecanvas2Egeometry_p_h__

#endif // __microsoft2Egraphics2Ecanvas2Egeometry_h__
