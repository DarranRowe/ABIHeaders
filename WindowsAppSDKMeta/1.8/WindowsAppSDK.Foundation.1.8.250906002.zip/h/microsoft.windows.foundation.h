
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

/* verify that the <rpcsal.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCSAL_H_VERSION__
#define __REQUIRED_RPCSAL_H_VERSION__ 100
#endif

#include <rpc.h>
#include <rpcndr.h>

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include <windows.h>
#include <ole2.h>
#endif /*COM_NO_WINDOWS_H*/
#ifndef __microsoft2Ewindows2Efoundation_h__
#define __microsoft2Ewindows2Efoundation_h__
#ifndef __microsoft2Ewindows2Efoundation_p_h__
#define __microsoft2Ewindows2Efoundation_p_h__


#pragma once

//
// Deprecated attribute support
//

#pragma push_macro("DEPRECATED")
#undef DEPRECATED

#if !defined(DISABLE_WINRT_DEPRECATION)
#if defined(__cplusplus)
#if __cplusplus >= 201402
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#elif defined(_MSC_VER)
#if _MSC_VER >= 1900
#define DEPRECATED(x) [[deprecated(x)]]
#define DEPRECATEDENUMERATOR(x) [[deprecated(x)]]
#else
#define DEPRECATED(x) __declspec(deprecated(x))
#define DEPRECATEDENUMERATOR(x)
#endif // _MSC_VER >= 1900
#else // Not Standard C++ or MSVC, ignore the construct.
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  // C++ deprecation
#else // C - disable deprecation
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif
#else // Deprecation is disabled
#define DEPRECATED(x)
#define DEPRECATEDENUMERATOR(x)
#endif  /* DEPRECATED */

// Disable Deprecation for this header, MIDL verifies that cross-type access is acceptable
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#else
#pragma warning(push)
#pragma warning(disable: 4996)
#endif

// Ensure that the setting of the /ns_prefix command line switch is consistent for all headers.
// If you get an error from the compiler indicating "warning C4005: 'CHECK_NS_PREFIX_STATE': macro redefinition", this
// indicates that you have included two different headers with different settings for the /ns_prefix MIDL command line switch
#if !defined(DISABLE_NS_PREFIX_CHECKS)
#define CHECK_NS_PREFIX_STATE "always"
#endif // !defined(DISABLE_NS_PREFIX_CHECKS)


#pragma push_macro("MIDL_CONST_ID")
#undef MIDL_CONST_ID
#define MIDL_CONST_ID const __declspec(selectany)


//  API Contract Inclusion Definitions
#if !defined(SPECIFIC_API_CONTRACT_DEFINITIONS)
#if !defined(MICROSOFT_WINDOWS_FOUNDATION_DECIMALCONTRACT_VERSION)
#define MICROSOFT_WINDOWS_FOUNDATION_DECIMALCONTRACT_VERSION 0x10000
#endif // defined(MICROSOFT_WINDOWS_FOUNDATION_DECIMALCONTRACT_VERSION)

#if !defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)
#define WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION 0x70000
#endif // defined(WINDOWS_APPLICATIONMODEL_CALLS_CALLSPHONECONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)
#define WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION 0x40000
#endif // defined(WINDOWS_FOUNDATION_FOUNDATIONCONTRACT_VERSION)

#if !defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)
#define WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION 0x130000
#endif // defined(WINDOWS_FOUNDATION_UNIVERSALAPICONTRACT_VERSION)

#if !defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)
#define WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION 0x30000
#endif // defined(WINDOWS_NETWORKING_SOCKETS_CONTROLCHANNELTRIGGERCONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)
#define WINDOWS_PHONE_PHONECONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONECONTRACT_VERSION)

#if !defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)
#define WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_PHONE_PHONEINTERNALCONTRACT_VERSION)

#if !defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)
#define WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION 0x10000
#endif // defined(WINDOWS_UI_WEBUI_CORE_WEBUICOMMANDBARCONTRACT_VERSION)

#endif // defined(SPECIFIC_API_CONTRACT_DEFINITIONS)


// Header files for imported files
#include "inspectable.h"
#include "AsyncInfo.h"
#include "EventToken.h"
#include "windowscontracts.h"
#include "Windows.Foundation.h"

#if defined(__cplusplus) && !defined(CINTERFACE)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FWD_DEFINED__
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Foundation {
                interface IDecimalHelperStatics;
            } /* Foundation */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics ABI::Microsoft::Windows::Foundation::IDecimalHelperStatics

#endif // ____x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FWD_DEFINED__



namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Foundation {
                
                typedef struct DecimalValue DecimalValue;
                
            } /* Foundation */
        } /* Windows */
    } /* Microsoft */
} /* ABI */








/*
 *
 * Struct Microsoft.Windows.Foundation.DecimalValue
 *
 * Introduced to Microsoft.Windows.Foundation.DecimalContract in version 1.0
 *
 *
 */
#if MICROSOFT_WINDOWS_FOUNDATION_DECIMALCONTRACT_VERSION >= 0x10000

namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Foundation {
                /* [contract] */
                struct DecimalValue
                {
                    UINT16 Reserved;
                    BYTE Scale;
                    BYTE Sign;
                    UINT32 Hi32;
                    UINT64 Lo64;
                };
                
            } /* Foundation */
        } /* Windows */
    } /* Microsoft */
} /* ABI */
#endif // MICROSOFT_WINDOWS_FOUNDATION_DECIMALCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Foundation.IDecimalHelperStatics
 *
 * Introduced to Microsoft.Windows.Foundation.DecimalContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Foundation.DecimalHelper
 *
 *
 */
#if MICROSOFT_WINDOWS_FOUNDATION_DECIMALCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Foundation_IDecimalHelperStatics[] = L"Microsoft.Windows.Foundation.IDecimalHelperStatics";
namespace ABI {
    namespace Microsoft {
        namespace Windows {
            namespace Foundation {
                /* [object, uuid("BA09A415-E26C-55B3-9B76-B3AFFD556A7F"), exclusiveto, contract] */
                MIDL_INTERFACE("BA09A415-E26C-55B3-9B76-B3AFFD556A7F")
                IDecimalHelperStatics : public IInspectable
                {
                public:
                    virtual HRESULT STDMETHODCALLTYPE FromBoolean(
                        /* [in] */::boolean value,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE FromInt16(
                        /* [in] */INT16 value,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE FromInt32(
                        /* [in] */INT32 value,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE FromInt64(
                        /* [in] */INT64 value,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE FromUInt8(
                        /* [in] */BYTE value,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE FromUInt16(
                        /* [in] */UINT16 value,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE FromUInt32(
                        /* [in] */UINT32 value,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE FromUInt64(
                        /* [in] */UINT64 value,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE FromSingle(
                        /* [in] */FLOAT value,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE FromDouble(
                        /* [in] */DOUBLE value,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FromString(
                        /* [in] */HSTRING source,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE FromStringInvariant(
                        /* [in] */HSTRING source,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE FromStringWithLocale(
                        /* [in] */HSTRING source,
                        /* [in] */HSTRING localeName,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE TryFromString(
                        /* [in] */HSTRING source,
                        /* [out] */ABI::Microsoft::Windows::Foundation::DecimalValue * value,
                        /* [retval, out] */::boolean * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE TryFromStringInvariant(
                        /* [in] */HSTRING source,
                        /* [out] */ABI::Microsoft::Windows::Foundation::DecimalValue * value,
                        /* [retval, out] */::boolean * result
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE TryFromStringWithLocale(
                        /* [in] */HSTRING source,
                        /* [in] */HSTRING localeName,
                        /* [out] */ABI::Microsoft::Windows::Foundation::DecimalValue * value,
                        /* [retval, out] */::boolean * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE ToBoolean(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */::boolean * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE ToInt16(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */INT16 * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE ToInt32(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */INT32 * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE ToInt64(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */INT64 * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE ToUInt8(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */BYTE * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE ToUInt16(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */UINT16 * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE ToUInt32(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */UINT32 * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE ToUInt64(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */UINT64 * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE ToSingle(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */FLOAT * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE ToDouble(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */DOUBLE * result
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE ToString(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */HSTRING * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE ToStringInvariant(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */HSTRING * result
                        ) = 0;
                    /* [overload] */virtual HRESULT STDMETHODCALLTYPE ToStringWithLocale(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [in] */HSTRING localeName,
                        /* [retval, out] */HSTRING * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Equals(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue left,
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue right,
                        /* [retval, out] */::boolean * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Compare(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue left,
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue right,
                        /* [retval, out] */INT32 * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE IsValid(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */::boolean * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE IsInteger(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */::boolean * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Scale(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */BYTE * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Sign(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */INT32 * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE MaxScale(
                        /* [retval, out] */BYTE * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE MaxValue(
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE MinValue(
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Negate(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Abs(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Truncate(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Floor(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Ceiling(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Round(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [in] */INT32 decimalPlaces,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Clamp(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue value,
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue min,
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue max,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Add(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue left,
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue right,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Subtract(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue left,
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue right,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Multiply(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue left,
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue right,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Divide(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue left,
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue right,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    virtual HRESULT STDMETHODCALLTYPE Modulo(
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue left,
                        /* [in] */ABI::Microsoft::Windows::Foundation::DecimalValue right,
                        /* [retval, out] */ABI::Microsoft::Windows::Foundation::DecimalValue * result
                        ) = 0;
                    
                };

                MIDL_CONST_ID IID & IID_IDecimalHelperStatics=__uuidof(IDecimalHelperStatics);
                
            } /* Foundation */
        } /* Windows */
    } /* Microsoft */
} /* ABI */

EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_FOUNDATION_DECIMALCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.Foundation.DecimalHelper
 *
 * Introduced to Microsoft.Windows.Foundation.DecimalContract in version 1.0
 *
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.Foundation.IDecimalHelperStatics interface starting with version 1.0 of the Microsoft.Windows.Foundation.DecimalContract API contract
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_FOUNDATION_DECIMALCONTRACT_VERSION >= 0x10000
#ifndef RUNTIMECLASS_Microsoft_Windows_Foundation_DecimalHelper_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Foundation_DecimalHelper_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Foundation_DecimalHelper[] = L"Microsoft.Windows.Foundation.DecimalHelper";
#endif
#endif // MICROSOFT_WINDOWS_FOUNDATION_DECIMALCONTRACT_VERSION >= 0x10000




#else // !defined(__cplusplus)
/* Forward Declarations */
#ifndef ____x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FWD_DEFINED__
#define ____x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FWD_DEFINED__
typedef interface __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics;

#endif // ____x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FWD_DEFINED__



typedef struct __x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue __x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue;








/*
 *
 * Struct Microsoft.Windows.Foundation.DecimalValue
 *
 * Introduced to Microsoft.Windows.Foundation.DecimalContract in version 1.0
 *
 *
 */
#if MICROSOFT_WINDOWS_FOUNDATION_DECIMALCONTRACT_VERSION >= 0x10000

/* [contract] */
struct __x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue
{
    UINT16 Reserved;
    BYTE Scale;
    BYTE Sign;
    UINT32 Hi32;
    UINT64 Lo64;
};
#endif // MICROSOFT_WINDOWS_FOUNDATION_DECIMALCONTRACT_VERSION >= 0x10000


/*
 *
 * Interface Microsoft.Windows.Foundation.IDecimalHelperStatics
 *
 * Introduced to Microsoft.Windows.Foundation.DecimalContract in version 1.0
 *
 *
 * Interface is a part of the implementation of type Microsoft.Windows.Foundation.DecimalHelper
 *
 *
 */
#if MICROSOFT_WINDOWS_FOUNDATION_DECIMALCONTRACT_VERSION >= 0x10000
#if !defined(____x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_INTERFACE_DEFINED__)
#define ____x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_INTERFACE_DEFINED__
extern const __declspec(selectany) _Null_terminated_ WCHAR InterfaceName_Microsoft_Windows_Foundation_IDecimalHelperStatics[] = L"Microsoft.Windows.Foundation.IDecimalHelperStatics";
/* [object, uuid("BA09A415-E26C-55B3-9B76-B3AFFD556A7F"), exclusiveto, contract] */
typedef struct __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStaticsVtbl
{
    BEGIN_INTERFACE
    HRESULT ( STDMETHODCALLTYPE *QueryInterface)(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
    /* [in] */ __RPC__in REFIID riid,
    /* [annotation][iid_is][out] */
    _COM_Outptr_  void **ppvObject
    );

ULONG ( STDMETHODCALLTYPE *AddRef )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This
    );

ULONG ( STDMETHODCALLTYPE *Release )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This
    );

HRESULT ( STDMETHODCALLTYPE *GetIids )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
    /* [out] */ __RPC__out ULONG *iidCount,
    /* [size_is][size_is][out] */ __RPC__deref_out_ecount_full_opt(*iidCount) IID **iids
    );

HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
    /* [out] */ __RPC__deref_out_opt HSTRING *className
    );

HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )(
    __RPC__in __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
    /* [OUT ] */ __RPC__out TrustLevel *trustLevel
    );
HRESULT ( STDMETHODCALLTYPE *FromBoolean )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */boolean value,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *FromInt16 )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */INT16 value,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *FromInt32 )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */INT32 value,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *FromInt64 )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */INT64 value,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *FromUInt8 )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */BYTE value,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *FromUInt16 )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */UINT16 value,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *FromUInt32 )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */UINT32 value,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *FromUInt64 )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */UINT64 value,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *FromSingle )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */FLOAT value,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *FromDouble )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */DOUBLE value,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FromString )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */HSTRING source,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *FromStringInvariant )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */HSTRING source,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *FromStringWithLocale )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */HSTRING source,
        /* [in] */HSTRING localeName,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *TryFromString )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */HSTRING source,
        /* [out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * value,
        /* [retval, out] */boolean * result
        );
    HRESULT ( STDMETHODCALLTYPE *TryFromStringInvariant )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */HSTRING source,
        /* [out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * value,
        /* [retval, out] */boolean * result
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *TryFromStringWithLocale )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */HSTRING source,
        /* [in] */HSTRING localeName,
        /* [out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * value,
        /* [retval, out] */boolean * result
        );
    HRESULT ( STDMETHODCALLTYPE *ToBoolean )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */boolean * result
        );
    HRESULT ( STDMETHODCALLTYPE *ToInt16 )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */INT16 * result
        );
    HRESULT ( STDMETHODCALLTYPE *ToInt32 )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */INT32 * result
        );
    HRESULT ( STDMETHODCALLTYPE *ToInt64 )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */INT64 * result
        );
    HRESULT ( STDMETHODCALLTYPE *ToUInt8 )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */BYTE * result
        );
    HRESULT ( STDMETHODCALLTYPE *ToUInt16 )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */UINT16 * result
        );
    HRESULT ( STDMETHODCALLTYPE *ToUInt32 )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */UINT32 * result
        );
    HRESULT ( STDMETHODCALLTYPE *ToUInt64 )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */UINT64 * result
        );
    HRESULT ( STDMETHODCALLTYPE *ToSingle )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */FLOAT * result
        );
    HRESULT ( STDMETHODCALLTYPE *ToDouble )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */DOUBLE * result
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *ToString )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */HSTRING * result
        );
    HRESULT ( STDMETHODCALLTYPE *ToStringInvariant )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */HSTRING * result
        );
    /* [overload] */HRESULT ( STDMETHODCALLTYPE *ToStringWithLocale )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [in] */HSTRING localeName,
        /* [retval, out] */HSTRING * result
        );
    HRESULT ( STDMETHODCALLTYPE *Equals )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue left,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue right,
        /* [retval, out] */boolean * result
        );
    HRESULT ( STDMETHODCALLTYPE *Compare )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue left,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue right,
        /* [retval, out] */INT32 * result
        );
    HRESULT ( STDMETHODCALLTYPE *IsValid )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */boolean * result
        );
    HRESULT ( STDMETHODCALLTYPE *IsInteger )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */boolean * result
        );
    HRESULT ( STDMETHODCALLTYPE *Scale )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */BYTE * result
        );
    HRESULT ( STDMETHODCALLTYPE *Sign )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */INT32 * result
        );
    HRESULT ( STDMETHODCALLTYPE *MaxScale )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [retval, out] */BYTE * result
        );
    HRESULT ( STDMETHODCALLTYPE *MaxValue )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *MinValue )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *Negate )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *Abs )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *Truncate )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *Floor )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *Ceiling )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *Round )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [in] */INT32 decimalPlaces,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *Clamp )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue value,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue min,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue max,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *Add )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue left,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue right,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *Subtract )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue left,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue right,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *Multiply )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue left,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue right,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *Divide )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue left,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue right,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    HRESULT ( STDMETHODCALLTYPE *Modulo )(
        __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics * This,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue left,
        /* [in] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue right,
        /* [retval, out] */__x_ABI_CMicrosoft_CWindows_CFoundation_CDecimalValue * result
        );
    END_INTERFACE
    
} __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStaticsVtbl;

interface __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics
{
    CONST_VTBL struct __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStaticsVtbl *lpVtbl;
};

#ifdef COBJMACROS
#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_QueryInterface(This,riid,ppvObject) \
( (This)->lpVtbl->QueryInterface(This,riid,ppvObject) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_AddRef(This) \
        ( (This)->lpVtbl->AddRef(This) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_Release(This) \
        ( (This)->lpVtbl->Release(This) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_GetIids(This,iidCount,iids) \
        ( (This)->lpVtbl->GetIids(This,iidCount,iids) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_GetRuntimeClassName(This,className) \
        ( (This)->lpVtbl->GetRuntimeClassName(This,className) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_GetTrustLevel(This,trustLevel) \
        ( (This)->lpVtbl->GetTrustLevel(This,trustLevel) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FromBoolean(This,value,result) \
    ( (This)->lpVtbl->FromBoolean(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FromInt16(This,value,result) \
    ( (This)->lpVtbl->FromInt16(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FromInt32(This,value,result) \
    ( (This)->lpVtbl->FromInt32(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FromInt64(This,value,result) \
    ( (This)->lpVtbl->FromInt64(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FromUInt8(This,value,result) \
    ( (This)->lpVtbl->FromUInt8(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FromUInt16(This,value,result) \
    ( (This)->lpVtbl->FromUInt16(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FromUInt32(This,value,result) \
    ( (This)->lpVtbl->FromUInt32(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FromUInt64(This,value,result) \
    ( (This)->lpVtbl->FromUInt64(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FromSingle(This,value,result) \
    ( (This)->lpVtbl->FromSingle(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FromDouble(This,value,result) \
    ( (This)->lpVtbl->FromDouble(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FromString(This,source,result) \
    ( (This)->lpVtbl->FromString(This,source,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FromStringInvariant(This,source,result) \
    ( (This)->lpVtbl->FromStringInvariant(This,source,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_FromStringWithLocale(This,source,localeName,result) \
    ( (This)->lpVtbl->FromStringWithLocale(This,source,localeName,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_TryFromString(This,source,value,result) \
    ( (This)->lpVtbl->TryFromString(This,source,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_TryFromStringInvariant(This,source,value,result) \
    ( (This)->lpVtbl->TryFromStringInvariant(This,source,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_TryFromStringWithLocale(This,source,localeName,value,result) \
    ( (This)->lpVtbl->TryFromStringWithLocale(This,source,localeName,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_ToBoolean(This,value,result) \
    ( (This)->lpVtbl->ToBoolean(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_ToInt16(This,value,result) \
    ( (This)->lpVtbl->ToInt16(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_ToInt32(This,value,result) \
    ( (This)->lpVtbl->ToInt32(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_ToInt64(This,value,result) \
    ( (This)->lpVtbl->ToInt64(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_ToUInt8(This,value,result) \
    ( (This)->lpVtbl->ToUInt8(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_ToUInt16(This,value,result) \
    ( (This)->lpVtbl->ToUInt16(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_ToUInt32(This,value,result) \
    ( (This)->lpVtbl->ToUInt32(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_ToUInt64(This,value,result) \
    ( (This)->lpVtbl->ToUInt64(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_ToSingle(This,value,result) \
    ( (This)->lpVtbl->ToSingle(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_ToDouble(This,value,result) \
    ( (This)->lpVtbl->ToDouble(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_ToString(This,value,result) \
    ( (This)->lpVtbl->ToString(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_ToStringInvariant(This,value,result) \
    ( (This)->lpVtbl->ToStringInvariant(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_ToStringWithLocale(This,value,localeName,result) \
    ( (This)->lpVtbl->ToStringWithLocale(This,value,localeName,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_Equals(This,left,right,result) \
    ( (This)->lpVtbl->Equals(This,left,right,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_Compare(This,left,right,result) \
    ( (This)->lpVtbl->Compare(This,left,right,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_IsValid(This,value,result) \
    ( (This)->lpVtbl->IsValid(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_IsInteger(This,value,result) \
    ( (This)->lpVtbl->IsInteger(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_Scale(This,value,result) \
    ( (This)->lpVtbl->Scale(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_Sign(This,value,result) \
    ( (This)->lpVtbl->Sign(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_MaxScale(This,result) \
    ( (This)->lpVtbl->MaxScale(This,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_MaxValue(This,result) \
    ( (This)->lpVtbl->MaxValue(This,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_MinValue(This,result) \
    ( (This)->lpVtbl->MinValue(This,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_Negate(This,value,result) \
    ( (This)->lpVtbl->Negate(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_Abs(This,value,result) \
    ( (This)->lpVtbl->Abs(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_Truncate(This,value,result) \
    ( (This)->lpVtbl->Truncate(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_Floor(This,value,result) \
    ( (This)->lpVtbl->Floor(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_Ceiling(This,value,result) \
    ( (This)->lpVtbl->Ceiling(This,value,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_Round(This,value,decimalPlaces,result) \
    ( (This)->lpVtbl->Round(This,value,decimalPlaces,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_Clamp(This,value,min,max,result) \
    ( (This)->lpVtbl->Clamp(This,value,min,max,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_Add(This,left,right,result) \
    ( (This)->lpVtbl->Add(This,left,right,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_Subtract(This,left,right,result) \
    ( (This)->lpVtbl->Subtract(This,left,right,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_Multiply(This,left,right,result) \
    ( (This)->lpVtbl->Multiply(This,left,right,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_Divide(This,left,right,result) \
    ( (This)->lpVtbl->Divide(This,left,right,result) )

#define __x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_Modulo(This,left,right,result) \
    ( (This)->lpVtbl->Modulo(This,left,right,result) )


#endif /* COBJMACROS */


EXTERN_C const IID IID___x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics;
#endif /* !defined(____x_ABI_CMicrosoft_CWindows_CFoundation_CIDecimalHelperStatics_INTERFACE_DEFINED__) */
#endif // MICROSOFT_WINDOWS_FOUNDATION_DECIMALCONTRACT_VERSION >= 0x10000


/*
 *
 * Class Microsoft.Windows.Foundation.DecimalHelper
 *
 * Introduced to Microsoft.Windows.Foundation.DecimalContract in version 1.0
 *
 *
 * RuntimeClass contains static methods.
 *   Static Methods exist on the Microsoft.Windows.Foundation.IDecimalHelperStatics interface starting with version 1.0 of the Microsoft.Windows.Foundation.DecimalContract API contract
 *
 * Class Threading Model:  Both Single and Multi Threaded Apartment
 *
 * Class Marshaling Behavior:  Agile - Class is agile
 *
 */
#if MICROSOFT_WINDOWS_FOUNDATION_DECIMALCONTRACT_VERSION >= 0x10000
#ifndef RUNTIMECLASS_Microsoft_Windows_Foundation_DecimalHelper_DEFINED
#define RUNTIMECLASS_Microsoft_Windows_Foundation_DecimalHelper_DEFINED
extern const __declspec(selectany) _Null_terminated_ WCHAR RuntimeClass_Microsoft_Windows_Foundation_DecimalHelper[] = L"Microsoft.Windows.Foundation.DecimalHelper";
#endif
#endif // MICROSOFT_WINDOWS_FOUNDATION_DECIMALCONTRACT_VERSION >= 0x10000




#endif // defined(__cplusplus)
#pragma pop_macro("MIDL_CONST_ID")
// Restore the original value of the 'DEPRECATED' macro
#pragma pop_macro("DEPRECATED")

#ifdef __clang__
#pragma clang diagnostic pop // deprecated-declarations
#else
#pragma warning(pop)
#endif
#endif // __microsoft2Ewindows2Efoundation_p_h__

#endif // __microsoft2Ewindows2Efoundation_h__
